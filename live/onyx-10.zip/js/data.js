/* Onyx Vanguard — data.js
   Game data: skill cards, tags/synergies, gear, sets, capes, training, enemies, acts, challenges.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   DATA: TAGS, CARDS
===================================================================== */
const TAGS = {
  blade:{name:"Blade", color:"#dfe6f2", icon:"edge", s2:"+10% attack speed", s3:"Critical hits deal +50% damage", a3:"Critical hits heal 2% of your max HP"},
  bleed:{name:"Bleed", color:"#ff5a64", icon:"serrated", s2:"Bleed deals +40% damage", s3:"Bleeding enemies take +20% damage", a3:"When a bleeding enemy dies, its Bleed jumps to the next enemy"},
  fire:{name:"Fire", color:"#ff8a2a", icon:"ember", s2:"Burn deals +50% damage", s3:"Fireball cooldown halved", a3:"Burning enemies deal 20% less damage"},
  holy:{name:"Holy", color:"#ffe07a", icon:"light", s2:"All healing +25%", s3:"Once per battle, survive a killing blow at 30% HP", a3:"Half of all healing also becomes a barrier, up to 20% of your max HP"},
  shield:{name:"Shield", color:"#5aa0ff", icon:"ironskin", s2:"+10 Armor and +8% Block", s3:"Blocks heal 2% HP, Thorns doubled", a3:"Blocks stun the attacker for 1s"},
  storm:{name:"Storm", color:"#7ee0ff", icon:"chain", s2:"Storm cooldowns -25%", s3:"Lightning hits 2 extra enemies", a3:"Lightning deals +35% damage"},
  core:{name:"Core", color:"#b8abd4", icon:"keen"},          // Core skills join the skill type you hold most (coreBind in engine.js)
  legend:{name:"Legendary", color:"#ffb347", icon:"crown"}
};
/* Every synergy also pays in raw power, so a focused build is worth about as much as an act of gear.
   2 cards of a tag: SYN_PAY[2]; 3 cards: SYN_PAY[3] on top. Building from two tags or fewer adds FOCUS_DMG ("Focused Oath"). */
const SYN_PAY = {2:{dmg:25, hp:10}, 3:{dmg:60, hp:25}}, FOCUS_DMG = 20;
const synPay = n => `+${SYN_PAY[n].dmg}% damage, +${SYN_PAY[n].hp}% max HP`;
/* a tag's synergy III has a second form, unlocked by tag mastery and chosen in the Skills tab (synAlt in items.js) */
const syn3 = t => synAlt(t) ? TAGS[t].a3 : TAGS[t].s3;
const synLine = (t, n) => `${n===2 ? TAGS[t].s2 : syn3(t)} · ${synPay(n)}`;
const SYN_TAGS = ["blade","bleed","fire","holy","shield","storm"];
const CARDS = [
  {id:"edge",tag:"blade",icon:"edge",name:"Honed Edge",v:(r,m)=>Math.round(15*r*m),text:v=>`+${v}% damage`},
  {id:"twin",tag:"blade",icon:"twin",name:"Twin Strike",v:(r,m)=>Math.round(13*r*m),text:v=>`${v}% chance to strike twice`},
  {id:"execute",tag:"blade",icon:"execute",name:"Executioner",v:(r,m)=>Math.round(40*r*m),text:v=>`+${v}% damage to enemies below 35% HP`},
  {id:"cleave",tag:"blade",icon:"cleave",name:"Cleave",v:(r,m)=>Math.round((30+20*r)*m),text:v=>`Each hit also strikes the next enemy for ${v}% damage`},
  {id:"serrated",tag:"bleed",icon:"serrated",name:"Serrated Steel",v:(r,m)=>Math.round(40*r*m),text:v=>`Hits cause Bleed: ${v}% of the hit as damage over 3s`},
  {id:"hemorrhage",tag:"bleed",icon:"hemorrhage",name:"Hemorrhage",v:(r,m)=>Math.round(10*r*m),text:v=>`Bleeding enemies take +${v}% damage from your hits`},
  {id:"bloodprice",tag:"bleed",icon:"bloodprice",name:"Blood Price",v:(r,m)=>r1(2.5*r*m),text:v=>`Killing a bleeding enemy heals ${v}% max HP`},
  {id:"ember",tag:"fire",icon:"ember",name:"Ember Brand",v:(r,m)=>Math.min(75,Math.round(20*r*m)),text:v=>`${v}% chance to Ignite: 60% of the hit burns over 3s`},
  {id:"fireball",tag:"fire",icon:"fireball",name:"Fireball",v:(r,m)=>Math.round((80+50*r)*m),text:v=>`Every 4s hurl a fireball for ${v}% damage that splashes the next enemy`},
  {id:"inferno",tag:"fire",icon:"inferno",name:"Pyre Burst",v:(r,m)=>Math.round((40+30*r)*m),text:v=>`Burning enemies explode on death for ${v}% damage to the next 2 enemies`},
  {id:"light",tag:"holy",icon:"light",name:"Divine Light",v:(r,m)=>r1((1.2+1.3*r)*m),text:v=>`Heal ${v}% max HP every 5s`},
  {id:"smite",tag:"holy",icon:"smite",name:"Smite",v:(r,m)=>Math.round((60+50*r)*m),text:v=>`Every 4th attack deals +${v}% bonus holy damage`},
  {id:"flask",tag:"holy",icon:"flask",name:"Blessed Flask",v:(r,m)=>Math.round(15*r*m),text:v=>`+1 potion now, potions heal +${v}%`},
  {id:"ironskin",tag:"shield",icon:"ironskin",name:"Iron Skin",v:(r,m)=>Math.round(10*r*m),text:v=>`+${v} Armor`},
  {id:"thorns",tag:"shield",icon:"thorns",name:"Thorns",v:(r,m)=>Math.round(22*r*m),text:v=>`When hit in melee, strike back for ${v}% of the blow plus ${Math.round(v/2)}% of your damage`},
  {id:"bulwark",tag:"shield",icon:"bulwark",name:"Bulwark",v:(r,m)=>Math.round(7*r*m),text:v=>`${v}% chance to block a hit completely`},
  {id:"chain",tag:"storm",icon:"chain",name:"Chain Lightning",v:(r,m)=>Math.round((50+30*r)*m),text:v=>`Every 3.5s lightning hits 3 enemies for ${v}% damage`},
  {id:"tempest",tag:"storm",icon:"tempest",name:"Tempest",v:(r,m)=>Math.round(10*r*m),text:v=>`+${v}% attack speed`},
  {id:"static",tag:"storm",icon:"static",name:"Static Charge",v:(r,m)=>Math.round((40+25*r)*m),text:v=>`Critical hits call lightning for ${v}% damage`},
  {id:"whirl",tag:"storm",icon:"whirl",name:"Whirlwind",v:(r,m)=>Math.round((45+30*r)*m),text:v=>`Every 5th attack spins, hitting every nearby enemy for ${v}% damage`},
  {id:"pierce",tag:"core",icon:"pierce",name:"Piercing Strike",v:(r,m)=>Math.round((20+15*r)*m),text:v=>`Hits pierce through, dealing ${v}% damage to every enemy behind the target`},
  {id:"keen",tag:"core",icon:"keen",name:"Keen Eye",v:(r,m)=>Math.round(5*r*m),text:v=>`+${v}% critical chance`},
  {id:"vigor",tag:"core",icon:"vigor",name:"Vigor",v:(r,m)=>Math.round(12*r*m),text:v=>`+${v}% max HP`},
  {id:"greed",tag:"core",icon:"greed",name:"Plunder",v:(r,m)=>Math.round(25*r*m),text:v=>`+${v}% gold from enemies. More gold, no combat power`}
];
const CARD_BY = Object.fromEntries(CARDS.map(c=>[c.id,c]));
const MAX_BANS = 3;
const cardLv = id => S.cardLv[id] || 1;
/* Skill levels: 1-5 add 15% each; Review 5 adds levels 6-10 (8% each, at steep prices) so orbs stay worth earning after the story. */
const CARD_MAX = 10;
const cardMultAt = lv => lv <= 5 ? 1 + .15*(lv-1) : 1.6 + .08*(lv-5);
const cardMult = id => cardMultAt(cardLv(id));
const orbCost = lv => [0,6,14,28,50,80,130,200,300,450][lv] || 0;

/* =====================================================================
   DATA: ACTIVE ABILITIES, EVOLUTIONS, LEGENDARY CARDS
===================================================================== */
/* The first two tags that reach 2 cards in a battle each grant their ability (two buttons, tapped by hand or auto-cast). */
const ABILITIES = {
  fire:{name:"Meteor", icon:"ab_meteor", cd:14, text:"300% damage to every enemy in view"},
  storm:{name:"Thunderclap", icon:"ab_thunder", cd:15, text:"150% damage to nearby enemies and stops their attacks for 2s"},
  bleed:{name:"Rend", icon:"ab_rend", cd:12, text:"A heavy bleed on the front enemy: 600% damage over 3s"},
  blade:{name:"Blade Dance", icon:"ab_dance", cd:16, text:"Double attack speed for 4s"},
  holy:{name:"Divine Shield", icon:"ab_divine", cd:20, text:"Immune to damage for 3s and heal 15% HP", def:true},
  shield:{name:"Shield Wall", icon:"ab_wall", cd:16, text:"Immune for 3.5s. A shield bash hits nearby enemies for 150% damage and stuns them", def:true}
};
const MAX_ABIL = 2;
/* Evolutions: a card plus the matching gear (or card) turns into something new. Offered once, with a gold frame.
   Review 3: owning the card is enough (it used to need rank 2), so players who do not plan their build meet them too. */
const EVOS = [
  {id:"evo_firestorm", base:"fireball", tag:"fire", icon:"evo_firestorm", name:"Firestorm", need:"Fireball and an Emberforged set item equipped", gear:()=>setWorn("ember")>=1, text:"Every 6s a meteor shower hits every enemy in view for 250% damage and ignites them"},
  {id:"evo_cuts", base:"twin", tag:"blade", icon:"evo_cuts", name:"Thousand Cuts", need:"Twin Strike and Serrated Steel in your build", gear:R=>!!(R && R.cards.serrated), text:"Every extra strike re-applies Bleed at double strength"},
  {id:"evo_crown", base:"chain", tag:"storm", icon:"evo_crown", name:"Storm Crown", need:"Chain Lightning and a Stormcaller set item equipped", gear:()=>setWorn("storm")>=1, text:"Chain Lightning jumps to 6 enemies and stuns each for 0.5s"},
  {id:"evo_bastion", base:"bulwark", tag:"shield", icon:"evo_bastion", name:"Bastion", need:"Bulwark and a Legendary or Onyx Warden shield equipped", gear:()=>{ const it = equipped("shield"); return !!it && (it.r>=3 || it.set==="warden"); }, text:"Every block grants a barrier worth 10% of your max HP"},
  {id:"evo_judge", base:"smite", tag:"holy", icon:"evo_judge", name:"Judgement", need:"Smite and a Legendary or better weapon equipped", gear:()=>{ const it = equipped("weapon"); return !!it && it.r>=3; }, text:"Smite calls a pillar of light on every enemy in view"}
];
/* Legendary cards: offered while both of their tags are in the build with 3 cards between them (LEGEND_CARDS). */
const LEGEND_CARDS = 3;
const LEGENDS = [
  {id:"leg_plasma", tags:["fire","storm"], icon:"leg_plasma", name:"Plasma Arc", text:"Lightning ignites its targets, and burning enemies take +30% lightning damage"},
  {id:"leg_martyr", tags:["bleed","holy"], icon:"leg_martyr", name:"Martyr's Blood", text:"20% of your Bleed damage heals you"},
  {id:"leg_riposte", tags:["shield","blade"], icon:"leg_riposte", name:"Riposte", text:"Every block strikes back for 200% damage and makes your next hit critical"},
  {id:"leg_static", tags:["storm","bleed"], icon:"leg_static", name:"Static Wounds", text:"Lightning hits also apply Bleed for 50% of their damage"},
  {id:"leg_molten", tags:["blade","fire"], icon:"leg_molten", name:"Molten Edge", text:"Critical hits always ignite, burning for 120% of the hit"},
  {id:"leg_sanct", tags:["holy","shield"], icon:"leg_sanct", name:"Sanctuary", text:"Healing above full health becomes a barrier, up to 20% of your max HP"}
];
for(const e of EVOS){ e.evo = true; e.v = ()=>1; const t = e.text; e.text = ()=>t; e.desc = t; CARD_BY[e.id] = e; }
for(const l of LEGENDS){ l.legend = true; l.tag = "legend"; l.v = ()=>1; const t = l.text; l.text = ()=>t; l.desc = t; CARD_BY[l.id] = l; }
const EVO_OF = Object.fromEntries(EVOS.map(e=>[e.base, e]));
/* build-shaping lines on Epic and better gear: a lower-power item can be the right one for a build */
const PERKS = {
  fb_twin:{tag:"fire", text:"Fireball throws 2 fireballs"},
  burn_long:{tag:"fire", text:"Burn lasts 2s longer"},
  bleed_long:{tag:"bleed", text:"Bleed lasts 2s longer"},
  rend_fast:{tag:"bleed", text:"Killing a bleeding enemy refreshes 2s of ability cooldowns"},
  chain_plus:{tag:"storm", text:"Chain Lightning hits 2 more enemies"},
  whirl_fast:{tag:"storm", text:"Whirlwind spins every 4th attack"},
  smite_fast:{tag:"holy", text:"Smite strikes every 3rd attack"},
  light_fast:{tag:"holy", text:"Divine Light heals every 3.5s"},
  thorns_plus:{tag:"shield", text:"Thorns reflects 50% more"},
  block_heal:{tag:"shield", text:"Blocks heal 3% HP"},
  twin_crit:{tag:"blade", text:"Twin Strike's second hit is always critical"},
  exec_wide:{tag:"blade", text:"Executioner works below 50% HP"},
  abil_fast:{tag:"core", text:"Abilities recharge 15% faster"},
  first_four:{tag:"core", text:"Your first skill offer shows 4 cards"}
};
const PERK_KEYS = Object.keys(PERKS);

/* =====================================================================
   DATA: GEAR, SETS, CAPES, META
===================================================================== */
const SLOTS = ["weapon","helm","armor","shield","ring"];
const SLOT_DEF = {
  weapon:{name:"Weapon",bases:["Shortsword","Longsword","Bastard Sword","Warblade"],legend:["Kingsbane","Oathkeeper","Dawnsplitter"],mythic:["Worldrender","Grief of Kings"],main:(il,m)=>({dmg:(3+il*1.1)*m})},
  helm:{name:"Helm",bases:["Cap","Bascinet","Greathelm","Visored Helm"],legend:["Crown of Ash","Warden's Gaze"],mythic:["Visage of Ruin"],main:(il,m)=>({hp:(10+il*5)*m})},
  armor:{name:"Armor",bases:["Gambeson","Mail Hauberk","Brigandine","Plate Cuirass"],legend:["Heart of the Mountain","Aegis of Dusk"],mythic:["Bloodforged Mail"],main:(il,m)=>({armor:(3+il*1)*m,hp:(4+il*2)*m})},
  shield:{name:"Shield",bases:["Buckler","Heater Shield","Kite Shield","Tower Shield"],legend:["Last Bastion","Sunward Wall"],mythic:["Wall of Cinders"],main:(il,m)=>({armor:(2+il*.7)*m,block:2+m*2})},
  ring:{name:"Ring",bases:["Iron Band","Silver Ring","Signet","Seal Ring"],legend:["Band of the Nine","Eye of Dusk"],mythic:["Seal of the Council"],main:(il,m)=>({crit:1+m*1.5+il*.15,dmg:(1+il*.4)*m})}
};
const SECONDARY = [
  {k:"dmgPct",v:r=>3+r*2},{k:"hpPct",v:r=>4+r*2},{k:"crit",v:r=>1+r*1.5},{k:"aspd",v:r=>3+r*2},{k:"armor",v:r=>2+r*2}
];
const STAT_LABEL = {dmg:["","Damage"],hp:["","Max HP"],armor:["","Armor"],block:["%","Block"],crit:["%","Crit"],aspd:["%","Attack speed"],dmgPct:["%","Damage"],hpPct:["%","Max HP"],armorPct:["%","Armor"],goldPct:["%","Gold found"]};
const SETS = {
  warden:{name:"Onyx Warden",slots:["helm","armor","shield"],b2:"+15% max HP",b3:"+25% Armor and +6% Block"},
  ember:{name:"Emberforged",slots:["weapon","armor","ring"],b2:"+12% damage",b3:"Hits have +20% chance to Ignite"},
  storm:{name:"Stormcaller",slots:["weapon","helm","ring"],b2:"+12% attack speed",b3:"Every 5s lightning strikes 2 enemies for 120% damage"}
};
const CAPES = {
  crimson:{name:"Crimson Oath",c:"#b8323c",d:"#7a1c26",how:"Starting cape"},
  royal:{name:"Royal Violet",c:"#7b4fd6",d:"#4d2e8f",how:"Clear Act I"},
  ashen:{name:"Ashen Shroud",c:"#6a6a78",d:"#3a3a44",how:"Clear Act II"},
  sun:{name:"Sunlord",c:"#e8b43a",d:"#a8741a",how:"Clear Act III"},
  forge:{name:"Forgeheart",c:"#ff7a2a",d:"#5a1a0c",how:"Clear Act IV"},
  starborn:{name:"Starborn",c:"#b07aff",d:"#1c1240",how:"Clear Act V"},
  frost:{name:"Frostbound",c:"#6fd0ff",d:"#2f7fb0",how:"Reach wave 15 in Endless"},
  emberc:{name:"Emberfall",c:"#ff6a2a",d:"#a8321a",how:"Complete every Challenge"},
  void:{name:"Voidwalker",c:"#3a2466",d:"#170d2c",how:"Vanguard Bundle"},
  oathbound:{name:"Oathbound",c:"#2fd0b8",d:"#0e4a44",how:"Oath Pass premium, level 20"},
  favor:{name:"Vanguard Gold",c:"#f2c14e",d:"#8a5a10",how:"Vanguard's Favor members"},
  outlaw:{name:"Outlaw's Crown",c:"#8a1630",d:"#2b0510",how:"Victory offer after the Outlaw King (48 hours)"},
  duelist:{name:"Duelist's Mantle",c:"#d8603a",d:"#4a1408",how:"Arena Bundle"},
  heat5:{name:"Cindermark",c:"#ff9a4a",d:"#7a2a0a",how:"Win a stage at Heat 10"},
  heat10:{name:"Molten Oath",c:"#ffcf5a",d:"#b0300a",how:"Win a stage at Heat 15"},
  heat15:{name:"Solar Regent",c:"#fff2c0",d:"#e0701a",how:"Win a stage at Heat 20"},
  pact:{name:"Ember Pact",c:"#e8502a",d:"#3a0c06",how:"Oath Pass premium, level 20 (The Ember Pact)"},
  vigil:{name:"Frost Vigil",c:"#9fd8ff",d:"#1c4a7a",how:"Oath Pass premium, level 20 (The Frost Vigil)"},
  choir:{name:"Hollow Choir",c:"#a88ad8",d:"#2a1a4a",how:"Oath Pass premium, level 20 (The Hollow Choir)"},
  accord:{name:"Astral Accord",c:"#f2cf6b",d:"#4a2a8a",how:"Oath Pass premium, level 20 (The Astral Accord)"}
};
/* Heat: a difficulty the player chooses before a campaign battle.
   Review 5: every step MULTIPLIES enemy health and damage by HEAT.step (gear grows by multiplying too, so a ladder that only
   added was outrun in a day), the loot bonus is +10% a step up to +200%, and the ladder has a summit: Heat 20.
   Measured with a skilled bot on this scale: Heat 10 on day 2, Heat 15 on day 9, Heat 20 after about eight weeks. */
const HEAT = {step:1.20, loot:.10, lootMax:2, max:20};
const heatMul = h => Math.pow(HEAT.step, h);                          // enemy health, and enemy damage
const heatLoot = h => 1 + Math.min(HEAT.lootMax, HEAT.loot*h);        // gold and orbs
/* capes and titles for the ladder (the cape keys keep their old names so saves stay valid) */
const HEAT_MILESTONES = [{at:10, cape:"heat5", title:"Emberwalker"}, {at:15, cape:"heat10", title:"Heatforged"}, {at:20, cape:"heat15", title:"Sunbreaker"}];
/* Seasons of the Oath Pass rotate through these themes (28 days each) */
const SEASONS = [
  {name:"The Ember Pact", col:"#ff7a3a", cape:"pact", img:"vista_ember", line:"The Council's forges burn for a new master. Break the pact."},
  {name:"The Frost Vigil", col:"#8fd8ff", cape:"vigil", img:"vista_frost", line:"The pass is closing. Hold the watchfires through the long night."},
  {name:"The Hollow Choir", col:"#b58cff", cape:"choir", img:"vista_gothic", line:"The dead are singing in the cathedral again. Silence them."},
  {name:"The Astral Accord", col:"#f2cf6b", cape:"accord", img:"vista_astral", line:"The stars are aligning over the Sanctum. Be there first."}
];
const seasonNow = () => SEASONS[((S.pass && S.pass.season)||0) % SEASONS.length];
const META = [
  {id:"vit",icon:"vit",name:"Vitality",short:"+15 HP",desc:"+15 max HP per rank",max:60,base:40,g:1.26},
  {id:"might",icon:"might",name:"Might",short:"+2 damage",desc:"+2 damage per rank",max:60,base:45,g:1.27},
  {id:"plating",icon:"plating",name:"Plating",short:"+3 armor",desc:"+3 armor per rank",max:50,base:50,g:1.28},
  {id:"alchemy",icon:"alchemy",name:"Alchemy",short:"+4% potion healing",desc:"+4% potion healing per rank",max:15,base:60,g:1.3},
  {id:"flasks",icon:"flasks",name:"Flask Belt",short:"+1 potion",desc:"+1 potion per battle",max:3,base:300,g:3},
  {id:"precision",icon:"keen",name:"Precision",short:"+0.5% crit",desc:"+0.5% critical chance per rank",max:30,base:450,g:1.3},
  {id:"swift",icon:"tempest",name:"Swiftness",short:"+1% attack speed",desc:"+1% attack speed per rank",max:30,base:500,g:1.3},
  {id:"fortune",icon:"greed",name:"Fortune",short:"+4% gold",desc:"+4% gold found per rank",max:25,base:350,g:1.3}
];
/* cost of the next rank: steep early, then flat (x1.12) after rank 20 so late-game gold always buys something */
const META_FLAT = 20;
const metaCostAt = (m, lv) => Math.round(m.base*Math.pow(m.g, Math.min(lv, META_FLAT))*Math.pow(1.12, Math.max(0, lv-META_FLAT)));
const metaCost = m => metaCostAt(m, S.meta[m.id]);

/* =====================================================================
   DATA: ENEMIES, ACTS, CHALLENGES
===================================================================== */
const ENEMY = {
  // Act I · Verdant Hollow
  bandit:{name:"Bandit",hp:28,dmg:5.5,atk:1.25,spd:22,xp:3,gold:3,trait:"Balanced melee fighter"},
  archer:{name:"Bandit Archer",hp:18,dmg:4,atk:1.9,spd:18,ranged:true,xp:3,gold:3,trait:"Shoots arrows from range"},
  wolf:{name:"Dire Wolf",hp:16,dmg:3,atk:.75,spd:46,xp:2,gold:2,trait:"Fast, bites rapidly"},
  rotbark:{name:"Elder Rotbark",hp:74,dmg:9.5,atk:2.2,spd:10,xp:7,gold:8,big:true,trait:"Huge and slow, hits very hard"},
  banditKing:{name:"Outlaw King",hp:240,dmg:10,atk:1.5,spd:16,xp:25,gold:40,boss:true,scale:1.5,trait:"Boss: heavy axe blows"},
  // Act II · Obsidian Cathedral
  skeleton:{name:"Hollow Squire",hp:30,dmg:6,atk:1.3,spd:20,xp:3,gold:3,trait:"Tireless undead soldier"},
  skelArcher:{name:"Bone Archer",hp:22,dmg:5,atk:1.9,spd:16,ranged:true,xp:3,gold:3,trait:"Shoots from range"},
  zombie:{name:"Crypt Wraith",hp:52,dmg:7,atk:1.7,spd:11,xp:4,gold:4,trait:"Slow but very tough"},
  boneLord:{name:"Bone Lord",hp:280,dmg:10.5,atk:1.45,spd:15,xp:30,gold:55,boss:true,scale:1.55,trait:"Boss: fast cursed blade"},
  // Act III · Frostveil Citadel
  raider:{name:"Frost Raider",hp:32,dmg:7,atk:1.3,spd:22,xp:3,gold:4,trait:"Hardy northern axeman"},
  frostWolf:{name:"Frost Wolf",hp:20,dmg:4,atk:.75,spd:48,xp:2,gold:3,trait:"Fast, bites rapidly"},
  giant:{name:"Glacial Colossus",hp:105,dmg:13,atk:2.3,spd:10,xp:9,gold:10,big:true,trait:"Huge and slow, hits very hard"},
  jarl:{name:"Jarl of Winter",hp:470,dmg:15,atk:2,spd:12,xp:40,gold:70,boss:true,scale:2,trait:"Boss: crushing frost mace"},
  // Act IV · Emberforge Caldera (also the Endless Descent)
  cultist:{name:"Cinder Cultist",hp:22,dmg:5,atk:1.9,spd:16,ranged:true,xp:3,gold:3,trait:"Hurls fire from range"},
  magmaGolem:{name:"Magma Colossus",hp:105,dmg:13,atk:2.3,spd:10,xp:9,gold:10,big:true,trait:"Huge and slow, hits very hard"},
  forgeBrute:{name:"Forge Brute",hp:34,dmg:7.5,atk:1.35,spd:20,xp:4,gold:4,trait:"Heavy axe, thick armor"},
  forgeTyrant:{name:"Forge Tyrant",hp:480,dmg:15,atk:1.8,spd:13,xp:40,gold:70,boss:true,scale:1.6,trait:"Boss: molten greatsword"},
  // Act V · Astral Sanctum (also the Endless Descent)
  acolyte:{name:"Void Acolyte",hp:22,dmg:5.5,atk:1.9,spd:16,ranged:true,xp:3,gold:3,trait:"Casts void bolts from range"},
  sentinel:{name:"Void Sentinel",hp:78,dmg:9,atk:2.4,spd:9,ranged:true,big:true,xp:8,gold:9,trait:"Floating eye that blasts from afar"},
  voidTemplar:{name:"Void Templar",hp:36,dmg:7.5,atk:1.3,spd:21,xp:4,gold:4,trait:"Swift and relentless"},
  voidHerald:{name:"Void Herald",hp:500,dmg:15,atk:1.7,spd:13,xp:40,gold:70,boss:true,scale:1.6,trait:"Boss: blade of the void"}
};
/* Counterplay: what each enemy is weak to or shrugs off (damage multipliers by element). Shown on the prefight enemy cards.
   Elements: phys (weapon hits), bleed, fire (burn, fireballs), storm (lightning), holy. */
const ENEMY_MOD = {
  wolf:{fire:1.5}, rotbark:{fire:1.5, bleed:.5},
  skeleton:{holy:1.5, bleed:.5}, skelArcher:{holy:1.5, bleed:.5}, zombie:{phys:.7, fire:1.5}, boneLord:{holy:1.3, bleed:.6},
  raider:{bleed:1.5}, frostWolf:{fire:1.5}, giant:{fire:1.5, storm:.5}, jarl:{fire:1.3},
  cultist:{fire:.5, storm:1.5}, forgeBrute:{bleed:1.5, fire:.6}, magmaGolem:{fire:.25, storm:.5}, forgeTyrant:{fire:.6, bleed:1.25},
  acolyte:{bleed:1.5}, sentinel:{storm:1.5, bleed:.5}, voidTemplar:{holy:1.5, fire:.7}, voidHerald:{holy:1.3}
};
for(const k in ENEMY_MOD) ENEMY[k].mod = ENEMY_MOD[k];
const ELEM = {hit:"phys", crit:"phys", cleave:"phys", pierce:"phys", whirl:"phys", thorn:"phys", bleed:"bleed", burn:"fire", fire:"fire", blast:"fire", zap:"storm", holy:"holy"};
const ELEM_NAME = {phys:"weapon hits", bleed:"Bleed", fire:"Fire", storm:"Lightning", holy:"Holy"};
const ELEM_TAG = {phys:"blade", bleed:"bleed", fire:"fire", storm:"storm", holy:"holy"};
/* [weak elements, resisted elements] of an enemy type */
function enemyMods(type){ const m = (ENEMY[type] && ENEMY[type].mod) || {}; return [Object.keys(m).filter(k=>m[k]>1), Object.keys(m).filter(k=>m[k]<1)]; }
/* How each enemy looks: a skin for the shared character rig, or a creature. `elite` is the look used by elite versions.
   w = half body width in world units (1 unit = 4px), used for spacing and melee reach. */
const LOOKS = {
  bandit:{kind:"rig", w:7, skin:{body:"armor", robe:"#34401e", armD:"#2e2418", armL:"#8a6e4c", trim:"#a88450", cape:"#3a4a22", capeD:"#141c0a", tabard:"#4a3a22", helm:"hood", glow:"#ffd27a", weapon:{type:"sword", glow:"#e8d8a8", steelL:"#d8d0c0", steelD:"#4a4640", trim:"#8a6a3a"}, shield:{type:"round", col:"#4a3622", trim:"#8a6a3a"}},
    elite:{kind:"rig", w:7, skin:{body:"armor", armD:"#221a10", armL:"#6a5a3a", trim:"#6a8a2a", cape:"#1e2a10", capeD:"#0a1004", helm:"horned", hornCol:"#4a3a22", glow:"#ff9a3a", spikes:1, weapon:{type:"axe", glow:"#b8ff5a", steelL:"#d8d0b8", steelD:"#4a4030"}}}},
  archer:{kind:"rig", w:7, style:"shoot", proj:"arrow", projH:62, skin:{body:"robe", robe:"#3a4a22", trim:"#8a6a3a", helm:"hood", glow:"#c8ff5a", weapon:{type:"bow", wood:"#5a3a22", trim:"#c9a45c", glow:"#c8ff5a"}}},
  wolf:{kind:"creature", type:"wolf", w:9, m:{d:"#2a2622", l:"#7a7066", rim:"#ffe0a0", eye:"#ffcf3a"}},
  rotbark:{kind:"creature", type:"treant", w:12, m:{d:"#2a1e12", l:"#6a5436", leafL:"#9ac85a", leafD:"#2a4a1a", moss:"#4a7a2a", shroom:"#7affd8", eye:"#ffb03a"}},
  banditKing:{kind:"rig", w:7, skin:{body:"armor", armD:"#2a1c14", armL:"#a88a6a", trim:"#f2c14e", cape:"#8a1630", capeD:"#2b0510", capeTrim:"#f2c14e", tabard:"#6a1022", helm:"crown", crownCol:"#f2c14e", gem:"#ff4d6d", glow:"#ffd27a", spikes:1, weapon:{type:"axe", glow:"#ffb04a", trim:"#f2c14e"}, shield:{type:"round", col:"#3a2518", trim:"#f2c14e", emblem:"sun"}}},
  skeleton:{kind:"rig", w:7, skin:{body:"bone", armD:"#6b6456", armL:"#d8cfb8", trim:"#8a7a5a", helm:"skull", brokenHelm:1, rags:"#3a2a3a", glow:"#b58cff", weapon:{type:"sword", glow:"#9a7ad8", steelL:"#b8b2a8", steelD:"#4a4540", trim:"#6a5a44"}, shield:{type:"round", col:"#3a3030", trim:"#6a5a44"}},
    elite:{kind:"rig", w:7, skin:{body:"armor", armD:"#1c1a20", armL:"#6e6a7c", trim:"#7a5ab0", cape:"#2a1a3a", capeD:"#0a0610", helm:"horned", hornCol:"#d8ccb0", glow:"#9dff9a", weapon:{type:"greatsword", glow:"#8dff8a", steelL:"#cfd6c8", steelD:"#3a4038"}, spikes:1}}},
  skelArcher:{kind:"rig", w:7, style:"shoot", proj:"arrow", projH:62, skin:{body:"bone", armD:"#6b6456", armL:"#d8cfb8", trim:"#8a7a5a", helm:"skull", rags:"#2a1e2e", glow:"#b58cff", weapon:{type:"bow", wood:"#3a2e26", trim:"#8a7a5a", glow:"#b58cff"}}},
  zombie:{kind:"creature", type:"wraith", w:9, m:{d:"#120a1c", l:"#4a2f66", rim:"#c9a2ff", eye:"#ff4fd0"}},
  boneLord:{kind:"rig", w:7, skin:{body:"bone", armD:"#5a5446", armL:"#e8e2cf", trim:"#b36bff", helm:"skull", skullCrown:1, crownCol:"#c9a2ff", gem:"#8ff0ff", glow:"#8ff0ff", cape:"#3a2a5a", capeD:"#120a20", capeTrim:"#b36bff", rags:"#241838", weapon:{type:"greatsword", glow:"#8ff0ff", steelL:"#e0f8ff", steelD:"#3a4a58", trim:"#b36bff", rune:1}}},
  raider:{kind:"rig", w:7, skin:{body:"armor", armD:"#2a3446", armL:"#9ab0c8", trim:"#c8d8e8", cape:"#2a4a6a", capeD:"#0a1a2a", helm:"horned", hornCol:"#e8dcc0", acc:"fur", glow:"#8ff0ff", weapon:{type:"axe", glow:"#9fe8ff", steelL:"#eef6ff", steelD:"#4a5a6a", trim:"#c8d8e8"}, shield:{type:"round", col:"#2a3a52", trim:"#c8d8e8", emblem:"flake"}},
    elite:{kind:"rig", w:7, skin:{body:"armor", armD:"#1c2838", armL:"#7a94b0", trim:"#6fb8e8", cape:"#0e2038", capeD:"#050c18", helm:"horned", hornCol:"#dff4ff", glow:"#4ff0ff", spikes:1, weapon:{type:"mace", glow:"#4ff0ff", steelL:"#e6f8ff", steelD:"#3a5a7a"}}}},
  frostWolf:{kind:"creature", type:"wolf", w:9, m:{d:"#5a7696", l:"#e6f2ff", rim:"#ffffff", eye:"#4fd0ff"}},
  giant:{kind:"creature", type:"golem", w:12, m:{d:"#2a4a70", l:"#cfeeff", rim:"#ffffff", crack:"#6fe8ff", eye:"#ffffff", emit:"snowburst"}},
  jarl:{kind:"rig", w:7, skin:{body:"armor", armD:"#33455e", armL:"#dfeefb", trim:"#a8d8f5", cape:"#1f3f7a", capeD:"#081630", capeTrim:"#dff4ff", tabard:"#1a3668", helm:"crown", crownCol:"#e6f4ff", gem:"#7fe8ff", glow:"#7fe8ff", acc:"fur", spikes:1, weapon:{type:"mace", glow:"#9fe8ff", trim:"#e8f0ff", steelL:"#ffffff", steelD:"#6a8ab0"}}},
  cultist:{kind:"rig", w:7, style:"cast", proj:"orb", projH:92, skin:{body:"robe", robe:"#3a0e0a", trim:"#d88030", helm:"hood", glow:"#ffcf4a", weapon:{type:"staff", glow:"#ff7a1a", wood:"#2a1810"}}},
  magmaGolem:{kind:"creature", type:"golem", w:12, m:{d:"#1a100c", l:"#5a3a2c", rim:"#ff8a3a", crack:"#ff6a1a", eye:"#ffe08a", emit:"ember"}},
  forgeBrute:{kind:"rig", w:7, skin:{body:"armor", armD:"#1a1616", armL:"#6a5a54", trim:"#c86020", helm:"horned", hornCol:"#3a2a22", glow:"#ff5a1a", spikes:1, weapon:{type:"axe", glow:"#ff5a1a", steelL:"#d0b8a8", steelD:"#3a2a22"}}},
  forgeTyrant:{kind:"rig", w:7, skin:{body:"armor", armD:"#1a1412", armL:"#8a6f63", trim:"#ff7a2a", cape:"#2a0a06", capeD:"#0a0302", capeTrim:"#ff7a2a", helm:"crown", crownCol:"#ffb060", gem:"#ff3a1a", glow:"#ff6a2a", spikes:1, weapon:{type:"greatsword", glow:"#ff5a1a", rune:1, steelL:"#f0d8c8", steelD:"#4a2a20", trim:"#ff9a4a"}}},
  acolyte:{kind:"rig", w:7, style:"cast", proj:"orb", projH:92, skin:{body:"robe", robe:"#1a0c2e", trim:"#b04ad8", helm:"hood", glow:"#ff4fd8", weapon:{type:"staff", glow:"#ff4fd8", wood:"#1a1024"}}},
  sentinel:{kind:"creature", type:"sentinel", w:9, proj:"orb", projH:100, m:{d:"#1a1030", l:"#6a4aa8", ring:"#f2cf6b", eye:"#ff4fd8"}},
  voidTemplar:{kind:"rig", w:7, skin:{body:"armor", armD:"#140c22", armL:"#5a4a7a", trim:"#b04ad8", cape:"#2a0c3a", capeD:"#0a0412", helm:"crown", crownCol:"#b04ad8", gem:"#ff4fd8", glow:"#ff4fd8", spikes:1, weapon:{type:"greatsword", glow:"#ff4fd8", steelL:"#e8d8ff", steelD:"#3a2a5a", trim:"#b04ad8"}}},
  voidHerald:{kind:"rig", w:7, skin:{body:"armor", armD:"#2a2a3e", armL:"#f4f2ff", trim:"#ffe08a", cape:"#6a2a8a", capeD:"#1a0a2a", capeTrim:"#ffe08a", helm:"winged", wingCol:"#ffffff", glow:"#ff6ff0", acc:"halo", haloCol:"#ff9af0", weapon:{type:"greatsword", glow:"#ff6ff0", rune:1, steelL:"#ffffff", steelD:"#8a6ab8", trim:"#ffe08a"}}}
};
const ACTS = [
  {name:"Act I: The Kingsroad",short:"I",theme:"verdant",lore:"The King rode out along the Kingsroad and never came back. Now outlaws own it.",pool:["bandit","bandit","archer","wolf","rotbark"],boss:"banditKing",
   levels:["Kingsroad Gate","Wolfwood","Bandit Camp","Burning Mill","The Outlaw Throne"]},
  {name:"Act II: The Hollow Cathedral",short:"II",theme:"gothic",lore:"His trail leads into the sunken cathedral, where the dead refuse to rest.",pool:["skeleton","skeleton","skelArcher","zombie"],boss:"boneLord",
   levels:["Chapel Ruins","The Ossuary","Sunken Nave","Silent Catacombs","The Bone Crown"]},
  {name:"Act III: The Frostveil",short:"III",theme:"frost",lore:"Giants of ice guard the pass to the Council of Nine. The truth waits beyond.",pool:["raider","raider","frostWolf","giant"],boss:"jarl",
   levels:["Frostfoot Pass","Giant's Stair","Howling Ridge","Ice-Hall Gates","Throne of Winter"]},
  {name:"Act IV: The Emberforge",short:"IV",theme:"ember",lore:"Past the pass, the Council's forges burn day and night, arming a host in the King's name.",pool:["forgeBrute","forgeBrute","cultist","magmaGolem"],boss:"forgeTyrant",
   levels:["Ashen Steps","Cinder Mines","The Molten Gate","Slag Bridges","The Tyrant's Anvil"]},
  {name:"Act V: The Astral Sanctum",short:"V",theme:"astral",lore:"The Council kneels to a voice from beyond the stars. The King climbed up to silence it. Follow him.",pool:["voidTemplar","voidTemplar","acolyte","sentinel"],boss:"voidHerald",
   levels:["Starfall Ruins","The Silent Choir","Halls of the Nine","The Celestial Stair","The Herald's Throne"]}
];
const LAST_ACT = ACTS.length - 1;
/* Stops between fights. Auto events play out on their own; the others ask the player to choose. */
const EVENTS = {
  heal:{name:"Healing Spring",icon:"ev_heal",w:3,text:"Clear water restores your wounds."},
  chest:{name:"Forgotten Chest",icon:"chest",w:3,text:"Gold, and sometimes gear."},
  shrine:{name:"Ancient Shrine",icon:"ev_shrine",w:3,text:"Choose one blessing for this battle."},
  altar:{name:"Blood Altar",icon:"ev_altar",w:2,text:"Trade health for power."},
  merchant:{name:"Wandering Merchant",icon:"ev_merchant",w:2,text:"Spend this battle's gold."},
  fork:{name:"A fork in the road",icon:"ev_fork",w:0,text:"The road splits. Choose your way."}      // placed by the level builder, never rolled
};
const BLESSINGS = [
  {id:"might",icon:"might",name:"Blessing of Might",text:"+20% damage"},
  {id:"swift",icon:"tempest",name:"Blessing of Haste",text:"+15% attack speed"},
  {id:"vigor",icon:"vigor",name:"Blessing of Vigor",text:"+25% max HP, fully healed"},
  {id:"keen",icon:"keen",name:"Blessing of Sight",text:"+8% critical chance"},
  {id:"ward",icon:"ironskin",name:"Blessing of Stone",text:"+12 armor"},
  {id:"fortune",icon:"greed",name:"Blessing of Fortune",text:"+40% gold from enemies"}
];
/* Endless Descent alternates between these two realms every 10 waves (a boss closes each one). */
const ENDLESS_ZONES = [
  {name:"Emberforge Caldera",theme:"ember",pool:["cultist","forgeBrute","forgeBrute","magmaGolem"],boss:"forgeTyrant"},
  {name:"Astral Sanctum",theme:"astral",pool:["acolyte","voidTemplar","voidTemplar","sentinel"],boss:"voidHerald"}
];
const CHALLENGES = [
  {id:"lastbreath",icon:"lastbreath",name:"Last Breath",desc:"Start the battle with 1 HP.",act:0,lvl:2,d:4,mods:{lastBreath:true},reward:{orbs:25,gems:40}},
  {id:"horde",icon:"horde",name:"Horde Night",desc:"Every wave has twice as many enemies.",act:0,lvl:3,d:5,mods:{horde:true},reward:{orbs:30,gems:40}},
  {id:"dry",icon:"dry",name:"Dry Flask",desc:"No potions. Heal only with skills.",act:1,lvl:1,d:7,mods:{dry:true},reward:{orbs:35,gems:50}},
  {id:"glass",icon:"glass",name:"Glass Blade",desc:"You deal double damage and take double damage.",act:1,lvl:3,d:9,mods:{glass:true},reward:{orbs:40,gems:60}},
  {id:"frostdry",icon:"dry",name:"Frozen Flasks",desc:"No potions in the Frostveil.",act:2,lvl:2,d:13,mods:{dry:true},reward:{orbs:50,gems:70}},
  {id:"forgehorde",icon:"horde",name:"Forge Riot",desc:"Twice the enemies in the Emberforge.",act:3,lvl:1,d:17,mods:{horde:true},reward:{orbs:60,gems:80}},
  {id:"starglass",icon:"glass",name:"Shattered Stars",desc:"Double damage dealt and taken in the Sanctum.",act:4,lvl:2,d:23,mods:{glass:true},reward:{orbs:70,gems:100}}
];
const RIVAL_NAMES = ["Sir Aldric","Maelis","Varn","Ysolde","Brother Cade","Kethra","Lord Osric","Tamsin","Dunmore","Hilde","Rook","Sable"];

/* =====================================================================
   DATA: QUESTS, JOURNEY, ARENA, RAID
===================================================================== */
/* Daily quests: 4 are drawn each day from the ones the player has unlocked. `key` is the stat they count. */
const QUESTS = [
  {id:"kills",key:"kills",icon:"skull",need:60,text:n=>`Defeat ${n} enemies`},
  {id:"wins",key:"wins",icon:"battle",need:3,text:n=>`Win ${n} battles`},
  {id:"events",key:"events",icon:"chest",need:4,text:n=>`Visit ${n} stops on the road`},
  {id:"elites",key:"elites",icon:"horde",need:3,text:n=>`Defeat ${n} elite enemies`},
  {id:"potions",key:"potions",icon:"potion",need:3,text:n=>`Drink ${n} potions`},
  {id:"gold",key:"goldEarned",icon:"gold",need:600,text:n=>`Loot ${n} gold in battle`},
  {id:"forge",key:"forges",icon:"might",need:2,text:n=>`Forge gear ${n} times`},
  {id:"cardup",key:"cardUps",icon:"skills",need:1,text:()=>`Upgrade a skill card`},
  {id:"duels",key:"duels",icon:"arena",need:2,text:n=>`Fight ${n} arena duels`,unlock:"arena"},
  {id:"raid",key:"raids",icon:"raid",need:1,text:()=>`Attack the raid boss`,unlock:"raid"},
  {id:"waves",key:"waves",icon:"endless",need:8,text:n=>`Clear ${n} Endless waves`,unlock:"endless"},
  // Review 5: quests that ask for a choice, not only a count (two of the day's four, once they are unlocked)
  {id:"syn2",key:"syn2",icon:"skills",need:1,choice:true,text:()=>`Win a battle with two synergies`},
  {id:"dry",key:"dryWins",icon:"dry",need:1,choice:true,text:()=>`Win a battle without drinking a potion`},
  {id:"heat",key:"heatWins",icon:"heat",need:2,choice:true,text:n=>`Win ${n} battles at Heat 1 or higher`,unlock:"heat"},
  {id:"stop",key:"interrupts",icon:"ab_wall",need:2,choice:true,text:n=>`Interrupt ${n} heavy attacks with an ability`,unlock:"heat"},
  {id:"focus",key:"focusWins",icon:"keen",need:1,choice:true,text:()=>`Win a battle using only one skill type`,unlock:"keep"}
];
/* THE STORY (Review 5): a page when each act ends, and a real ending. Shown once, on the map, after the boss falls. */
const ACT_END = [
  {title:"The Outlaw King falls", lines:["Among his spoils lies a royal signet, pried from a saddlebag.", "The King passed this way alive, riding hard for the old cathedral.", "The road is open again. The Vanguard rides on."]},
  {title:"The Bone Lord is dust", lines:["In the crypt the dead were keeping a guest's banner: the King's own, folded with care.", "Someone woke them to bar the way. The order bore the seal of the Council of Nine.", "The trail climbs north, into the ice."]},
  {title:"Winter breaks", lines:["The Jarl held the pass for the Council, and died without knowing why.", "Beyond it the sky glows red: forges, burning day and night.", "They are arming a host in the King's name. He never asked for one."]},
  {title:"The forges fall silent", lines:["The Tyrant's last work is still on the anvil: nine crowns, and a tenth left unfinished.", "The Council no longer serves the King. It serves a voice from beyond the stars.", "He went up alone to silence it. Follow him."]},
  {title:"The Herald falls", end:true, lines:["The Sanctum is silent. The voice is gone, and the Nine have fled.", "On the highest stair lies the King's sword, broken at the hilt.", "His footprints do not stop there. They lead on, into the stars.", "You are the last knight of the Onyx Vanguard. The road goes on."]}
];
/* Journey: one-time milestones that pay out gems. val() reads the save. */
const JOURNEY = [
  {id:"act1",icon:"battle",name:"The Kingsroad",text:"Defeat the Outlaw King",need:1,val:()=>S.cleared["0-4"]?1:0,gems:40},
  {id:"act2",icon:"skull",name:"The Hollow Cathedral",text:"Defeat the Bone Lord",need:1,val:()=>S.cleared["1-4"]?1:0,gems:60},
  {id:"act3",icon:"crown",name:"The Frostveil",text:"Defeat the Jarl of Winter",need:1,val:()=>S.cleared["2-4"]?1:0,gems:100},
  {id:"act4",icon:"might",name:"The Emberforge",text:"Defeat the Forge Tyrant",need:1,val:()=>S.cleared["3-4"]?1:0,gems:140},
  {id:"act5",icon:"sigil",name:"The Astral Sanctum",text:"Defeat the Void Herald",need:1,val:()=>S.cleared["4-4"]?1:0,gems:200},
  {id:"k1",icon:"skull",name:"Road Warden",text:"Defeat 500 enemies",need:500,val:()=>S.stats.kills,gems:20},
  {id:"k2",icon:"skull",name:"Scourge of Outlaws",text:"Defeat 2,500 enemies",need:2500,val:()=>S.stats.kills,gems:40},
  {id:"k3",icon:"skull",name:"Legend of the Vanguard",text:"Defeat 10,000 enemies",need:10000,val:()=>S.stats.kills,gems:80},
  {id:"e1",icon:"endless",name:"Into the Deep",text:"Reach wave 10 in the Endless Descent",need:10,val:()=>S.endlessBest,gems:30},
  {id:"e2",icon:"endless",name:"Deeper Still",text:"Reach wave 25 in the Endless Descent",need:25,val:()=>S.endlessBest,gems:60},
  {id:"e3",icon:"endless",name:"Abyss Walker",text:"Reach wave 50 in the Endless Descent",need:50,val:()=>S.endlessBest,gems:120},
  {id:"a1",icon:"arena",name:"First Blood",text:"Win 5 arena duels",need:5,val:()=>S.stats.duelWins,gems:20},
  {id:"a2",icon:"trophy",name:"Gold League",text:"Reach the Gold league",need:900,val:()=>S.arena.best,gems:50},
  {id:"a3",icon:"trophy",name:"Onyx League",text:"Reach the Onyx league",need:1600,val:()=>S.arena.best,gems:100},
  {id:"r1",icon:"raid",name:"Giant Slayer",text:"Defeat a raid boss",need:1,val:()=>S.raid.tier,gems:40},
  {id:"r2",icon:"raid",name:"Titan's Bane",text:"Defeat 4 raid bosses",need:4,val:()=>S.raid.tier,gems:100},
  {id:"f1",icon:"might",name:"Master Smith",text:"Forge an item to +5",need:5,val:()=>Math.max(0,...S.inv.map(i=>i.upg||0)),gems:25},
  {id:"l1",icon:"knightchest",name:"Relic Hunter",text:"Own a Legendary item",need:1,val:()=>S.inv.some(i=>i.r===3)?1:0,gems:40},
  {id:"c1",icon:"challenges",name:"Tested",text:"Complete every challenge",need:CHALLENGES.length,val:()=>CHALLENGES.filter(c=>S.challenges[c.id]).length,gems:60}
];
const LEAGUES = [
  {name:"Bronze",min:0,color:"#d08a52"},{name:"Silver",min:400,color:"#cfd6e6"},{name:"Gold",min:900,color:"#f2c14e"},
  {name:"Onyx",min:1600,color:"#c9a2ff"},{name:"Crown",min:2500,color:"#ff6a8a"}
];
const leagueOf = t => { let L = LEAGUES[0]; for(const l of LEAGUES) if(t>=l.min) L = l; return L; };
const ARENA_TICKETS = 5, RAID_KEYS = 3, RAID_TIME = 40;
const RIVAL_TITLES = ["of the Ashen Vale","the Unbroken","of Greywatch","the Pale","of Thornmere","the Oathsworn","of the North Road","the Grim","of Emberhold","the Silent"];
/* Raid bosses rotate. Each defeat raises the tier; HP carries over between attempts. */
const RAIDS = [
  {type:"raidTreant",name:"The Rotting Elder",theme:"verdant",text:"An ancient tree-giant, swollen with rot."},
  {type:"raidGolem",name:"The Frozen Titan",theme:"frost",text:"A colossus of glacier ice that shakes the pass."},
  {type:"raidMagma",name:"The Molten Heart",theme:"ember",text:"A living forge that never cools."},
  {type:"raidEye",name:"The Eye Beyond",theme:"astral",text:"A floating eye that stares from the void."}
];
ENEMY.raidTreant = {name:"The Rotting Elder",hp:1,dmg:10,atk:2.2,spd:0,xp:0,gold:0,boss:true,big:true,scale:2.6,trait:"Raid boss"};
ENEMY.raidGolem = {name:"The Frozen Titan",hp:1,dmg:12,atk:2.4,spd:0,xp:0,gold:0,boss:true,big:true,scale:2.6,trait:"Raid boss"};
ENEMY.raidMagma = {name:"The Molten Heart",hp:1,dmg:12,atk:2.3,spd:0,xp:0,gold:0,boss:true,big:true,scale:2.6,trait:"Raid boss"};
ENEMY.raidEye = {name:"The Eye Beyond",hp:1,dmg:10,atk:2.1,spd:0,ranged:true,xp:0,gold:0,boss:true,big:true,scale:2.6,trait:"Raid boss"};
LOOKS.raidTreant = {kind:"creature", type:"treant", w:19, m:{d:"#1e1a10", l:"#5a4a2c", leafL:"#b8c85a", leafD:"#3a2a1a", moss:"#7a8a2a", shroom:"#ff7ad8", eye:"#ff4a2a"}};
LOOKS.raidGolem = {kind:"creature", type:"golem", w:19, m:{d:"#1f3a5a", l:"#e6f6ff", rim:"#ffffff", crack:"#4fd8ff", eye:"#9ff6ff", emit:"snowburst"}};
LOOKS.raidMagma = {kind:"creature", type:"golem", w:19, m:{d:"#140a08", l:"#6a2c1c", rim:"#ffb04a", crack:"#ffcf3a", eye:"#fff2a0", emit:"ember"}};
LOOKS.raidEye = {kind:"creature", type:"sentinel", w:12, proj:"orb", projH:130, m:{d:"#12081e", l:"#8a3ab8", ring:"#ff9af0", eye:"#ff2a6a"}};
const raidBoss = () => RAIDS[S.raid.tier % RAIDS.length];
const raidMaxHp = tier => Math.round(7000*Math.pow(1.75, tier));

/* =====================================================================
   DATA: CRAFTING — runes (from fragments), sockets, Arcane Dust, Starmetal
===================================================================== */
/* 5 fragments forge a rank I rune; 3 runes of one rank merge into the next rank (I–V). Runes go into item sockets. */
const RUNES = {
  fury:{name:"Fury",stat:"dmgPct",per:[3,6,10,15,22],color:"#ff5a4a"},
  life:{name:"Life",stat:"hpPct",per:[4,8,13,19,27],color:"#5ae08a"},
  precision:{name:"Precision",stat:"crit",per:[1.5,3,5,7.5,11],color:"#ffd24a"},
  haste:{name:"Haste",stat:"aspd",per:[2,4,7,10,14],color:"#7ee0ff"},
  stone:{name:"Stone",stat:"armorPct",per:[4,8,13,19,27],color:"#c8b8a8"},
  fortune:{name:"Fortune",stat:"goldPct",per:[6,12,20,30,45],color:"#f2c14e"}
};
const RUNE_KEYS = Object.keys(RUNES);
const ROMAN = ["I","II","III","IV","V"];
const FRAGS_PER_RUNE = 5, RUNES_TO_MERGE = 3;
const SOCKETS = [0,1,2,2,3,3];           // by rarity
/* ascend: raise rarity by one (up to Mythic). Starmetal + dust, by current rarity */
const ASCEND_COST = [{star:2,dust:40},{star:4,dust:90},{star:8,dust:180},{star:14,dust:320}];

/* =====================================================================
   DATA: ANCIENT RELICS — the premium rarity, only from Ancient Sigils
===================================================================== */
const ANCIENTS = {
  weapon:{name:"Oathblade of the First King",power:"oathblade",text:"Every 4th hit sends out a wave that strikes every enemy in view for 60% damage."},
  helm:{name:"Crown of Ages",power:"crown",text:"+1 potion every battle, and potions heal 50% more."},
  armor:{name:"Heartplate of Dawn",power:"heart",text:"Once per battle, survive a killing blow and heal to 50% HP."},
  shield:{name:"Aegis of the Vanished King",power:"aegis",text:"+10% block, and blocked hits strike back for 150% of the damage."},
  ring:{name:"Band of Eternity",power:"eternity",text:"Skill offers show 4 cards, and you gain 20% more XP."}
};

/* =====================================================================
   DATA: OATH TIERS, BOUNTIES, TRIALS
===================================================================== */
const TIER_NAMES = ["I","II","III","IV","V","VI","VII","VIII","IX","X"];
const tierName = t => TIER_NAMES[t-1] || String(t);
const AFFIXES = {
  vampiric:{name:"Vampiric",text:"heals 30% of the damage it deals"},
  shielded:{name:"Shielded",text:"blocks 25% of hits"},
  enraged:{name:"Enraged",text:"attacks 60% faster below half health"},
  thorned:{name:"Thorned",text:"reflects 15% of damage taken"},
  frenzied:{name:"Frenzied",text:"attacks 30% faster"},
  colossal:{name:"Colossal",text:"has 60% more health"}
};
const CHAMP_FIRST = ["Gorvak","Mirelle","Thane Hakon","Old Scarbelly","Vesk","Brannoc","Yrsa","The Pale Widow","Kodric","Ulfrun","Sister Maud","Harrow"];
const CHAMP_LAST = ["the Butcher","Bonegrinder","the Unkind","of the Black Wood","the Hollow","Ironjaw","the Frostborn","Nine-Fingers","the Cruel","Grave-Singer"];
const TRIAL_RULES = {
  dry:{name:"Dry Flask",text:"No potions",icon:"dry"},
  timed:{name:"Against the Clock",text:"Win before the clock runs out",icon:"trial"},
  glass:{name:"Glass Blade",text:"Deal and take double damage",icon:"glass"},
  horde:{name:"Horde",text:"+2 enemies in every pack",icon:"horde"},
  haste:{name:"Bloodlust",text:"Enemies attack 35% faster",icon:"frenzy"},
  fragile:{name:"Fragile",text:"40% less max HP",icon:"lastbreath"},
  noEvents:{name:"No Rest",text:"No stops on the road",icon:"ev_heal"},
  oneTag:{name:"Single Path",text:"Only one skill tag (and Core) is offered",icon:"skills"},
  elite:{name:"Champions",text:"Every pack has an elite",icon:"skull"}
};
const TRIAL_TIME = 150;

/* =====================================================================
   DATA: LOGIN CALENDAR, OATH PASS
===================================================================== */
/* 7-day cycle; amounts scale a little with progress */
const LOGIN = [
  {gold:250, label:"Gold"}, {orbs:15, label:"Orbs"}, {dust:60, label:"Arcane Dust"}, {frags:6, label:"Rune fragments"},
  {gems:30, label:"Gems"}, {star:2, label:"Starmetal"}, {gems:60, star:3, frags:10, label:"Grand chest"}
];
const PASS_LEVELS = 30, PASS_XP = 100, PASS_DAYS = 28;
/* reward for each pass level (1-based): free lane for everyone, premium lane for Oath Pass owners */
function passReward(lv, premium){
  if(premium){ if(lv===30) return {sigil:1, gems:150}; if(lv===20) return {cape:seasonNow().cape, gems:100}; if(lv%5===0) return {gems:80}; return [{star:2},{frags:8},{dust:120},{orbs:25}][lv%4]; }
  return [{gold:400},{orbs:8},{dust:40},{frags:4},{gems:10},{star:1}][lv%6];
}
const PASS_XP_FOR = {win:20, trial:40, bounty:40, quest:30, duel:15, raid:20, waves5:10};

/* knight skins: cosmetic armour sets (gem sink). look overrides the gear colours; weaponGlow tints every hit */
const SKINS = {
  paladin:{name:"Onyx Paladin", price:600, look:{armD:"#1a1620", armL:"#5a5070", trim:"#f2c14e", helm:"winged", wingCol:"#fff4d8", helmD:"#1a1620", helmL:"#6a6080", glow:"#ffd86a", tabard:"#2a1a3a"}, weaponGlow:"#ffd86a"},
  frostjarl:{name:"Frost Jarl", price:750, look:{armD:"#33455e", armL:"#dfeefb", trim:"#a8d8f5", helm:"horned", hornCol:"#e8f4ff", helmD:"#33455e", helmL:"#dfeefb", acc:"fur", glow:"#9fe8ff", spikes:1}, weaponGlow:"#9fe8ff"},
  voidknight:{name:"Void Knight", price:900, look:{armD:"#140c22", armL:"#5a4a7a", trim:"#b04ad8", helm:"crown", crownCol:"#b04ad8", gem:"#ff4fd8", helmD:"#140c22", helmL:"#5a4a7a", glow:"#ff4fd8", spikes:1}, weaponGlow:"#ff4fd8"},
  sunforged:{name:"Sunforged", price:900, look:{armD:"#5a3a10", armL:"#f2d38a", trim:"#fff0b0", helm:"crown", crownCol:"#ffd86a", gem:"#ff6a2a", helmD:"#5a3a10", helmL:"#f2d38a", glow:"#ffd86a", acc:"halo", haloCol:"#ffe07a"}, weaponGlow:"#ffb04a"}
};
