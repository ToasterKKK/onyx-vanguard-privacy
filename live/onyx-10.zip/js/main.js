/* Onyx Vanguard — main.js
   Boot sequence. Must be the last script loaded.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   GRAPHICS QUALITY
   "auto" starts on High and drops to Battery saver if the first seconds run slowly.
===================================================================== */
let autoQ = "high";
function qualityNow(){ return S.quality==="low" ? "low" : S.quality==="high" ? "high" : autoQ; }
function applyQuality(){ World.setQuality(qualityNow()); hudCache = {}; }
const perf = { n:0, sum:0, done:false, t0:0 };
function perfSample(dt){
  if(perf.done || S.quality!=="auto" || document.hidden) return;
  if(performance.now() - perf.t0 < 1500) return;          // ignore start-up frames
  perf.n++; perf.sum += dt;
  if(perf.n >= 150){ perf.done = true; const avg = perf.sum/perf.n; if(avg > 1/40 && autoQ==="high"){ autoQ = "low"; applyQuality(); } }
}

/* =====================================================================
   INIT
===================================================================== */
function boot(){
  buildChrome();
  if(S.sound) initAudio();          // decode sound effects early; playback starts after the first tap (iOS rule)
  giveStarterGear();
  migrateSave();                     // older saves: gear perks and the new systems' defaults
  World.init($("#world"), qualityNow()); World.setCalm(calmOn()); applyComfort();
  renderAll();                       // also sets the act's world theme
  Monetization.init();
  setTimeout(()=>{ Cloud.init(); GameCenter.init(); }, 1200);
  perf.t0 = performance.now();
  const lost = recoverRun(); if(lost) setTimeout(()=>toast(lost, "#d0ab62"), 1600);
  const back = returnReward();       // away for 3 days or more: a welcome-back chest (also stamps this visit)
  if(saveState==="rescued" || saveState==="lost") setTimeout(openSaveRescue, 700);
  try{ matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", ()=>{ World.setCalm(calmOn()); applyComfort(); }); }catch(e){}
  if(S.seenIntro) setTimeout(()=>{ if(run || $("#modalRoot").children.length) return; if(back) openWelcomeBack(back);
    else if(loginReady()) openLogin(); else coachNext(); }, 900);
  requestAnimationFrame(t=>{ lastT = t; requestAnimationFrame(frame); });      // the opening screen fades out in startUp() once the first frames are drawn
  // first launch: no title card, no menus. The story is told in captions while the knight rides into his first fight.
  if(!S.seenIntro && saveState==="lost"){ S.seenIntro = true; }
  else if(!S.seenIntro){ S.seenIntro = true; persist(); setTimeout(()=>{ if(!run) startRun({mode:"campaign", a:0, i:0, tier:1}); }, 500); }
}
ACTIONS.introDone = ()=>{ S.seenIntro = true; persist(); SFX.pick(); closeAllModals(); setTimeout(()=>{ if(!run && loginReady()) openLogin(); }, 400); };

/* =====================================================================
   OPENING SCREEN (Review 10): loading steps with a real progress bar, then a check for a newer App Store version
===================================================================== */
const BOOT_MIN_MS = 1400, UPDATE_TIMEOUT = 3000;
function bootStep(pct, text){ const b = $("#boot .bl i"); if(b) b.style.width = pct + "%"; if(text != null) $("#bootStep").textContent = text; }
const wait = ms => new Promise(r=>setTimeout(r, ms));
/* "1.10.0" > "1.9.2" */
function newerVersion(a, b){ const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number);
  for(let i=0;i<3;i++){ const d = (x[i]||0) - (y[i]||0); if(d) return d > 0; } return false; }
/* the App Store's own record of this app (JSONP, so no CORS setup is needed in the web view); null when offline or slow */
function storeLookup(){
  return new Promise(res=>{
    const cb = "__ovLookup" + Date.now(), s = document.createElement("script"); let done = false;
    const end = v=>{ if(done) return; done = true; delete window[cb]; s.remove(); res(v); };
    window[cb] = d=>end(d && d.results && d.results[0] || null);
    s.onerror = ()=>end(null); setTimeout(()=>end(null), UPDATE_TIMEOUT);
    s.src = `https://itunes.apple.com/lookup?bundleId=${encodeURIComponent(BUNDLE_ID)}&callback=${cb}&t=${Date.now()}`;
    document.head.appendChild(s);
  });
}
/* a new App Store build is needed (the live files say so): the card has one button, Update, since this version can't run the new content */
function requireStoreUpdate(info){
  const el = $("#bootUpd");
  el.innerHTML = `<b>Update needed</b><p>A new version of Onyx Vanguard is ready in the App Store.</p><div class="mbtns"><button class="btn gold" id="updGo">Update</button></div>`;
  el.hidden = false; $("#boot").classList.add("upd");
  $("#updGo").onclick = ()=>window.open((info && info.trackViewUrl) || `https://apps.apple.com/app/id${(info && info.trackId) || ""}`, "_blank");
  return new Promise(()=>{});      // stays here: the player continues in the new version
}
/* live updates (Review 11): new web files are fetched and swapped in without asking, then the app restarts into them.
   manifest.json: {content, minApp, url, sha256}. A bundle that fails to start is rolled back by the plugin (no notifyAppReady
   within appReadyTimeout); LIVE_TRY / LIVE_BAD remember it so the same bundle is never tried twice. */
const LIVE_TRY = "ov_live_try", LIVE_BAD = "ov_live_bad";
const lsGet = k=>{ try{ return localStorage.getItem(k); }catch(e){ return null; } }, lsSet = (k, v)=>{ try{ v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); }catch(e){} };
async function fetchJSON(url, ms){
  const ac = typeof AbortController !== "undefined" ? new AbortController() : null, tm = setTimeout(()=>ac && ac.abort(), ms);
  try{ const r = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + Date.now(), {cache:"no-store", signal: ac && ac.signal}); return r.ok ? await r.json() : null; }
  catch(e){ return null; } finally{ clearTimeout(tm); }
}
async function liveUpdate(){
  const U = nativePlugins().CapacitorUpdater; if(!U) return;
  const tried = +lsGet(LIVE_TRY) || 0;
  if(tried){ lsSet(LIVE_TRY, null); if(CONTENT_VERSION < tried) lsSet(LIVE_BAD, tried); }        // we asked for `tried` and are not running it: it was rolled back
  const m = await fetchJSON(LIVE_URL, UPDATE_TIMEOUT);
  if(!m || !m.content) return;
  if(m.minApp && newerVersion(m.minApp, APP_VERSION)){ await requireStoreUpdate(await storeLookup()); return; }
  if(m.content <= CONTENT_VERSION || m.content == lsGet(LIVE_BAD) || !m.url) return;
  bootStep(60, "Downloading update");
  let h = null; try{ h = await U.addListener("download", e=>bootStep(60 + Math.round((e.percent || 0) * .35), `Downloading update ${Math.round(e.percent || 0)}%`)); }catch(e){}
  try{
    const b = await U.download({ url:m.url, version:String(m.content), checksum:m.sha256 || undefined });
    bootStep(100, "Restarting"); lsSet(LIVE_TRY, m.content); await wait(400);
    await U.set({ id:b.id });                  // reloads the web view into the new files
    await new Promise(()=>{});
  }catch(e){ bootStep(70, "Update failed, starting"); }
  finally{ try{ h && h.remove(); }catch(e){} }
}
async function startUp(){
  const t0 = performance.now();
  $("#bootVer").textContent = "Version " + APP_VERSION + " · content " + CONTENT_VERSION;
  bootStep(8, "Loading fonts");
  if(document.fonts && document.fonts.load) await Promise.race([Promise.all([document.fonts.load('700 16px "Source Serif 4"'), document.fonts.load('600 16px "Source Serif 4"'), document.fonts.load('16px "Source Serif 4"')]), wait(900)]).catch(()=>{});
  bootStep(30, "Checking for updates");
  if(isNativeApp()) await liveUpdate().catch(()=>{});
  bootStep(70, "Forging armour");
  try{ const sk = heroSkin(); for(let k=0; k<30 && typeof rigPartsReady === "function" && !rigPartsReady(sk); k++) await wait(50); }catch(e){}     // the knight's drawn parts, so he never appears in the old shapes
  bootStep(85, "Entering the realm");
  await wait(30); boot();
  try{ const U = nativePlugins().CapacitorUpdater; if(U) U.notifyAppReady(); }catch(e){}      // these files started: keep them
  try{ Telemetry.ping(); document.addEventListener("visibilitychange", ()=>{ if(!document.hidden) Telemetry.ping(); }); }catch(e){}      // anonymous player count
  bootStep(100);
  await wait(Math.max(250, BOOT_MIN_MS - (performance.now() - t0)));
  $("#boot").classList.add("done");
}
startUp();

// debug / automation hook (browser only, never inside the native app)
if(!isNativeApp()) window.__OV = { get S(){ return S; }, get run(){ return run; }, startRun, ACTIONS, update:(dt)=>update(dt), heroStats, genItem, gainXp, persist, powerOf, suggestedPower, nextLevel, finishRun, META, metaCost, orbCost, CARD_BY, tagCount, SLOTS, World, castAbility, applyCard, offerCards, renderAll, get autoQ(){ return autoQ; } };
