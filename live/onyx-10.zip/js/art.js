/* Onyx Vanguard — art.js
   Painted icons for skills, currencies, tabs, training, challenges, shop items and modes.
   Every icon is painted once with canvas gradients and light (same painter as the world, via World.*),
   then cached as a PNG data URL. Use art(name) for an <img> tag, artURL(name) for the URL.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

const ART_PX = 192;               // rendered size; shown at 16–64 CSS px
const ART_CACHE = {};
const TAU2 = Math.PI*2;
const W_ = () => World;
function aglow(g, col, x, y, r, a){ g.save(); g.globalCompositeOperation = "lighter"; World.glow(g, col, x, y, r, a); g.restore(); }
function lg(g, x0,y0,x1,y1, stops){ const gr = g.createLinearGradient(x0,y0,x1,y1); stops.forEach((c,i)=>gr.addColorStop(i/(stops.length-1), c)); return gr; }
function rg(g, x,y,r0, x1,y1,r1, stops){ const gr = g.createRadialGradient(x,y,r0,x1,y1,r1); stops.forEach((c,i)=>gr.addColorStop(i/(stops.length-1), c)); return gr; }
function path(g, pts, close=true){ g.beginPath(); pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1])); if(close) g.closePath(); }
function sparkle(g, x, y, s, col="#fff8e0", a=1){ g.save(); g.globalCompositeOperation="lighter"; g.globalAlpha=a; g.fillStyle=col;
  g.beginPath(); g.moveTo(x, y-s); g.quadraticCurveTo(x, y, x+s*.28, y); g.quadraticCurveTo(x, y, x, y+s); g.quadraticCurveTo(x, y, x-s*.28, y); g.quadraticCurveTo(x, y, x, y-s); g.fill();
  g.beginPath(); g.moveTo(x-s*.7, y); g.quadraticCurveTo(x, y, x, y-s*.2); g.quadraticCurveTo(x, y, x+s*.7, y); g.quadraticCurveTo(x, y, x, y+s*.2); g.quadraticCurveTo(x, y, x-s*.7, y); g.fill();
  World.glow(g, col, x, y, s*1.6, .6*a); g.restore(); }
function shadowUnder(g, x, y, w){ g.fillStyle = rg(g, x,y,0, x,y,w, ["rgba(0,0,0,.55)","rgba(0,0,0,0)"]); g.beginPath(); g.ellipse(x, y, w, w*.28, 0, 0, TAU2); g.fill(); }
/* medallion backdrop tinted by the tag colour */
function medallion(g, col){
  g.fillStyle = rg(g, 44,36,4, 50,52,50, [World.mix(col,"#ffffff",.05), World.mix(col,"#120a1c",.72), "#07040b"]); g.beginPath(); g.arc(50,50,47,0,TAU2); g.fill();
  aglow(g, col, 50, 56, 44, .22);
  g.lineWidth = 2.2; g.strokeStyle = lg(g, 10,10,90,90, [World.mix(col,"#ffffff",.55), World.mix(col,"#000",.1), World.mix(col,"#000",.55)]); g.beginPath(); g.arc(50,50,46,0,TAU2); g.stroke();
  g.lineWidth = .8; g.strokeStyle = "rgba(255,255,255,.18)"; g.beginPath(); g.arc(50,50,43,Math.PI*1.05,Math.PI*1.7); g.stroke();
}
/* ---------- reusable painted parts ---------- */
function blade(g, len, w, steelL, steelD, glowCol, glowA){
  g.fillStyle = lg(g, 0,-w,0,w, [steelL, World.mix(steelL, steelD, .5), steelD]);
  path(g, [[0,-w],[len-w*2.2,-w*.8],[len,0],[len-w*2.2,w*.8],[0,w]]); g.fill();
  g.strokeStyle = "rgba(255,255,255,.75)"; g.lineWidth = .7; g.beginPath(); g.moveTo(2,-w+.6); g.lineTo(len-w*2.2,-w*.8+.4); g.lineTo(len-.5,0); g.stroke();
  g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = .8; g.beginPath(); g.moveTo(3,0); g.lineTo(len-w*3,0); g.stroke();
  if(glowCol){ aglow(g, glowCol, len*.6, 0, len*.45, glowA||.35); }
}
function hilt(g, gold="#d8b25a", grip="#4a2e1c"){
  g.fillStyle = lg(g,0,-10,0,10,[World.mix(gold,"#fff",.45), gold, World.mix(gold,"#000",.45)]); path(g, [[-2,-11],[3,-12],[4,-3],[4,3],[3,12],[-2,11],[0,0]]); g.fill();
  g.fillStyle = lg(g,0,-2.5,0,2.5,[World.mix(grip,"#fff",.25), grip, World.mix(grip,"#000",.5)]); g.fillRect(-16,-2.4,15,4.8);
  g.strokeStyle = "rgba(0,0,0,.4)"; g.lineWidth = .6; for(let x=-15;x<-2;x+=2.6){ g.beginPath(); g.moveTo(x,-2.4); g.lineTo(x+1.3,2.4); g.stroke(); }
  g.fillStyle = rg(g,-19,-1,0,-18,0,4,[World.mix(gold,"#fff",.6), gold, World.mix(gold,"#000",.5)]); g.beginPath(); g.arc(-18.5,0,3.8,0,TAU2); g.fill();
}
function sword(g, x, y, ang, len=62, glowCol=null, steel=["#f4f7fc","#5a6070"]){
  g.save(); g.translate(x,y); g.rotate(ang); blade(g, len, 4.2, steel[0], steel[1], glowCol, .4); hilt(g); g.restore();
}
function flame(g, x, y, s, cols=["#fff6c8","#ffc04a","#ff6a1a","#b8240a"], t=0){
  const lick = (w,h,k)=>{ g.beginPath(); g.moveTo(x-w, y); g.bezierCurveTo(x-w*1.1, y-h*.5, x-w*.3+Math.sin(k)*w*.3, y-h*.7, x+Math.sin(k+1)*w*.25, y-h);
    g.bezierCurveTo(x+w*.3, y-h*.7, x+w*1.1, y-h*.45, x+w, y); g.quadraticCurveTo(x, y+w*.5, x-w, y); g.fill(); };
  g.save(); g.globalCompositeOperation = "source-over";
  g.fillStyle = cols[3]; lick(s*.62, s*1.25, 1.3); g.fillStyle = cols[2]; lick(s*.5, s*1.05, 2.1); g.fillStyle = cols[1]; lick(s*.36, s*.8, .4); g.fillStyle = cols[0]; lick(s*.2, s*.5, 2.8);
  aglow(g, cols[1], x, y - s*.45, s*1.4, .55); g.restore();
}
function drop(g, x, y, s, col="#c0102a"){
  g.fillStyle = rg(g, x-s*.3, y+s*.1, s*.1, x, y+s*.3, s*1.1, [World.mix(col,"#ffffff",.35), col, World.mix(col,"#000",.6)]);
  g.beginPath(); g.moveTo(x, y-s*1.25); g.bezierCurveTo(x+s*.35, y-s*.55, x+s, y, x+s, y+s*.4); g.arc(x, y+s*.4, s, 0, Math.PI); g.bezierCurveTo(x-s, y, x-s*.35, y-s*.55, x, y-s*1.25); g.fill();
  g.fillStyle = "rgba(255,255,255,.7)"; g.beginPath(); g.ellipse(x-s*.38, y+s*.1, s*.16, s*.32, -.4, 0, TAU2); g.fill();
}
function coinShape(g, x, y, r, face=true){
  g.fillStyle = World.mix("#8a5a10","#000",.2); g.beginPath(); g.ellipse(x, y+r*.12, r, r*.98, 0, 0, TAU2); g.fill();
  g.fillStyle = rg(g, x-r*.35, y-r*.4, r*.1, x, y, r, ["#fff4c0","#f2c14e","#b8801a"]); g.beginPath(); g.arc(x, y, r, 0, TAU2); g.fill();
  g.strokeStyle = "rgba(120,70,10,.8)"; g.lineWidth = r*.09; g.beginPath(); g.arc(x, y, r*.78, 0, TAU2); g.stroke();
  if(face){ g.fillStyle = "rgba(140,90,20,.85)"; const s = r*.42; path(g, [[x-s,y+s*.55],[x-s,y-s*.25],[x-s*.5,y+s*.1],[x,y-s*.6],[x+s*.5,y+s*.1],[x+s,y-s*.25],[x+s,y+s*.55]]); g.fill(); }
  g.strokeStyle = "rgba(255,255,255,.7)"; g.lineWidth = r*.07; g.beginPath(); g.arc(x, y, r*.9, Math.PI*1.1, Math.PI*1.55); g.stroke();
}
function gemShape(g, x, y, s, col="#ff3a5a"){
  const L = World.mix(col,"#ffffff",.55), M = col, D = World.mix(col,"#000",.55);
  const top = [[x-s,y-s*.25],[x-s*.55,y-s*.8],[x+s*.55,y-s*.8],[x+s,y-s*.25]];
  g.fillStyle = D; path(g, [[x-s,y-s*.25],[x+s,y-s*.25],[x,y+s]]); g.fill();
  g.fillStyle = M; path(g, [[x-s*.45,y-s*.25],[x+s*.45,y-s*.25],[x,y+s]]); g.fill();
  g.fillStyle = World.mix(col,"#000",.25); path(g, [[x-s,y-s*.25],[x-s*.45,y-s*.25],[x,y+s]]); g.fill();
  g.fillStyle = L; path(g, top); g.fill();
  g.fillStyle = World.mix(col,"#ffffff",.8); path(g, [[x-s*.55,y-s*.8],[x-s*.1,y-s*.8],[x-s*.4,y-s*.25],[x-s,y-s*.25]]); g.fill();
  g.strokeStyle = "rgba(255,255,255,.5)"; g.lineWidth = .7; path(g, [...top, [x,y+s]]); g.stroke();
  aglow(g, col, x, y, s*1.8, .35); sparkle(g, x-s*.45, y-s*.55, s*.45);
}
function heartShape(g, x, y, s, col="#e8243e"){
  g.fillStyle = rg(g, x-s*.4, y-s*.4, s*.1, x, y, s*1.3, [World.mix(col,"#ffffff",.45), col, World.mix(col,"#000",.6)]);
  g.beginPath(); g.moveTo(x, y+s); g.bezierCurveTo(x-s*1.5, y, x-s*1.1, y-s*1.15, x, y-s*.45); g.bezierCurveTo(x+s*1.1, y-s*1.15, x+s*1.5, y, x, y+s); g.fill();
  g.fillStyle = "rgba(255,255,255,.55)"; g.beginPath(); g.ellipse(x-s*.5, y-s*.45, s*.22, s*.13, -.6, 0, TAU2); g.fill();
}
function flask(g, x, y, s, liquid="#e8243e", round=true){
  g.fillStyle = lg(g, x-4,y-s*1.5,x+4,y-s*1.5,["#a07850","#6a4a2a","#3a2614"]); g.fillRect(x-s*.28, y-s*1.55, s*.56, s*.35);
  g.fillStyle = "rgba(200,220,240,.35)"; g.fillRect(x-s*.24, y-s*1.2, s*.48, s*.4);
  g.save(); g.beginPath(); if(round){ g.arc(x, y, s*.85, 0, TAU2); } else { g.moveTo(x-s*.24,y-s*.8); g.lineTo(x-s*.8,y+s*.7); g.quadraticCurveTo(x,y+s*1.05,x+s*.8,y+s*.7); g.lineTo(x+s*.24,y-s*.8); g.closePath(); }
  g.fillStyle = "rgba(210,230,250,.18)"; g.fill(); g.clip();
  g.fillStyle = lg(g, x, y-s*.2, x, y+s, [World.mix(liquid,"#fff",.35), liquid, World.mix(liquid,"#000",.5)]); g.fillRect(x-s, y-s*.18, s*2, s*2);
  g.fillStyle = "rgba(255,255,255,.35)"; g.fillRect(x-s, y-s*.2, s*2, s*.06);
  for(let i=0;i<5;i++){ g.fillStyle = "rgba(255,255,255,.5)"; g.beginPath(); g.arc(x-s*.4+i*s*.2, y+s*.25-(i%2)*s*.2, s*.05+ (i%3)*s*.02, 0, TAU2); g.fill(); }
  g.restore();
  g.strokeStyle = "rgba(230,240,255,.8)"; g.lineWidth = 1.1; g.beginPath(); if(round) g.arc(x, y, s*.85, 0, TAU2); else { g.moveTo(x-s*.24,y-s*.8); g.lineTo(x-s*.8,y+s*.7); g.quadraticCurveTo(x,y+s*1.05,x+s*.8,y+s*.7); g.lineTo(x+s*.24,y-s*.8); } g.stroke();
  g.strokeStyle = "rgba(255,255,255,.8)"; g.lineWidth = 1.4; g.beginPath(); g.arc(x, y, s*.66, Math.PI*1.1, Math.PI*1.45); g.stroke();
  aglow(g, liquid, x, y+s*.2, s*1.4, .35);
}
function bolt(g, pts, col="#8ff0ff", w=2.4){
  g.save(); g.globalCompositeOperation = "lighter"; g.lineJoin = "round"; g.lineCap = "round";
  g.strokeStyle = World.rgba(col,.35); g.lineWidth = w*3.2; path(g, pts, false); g.stroke();
  g.strokeStyle = col; g.lineWidth = w*1.4; path(g, pts, false); g.stroke();
  g.strokeStyle = "#ffffff"; g.lineWidth = w*.6; path(g, pts, false); g.stroke();
  pts.forEach(p=>World.glow(g, col, p[0], p[1], w*6, .25)); g.restore();
}
function rays(g, x, y, r0, r1, n, col, a=.6, rot=0){
  g.save(); g.globalCompositeOperation = "lighter";
  for(let i=0;i<n;i++){ const ang = rot + i/n*TAU2, w = (i%2?.06:.1);
    g.fillStyle = lg(g, x, y, x+Math.cos(ang)*r1, y+Math.sin(ang)*r1, [World.rgba(col,a), World.rgba(col,0)]);
    path(g, [[x+Math.cos(ang-w)*r0, y+Math.sin(ang-w)*r0],[x+Math.cos(ang)*r1, y+Math.sin(ang)*r1],[x+Math.cos(ang+w)*r0, y+Math.sin(ang+w)*r0]]); g.fill(); }
  g.restore();
}
function chest(g, x, y, s, wood="#6a3a1c", trim="#d8b25a", glowCol=null, open=false){
  const w = s*1.3, h = s*.8;
  shadowUnder(g, x, y+h*.62, w*1.05);
  if(open && glowCol){ aglow(g, glowCol, x, y-h*.4, s*1.5, .8); rays(g, x, y-h*.3, s*.2, s*1.6, 10, glowCol, .45, -Math.PI/2+.15); }
  g.fillStyle = lg(g, x-w, y, x+w, y, [World.mix(wood,"#000",.45), World.mix(wood,"#fff",.12), World.mix(wood,"#000",.3)]); g.fillRect(x-w, y-h*.15, w*2, h*.75);
  g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = .8; for(let i=1;i<4;i++){ g.beginPath(); g.moveTo(x-w, y-h*.15+i*h*.19); g.lineTo(x+w, y-h*.15+i*h*.19); g.stroke(); }
  if(open){ g.fillStyle = lg(g, x, y-h*1.25, x, y-h*.15, [World.mix(wood,"#fff",.15), World.mix(wood,"#000",.4)]); path(g, [[x-w,y-h*.18],[x-w*.95,y-h*1.1],[x+w*.95,y-h*1.1],[x+w,y-h*.18]]); g.fill(); }
  else { g.fillStyle = lg(g, x, y-h, x, y-h*.1, [World.mix(wood,"#fff",.25), World.mix(wood,"#000",.2)]); g.beginPath(); g.moveTo(x-w, y-h*.15); g.bezierCurveTo(x-w, y-h*1.05, x+w, y-h*1.05, x+w, y-h*.15); g.closePath(); g.fill(); }
  g.fillStyle = lg(g, 0, y-h, 0, y+h*.6, [World.mix(trim,"#fff",.5), trim, World.mix(trim,"#000",.45)]);
  for(const bx of [-w*.72, w*.6]) g.fillRect(x+bx, y-h*(open?1.1:.8), w*.12, h*(open?1.7:1.4));
  g.fillRect(x-w, y-h*.2, w*2, h*.1); g.fillRect(x-w*.14, y-h*.18, w*.28, h*.3);
  g.fillStyle = "#1a0e06"; g.fillRect(x-w*.04, y-h*.1, w*.08, h*.14);
}
function helmIcon(g, x, y, sc, sk){ g.save(); g.translate(x, y); g.scale(sc, sc); World.drawHelm(g, sk, 0, 1, 0, 0); g.restore(); }
function book(g, x, y, s){
  shadowUnder(g, x, y+s*.55, s*1.2);
  g.fillStyle = "#3a1a10"; path(g, [[x-s*1.15,y+s*.45],[x-s*1.1,y-s*.55],[x,y-s*.35],[x+s*1.1,y-s*.55],[x+s*1.15,y+s*.45],[x,y+s*.62]]); g.fill();
  const page = (side)=>{ g.fillStyle = lg(g, x, y, x+side*s, y, ["#c8b890","#f4ead0","#e0d0a8"]); path(g, [[x, y-s*.3],[x+side*s, y-s*.5],[x+side*s*1.02, y+s*.38],[x, y+s*.52]]); g.fill(); };
  page(-1); page(1);
  g.strokeStyle = "rgba(90,60,30,.5)"; g.lineWidth = .7; for(let i=0;i<5;i++){ for(const sd of [-1,1]){ g.beginPath(); g.moveTo(x+sd*s*.15, y-s*.18+i*s*.14); g.lineTo(x+sd*s*.85, y-s*.33+i*s*.14); g.stroke(); } }
  g.save(); g.globalCompositeOperation="lighter"; g.fillStyle = "#c9a2ff"; g.font = `700 ${s*.5}px serif`; g.textAlign = "center"; g.fillText("ᚱ", x-s*.5, y+s*.1); g.fillText("ᛟ", x+s*.5, y+s*.05); g.restore();
  aglow(g, "#c9a2ff", x, y-s*.1, s*1.4, .45); sparkle(g, x+s*.2, y-s*.8, s*.25, "#e8d8ff"); sparkle(g, x-s*.5, y-s*.95, s*.18, "#e8d8ff");
}
function skull(g, x, y, s, eye="#ff5a3c"){
  g.fillStyle = rg(g, x-s*.3, y-s*.4, s*.1, x, y, s*1.1, ["#f4ecd8","#cfc4a8","#7a6e58"]);
  g.beginPath(); g.arc(x, y-s*.15, s*.8, Math.PI*.9, Math.PI*2.1); g.lineTo(x+s*.55, y+s*.45); g.lineTo(x-s*.55, y+s*.45); g.closePath(); g.fill();
  g.fillStyle = "#cfc4a8"; g.fillRect(x-s*.42, y+s*.4, s*.84, s*.32);
  g.fillStyle = "#140a08"; g.beginPath(); g.ellipse(x-s*.3, y-s*.05, s*.2, s*.24, 0, 0, TAU2); g.ellipse(x+s*.3, y-s*.05, s*.2, s*.24, 0, 0, TAU2); g.fill();
  path(g, [[x, y+s*.1],[x-s*.08, y+s*.3],[x+s*.08, y+s*.3]]); g.fill();
  g.strokeStyle = "#140a08"; g.lineWidth = s*.05; for(let i=-2;i<=2;i++){ g.beginPath(); g.moveTo(x+i*s*.14, y+s*.46); g.lineTo(x+i*s*.14, y+s*.7); g.stroke(); }
  aglow(g, eye, x-s*.3, y-s*.05, s*.3, .9); aglow(g, eye, x+s*.3, y-s*.05, s*.3, .9);
}

/* ---------- the icon catalogue: each paints into a 100×100 box ---------- */
/* a carved rune stone; glyph 0-5 */
function runeStone(g, col, glyph){
  shadowUnder(g,50,86,26); aglow(g, col, 50, 50, 42, .4);
  g.fillStyle = lg(g,20,16,80,84,["#8a8298","#4a4456","#221e2a"]); g.beginPath(); g.moveTo(30,20); g.quadraticCurveTo(50,10,70,20); g.quadraticCurveTo(80,50,70,82); g.quadraticCurveTo(50,90,30,82); g.quadraticCurveTo(20,50,30,20); g.fill();
  g.strokeStyle = "rgba(255,255,255,.25)"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(31,22); g.quadraticCurveTo(50,13,69,22); g.stroke();
  g.save(); g.strokeStyle = World.mix(col,"#ffffff",.35); g.lineWidth = 4.2; g.lineCap = "round"; g.lineJoin = "round"; g.shadowColor = col; g.shadowBlur = 10; g.beginPath();
  const G = [ [[40,30],[60,50],[40,50],[60,70]], null, [[36,50],[50,30],[64,50],[50,70],[36,50]], [[38,30],[56,48],[40,48],[62,72]], [[38,30],[38,70],[62,70],[62,30]], null ][glyph];
  if(glyph===1){ g.moveTo(50,28); g.lineTo(50,72); g.moveTo(36,44); g.lineTo(50,58); g.lineTo(64,44); }
  else if(glyph===5){ g.moveTo(50,28); g.lineTo(50,72); g.moveTo(36,40); g.lineTo(50,50); g.lineTo(64,40); g.moveTo(36,56); g.lineTo(50,66); g.lineTo(64,56); }
  else { g.moveTo(G[0][0],G[0][1]); for(let i=1;i<G.length;i++) g.lineTo(G[i][0],G[i][1]); }
  g.stroke(); g.restore(); aglow(g, col, 50, 50, 22, .45);
}
const ART = {
  // BLADE
  edge:g=>{ medallion(g,"#dfe6f2"); sword(g, 22, 80, -.82, 70, "#bfe0ff"); for(let i=0;i<5;i++) sparkle(g, 52+i*7, 44-i*6, 2.5+ (i%2)*1.5, "#ffffff", .9); },
  twin:g=>{ medallion(g,"#dfe6f2"); sword(g, 20, 78, -.8, 66, "#cfe0ff"); sword(g, 80, 78, -Math.PI+.8, 66, "#cfe0ff");
    g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="rgba(210,230,255,.55)"; g.lineWidth=2; g.beginPath(); g.arc(50,58,34,-2.6,-1.9); g.stroke(); g.beginPath(); g.arc(50,58,34,-1.25,-.55); g.stroke(); g.restore(); sparkle(g, 50, 36, 6); },
  execute:g=>{ medallion(g,"#dfe6f2"); g.save(); g.translate(28,82); g.rotate(-.9); World.drawWeapon(g, {type:"axe", glow:"#ff3a3a", steelL:"#eef0f4", steelD:"#3a3e48", trim:"#9a7a4a", wood:"#3a2616", len:66}, 1, 0, 1); g.restore(); drop(g, 70, 70, 4, "#b00a20"); drop(g, 78, 60, 3, "#b00a20"); },
  // BLEED
  serrated:g=>{ medallion(g,"#ff5a64"); g.save(); g.translate(22,80); g.rotate(-.82);
    g.fillStyle = lg(g,0,-5,0,5,["#f4f7fc","#9aa0ae","#4a4e58"]); const pts=[[0,-5]]; for(let i=0;i<9;i++){ pts.push([6+i*7,-5.5-(i%2)*3]); } pts.push([72,0],[64,5],[0,5]); path(g,pts); g.fill();
    g.fillStyle = "#b00a20"; g.beginPath(); g.moveTo(30,5); g.quadraticCurveTo(34,14,31,18); g.quadraticCurveTo(28,12,26,5); g.fill(); g.beginPath(); g.moveTo(48,5); g.quadraticCurveTo(51,11,49,14); g.quadraticCurveTo(46,10,44,5); g.fill();
    hilt(g, "#8a7a5a", "#2a1a10"); g.restore(); drop(g, 66, 76, 4.5); },
  hemorrhage:g=>{ medallion(g,"#ff5a64"); drop(g, 42, 44, 15); drop(g, 66, 62, 9); drop(g, 32, 72, 6);
    g.fillStyle = "rgba(160,10,30,.8)"; for(let i=0;i<7;i++){ g.beginPath(); g.arc(24+i*9, 84+(i%2)*3, 1.4+(i%3), 0, TAU2); g.fill(); } },
  bloodprice:g=>{ medallion(g,"#ff5a64"); shadowUnder(g, 50, 86, 20);
    const gold = y=>lg(g,30,y,70,y,["#7a5212","#fff0b0","#d8a83a","#7a5212"]);
    g.fillStyle = gold(0); g.beginPath(); g.moveTo(28,26); g.lineTo(72,26); g.bezierCurveTo(72,50,62,58,50,58); g.bezierCurveTo(38,58,28,50,28,26); g.fill();
    g.fillRect(47,56,6,18); g.beginPath(); g.ellipse(50,82,16,5,0,0,TAU2); g.fill(); g.fillRect(40,74,20,8);
    g.fillStyle = rg(g,45,26,1,50,28,22,["#ff4a5a","#a00a20","#50040e"]); g.beginPath(); g.ellipse(50,27,21,5,0,0,TAU2); g.fill();
    g.fillStyle = "#a00a20"; g.beginPath(); g.moveTo(66,28); g.quadraticCurveTo(72,40,69,48); g.quadraticCurveTo(66,40,62,29); g.fill(); drop(g, 69, 52, 3);
    g.fillStyle = "#ff5a8a"; [38,50,62].forEach(x=>{ g.beginPath(); g.arc(x,42,2.4,0,TAU2); g.fill(); }); aglow(g,"#ff2a4a",50,28,26,.4); },
  // FIRE
  ember:g=>{ medallion(g,"#ff8a2a"); sword(g, 22, 82, -.82, 66, null, ["#ffe0b0","#6a3020"]); flame(g, 50, 50, 20); flame(g, 64, 38, 13); flame(g, 38, 64, 11); },
  fireball:g=>{ medallion(g,"#ff8a2a");
    g.save(); g.translate(60,40); g.rotate(2.36);
    for(const [w,l,c] of [[20,58,"#b8240a"],[15,50,"#ff6a1a"],[10,40,"#ffc04a"],[5,30,"#fff6c8"]]){ g.fillStyle = lg(g,0,0,l,0,[c, World.rgba(c,0)]); g.beginPath(); g.moveTo(0,-w); g.bezierCurveTo(l*.4,-w*.9,l*.7,-w*.3,l,0); g.bezierCurveTo(l*.7,w*.3,l*.4,w*.9,0,w); g.closePath(); g.fill(); }
    g.restore();
    g.fillStyle = rg(g, 56,36,2, 60,40,19, ["#fffbe8","#ffd060","#ff7a1a","rgba(200,40,10,0)"]); g.beginPath(); g.arc(60,40,19,0,TAU2); g.fill();
    aglow(g,"#ff8a2a",60,40,34,.6); for(let i=0;i<6;i++) sparkle(g, 26+i*5, 60+(i%3)*7, 2, "#ffd080", .8); },
  inferno:g=>{ medallion(g,"#ff8a2a"); rays(g, 50, 54, 6, 44, 14, "#ffb04a", .8, .2);
    g.fillStyle = rg(g, 48,50,2, 50,54,22, ["#fffbe0","#ffc84a","#ff5a1a","rgba(160,20,10,0)"]); g.beginPath(); g.arc(50,54,22,0,TAU2); g.fill();
    g.fillStyle = "#2a1208"; for(let i=0;i<8;i++){ const a=i/8*TAU2+.3, r=28+ (i%3)*5; g.save(); g.translate(50+Math.cos(a)*r, 54+Math.sin(a)*r); g.rotate(a); path(g,[[-3,-2],[3,-1],[2,3],[-2,2]]); g.fill(); g.restore(); }
    aglow(g,"#ff7a1a",50,54,40,.5); },
  // HOLY
  light:g=>{ medallion(g,"#ffe07a"); rays(g, 50, 50, 12, 46, 16, "#ffe9a0", .75, .1);
    g.fillStyle = rg(g, 47,47,1, 50,50,16, ["#ffffff","#fff4c8","#ffd060","rgba(255,200,80,0)"]); g.beginPath(); g.arc(50,50,16,0,TAU2); g.fill();
    g.strokeStyle = "#ffe9a0"; g.lineWidth = 2.2; g.beginPath(); g.ellipse(50,22,14,4,0,0,TAU2); g.stroke(); aglow(g,"#ffe07a",50,50,40,.6); },
  smite:g=>{ medallion(g,"#ffe07a");
    g.save(); g.globalCompositeOperation="lighter"; g.fillStyle = lg(g,50,0,50,86,["rgba(255,240,180,0)","rgba(255,236,160,.85)","#ffffff"]); path(g,[[42,4],[58,4],[62,84],[38,84]]); g.fill(); g.restore();
    g.save(); g.translate(50,70); g.rotate(-Math.PI/2+.02); World.drawWeapon(g,{type:"mace", glow:"#ffe07a", trim:"#e8c060", steelL:"#fff8e0", steelD:"#8a7040", wood:"#6a4a2a", len:50},1,0,1); g.restore();
    rays(g, 50, 84, 2, 30, 10, "#fff0b0", .7, Math.PI); },
  flask:g=>{ medallion(g,"#ffe07a"); flask(g, 50, 58, 22, "#ffcf4a"); sparkle(g, 70, 30, 5); sparkle(g, 30, 36, 3.5); rays(g, 50, 58, 20, 40, 8, "#ffe9a0", .35); },
  // SHIELD
  ironskin:g=>{ medallion(g,"#5aa0ff"); g.save(); g.translate(50,52); g.scale(2.2,2.2); World.drawShield(g,{type:"kite", col:"#3a4a62", trim:"#cfd8e8", emblem:"cross", emblemCol:"#e8eef8"},1); g.restore();
    g.fillStyle="#e8eef8"; [[34,34],[66,34],[50,82]].forEach(p=>{ g.beginPath(); g.arc(p[0],p[1],1.6,0,TAU2); g.fill(); }); sparkle(g, 36, 30, 4); },
  thorns:g=>{ medallion(g,"#5aa0ff"); g.save(); g.translate(50,54); g.scale(2,2); World.drawShield(g,{type:"round", col:"#2a3a2a", trim:"#9aa89a"},1); g.restore();
    g.strokeStyle = "#3a5a22"; g.lineWidth = 4; g.lineCap="round"; g.beginPath(); g.moveTo(16,70); g.bezierCurveTo(30,30,70,80,84,36); g.stroke(); g.strokeStyle="#6a8a3a"; g.lineWidth=1.4; g.stroke();
    g.fillStyle = "#e8e0c0"; for(let i=0;i<9;i++){ const t=i/8, x=16+68*t, y=70-34*t+Math.sin(t*6.3)*12; const a=(i%2?-1:1); path(g,[[x-2,y],[x+ a*1,y-9*a],[x+2,y]]); g.fill(); }
    g.fillStyle="#6a9a3a"; for(let i=0;i<4;i++){ g.beginPath(); g.ellipse(26+i*16, 58-i*6, 4, 2, .6, 0, TAU2); g.fill(); } },
  bulwark:g=>{ medallion(g,"#5aa0ff"); shadowUnder(g,50,88,22);
    g.fillStyle = lg(g,26,0,74,0,["#1a2438","#4a6a9a","#2a3a58"]); path(g,[[28,18],[72,18],[74,76],[50,90],[26,76]]); g.fill();
    g.strokeStyle = lg(g,0,18,0,90,["#fff0c0","#d8b25a","#7a5a20"]); g.lineWidth=3; g.stroke();
    g.fillStyle="#d8b25a"; g.fillRect(47,22,6,60); g.fillRect(32,40,36,6);
    g.fillStyle="#e8eef8"; for(const p of [[33,24],[67,24],[33,70],[67,70]]){ g.beginPath(); g.arc(p[0],p[1],1.8,0,TAU2); g.fill(); }
    g.fillStyle="rgba(255,255,255,.25)"; path(g,[[30,20],[40,20],[34,74],[28,74]]); g.fill(); },
  // STORM
  chain:g=>{ medallion(g,"#7ee0ff"); const o=[[24,30],[74,44],[34,76]];
    bolt(g,[[24,30],[40,40],[36,34],[58,44],[74,44]]); bolt(g,[[74,44],[60,56],[64,62],[44,68],[34,76]]);
    o.forEach(p=>{ g.fillStyle=rg(g,p[0]-2,p[1]-2,0,p[0],p[1],7,["#ffffff","#8ff0ff","#1a6a8a"]); g.beginPath(); g.arc(p[0],p[1],6,0,TAU2); g.fill(); aglow(g,"#8ff0ff",p[0],p[1],16,.7); }); },
  tempest:g=>{ medallion(g,"#7ee0ff"); g.save(); g.globalCompositeOperation="lighter";
    for(let i=0;i<8;i++){ const y=22+i*8, w=30-i*3.2; g.strokeStyle = World.rgba(i%2?"#bff4ff":"#6ad0f0", .85-i*.06); g.lineWidth = 3.2-i*.2; g.beginPath(); g.ellipse(50+Math.sin(i*.9)*4, y, w, 3.2, 0, .2, Math.PI*1.75); g.stroke(); }
    g.restore(); for(let i=0;i<4;i++){ g.fillStyle="#9ab0c0"; g.save(); g.translate(26+i*16, 28+ (i%2)*40); g.rotate(i); g.fillRect(-2,-1,4,2); g.restore(); } aglow(g,"#7ee0ff",50,50,36,.35); },
  static:g=>{ medallion(g,"#7ee0ff");
    const cloud=(x,y,s,c)=>{ g.fillStyle=c; g.beginPath(); g.arc(x-s,y,s*.8,0,TAU2); g.arc(x,y-s*.5,s,0,TAU2); g.arc(x+s,y,s*.8,0,TAU2); g.rect(x-s*1.6,y,s*3.2,s*.7); g.fill(); };
    cloud(50,36,12,"#2a3a58"); cloud(50,33,11,lg(g,0,18,0,44,["#9ab0d0","#4a5a7a"]));
    bolt(g,[[48,44],[42,58],[50,58],[42,78]], "#8ff0ff", 2.6); bolt(g,[[62,44],[66,54],[60,56],[64,66]], "#bff4ff", 1.6); },
  // CORE
  keen:g=>{ medallion(g,"#b8abd4");
    g.strokeStyle = "rgba(255,120,100,.8)"; g.lineWidth = 2; for(const r of [34,24]){ g.beginPath(); g.arc(50,50,r,0,TAU2); g.stroke(); }
    g.fillStyle = "#f4ecd8"; g.beginPath(); g.moveTo(22,50); g.quadraticCurveTo(50,26,78,50); g.quadraticCurveTo(50,74,22,50); g.fill();
    g.fillStyle = rg(g,48,48,1,50,50,12,["#fff0a0","#e8a020","#6a3a08"]); g.beginPath(); g.arc(50,50,11,0,TAU2); g.fill();
    g.fillStyle = "#140806"; g.beginPath(); g.ellipse(50,50,3,8,0,0,TAU2); g.fill(); g.fillStyle="#fff"; g.beginPath(); g.arc(46,46,2.4,0,TAU2); g.fill();
    g.strokeStyle="#3a2a1a"; g.lineWidth=1.6; g.beginPath(); g.moveTo(22,50); g.quadraticCurveTo(50,26,78,50); g.stroke(); aglow(g,"#ffcf4a",50,50,20,.4); },
  vigor:g=>{ medallion(g,"#ff6a7a"); heartShape(g, 50, 52, 24); aglow(g,"#ff4a5a",50,50,36,.4); sparkle(g, 64, 34, 4.5); },
  greed:g=>{ medallion(g,"#f2c14e"); shadowUnder(g,50,86,24);
    g.fillStyle = lg(g,26,0,74,0,["#5a3a1a","#9a6a3a","#4a2e12"]); g.beginPath(); g.moveTo(40,30); g.bezierCurveTo(18,40,20,82,50,84); g.bezierCurveTo(80,82,82,40,60,30); g.closePath(); g.fill();
    g.fillStyle="#7a4a1e"; path(g,[[38,24],[62,24],[58,32],[42,32]]); g.fill(); g.strokeStyle="#d8b25a"; g.lineWidth=2.4; g.beginPath(); g.moveTo(38,32); g.lineTo(62,32); g.stroke();
    coinShape(g, 30, 80, 8); coinShape(g, 70, 78, 9); coinShape(g, 52, 88, 7); coinShape(g, 50, 26, 7); sparkle(g, 68, 60, 4); },
  heal:g=>{ medallion(g,"#5bd26a"); shadowUnder(g,50,82,26);
    g.fillStyle = lg(g,0,50,0,82,["#e8c890","#b88850","#6a4a28"]); g.beginPath(); g.ellipse(46,68,26,13,0,0,TAU2); g.fill();
    g.fillStyle = rg(g,40,56,2,48,66,26,["#e89a5a","#a8501e","#5a2a0e"]); g.beginPath(); g.moveTo(24,64); g.bezierCurveTo(24,44,60,40,66,56); g.bezierCurveTo(70,68,40,78,24,64); g.fill();
    g.fillStyle="#f4ecd8"; g.fillRect(64,50,14,5); g.beginPath(); g.arc(79,50,3.2,0,TAU2); g.arc(79,55,3.2,0,TAU2); g.fill();
    g.fillStyle="rgba(255,255,255,.35)"; g.beginPath(); g.ellipse(38,52,8,3,-.3,0,TAU2); g.fill();
    g.fillStyle="#c83a2a"; g.beginPath(); g.arc(68,72,7,0,TAU2); g.fill(); g.fillStyle="#3a7a2a"; g.beginPath(); g.ellipse(70,64,3,1.5,.6,0,TAU2); g.fill(); },
  // CURRENCIES (no medallion)
  gold:g=>{ coinShape(g, 58, 58, 24); coinShape(g, 40, 44, 26); sparkle(g, 30, 28, 6); },
  orbs:g=>{ g.fillStyle = rg(g,42,38,3,50,52,34,["#fbe8ff","#b36bff","#3a1070","rgba(20,0,40,0)"]); g.beginPath(); g.arc(50,52,33,0,TAU2); g.fill();
    flame(g, 50, 66, 18, ["#ffffff","#e8c8ff","#b36bff","#5a1aa8"]); g.strokeStyle="rgba(255,255,255,.7)"; g.lineWidth=2; g.beginPath(); g.arc(50,52,28,Math.PI*1.1,Math.PI*1.5); g.stroke(); aglow(g,"#c9a2ff",50,52,40,.5); },
  gems:g=>{ gemShape(g, 50, 52, 32, "#ff3a6a"); },
  // TABS
  battle:g=>{ sword(g, 18, 84, -.82, 72, "#cfe0ff"); sword(g, 82, 84, -Math.PI+.82, 72, "#ffd0a0"); sparkle(g, 50, 36, 6); },
  hero:g=>{ aglow(g,"#c9a2ff",50,54,40,.35); helmIcon(g, 42, 174, 2.15, {helm:"winged", wingCol:"#f1f6ff", helmD:"#2a2934", helmL:"#d8d4e8", trim:"#d8b25a", glow:"#c9a2ff"}); },
  skills:g=>{ book(g, 50, 60, 30); },
  shop:g=>{ chest(g, 50, 62, 26, "#5a3018", "#d8b25a", "#ffd86a", true); gemShape(g, 50, 44, 10, "#ff3a6a"); coinShape(g, 36, 50, 6); coinShape(g, 64, 48, 6); },
  // TRAINING
  vit:g=>{ medallion(g,"#ff6a7a"); heartShape(g, 50, 54, 22); g.fillStyle="#fff4f0"; g.fillRect(46,40,8,24); g.fillRect(38,48,24,8); aglow(g,"#ffffff",50,52,14,.35); },
  might:g=>{ medallion(g,"#dfe6f2");
    g.fillStyle = lg(g,30,0,70,0,["#3a3e48","#c8ccd8","#5a5e6a"]); g.beginPath(); g.moveTo(30,84); g.lineTo(34,56); g.quadraticCurveTo(30,40,40,34); g.lineTo(62,32); g.quadraticCurveTo(72,36,70,50); g.lineTo(66,84); g.closePath(); g.fill();
    g.strokeStyle="rgba(0,0,0,.4)"; g.lineWidth=1.2; for(let i=0;i<4;i++){ g.beginPath(); g.moveTo(38+i*8,34); g.lineTo(38+i*8,48); g.stroke(); } g.beginPath(); g.moveTo(34,56); g.lineTo(68,54); g.stroke();
    g.fillStyle="#d8b25a"; g.fillRect(32,66,36,5); sparkle(g, 64, 28, 5); aglow(g,"#ffffff",52,40,20,.3); },
  plating:g=>{ medallion(g,"#5aa0ff"); shadowUnder(g,50,86,22);
    const steel = lg(g,24,0,76,0,["#2a3446","#8aa0c0","#e8eef8","#6a7a98","#2a3446"]);
    g.fillStyle = steel; g.beginPath(); g.moveTo(30,28); g.lineTo(42,24); g.quadraticCurveTo(50,30,58,24); g.lineTo(70,28); g.bezierCurveTo(74,48,72,68,62,84); g.lineTo(38,84); g.bezierCurveTo(28,68,26,48,30,28); g.fill();
    g.strokeStyle = "#d8b25a"; g.lineWidth = 2; g.stroke();
    for(const sd of [-1,1]){ g.fillStyle = steel; g.beginPath(); g.ellipse(50+sd*24,32,12,8,sd*.4,0,TAU2); g.fill(); g.strokeStyle="#d8b25a"; g.lineWidth=1.4; g.stroke(); }
    g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(50,32); g.lineTo(50,82); g.moveTo(34,56); g.quadraticCurveTo(50,62,66,56); g.moveTo(36,68); g.quadraticCurveTo(50,74,64,68); g.stroke();
    g.fillStyle = "rgba(255,255,255,.35)"; g.beginPath(); g.ellipse(42,44,4,12,.2,0,TAU2); g.fill(); sparkle(g, 64, 40, 4); },
  alchemy:g=>{ medallion(g,"#5bd26a"); flask(g, 50, 60, 20, "#4ae08a", false);
    for(let i=0;i<4;i++){ g.fillStyle = World.rgba("#bfffd8", .7-i*.15); g.beginPath(); g.arc(46+i*4, 30-i*6, 3-i*.4, 0, TAU2); g.fill(); } aglow(g,"#4ae08a",50,64,30,.4); },
  flasks:g=>{ medallion(g,"#ff6a7a"); g.fillStyle = lg(g,0,62,0,74,["#8a5a2a","#5a3a18"]); g.fillRect(12,64,76,10); g.fillStyle="#d8b25a"; g.fillRect(46,63,8,12);
    flask(g, 28, 52, 11, "#e8243e"); flask(g, 50, 48, 12, "#ffcf4a"); flask(g, 72, 52, 11, "#4ab0ff"); },
  // CHALLENGES
  lastbreath:g=>{ medallion(g,"#ff5a6e"); skull(g, 50, 48, 24, "#ff4a3a"); heartShape(g, 50, 82, 7, "#ff2a4a"); aglow(g,"#ff2a4a",50,80,14,.6); },
  horde:g=>{ medallion(g,"#ff8a2a"); for(const [x,y,s] of [[30,56,12],[70,56,12],[50,62,15]]) skull(g, x, y, s, "#ffb03a"); for(let i=0;i<5;i++){ g.fillStyle="rgba(10,6,10,.8)"; g.beginPath(); g.arc(16+i*17, 88, 9, Math.PI, 0); g.fill(); } },
  dry:g=>{ medallion(g,"#6ab8ff"); flask(g, 50, 56, 22, "#20304a"); g.strokeStyle="#e8f0ff"; g.lineWidth=1.3; g.beginPath(); g.moveTo(40,44); g.lineTo(48,54); g.lineTo(44,60); g.lineTo(52,70); g.stroke(); aglow(g,"#6ab8ff",50,56,30,.2); },
  glass:g=>{ medallion(g,"#c9a2ff"); sword(g, 22, 82, -.82, 70, "#e8d8ff", ["#ffffff","#b8c8ff"]); g.strokeStyle="rgba(255,255,255,.95)"; g.lineWidth=1.1; g.beginPath(); g.moveTo(46,56); g.lineTo(52,50); g.lineTo(50,46); g.lineTo(58,42); g.stroke(); for(let i=0;i<5;i++) sparkle(g, 40+i*9, 60-i*9, 2.4, "#e8d8ff"); },
  // MODES & SHOP
  endless:g=>{ medallion(g,"#b36bff"); for(let i=0;i<7;i++){ g.strokeStyle = World.rgba(i%2?"#c9a2ff":"#6a3ad8", .9-i*.1); g.lineWidth=3-i*.3; g.beginPath(); g.arc(50,52,6+i*5.2, i*.9, i*.9+4.2); g.stroke(); }
    g.fillStyle=rg(g,50,52,0,50,52,10,["#ffffff","#c9a2ff","rgba(90,40,180,0)"]); g.beginPath(); g.arc(50,52,10,0,TAU2); g.fill(); aglow(g,"#b36bff",50,52,40,.5); },
  challenges:g=>{ medallion(g,"#ff8a2a"); g.fillStyle=lg(g,30,0,70,0,["#3a2e28","#8a7a6a","#3a2e28"]); path(g,[[30,62],[70,62],[62,76],[38,76]]); g.fill(); g.fillRect(44,76,12,10); g.fillRect(36,86,28,4); flame(g, 50, 62, 24); },
  potion:g=>{ flask(g, 50, 58, 26, "#e8243e"); sparkle(g, 72, 30, 5); },
  skull:g=>{ skull(g, 50, 50, 30, "#ff4a5a"); },
  chest:g=>{ chest(g, 50, 64, 27, "#6a3a1c", "#b8b0a0"); },
  knightchest:g=>{ chest(g, 50, 64, 27, "#2a1a3a", "#d8b25a", "#c9a2ff", true); gemShape(g, 50, 42, 9, "#c08aff"); },
  orbpouch:g=>{ shadowUnder(g,50,86,24); g.fillStyle = lg(g,26,0,74,0,["#2a1a4a","#5a3a8a","#1e1238"]); g.beginPath(); g.moveTo(40,34); g.bezierCurveTo(18,44,20,84,50,86); g.bezierCurveTo(80,84,82,44,60,34); g.closePath(); g.fill();
    g.strokeStyle="#d8b25a"; g.lineWidth=2.4; g.beginPath(); g.moveTo(38,36); g.lineTo(62,36); g.stroke(); for(const [x,y] of [[40,28],[58,26],[50,20]]){ g.fillStyle=rg(g,x-2,y-2,0,x,y,8,["#ffffff","#c9a2ff","#4a1a8a"]); g.beginPath(); g.arc(x,y,7,0,TAU2); g.fill(); aglow(g,"#c9a2ff",x,y,14,.5); } },
  squire:g=>{ shadowUnder(g,50,88,26); g.fillStyle = lg(g,26,0,74,0,["#4a2e14","#8a5a2a","#3a2410"]); g.beginPath(); g.moveTo(28,40); g.quadraticCurveTo(26,86,50,86); g.quadraticCurveTo(74,86,72,40); g.closePath(); g.fill();
    g.fillStyle = lg(g,0,26,0,52,["#a06a34","#6a4020"]); g.beginPath(); g.moveTo(26,42); g.quadraticCurveTo(50,22,74,42); g.lineTo(70,56); g.quadraticCurveTo(50,48,30,56); g.closePath(); g.fill();
    g.fillStyle="#d8b25a"; g.fillRect(46,52,8,8); gemShape(g, 36, 30, 7, "#ff3a6a"); gemShape(g, 62, 28, 6, "#4ae0c8"); aglow(g,"#c9a2ff",60,28,12,.4); },
  gemchest:g=>{ chest(g, 50, 66, 26, "#3a1a2a", "#d8b25a", "#ff4a7a", true); gemShape(g, 38, 44, 8, "#ff3a6a"); gemShape(g, 56, 40, 10, "#ff3a6a"); gemShape(g, 68, 48, 7, "#ff6a8a"); },
  crown:g=>{ shadowUnder(g,50,84,26); g.fillStyle = rg(g,50,76,2,50,76,34,["#a02a4a","#5a0a24"]); g.beginPath(); g.ellipse(50,78,32,9,0,0,TAU2); g.fill();
    g.fillStyle = lg(g,0,34,0,74,["#fff4c0","#f2c14e","#8a5a10"]); path(g,[[24,72],[20,38],[34,54],[42,30],[50,48],[58,30],[66,54],[80,38],[76,72]]); g.fill(); g.strokeStyle="rgba(255,255,255,.6)"; g.lineWidth=1; g.stroke();
    for(const [x,y,c] of [[50,62,"#ff3a5a"],[34,64,"#4ab0ff"],[66,64,"#4ae08a"]]) gemShape(g, x, y, 5, c); for(const [x,y] of [[20,36],[42,28],[58,28],[80,36]]){ g.fillStyle="#fff4c0"; g.beginPath(); g.arc(x,y,3,0,TAU2); g.fill(); } sparkle(g, 72, 26, 5); },
  noads:g=>{ shadowUnder(g,50,86,26); g.fillStyle = lg(g,0,20,0,80,["#f4ead0","#d8c8a0"]); g.fillRect(24,22,52,58); g.fillStyle="#b8a880"; g.beginPath(); g.ellipse(50,22,28,5,0,0,TAU2); g.ellipse(50,80,28,5,0,0,TAU2); g.fill();
    g.strokeStyle="rgba(90,60,30,.55)"; g.lineWidth=1.2; for(let i=0;i<5;i++){ g.beginPath(); g.moveTo(32,34+i*8); g.lineTo(68-(i%2)*8,34+i*8); g.stroke(); }
    g.fillStyle = rg(g,60,70,1,62,72,12,["#ff6a6a","#b0101a","#5a0008"]); g.beginPath(); g.arc(62,72,11,0,TAU2); g.fill(); g.fillStyle="#7a0a12"; g.beginPath(); g.arc(62,72,6,0,TAU2); g.fill();
    g.fillStyle="#b0101a"; path(g,[[56,80],[60,94],[63,84]]); g.fill(); path(g,[[66,80],[70,92],[64,84]]); g.fill(); },
  cleave:g=>{ medallion(g,"#dfe6f2"); g.save(); g.globalCompositeOperation="lighter";
    for(let i=0;i<3;i++){ g.strokeStyle = World.rgba(i?"#cfe0ff":"#ffffff", .85-i*.25); g.lineWidth = 6-i*1.6; g.lineCap="round"; g.beginPath(); g.arc(34, 60, 30+i*6, -1.25, .35); g.stroke(); } g.restore();
    g.save(); g.translate(26,76); g.rotate(-1.05); World.drawWeapon(g,{type:"axe", glow:"#cfe0ff", steelL:"#f4f7fc", steelD:"#4a4e58", trim:"#d8b25a", wood:"#4a2e1c", len:52},1,0,1); g.restore();
    for(const [x,y] of [[70,40],[76,64]]){ g.fillStyle="rgba(20,10,20,.7)"; g.beginPath(); g.arc(x,y,7,0,TAU2); g.fill(); sparkle(g,x,y,4,"#ffffff"); } },
  whirl:g=>{ medallion(g,"#7ee0ff"); g.save(); g.globalCompositeOperation="lighter";
    for(let i=0;i<4;i++){ const a0=i*Math.PI/2; g.strokeStyle=World.rgba("#bff4ff",.8); g.lineWidth=3; g.beginPath(); g.arc(50,52,28,a0,a0+1.1); g.stroke(); g.strokeStyle=World.rgba("#6ad0f0",.5); g.lineWidth=7; g.beginPath(); g.arc(50,52,22,a0+.2,a0+1.2); g.stroke(); } g.restore();
    for(let i=0;i<3;i++){ g.save(); g.translate(50,52); g.rotate(i*TAU2/3+.4); g.translate(4,0); blade(g, 30, 3.2, "#f4f7fc", "#5a6070", "#bff4ff", .3); g.restore(); }
    g.fillStyle=rg(g,48,50,1,50,52,7,["#ffffff","#8ff0ff","#1a6a8a"]); g.beginPath(); g.arc(50,52,6,0,TAU2); g.fill(); },
  pierce:g=>{ medallion(g,"#b8abd4"); for(const [x,s] of [[46,12],[64,10],[80,8]]){ g.fillStyle="rgba(30,18,40,.85)"; g.beginPath(); g.ellipse(x,52,s*.7,s*1.6,0,0,TAU2); g.fill(); }
    g.save(); g.translate(10,52); World.drawWeapon(g,{type:"spear", glow:"#e8f0ff", steelL:"#ffffff", steelD:"#6a7a98", trim:"#d8b25a", wood:"#5a3a22", len:74},1,0,1); g.restore();
    g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="rgba(230,240,255,.8)"; g.lineWidth=1.5; for(let i=-1;i<=1;i++){ g.beginPath(); g.moveTo(40,52+i*6); g.lineTo(90,52+i*3); g.stroke(); } g.restore(); sparkle(g, 86, 52, 5); },
  ev_heal:g=>{ medallion(g,"#5bd26a"); shadowUnder(g,50,84,26); g.fillStyle=lg(g,24,0,76,0,["#3a3446","#9a92a8","#3a3446"]); path(g,[[22,82],[26,66],[74,66],[78,82]]); g.fill(); g.fillRect(44,40,12,28);
    g.fillStyle="#6affc8"; g.beginPath(); g.ellipse(50,66,24,4,0,0,TAU2); g.fill(); g.save(); g.globalCompositeOperation="lighter"; g.fillStyle=lg(g,50,24,50,66,["rgba(190,255,232,.9)","rgba(106,255,200,.2)"]); path(g,[[46,38],[54,38],[60,66],[40,66]]); g.fill(); g.restore();
    aglow(g,"#6affc8",50,52,34,.5); sparkle(g,36,34,4,"#e0fff4"); sparkle(g,66,30,3,"#e0fff4"); },
  ev_shrine:g=>{ medallion(g,"#c9a2ff"); shadowUnder(g,50,86,20); g.fillStyle=lg(g,38,0,62,0,["#2a2436","#8a8298","#3a3446"]); path(g,[[38,86],[42,26],[50,14],[58,26],[62,86]]); g.fill();
    g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="#e0ccff"; g.lineWidth=2.2; g.beginPath(); g.moveTo(50,32); g.lineTo(50,70); g.moveTo(43,44); g.lineTo(57,56); g.moveTo(57,44); g.lineTo(43,56); g.stroke(); g.restore(); aglow(g,"#c9a2ff",50,50,34,.55); sparkle(g,30,40,4,"#e8d8ff"); sparkle(g,72,58,3,"#e8d8ff"); },
  ev_altar:g=>{ medallion(g,"#ff5a64"); shadowUnder(g,50,84,28); g.fillStyle=lg(g,22,0,78,0,["#1a1014","#5a3a44","#1a1014"]); g.fillRect(24,52,52,32); g.fillStyle="#2a1a20"; g.fillRect(20,46,60,8);
    g.fillStyle=rg(g,50,44,1,50,46,14,["#ff4a5a","#8a0a1a","#3a0008"]); g.beginPath(); g.ellipse(50,46,13,4,0,0,TAU2); g.fill();
    for(const cx of [28,72]){ g.fillStyle="#e8dcc0"; g.fillRect(cx-2.5,28,5,18); flame(g, cx, 28, 5); } aglow(g,"#ff2a3a",50,48,30,.5); drop(g, 50, 64, 5); },
  ev_merchant:g=>{ medallion(g,"#f2c14e"); shadowUnder(g,50,86,24); g.strokeStyle="#8a6a3a"; g.lineWidth=2.4; g.beginPath(); g.moveTo(50,22); g.lineTo(50,70); g.moveTo(26,34); g.lineTo(74,34); g.stroke();
    for(const [x,c] of [[28,"#f2c14e"],[72,"#ff3a6a"]]){ g.strokeStyle="#6a5a3a"; g.lineWidth=1; g.beginPath(); g.moveTo(x-8,52); g.lineTo(x,34); g.lineTo(x+8,52); g.stroke(); g.fillStyle=lg(g,x-10,0,x+10,0,["#6a4a1a","#d8b25a","#6a4a1a"]); g.beginPath(); g.ellipse(x,53,11,3.5,0,0,TAU2); g.fill(); }
    coinShape(g,28,46,5); gemShape(g,72,46,5,"#ff3a6a"); g.fillStyle="#6a4a2a"; g.fillRect(40,70,20,14); sparkle(g,50,20,4); },
  // world map & modes
  arena:g=>{ medallion(g,"#ff8a2a"); sword(g, 22, 80, -.82, 64, "#ffd0a0"); g.save(); g.translate(76,78); g.rotate(-Math.PI+.82); World.drawWeapon(g,{type:"axe",glow:"#ff6a3a",trim:"#d8b25a",len:56},.8,0,1); g.restore(); g.save(); g.translate(50,58); g.scale(1.3,1.3); World.drawShield(g,{type:"round",col:"#5a1a14",trim:"#d8b25a",emblem:"sun"},1); g.restore(); },
  raid:g=>{ medallion(g,"#ff5a6e"); g.save(); g.translate(50,86); g.scale(.46,.46); const v = World.makeVis({kind:"creature",type:"golem",m:{d:"#2a1010",l:"#7a3a2a",rim:"#ff8a3a",crack:"#ff3a1a",eye:"#ffe08a"}},3); v.C.draw(g, v, {ld:1, atk:null, t:0}, 0); g.restore(); aglow(g,"#ff3a1a",50,50,36,.3); },
  quests:g=>{ medallion(g,"#f2c14e"); g.fillStyle=lg(g,0,18,0,86,["#f4ead0","#d8c8a0"]); g.fillRect(28,20,44,64); g.fillStyle="#b8a880"; g.beginPath(); g.ellipse(50,20,24,5,0,0,TAU2); g.ellipse(50,84,24,5,0,0,TAU2); g.fill();
    for(let i=0;i<4;i++){ g.strokeStyle="#6a5a3a"; g.lineWidth=1.6; g.beginPath(); g.moveTo(40,34+i*12); g.lineTo(64,34+i*12); g.stroke(); g.strokeStyle= i<2?"#3a9a4a":"#8a7a5a"; g.lineWidth=2.2; g.beginPath(); if(i<2){ g.moveTo(31,34+i*12); g.lineTo(34,37+i*12); g.lineTo(38,30+i*12); } else g.rect(31,30+i*12,6,6); g.stroke(); }
    sparkle(g,72,22,5); },
  map:g=>{ medallion(g,"#d0ab62"); g.fillStyle=lg(g,20,0,80,0,["#c8b890","#f0e4c0","#c8b890"]); path(g,[[20,26],[40,20],[60,28],[80,22],[80,78],[60,84],[40,76],[20,82]]); g.fill();
    g.strokeStyle="rgba(90,60,30,.35)"; g.lineWidth=1; g.beginPath(); g.moveTo(40,20); g.lineTo(40,76); g.moveTo(60,28); g.lineTo(60,84); g.stroke();
    g.strokeStyle="#9a2a2a"; g.lineWidth=2.2; g.setLineDash([3,3]); g.beginPath(); g.moveTo(26,70); g.bezierCurveTo(40,50,52,70,66,40); g.stroke(); g.setLineDash([]);
    g.strokeStyle="#9a2a2a"; g.lineWidth=3; g.beginPath(); g.moveTo(62,34); g.lineTo(70,44); g.moveTo(70,34); g.lineTo(62,44); g.stroke(); g.fillStyle="#2a6a2a"; for(const [x,y] of [[30,40],[48,58],[70,66]]){ path(g,[[x,y-6],[x-5,y+3],[x+5,y+3]]); g.fill(); } },
  trophy:g=>{ const gold=lg(g,30,0,70,0,["#7a5212","#fff0b0","#d8a83a","#7a5212"]); shadowUnder(g,50,88,20);
    g.fillStyle=gold; g.beginPath(); g.moveTo(30,22); g.lineTo(70,22); g.bezierCurveTo(70,50,60,58,50,58); g.bezierCurveTo(40,58,30,50,30,22); g.fill();
    g.strokeStyle=gold; g.lineWidth=4; g.beginPath(); g.arc(28,34,8,Math.PI*.5,Math.PI*1.5); g.stroke(); g.beginPath(); g.arc(72,34,8,-Math.PI*.5,Math.PI*.5); g.stroke();
    g.fillStyle=gold; g.fillRect(46,56,8,14); g.fillRect(36,70,28,8); g.fillRect(32,78,36,6); gemShape(g,50,36,6,"#ff3a5a"); },
  energy:g=>{ bolt(g,[[56,14],[36,54],[52,54],[40,88]],"#ffd86a",4); },
  key:g=>{ const gold=lg(g,0,30,0,70,["#fff0b0","#d8a83a","#7a5212"]); g.strokeStyle=gold; g.lineWidth=7; g.beginPath(); g.arc(34,40,14,0,TAU2); g.stroke(); g.fillStyle=gold; g.fillRect(44,37,40,7); g.fillRect(72,44,6,12); g.fillRect(60,44,5,9); aglow(g,"#ffd86a",40,42,30,.3); },
  frag:g=>{ shadowUnder(g,50,86,24); aglow(g,"#c86aff",50,50,44,.35);
    const shard=(x,y,s,a,c)=>{ g.save(); g.translate(x,y); g.rotate(a); g.fillStyle = lg(g,-s,-s*1.6,s,s*1.6,[World.mix(c,"#ffffff",.7), c, World.mix(c,"#000000",.55)]); path(g,[[0,-s*1.7],[s*.75,-s*.2],[s*.35,s*1.4],[-s*.5,s*1],[-s*.7,-s*.4]]); g.fill();
      g.fillStyle = "rgba(255,255,255,.55)"; path(g,[[0,-s*1.7],[s*.12,-s*.1],[-s*.7,-s*.4]]); g.fill(); g.restore(); };
    shard(36,62,11,-.5,"#8a4aff"); shard(66,64,9,.6,"#ff5aa8"); shard(51,46,17,.1,"#b86aff"); sparkle(g,62,28,7); sparkle(g,30,40,4); },
  dust:g=>{ shadowUnder(g,50,84,30); aglow(g,"#6ab8ff",50,56,40,.4);
    g.fillStyle = lg(g,0,56,0,86,["#6a5a8a","#2a1e3a"]); g.beginPath(); g.ellipse(50,70,30,13,0,0,TAU2); g.fill();
    g.fillStyle = rg(g,46,52,2,50,60,28,["#ffffff","#9fd8ff","#5a7aff","#3a2a8a"]); g.beginPath(); g.moveTo(22,66); g.quadraticCurveTo(34,38,50,40); g.quadraticCurveTo(68,38,78,66); g.quadraticCurveTo(50,74,22,66); g.fill();
    for(const [x,y,z] of [[40,48,4],[58,44,5],[50,30,6],[70,54,3],[30,58,3],[62,24,3]]) sparkle(g,x,y,z,"#dff4ff"); },
  starmetal:g=>{ shadowUnder(g,50,82,30); aglow(g,"#9fd8ff",50,54,40,.3);
    g.fillStyle = lg(g,0,50,0,78,["#dfe8f8","#8a9ab8","#3a4458"]); path(g,[[20,74],[30,52],[74,52],[82,74]]); g.fill();
    g.fillStyle = lg(g,0,40,0,56,["#ffffff","#b8c8e8"]); path(g,[[30,52],[36,42],[70,42],[74,52]]); g.fill();
    g.strokeStyle = "rgba(255,255,255,.8)"; g.lineWidth = 1; path(g,[[30,52],[36,42],[70,42],[74,52]]); g.stroke();
    sparkle(g,62,40,13,"#ffffff"); sparkle(g,34,62,5,"#cfe8ff"); },
  sigil:g=>{ aglow(g,"#3ff0d0",50,50,48,.45);
    g.fillStyle = rg(g,42,40,4,50,50,44,["#fff6d0","#e8b84a","#8a5a10"]); g.beginPath(); g.arc(50,50,40,0,TAU2); g.fill();
    g.fillStyle = rg(g,46,44,2,50,50,32,["#b8fff0","#1f8a80","#062a28"]); g.beginPath(); g.arc(50,50,31,0,TAU2); g.fill();
    g.strokeStyle = "#9affea"; g.lineWidth = 3; g.lineCap = "round"; g.beginPath(); g.moveTo(50,28); g.lineTo(50,72); g.moveTo(36,40); g.lineTo(64,60); g.moveTo(64,40); g.lineTo(36,60); g.stroke();
    g.beginPath(); g.arc(50,50,10,0,TAU2); g.stroke(); aglow(g,"#9affea",50,50,24,.6);
    for(let k=0;k<12;k++){ const a = k/12*TAU2; g.fillStyle = "#6a4a10"; g.beginPath(); g.arc(50+Math.cos(a)*36, 50+Math.sin(a)*36, 1.6, 0, TAU2); g.fill(); } sparkle(g,70,26,7); },
  pass:g=>{ shadowUnder(g,50,88,26);
    g.fillStyle = lg(g,30,0,70,0,["#4a1e7a","#7a4ec8","#4a1e7a"]); path(g,[[30,14],[70,14],[70,82],[50,70],[30,82]]); g.fill();
    g.strokeStyle = "#f2c14e"; g.lineWidth = 2.4; path(g,[[30,14],[70,14],[70,82],[50,70],[30,82]]); g.stroke();
    g.fillStyle = lg(g,0,10,0,20,["#fff0b0","#c8902a"]); g.fillRect(24,10,52,8);
    gemShape(g,50,42,11,"#f2c14e"); sparkle(g,64,26,6); },
  keep:g=>{ medallion(g,"#d0ab62");
    g.fillStyle = lg(g,0,30,0,80,["#b8aac8","#5a4e6a"]); g.fillRect(34,40,32,40); g.fillRect(28,48,10,32); g.fillRect(62,48,10,32);
    g.fillStyle = "#a8323c"; path(g,[[32,40],[50,20],[68,40]]); g.fill(); path(g,[[26,48],[33,36],[40,48]]); g.fill(); path(g,[[60,48],[67,36],[74,48]]); g.fill();
    g.fillStyle = "#1a1016"; g.beginPath(); g.moveTo(45,80); g.lineTo(45,66); g.arc(50,66,5,Math.PI,0); g.lineTo(55,80); g.fill();
    aglow(g,"#ffd27a",50,56,10,.6); g.fillStyle = "#ffd27a"; g.fillRect(48.5,50,3,6); },
  bounty:g=>{ shadowUnder(g,50,90,26);
    g.save(); g.translate(50,50); g.rotate(-.06); g.fillStyle = lg(g,0,-40,0,40,["#f2e2b8","#c8a870"]); g.fillRect(-28,-38,56,76);
    g.strokeStyle = "rgba(90,60,20,.6)"; g.lineWidth = 1.2; g.strokeRect(-25,-35,50,70);
    g.fillStyle = "#6a2a1a"; g.font = "700 11px Georgia, serif"; g.textAlign = "center"; g.fillText("WANTED",0,-22);
    g.restore(); skull(g,50,56,15); g.strokeStyle = "#c0102a"; g.lineWidth = 3; g.lineCap = "round"; g.beginPath(); g.moveTo(36,78); g.lineTo(64,78); g.stroke();
    g.fillStyle = "#8a1a1a"; g.beginPath(); g.arc(50,13,3.2,0,TAU2); g.fill(); },
  trial:g=>{ medallion(g,"#ff8a4a");
    g.fillStyle = lg(g,0,20,0,80,["#f2d38a","#8a5a1a"]); g.fillRect(30,20,40,6); g.fillRect(30,74,40,6);
    g.fillStyle = "rgba(200,230,255,.35)"; path(g,[[34,26],[66,26],[52,50],[66,74],[34,74],[48,50]]); g.fill();
    g.strokeStyle = "rgba(255,255,255,.6)"; g.lineWidth = 1.2; path(g,[[34,26],[66,26],[52,50],[66,74],[34,74],[48,50]]); g.stroke();
    g.fillStyle = "#ffcf5a"; path(g,[[38,30],[62,30],[50,46]]); g.fill(); path(g,[[40,74],[60,74],[50,64]]); g.fill(); g.fillRect(49.2,46,1.6,18);
    aglow(g,"#ffcf5a",50,50,24,.3); },
  treasury:g=>{ shadowUnder(g,50,88,32); aglow(g,"#ffd86a",50,46,40,.45);
    ART.chest(g); for(const [x,y] of [[40,34],[52,28],[62,36],[46,24]]) coinShape(g,x,y,6,false); sparkle(g,68,22,7); },
  login:g=>{ shadowUnder(g,50,88,28);
    g.fillStyle = lg(g,0,20,0,84,["#f2e6c8","#c8b088"]); g.fillRect(22,24,56,58); g.fillStyle = "#a8323c"; g.fillRect(22,20,56,14);
    g.fillStyle = "#e8d0a0"; for(const x of [32,68]){ g.fillRect(x-2,14,4,12); }
    g.fillStyle = "rgba(90,60,30,.35)"; for(let r=0;r<3;r++) for(let c=0;c<4;c++) g.fillRect(27+c*12.5,40+r*13,9,9);
    g.fillStyle = "#f2c14e"; g.fillRect(64.5,66,9,9); sparkle(g,69,70,8); },
  frenzy:g=>{ medallion(g,"#ff4a4a"); g.strokeStyle = lg(g,20,20,80,80,["#ffb0a0","#ff2a2a","#8a0a0a"]); g.lineWidth = 6; g.lineCap = "round";
    for(const o of [-12,0,12]){ g.beginPath(); g.moveTo(34+o,24); g.quadraticCurveTo(48+o,50,40+o,78); g.stroke(); } aglow(g,"#ff4a4a",50,50,30,.4); },
  transmute:g=>{ medallion(g,"#6ab8ff"); g.strokeStyle = "#bfe4ff"; g.fillStyle = "#bfe4ff"; g.lineWidth = 4; g.lineCap = "round";
    g.beginPath(); g.arc(50,50,24,Math.PI*1.1,Math.PI*1.9); g.stroke(); path(g,[[70,36],[76,26],[80,40]]); g.fill();
    g.beginPath(); g.arc(50,50,24,Math.PI*.1,Math.PI*.9); g.stroke(); path(g,[[30,64],[24,74],[20,60]]); g.fill(); gemShape(g,50,50,11,"#6ab8ff"); },
  ascend:g=>{ medallion(g,"#ff7a5a"); g.fillStyle = lg(g,0,20,0,80,["#fff0c8","#ff7a5a","#8a1a1a"]); path(g,[[50,18],[74,46],[60,46],[60,80],[40,80],[40,46],[26,46]]); g.fill();
    g.strokeStyle = "rgba(255,255,255,.7)"; g.lineWidth = 1.2; path(g,[[50,18],[74,46],[60,46],[60,80],[40,80],[40,46],[26,46]]); g.stroke(); sparkle(g,50,30,8); aglow(g,"#ff7a5a",50,50,30,.35); },
  tier:g=>{ medallion(g,"#c9a2ff"); g.fillStyle = lg(g,0,20,0,80,["#fff0c8","#c9a2ff","#4a2a8a"]); for(const [y,w] of [[66,30],[50,22],[34,14]]){ path(g,[[50-w,y+10],[50,y-6],[50+w,y+10],[50,y+2]]); g.fill(); } sparkle(g,50,24,7); },
  rune_fury:g=>runeStone(g,"#ff5a4a",0),
  rune_life:g=>runeStone(g,"#5ae08a",1),
  rune_precision:g=>runeStone(g,"#ffd24a",2),
  rune_haste:g=>runeStone(g,"#7ee0ff",3),
  rune_stone:g=>runeStone(g,"#c8b8a8",4),
  rune_fortune:g=>runeStone(g,"#f2c14e",5),
  // ACTIVE ABILITIES (one per tag)
  ab_meteor:g=>{ medallion(g,"#ff8a2a");
    g.save(); g.translate(64,62); g.rotate(-2.2); for(const [w,l,c] of [[22,64,"#8a1a06"],[16,54,"#ff5a1a"],[10,42,"#ffc04a"],[5,30,"#fff6c8"]]){ g.fillStyle = lg(g,0,0,l,0,[c, World.rgba(c,0)]); g.beginPath(); g.moveTo(0,-w); g.bezierCurveTo(l*.4,-w*.9,l*.7,-w*.3,l,0); g.bezierCurveTo(l*.7,w*.3,l*.4,w*.9,0,w); g.closePath(); g.fill(); } g.restore();
    g.fillStyle = rg(g, 60,58,2, 64,62,17, ["#3a2018","#1a0c08","#0a0504"]); g.beginPath(); g.arc(64,62,15,0,TAU2); g.fill();
    g.strokeStyle = "#ffb04a"; g.lineWidth = 1.6; g.beginPath(); g.moveTo(56,56); g.lineTo(62,62); g.lineTo(58,68); g.moveTo(68,54); g.lineTo(66,64); g.lineTo(72,70); g.stroke();
    aglow(g,"#ff7a1a",64,62,28,.6); g.fillStyle="rgba(10,4,2,.7)"; g.beginPath(); g.ellipse(66,88,22,4,0,0,TAU2); g.fill(); for(let i=0;i<5;i++) sparkle(g, 22+i*6, 22+(i%2)*10, 2.4, "#ffd080", .8); },
  ab_thunder:g=>{ medallion(g,"#7ee0ff"); g.save(); g.globalCompositeOperation="lighter"; for(const r of [16,27,38]){ g.strokeStyle = World.rgba("#bff4ff", .9 - r*.016); g.lineWidth = 3.4 - r*.05; g.beginPath(); g.ellipse(50,74,r,r*.3,0,0,TAU2); g.stroke(); } g.restore();
    bolt(g,[[54,10],[40,38],[52,38],[38,64],[58,34],[46,34],[56,10]], "#ffffff", 3.4); aglow(g,"#8ff0ff",48,44,34,.6); sparkle(g, 48, 72, 8, "#ffffff"); },
  ab_rend:g=>{ medallion(g,"#ff5a64"); g.save(); g.globalCompositeOperation="lighter"; g.lineCap = "round";
    for(const [o,w] of [[-14,5],[0,7],[14,5]]){ g.strokeStyle = lg(g,24,20,76,80,["#ffd0d0","#ff2a3a","#6a0410"]); g.lineWidth = w; g.beginPath(); g.moveTo(30+o,18); g.quadraticCurveTo(54+o,48,44+o,84); g.stroke(); } g.restore();
    drop(g, 70, 72, 6); drop(g, 26, 78, 4); aglow(g,"#ff2a3a",50,50,36,.4); },
  ab_dance:g=>{ medallion(g,"#dfe6f2"); g.save(); g.globalCompositeOperation="lighter"; for(let i=0;i<3;i++){ g.strokeStyle = World.rgba("#ffffff", .7-i*.18); g.lineWidth = 5-i*1.3; g.lineCap="round"; g.beginPath(); g.arc(50,54,22+i*8, -2.4+i*.3, -.2+i*.3); g.stroke(); g.beginPath(); g.arc(50,54,22+i*8, .8+i*.3, 3+i*.3); g.stroke(); } g.restore();
    sword(g, 26, 76, -.9, 60, "#cfe0ff"); sword(g, 74, 30, Math.PI-.9, 60, "#cfe0ff"); sparkle(g, 50, 54, 9); },
  ab_divine:g=>{ medallion(g,"#ffe07a"); rays(g, 50, 52, 20, 46, 14, "#ffe9a0", .7, .15);
    g.save(); g.translate(50,54); g.scale(2.1,2.1); World.drawShield(g,{type:"kite", col:"#fff4d0", trim:"#e8b84a", emblem:"sun", emblemCol:"#e8a020"},1); g.restore();
    g.strokeStyle = "#ffe9a0"; g.lineWidth = 2.4; g.beginPath(); g.ellipse(50,18,16,4.5,0,0,TAU2); g.stroke(); aglow(g,"#ffe07a",50,52,44,.55); sparkle(g, 72, 30, 5); },
  ab_wall:g=>{ medallion(g,"#5aa0ff"); for(const [x,y,sc,a] of [[28,58,1.5,.75],[72,58,1.5,.75],[50,52,2.2,1]]){ g.save(); g.globalAlpha = a; g.translate(x,y); g.scale(sc,sc); World.drawShield(g,{type:"kite", col:"#2a3e62", trim:"#cfd8e8", emblem:"cross", emblemCol:"#e8eef8"},1); g.restore(); }
    g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="rgba(154,208,255,.85)"; g.lineWidth=2.6; g.beginPath(); g.arc(50,56,42,Math.PI*1.12,Math.PI*1.88); g.stroke(); g.restore(); aglow(g,"#9ad0ff",50,50,40,.35); },
  // EVOLUTIONS (gold medallion)
  evo_firestorm:g=>{ medallion(g,"#f2c14e"); for(const [x,y,sc] of [[30,34,.55],[58,26,.7],[72,50,.5]]){ g.save(); g.translate(x,y); g.scale(sc,sc); g.rotate(2.2);
      for(const [w,l,c] of [[20,58,"#b8240a"],[14,48,"#ff6a1a"],[8,36,"#ffc04a"]]){ g.fillStyle = lg(g,0,0,l,0,[c, World.rgba(c,0)]); g.beginPath(); g.moveTo(0,-w); g.bezierCurveTo(l*.4,-w*.9,l*.7,-w*.3,l,0); g.bezierCurveTo(l*.7,w*.3,l*.4,w*.9,0,w); g.closePath(); g.fill(); }
      g.fillStyle = rg(g,-2,-2,1,0,0,14,["#fffbe8","#ffd060","#ff7a1a"]); g.beginPath(); g.arc(0,0,13,0,TAU2); g.fill(); g.restore(); }
    flame(g, 34, 86, 12); flame(g, 54, 88, 15); flame(g, 72, 86, 11); aglow(g,"#ff8a2a",50,60,40,.45); },
  evo_cuts:g=>{ medallion(g,"#f2c14e"); g.save(); g.globalCompositeOperation="lighter"; g.lineCap="round";
    for(let i=0;i<7;i++){ g.strokeStyle = World.rgba(i%2?"#ffffff":"#ff8a94", .85); g.lineWidth = 1.8 + (i%3)*.8; g.beginPath(); g.moveTo(18+i*9, 24+(i%2)*8); g.lineTo(30+i*9, 76-(i%3)*8); g.stroke(); } g.restore();
    sword(g, 20, 84, -.86, 58, "#ffd0d0"); sword(g, 82, 84, -Math.PI+.86, 58, "#ffd0d0"); drop(g, 50, 70, 5); },
  evo_crown:g=>{ medallion(g,"#f2c14e"); g.fillStyle = lg(g,0,44,0,76,["#e6f8ff","#7ee0ff","#1a6a8a"]); path(g,[[26,74],[22,46],[36,58],[44,38],[50,54],[56,38],[64,58],[78,46],[74,74]]); g.fill(); g.strokeStyle="rgba(255,255,255,.7)"; g.lineWidth=1; g.stroke();
    bolt(g,[[50,6],[44,22],[52,22],[46,38]], "#ffffff", 2.6); bolt(g,[[24,16],[30,30],[24,32],[30,44]], "#bff4ff", 1.8); bolt(g,[[76,16],[70,30],[76,32],[70,44]], "#bff4ff", 1.8); aglow(g,"#8ff0ff",50,50,40,.5); },
  evo_bastion:g=>{ medallion(g,"#f2c14e"); g.fillStyle = lg(g,22,0,78,0,["#1a2438","#5a7aaa","#2a3a58"]); path(g,[[24,16],[76,16],[78,70],[50,92],[22,70]]); g.fill();
    g.strokeStyle = lg(g,0,16,0,92,["#fff4c0","#f2c14e","#8a5a10"]); g.lineWidth=3.4; g.stroke();
    g.fillStyle = lg(g,0,30,0,70,["#b8aac8","#5a4e6a"]); g.fillRect(38,42,24,30); g.fillRect(34,36,7,10); g.fillRect(46.5,36,7,10); g.fillRect(59,36,7,10);
    g.fillStyle = "#1a1016"; g.beginPath(); g.moveTo(46,72); g.lineTo(46,62); g.arc(50,62,4,Math.PI,0); g.lineTo(54,72); g.fill(); aglow(g,"#9ad0ff",50,50,40,.35); sparkle(g, 70, 26, 5); },
  evo_judge:g=>{ medallion(g,"#f2c14e"); g.save(); g.globalCompositeOperation="lighter"; for(const [x,w] of [[26,10],[50,18],[74,10]]){ g.fillStyle = lg(g,x,0,x,90,["rgba(255,240,180,0)","rgba(255,236,160,.85)","#ffffff"]); path(g,[[x-w*.5,4],[x+w*.5,4],[x+w*.75,88],[x-w*.75,88]]); g.fill(); } g.restore();
    rays(g, 50, 88, 2, 34, 10, "#fff0b0", .7, Math.PI); g.strokeStyle="#e8b84a"; g.lineWidth=3; g.lineCap="round"; g.beginPath(); g.moveTo(50,26); g.lineTo(50,64); g.moveTo(34,38); g.lineTo(66,38); g.stroke();
    for(const x of [34,66]){ g.strokeStyle="#e8b84a"; g.lineWidth=1.4; g.beginPath(); g.moveTo(x,38); g.lineTo(x-6,52); g.moveTo(x,38); g.lineTo(x+6,52); g.stroke(); g.fillStyle="#fff0b0"; g.beginPath(); g.ellipse(x,53,7,2.4,0,0,TAU2); g.fill(); } aglow(g,"#ffe07a",50,50,40,.4); },
  // LEGENDARY (cross-tag) CARDS
  leg_plasma:g=>{ medallion(g,"#ffb347"); g.fillStyle = rg(g, 46,46,2, 50,50,24, ["#ffffff","#bff4ff","#ff8a2a","rgba(200,40,10,0)"]); g.beginPath(); g.arc(50,50,24,0,TAU2); g.fill();
    bolt(g,[[18,30],[34,42],[30,48],[44,50]], "#8ff0ff", 2.4); bolt(g,[[82,70],[66,58],[70,52],[56,50]], "#8ff0ff", 2.4); flame(g, 30, 80, 10); flame(g, 72, 34, 9); aglow(g,"#ffb347",50,50,40,.5); },
  leg_martyr:g=>{ medallion(g,"#ffb347"); rays(g, 50, 50, 16, 44, 12, "#ffe9a0", .5, .1); heartShape(g, 50, 52, 22, "#c0102a"); drop(g, 50, 82, 5); g.strokeStyle = "#ffe9a0"; g.lineWidth = 2.2; g.beginPath(); g.ellipse(50,22,14,4,0,0,TAU2); g.stroke(); aglow(g,"#ffe07a",50,26,22,.5); },
  leg_riposte:g=>{ medallion(g,"#ffb347"); g.save(); g.translate(40,56); g.scale(1.8,1.8); World.drawShield(g,{type:"round", col:"#2a3e62", trim:"#cfd8e8"},1); g.restore();
    sword(g, 40, 84, -.95, 58, "#ffffff"); g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="rgba(255,255,255,.85)"; g.lineWidth=3; g.lineCap="round"; g.beginPath(); g.arc(46,60,34,-1.3,-.2); g.stroke(); g.restore(); sparkle(g, 78, 30, 8); },
  leg_static:g=>{ medallion(g,"#ffb347"); drop(g, 50, 56, 20, "#b0102a"); bolt(g,[[52,14],[42,38],[54,40],[44,62],[60,36],[50,34],[58,14]], "#bff4ff", 2.6); aglow(g,"#8ff0ff",50,40,30,.5); drop(g, 26, 78, 5); drop(g, 74, 76, 5); },
  leg_molten:g=>{ medallion(g,"#ffb347"); sword(g, 20, 84, -.84, 72, "#ff8a2a", ["#fff0c0","#ff6a1a"]); g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="rgba(255,200,90,.9)"; g.lineWidth=2; g.beginPath(); g.moveTo(34,70); g.lineTo(74,28); g.stroke(); g.restore();
    drop(g, 44, 78, 4.5, "#ff7a1a"); drop(g, 58, 66, 3.5, "#ffb04a"); flame(g, 70, 36, 12); sparkle(g, 76, 22, 6, "#fff0c0"); aglow(g,"#ff8a2a",52,52,38,.4); },
  leg_sanct:g=>{ medallion(g,"#ffb347"); g.save(); g.globalCompositeOperation="lighter"; g.strokeStyle="rgba(255,233,160,.9)"; g.lineWidth=3; g.beginPath(); g.arc(50,62,34,Math.PI,0); g.stroke(); g.fillStyle="rgba(255,233,160,.14)"; g.beginPath(); g.arc(50,62,34,Math.PI,0); g.fill(); g.restore();
    g.save(); g.translate(50,60); g.scale(1.5,1.5); World.drawShield(g,{type:"kite", col:"#3a4a62", trim:"#ffe9a0", emblem:"cross", emblemCol:"#fff4c8"},1); g.restore(); heartShape(g, 50, 28, 8, "#ff5a6e"); aglow(g,"#ffe07a",50,50,40,.4); },
  // SYSTEMS
  ev_fork:g=>{ medallion(g,"#d0ab62"); shadowUnder(g,50,88,20); g.fillStyle = lg(g,46,0,54,0,["#3a2816","#7a5a34"]); g.fillRect(47,26,6,62);
    const board=(y,dirn,c)=>{ g.fillStyle = lg(g,14,0,86,0,[World.mix(c,"#000",.3),c,World.mix(c,"#fff",.15)]); g.beginPath(); if(dirn>0){ g.moveTo(40,y-9); g.lineTo(76,y-9); g.lineTo(86,y); g.lineTo(76,y+9); g.lineTo(40,y+9); } else { g.moveTo(60,y-9); g.lineTo(24,y-9); g.lineTo(14,y); g.lineTo(24,y+9); g.lineTo(60,y+9); } g.closePath(); g.fill(); g.strokeStyle="rgba(0,0,0,.4)"; g.lineWidth=1; g.stroke(); };
    board(38,1,"#9a6a34"); board(60,-1,"#7a5228"); g.fillStyle="#f2d796"; g.fillRect(48,34,22,2); g.fillRect(30,56,22,2); sparkle(g, 50, 20, 5); },
  heat:g=>{ medallion(g,"#ff7a2a"); flame(g, 50, 78, 30); g.fillStyle = "rgba(255,255,255,.9)"; g.font = "700 0px serif"; aglow(g,"#ff7a1a",50,56,40,.5); sparkle(g, 70, 26, 5, "#ffe0a0"); },
  seal:g=>{ shadowUnder(g,50,88,26); g.fillStyle = rg(g,44,40,4,50,50,40,["#ff8a8a","#b01428","#4a0410"]); g.beginPath(); for(let i=0;i<=24;i++){ const a = i/24*TAU2, r = 36 + (i%2 ? 3 : 0); g.lineTo(50+Math.cos(a)*r, 48+Math.sin(a)*r); } g.closePath(); g.fill();
    g.strokeStyle = "rgba(255,200,200,.5)"; g.lineWidth = 1.4; g.beginPath(); g.arc(50,48,27,0,TAU2); g.stroke();
    g.fillStyle = "#ffd8d8"; path(g,[[34,58],[34,40],[42,48],[50,34],[58,48],[66,40],[66,58]]); g.fill(); g.fillRect(34,60,32,4);
    g.fillStyle = "#b01428"; path(g,[[38,80],[44,96],[49,84]]); g.fill(); path(g,[[62,80],[56,96],[51,84]]); g.fill(); sparkle(g, 72, 26, 6); },
  mythic:g=>{ medallion(g,"#ff4a5a"); gemShape(g,50,50,18,"#ff4a5a"); },
  ancient:g=>{ medallion(g,"#3ff0d0"); gemShape(g,50,50,18,"#3ff0d0"); sparkle(g,70,28,8); }
};
function artURL(name){
  if(ART_CACHE[name]) return ART_CACHE[name];
  const fn = ART[name]; if(!fn) return "";
  const c = document.createElement("canvas"); c.width = c.height = ART_PX; const g = c.getContext("2d");
  g.scale(ART_PX/100, ART_PX/100); try{ fn(g); }catch(e){ console.warn("art", name, e); }
  const url = c.toDataURL("image/png"); c.width = c.height = 0; ART_CACHE[name] = url; return url;
}
function art(name, size, cls){ return `<img class="art ${cls||''}" src="${artURL(name)}" width="${size||40}" height="${size||40}" alt="" draggable="false">`; }

/* currency glyphs used inline in pills, prices and rewards */
const CUR = { get gold(){ return art("gold",20,"cur"); }, get orbs(){ return art("orbs",20,"cur"); }, get gems(){ return art("gems",20,"cur"); } };
