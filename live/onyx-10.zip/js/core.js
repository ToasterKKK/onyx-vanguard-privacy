/* Onyx Vanguard — core.js
   Config, utilities, save system, procedural audio and haptics.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   CONFIG — fill these in before shipping
===================================================================== */
const REVENUECAT_API_KEY = "appl_ZGSaqODASIzsodWFiyyCEZpOyZO";
const ADMOB_REWARDED_ID  = "ca-app-pub-5394741845545426/2972953082"; // your AdMob rewarded unit (OnyxVanguard-Ads)
const ADS_TESTING        = false; // real ads. Add your own iPhone as a test device in AdMob before tapping any
const PRIVACY_URL        = "https://toasterkkk.github.io/onyx-vanguard-privacy/";   // your hosted privacy policy (e.g. a GitHub Pages copy of privacy.html); shown in Settings → Privacy
const APP_VERSION        = "1.1.0";   // the app itself: changes only with an App Store release
const CONTENT_VERSION    = 10;         // the game's content (rules, numbers, screens): goes up with every change to the web files. Settings shows both
const LIVE_MIN_APP       = "1.1.0";   // the oldest App Store build that can run these web files (raise it when native plugins change)
const LIVE_URL           = "https://toasterkkk.github.io/onyx-vanguard-privacy/live/manifest.json";   // live content updates (tools/live/publish.py writes it)
const BUNDLE_ID          = "com.tomershaked.onyxvanguard";   // the App Store record the opening screen checks for a newer version
const TERMS_URL          = "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/"; // Apple's standard EULA (required next to the subscription)
const SUPPORT_EMAIL      = "tomershaked3@gmail.com";   // shown in Settings → Support

const TELEMETRY_URL      = "https://apps-dashboard.tomershaked3.workers.dev/v1/event";   // anonymous player count (see Telemetry)
/* Anonymous player count (Review 13): a random install id, the app version and "tester or not", sent once a day.
   No name, email, contacts, device id or advertising id. Long-press the version line in Settings to mark a device as a tester. */
const Telemetry = {
  iid(){ try{ let v = localStorage.getItem("ov_iid"); if(!v || !/^[a-f0-9-]{16,40}$/.test(v)){ v = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c=>{ const r = Math.random()*16|0; return (c==="x" ? r : (r&3|8)).toString(16); }); localStorage.setItem("ov_iid", v); } return v; }catch(e){ return null; } },
  ping(force){ try{
    const now = Date.now(), last = +localStorage.getItem("ov_ping") || 0;
    if(!force && now - last < 6*3600e3) return;
    const iid = this.iid(); if(!iid) return;
    localStorage.setItem("ov_ping", String(now));
    fetch(TELEMETRY_URL, {method:"POST", headers:{"content-type":"text/plain"}, keepalive:true,
      body:JSON.stringify({app:"onyx", iid, ver:APP_VERSION, ch:isNativeApp()?"store":"web", t:(typeof S!=="undefined" && S && S.tester)?1:0})}).catch(()=>{});
  }catch(e){} },
};

/* Native plugins are only used inside the iOS/Android app. In a desktop browser the game runs in test mode. */
/* the last few script errors, attached to bug reports (Contact us) */
window.__ovErrors = []; window.addEventListener("error", e=>{ try{ window.__ovErrors.push(String(e.message || e.error).slice(0, 160)); if(window.__ovErrors.length > 10) window.__ovErrors.shift(); }catch(x){} });
function isNativeApp(){ const C = window.Capacitor; return !!(C && C.isNativePlatform && C.isNativePlatform()); }
function nativePlugins(){ if(!isNativeApp()) return {}; return window.NativePlugins || (window.Capacitor && window.Capacitor.Plugins) || {}; }

/* =====================================================================
   UTIL
===================================================================== */
const $ = (s, r=document) => r.querySelector(s);
const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
const rand = (a,b) => a + Math.random()*(b-a);
const lerp = (a,b,t) => a + (b-a)*t;
const pick = a => a[Math.floor(Math.random()*a.length)];
const fmt = n => { n = Math.floor(n); if(n>=999.95e6) return (n/1e9).toFixed(1)+"B"; if(n>=999950) return (n/1e6).toFixed(1)+"M"; if(n>=1e4) return (n/1e3).toFixed(1)+"K"; return n.toLocaleString("en-US"); };
const r1 = n => Math.round(n*10)/10;
function hashStr(s){ let h=2166136261; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619);} return h>>>0; }
function seeded(seed){ let s=seed>>>0||1; return ()=>{ s^=s<<13; s>>>=0; s^=s>>17; s^=s<<5; s>>>=0; return (s%100000)/100000; }; }
const todayKey = () => { const d=new Date(); return d.getFullYear()+"-"+(d.getMonth()+1)+"-"+d.getDate(); };

/* =====================================================================
   SAVE
===================================================================== */
const SAVE_KEY = "onyxVanguard_save_v1";
const SAVE_BAK = "onyxVanguard_save_bak";      // a second copy, written less often and only from a save that loaded cleanly
const SAVE_BROKEN = "onyxVanguard_save_broken"; // what could not be read, kept so nothing is ever thrown away
const SAVE_PRE = "onyxVanguard_save_pre";       // the save as it was before the last upgrade of its shape
const SAVE_V = 3;                               // shape of the save. A newer save than this is loaded as it is (unknown fields are kept and ignored), never reset
const BAK_EVERY = 120000;
let saveState = "ok";                           // "ok" | "new" | "rescued" (main copy unreadable, backup loaded) | "lost" (unreadable and no backup)
let saveRescueAt = 0;
function defaultSave(){
  return { v:SAVE_V, tester:false, sfx:1, bigText:false, lefty:false, calmSet:false, weekly:{week:"",best:0,day:"",used:0,got:[],runs:0}, grace:"", gold:0, orbs:0, gems:0, name:"", autoAb:{}, calm:false, found:[], trim:"",
    command:{date:"",used:0,bonus:0,ads:0}, heat:{max:0,cap:0,best:{},cur:0,easy:false,lost:0,edge:.95,own:false}, ads:{date:"",n:0}, firstBuy:{}, offers:{}, autoSalv:{c:false,r:false}, loadouts:[null,null], mastery:{}, synAlt:{}, oathSel:"", seenAt:0, streakFix:"", sale:{week:"",item:null,price:0,bought:false}, rush:{best:0,week:"",chest:false}, pendingRun:null,
    meta:{vit:0,might:0,plating:0,alchemy:0,flasks:0,precision:0,swift:0,fortune:0},
    dust:0, star:0, sigils:0, frags:{}, runes:{}, oath:{max:1,sel:1,cl:{}}, bounty:{date:"",list:[]}, trials:{date:"",list:[]},
    login:{last:"",day:0,streak:0,cycle:0}, offersSeen:{}, fails:{}, autoPick:false, music:.6, notif:"", skin:"", skins:[], shards:0, favor:{active:false,until:0,gemsDay:""}, tips:{}, mapAt:"", mapLoot:[], boosts:{}, lootSeen:false, gcAch:{}, savedAt:0, buys:{date:"",tickets:0,keys:0}, treasury:0, pass:{start:0,season:0,xp:0,prem:false,cf:[],cp:[]},
    cardLv:{}, bans:[], inv:[], equip:{weapon:null,helm:null,armor:null,shield:null,ring:null},
    cape:"crimson", capes:["crimson"], cleared:{}, selAct:0, endlessBest:0, challenges:{},
    removeAds:false, starterBought:false, daily:{date:"",offers:[],bought:[],adChest:false},
    stats:{runs:0,kills:0,bosses:0,wins:0,events:0,elites:0,potions:0,goldEarned:0,forges:0,cardUps:0,duels:0,duelWins:0,raids:0,waves:0,bounties:0,trials:0,crafted:0,syn2:0,dryWins:0,heatWins:0,interrupts:0,focusWins:0},
    quests:{date:"",list:[],bonus:false}, journey:{},
    arena:{trophies:0,best:0,date:"",tickets:5,adTicket:false,opps:[],week:""},
    raid:{tier:0,dmg:0,date:"",keys:3,best:0,day:0,goal:false}, sound:true, haptics:true, quality:"auto", lastSpeed:1, uid:1, seenIntro:false, starterGiven:false };
}
function readSave(o){
  { { const d = defaultSave();
    const s = Object.assign(d, o, { meta:Object.assign(d.meta,o.meta||{}), equip:Object.assign(d.equip,o.equip||{}), stats:Object.assign(d.stats,o.stats||{}), daily:Object.assign(d.daily,o.daily||{}),
      quests:Object.assign(d.quests,o.quests||{}), journey:Object.assign(d.journey,o.journey||{}), arena:Object.assign(d.arena,o.arena||{}), raid:Object.assign(d.raid,o.raid||{}) });
    if(!Array.isArray(s.quests.list)) s.quests.list = []; if(!Array.isArray(s.arena.opps)) s.arena.opps = [];
    for(const k of ["oath","bounty","trials","login","pass","offersSeen","fails","favor","tips","buys","boosts","gcAch","command","heat","ads","firstBuy","offers","autoSalv","mastery","synAlt","sale","rush","autoAb","weekly"]) s[k] = Object.assign(d[k], o[k]||{});
    if(!s.heat.best || typeof s.heat.best!=="object") s.heat.best = {}; if(!Array.isArray(s.found)) s.found = []; if(!Array.isArray(s.loadouts)) s.loadouts = [null,null];
    if(!Array.isArray(s.skins)) s.skins = []; if(!Array.isArray(s.mapLoot)) s.mapLoot = [];
    s.frags = Object.assign({}, o.frags||{}); s.runes = Object.assign({}, o.runes||{});
    if(!Array.isArray(s.inv)) s.inv = [];
    for(const it of s.inv){ if(!Array.isArray(it.sock)) it.sock = Array([0,1,2,2,3,3][it.r]||0).fill(null); } if(!Array.isArray(s.capes) || !s.capes.length) s.capes = ["crimson"]; if(!Array.isArray(s.bans)) s.bans = [];
    s.uid = Math.max(s.uid||1, ...s.inv.map(i=>(i.uid||0)+1)); if(!(s.selAct>=0 && s.selAct<=4)) s.selAct = 0;
    s.v = o.v || 1;                       // older saves are brought up to date by migrateSave() once every script has loaded
    return s; } }
}
function parseSave(raw){ if(!raw) return null; try{ const o = JSON.parse(raw); if(!o || typeof o!=="object" || Array.isArray(o) || !("gold" in o || "cleared" in o || "meta" in o)) return null; return readSave(o); }catch(e){ return null; } }
function loadSave(){
  let raw = null, bak = null; try{ raw = localStorage.getItem(SAVE_KEY); bak = localStorage.getItem(SAVE_BAK); }catch(e){}
  if(!raw && !bak){ saveState = "new"; return defaultSave(); }
  const s = parseSave(raw); if(s) return s;
  /* the main copy is missing or cannot be read: keep it aside, then fall back to the backup */
  try{ if(raw) localStorage.setItem(SAVE_BROKEN, raw); }catch(e){}
  const b = parseSave(bak); if(b){ saveState = "rescued"; saveRescueAt = b.savedAt||0; return b; }
  saveState = "lost"; return defaultSave();
}
let S = loadSave();
let bakAt = 0;
/* the backup is only ever written from a save that is in memory and healthy; before a save is upgraded its old form is kept too (see migrateSave) */
function backupSave(force){ const now = Date.now(); if(!force && now - bakAt < BAK_EVERY) return; bakAt = now; try{ localStorage.setItem(SAVE_BAK, JSON.stringify(S)); }catch(e){} }
function keepOldSave(){ try{ const raw = localStorage.getItem(SAVE_KEY); if(raw) localStorage.setItem(SAVE_PRE, raw); }catch(e){} }
/* this device's id (kept outside the save, so a save restored from iCloud still knows which device it is on) */
const DEVICE_ID = (()=>{ try{ let d = localStorage.getItem("ov_dev"); if(!d){ d = Math.random().toString(36).slice(2,10); localStorage.setItem("ov_dev", d); } return d; }catch(e){ return "web"; } })();
let gearRev = 0;   // bumped on every save; caches of "what is an upgrade" are keyed on it
function persist(){ if(typeof Cloud!=="undefined" && Cloud.restoring) return; gearRev++; S.savedAt = Date.now(); try{ localStorage.setItem(SAVE_KEY, JSON.stringify(S)); }catch(e){} backupSave(); if(typeof Cloud!=="undefined") Cloud.queue(); }

/* =====================================================================
   AUDIO + HAPTICS
   Sound effects are recorded-style WAVs in www/sfx (generated by tools/sfx/make_sfx.py),
   decoded once into memory and played through one master gain.
===================================================================== */
let AC = null, MASTER = null, voices = 0;
const BUF = {}, lastPlay = {};
/* name: [files, volume, pitch variation, min gap in ms] */
const SFX_DEF = {
  swing:[["swing1","swing2","swing3"],.32,.08,60], hit:[["hit1","hit2","hit3"],.5,.07,55], crit:[["crit"],.75,.04,90],
  block:[["block"],.6,.05,80], hurt:[["hurt"],.55,.06,90], death:[["death1","death2"],.5,.08,70],
  arrow:[["arrow"],.35,.08,70], cast:[["cast"],.35,.08,90], slam:[["slam"],.7,.04,200],
  fire:[["fire"],.45,.05,120], burn:[["burn"],.25,.1,250], zap:[["zap"],.5,.06,120], holy:[["holy"],.45,.03,300],
  potion:[["potion"],.6,.03,200], level:[["level"],.65,0,300], syn:[["syn"],.75,0,400], coin:[["coin"],.3,.07,70],
  click:[["click"],.35,.05,40], pick:[["pick"],.5,.03,120], forge:[["forge"],.6,.03,150], boss:[["boss"],.85,0,800],
  win:[["win"],.75,0,800], lose:[["lose"],.75,0,800], ready:[["ready"],.5,0,250], meteor:[["meteor"],.7,.03,300]
};
function ac(){ if(!S.sound) return null; if(!AC) initAudio(); if(!AC) return null; if(AC.state!=="running") AC.resume().catch(()=>{}); return AC.state==="running" ? AC : null; }
function initAudio(){
  if(AC) return; try{ AC = new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ return; }
  MASTER = AC.createGain(); MASTER.gain.value = .9 * sfxVolume(); MASTER.connect(AC.destination);
  AC.onstatechange = ()=>{ if(AC.state==="running") Music.resume(); };
  const files = [...new Set(Object.values(SFX_DEF).flatMap(d=>d[0]))];
  for(const f of files) fetch(`sfx/${f}.wav`).then(r=>{ if(!r.ok) throw new Error("missing sound"); return r.arrayBuffer(); }).then(decodeAudio).then(b=>{ BUF[f] = b; }).catch(()=>{});
}
/* decodeAudioData both calls back and (in modern browsers) returns a promise; a corrupt or missing file must fail quietly either way */
function decodeAudio(ab){ return new Promise((res, rej)=>{ let p; try{ p = AC.decodeAudioData(ab, res, rej); }catch(e){ rej(e); return; } if(p && p.catch) p.catch(()=>{}); }); }
function play(name){
  const d = SFX_DEF[name]; if(!d) return; const c = ac(); if(!c) return;
  const now = performance.now(); if(lastPlay[name] && now - lastPlay[name] < d[3]) return; lastPlay[name] = now;
  if(voices > 12) return; // cap simultaneous voices so ×3 fights can't flood the audio thread
  const b = BUF[d[0][Math.floor(Math.random()*d[0].length)]]; if(!b) return;
  const s = c.createBufferSource(), g = c.createGain(); s.buffer = b; s.playbackRate.value = 1 + (Math.random()*2-1)*d[2]; g.gain.value = d[1];
  s.connect(g).connect(MASTER); s.start(); voices++; s.onended = ()=>{ voices = Math.max(0, voices-1); s.disconnect(); g.disconnect(); };
}
function sfxVolume(){ return S.sfx==null ? 1 : clamp(+S.sfx||0, 0, 1); }
function setSfxVolume(v){ S.sfx = clamp(v, 0, 1); if(MASTER && AC) MASTER.gain.setTargetAtTime(.9 * S.sfx, AC.currentTime, .05); }
/* comfort settings. Reduce screen shake follows the phone's own Reduce Motion setting until the player chooses for himself */
function calmOn(){ if(S.calmSet) return !!S.calm; try{ if(window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches) return true; }catch(e){} return !!S.calm; }
function applyComfort(){ const c = document.body && document.body.classList; if(!c) return; c.toggle("bigtext", !!S.bigText); c.toggle("lefty", !!S.lefty); c.toggle("calm", calmOn()); }
const SFX = {}; for(const k of Object.keys(SFX_DEF)) SFX[k] = ()=>play(k);
/* MUSIC: generated loops in www/music (tools/music/make_music.py). Each file holds MUSIC_PAD seconds of the
   loop's end, the loop, then MUSIC_PAD seconds of its start, so looping between PAD and PAD+len never clicks.
   Only the playing track stays decoded in memory; tracks crossfade. */
const MUSIC_PAD = .5, MUSIC_LEN = {menu:50.5263, battle_verdant:30.9677, battle_gothic:36.9231, battle_frost:33.1034, battle_ember:34.2857, battle_astral:38.4, boss:26.6667};
const Music = (()=>{
  let bus = null, cur = null, want = null, ducked = false; const bufs = {}, loading = {};
  const level = ()=> (S.sound ? (S.music==null ? .6 : S.music) : 0) * (ducked ? .4 : 1) * .55;
  const busNode = ()=>{ if(!bus){ bus = AC.createGain(); bus.gain.value = level(); bus.connect(AC.destination); } return bus; };
  function load(k){ if(bufs[k]) return Promise.resolve(bufs[k]); if(loading[k]) return loading[k];
    return loading[k] = fetch(`music/${k}.mp3`).then(r=>{ if(!r.ok) throw new Error("missing track"); return r.arrayBuffer(); }).then(decodeAudio)
      .then(b=>{ delete loading[k]; for(const o of Object.keys(bufs)) if(o!==want && !(cur && cur.k===o)) delete bufs[o]; bufs[k] = b; return b; })
      .catch(()=>{ delete loading[k]; return null; }); }
  function sync(){
    if(!AC || AC.state!=="running" || !want || !S.sound || !(S.music>0 || S.music==null)) return; if(cur && cur.k===want) return;
    const k = want;
    load(k).then(b=>{ if(!b || want!==k || (cur && cur.k===k) || AC.state!=="running") return; const t = AC.currentTime, B = busNode();
      if(cur) fadeOut(cur);
      const s = AC.createBufferSource(), g = AC.createGain(), len = Math.min(MUSIC_LEN[k] || (b.duration - 2*MUSIC_PAD), b.duration - MUSIC_PAD - .05);
      s.buffer = b; s.loop = true; s.loopStart = MUSIC_PAD; s.loopEnd = MUSIC_PAD + len;
      g.gain.value = 0; g.gain.setTargetAtTime(1, t, .6); s.connect(g).connect(B); s.start(0, MUSIC_PAD); cur = {k, s, g}; });
  }
  function fadeOut(o){ try{ o.g.gain.cancelScheduledValues(AC.currentTime); o.g.gain.setTargetAtTime(0, AC.currentTime, .35); }catch(e){}
    setTimeout(()=>{ try{ o.s.stop(); }catch(e){} try{ o.s.disconnect(); o.g.disconnect(); }catch(e){} }, 2200); }
  return {
    play(k){ if(want===k) return; want = k; sync(); },
    stop(){ want = null; if(cur && AC){ fadeOut(cur); cur = null; } },
    duck(on){ if(ducked===!!on) return; ducked = !!on; this.volume(); },
    volume(){ if(bus && AC) bus.gain.setTargetAtTime(level(), AC.currentTime, .12); if(level()>0) sync(); else if(cur && AC){ fadeOut(cur); cur = null; } },
    resume(){ sync(); },
    get track(){ return cur ? cur.k : null; }
  };
})();
const MUSIC_FOR = {verdant:"battle_verdant", gothic:"battle_gothic", frost:"battle_frost", ember:"battle_ember", astral:"battle_astral"};
let lastHaptic = 0;
function haptic(style="LIGHT"){ if(!S.haptics) return; const now = performance.now(); if(now - lastHaptic < 90) return; lastHaptic = now; try{ const H = nativePlugins().Haptics; if(H) H.impact({style}).catch(()=>{}); }catch(e){} }
