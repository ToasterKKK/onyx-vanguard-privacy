/* Onyx Vanguard — monetization.js
   In-app purchases (RevenueCat) and rewarded ads (AdMob).
   In a desktop browser both run in a clearly-labelled test mode. Inside the iOS app nothing is ever simulated:
   if a store or ad service isn't configured, the related buttons are hidden or report that nothing is available.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* gem packs double their gems the first time each one is bought */
const gemGrant = (k, n) => () => { const dbl = !S.firstBuy[k]; S.firstBuy[k] = 1; S.gems += n*(dbl ? 2 : 1); };
const PRODUCTS = {
  squire:{id:"ov_squire_pack",contents:{gems:300,orbs:20,frags:10,star:2}, img:"banner_squire", ribbon:"Starter · one time",name:"Squire's Pack",price:"$2.99",icon:"squire",desc:"300 Gems, 20 Orbs, 10 rune fragments and 2 Starmetal. One time only.",grant(){ S.gems+=300; S.orbs+=20; rollFrags(10); S.star+=2; S.starterBought=true; }},
  gems_pouch:{id:"ov_gems_100",gems:100,contents:{gems:100}, img:"banner_gems", ribbon:"",name:"Pouch of Gems",price:"$0.99",icon:"gems",desc:"100 Gems.",grant:gemGrant("gems_pouch",100)},
  gems_sack:{id:"ov_gems_550",gems:550,contents:{gems:550}, img:"banner_gems", ribbon:"",name:"Sack of Gems",price:"$4.99",icon:"gems",desc:"550 Gems.",grant:gemGrant("gems_sack",550)},
  gems_chest:{id:"ov_gems_1150",gems:1150,contents:{gems:1150}, img:"banner_gems", ribbon:"Popular",name:"Chest of Gems",price:"$9.99",icon:"gemchest",desc:"1,150 Gems.",grant:gemGrant("gems_chest",1150)},
  gems_hoard:{id:"ov_gems_3000",gems:3000,contents:{gems:3000}, img:"banner_gems", ribbon:"Best value",name:"Hoard of Gems",price:"$24.99",icon:"gemchest",desc:"3,000 Gems.",grant:gemGrant("gems_hoard",3000)},
  gems_vault:{id:"ov_gems_6500",gems:6500,contents:{gems:6500}, img:"banner_gems", ribbon:"",name:"Vault of Gems",price:"$49.99",icon:"gemchest",desc:"6,500 Gems.",grant:gemGrant("gems_vault",6500)},
  gems_king:{id:"ov_gems_14000",gems:14000,contents:{gems:14000}, img:"banner_gems", ribbon:"Best value",name:"King's Treasury",price:"$99.99",icon:"gemchest",desc:"14,000 Gems.",grant:gemGrant("gems_king",14000)},
  vanguard:{id:"ov_vanguard_bundle",contents:{sigil:1,gems:800,orbs:60,star:5}, extra:"Voidwalker cape", img:"banner_vanguard", ribbon:"Bundle",name:"Vanguard Bundle",price:"$14.99",icon:"crown",desc:"An Ancient Sigil, 800 Gems, 60 Orbs, 5 Starmetal and the Voidwalker cape.",grant(){ S.sigils+=1; S.gems+=800; S.orbs+=60; S.star+=5; if(!S.capes.includes("void")) S.capes.push("void"); }},
  arenapack:{id:"ov_arena_bundle",contents:{gems:300}, extra:"10 Arena tickets · Duelist's Mantle cape", img:"banner_arena", ribbon:"Arena",name:"Arena Bundle",price:"$4.99",icon:"arena",desc:"10 Arena tickets, the Duelist's Mantle cape and 300 Gems.",grant(){ S.arena.tickets += 10; S.gems += 300; if(!S.capes.includes("duelist")) S.capes.push("duelist"); }},
  sigil:{id:"ov_ancient_sigil",contents:{sigil:1,gems:200}, img:"banner_sigil", ribbon:"Choose your relic",name:"Ancient Sigil",price:"$9.99",icon:"sigil",desc:"Claim one Ancient relic of your choice in the Ancient Armory, plus 200 Gems.",grant(){ S.sigils+=1; S.gems+=200; }},
  favor:{id:"ov_vanguard_favor", sub:true, period:"month", contents:{gems:1500}, img:"banner_gems", ribbon:"Monthly",name:"Vanguard's Favor",price:"$4.99",icon:"crown",desc:"Unlimited Vanguard Command, every ad reward without the ad, +50% treasury income, 50 Gems every day and the Vanguard Gold cape.",grant(){ if(!isNativeApp()) S.favor.until = Math.max(Date.now(), S.favor.until||0) + 30*864e5;      /* in the app the store entitlement decides (trial, refund, cancel) */ if(!S.capes.includes("favor")) S.capes.push("favor"); }},
  pass:{id:"ov_oath_pass",contents:null, img:"banner_pass", ribbon:"Season",name:"Oath Pass",price:"$4.99",icon:"pass",desc:"Unlock the premium lane of this season's Oath Pass: an Ancient Sigil, the season's cape, Gems, Starmetal and more.",grant(){ passSeason(); S.pass.prem = true; }},
  seal:{id:"ov_commander_seal",contents:null, img:"banner_keep", ribbon:"One time · forever",name:"Commander's Seal",price:"$7.99",icon:"seal",desc:"Unlimited Vanguard Command (speed ×3, auto-pick, auto-cast) and every ad reward without the video. One purchase, yours forever.",grant(){ S.removeAds=true; }}
};
const GEM_PACKS = ["gems_pouch","gems_sack","gems_chest","gems_hoard","gems_vault","gems_king"];
/* Review 5: the shop shows packs up to $24.99 at launch. The two largest stay defined (so a purchase made in an older build is
   still honoured) and can be switched back on by adding them here once there is enough to spend gems on. */
const GEM_SHOWN = ["gems_pouch","gems_sack","gems_chest","gems_hoard"];
/* the smallest pack that covers a gem shortfall (for "Get N gems" buttons) */
function packFor(need){ return GEM_SHOWN.find(k=>PRODUCTS[k].gems*(S.firstBuy[k] ? 1 : 2) >= need) || GEM_SHOWN[GEM_SHOWN.length-1]; }
const HIDDEN_PRODUCTS = GEM_PACKS.filter(k=>!GEM_SHOWN.includes(k));
const Monetization = {
  rc:false, admob:false, store:{}, adBusy:false, consent:null,
  plugins(){ return nativePlugins(); },
  /* the store section shows in the browser (test mode) and in the app once RevenueCat is configured */
  storeReady(){ return !isNativeApp() || this.rc; },
  price(k){ const sp = this.store[k]; return sp && sp.priceString ? sp.priceString : PRODUCTS[k].price; },
  async markTester(){ try{ const P = this.plugins(); if(this.rc && P.Purchases && (S.tester || S.testerSet)) await P.Purchases.setAttributes({attributes:{internal:S.tester?"1":""}}); }catch(e){} },
  async init(){
    const P = this.plugins();
    try{ if(P.Purchases && !REVENUECAT_API_KEY.includes("REPLACE")){
      await P.Purchases.configure({apiKey:REVENUECAT_API_KEY}); this.rc = true; this.markTester();
      for(const type of ["NON_SUBSCRIPTION","SUBSCRIPTION"]){ try{ const ids = Object.keys(PRODUCTS).filter(k=>!HIDDEN_PRODUCTS.includes(k)).map(k=>PRODUCTS[k]).filter(p=>!!p.sub===(type==="SUBSCRIPTION")).map(p=>p.id); const res = await P.Purchases.getProducts({productIdentifiers:ids, type});
        for(const sp of (res && res.products) || []){ const k = Object.keys(PRODUCTS).find(k=>PRODUCTS[k].id===sp.identifier); if(k) this.store[k] = sp; } }catch(e){ console.warn("products", e); } }
      try{ const r = await P.Purchases.getCustomerInfo(); this.applyEntitlements(r); }catch(e){}
      if(typeof renderAll==="function" && !run) renderAll();
    } }catch(e){ console.warn("RevenueCat init failed", e); }
    try{ if(P.AdMob){
      // 1. Google's consent message (required for players in the EEA, the UK and Switzerland; a no-op elsewhere).
      //    The message itself is set up in AdMob → Privacy & messaging (RELEASE.md §3).
      await this.askConsent(P.AdMob);
      // 2. Apple requires the App Tracking Transparency prompt before personalised ads.
      if(P.AdMob.trackingAuthorizationStatus && P.AdMob.requestTrackingAuthorization){ const t = await P.AdMob.trackingAuthorizationStatus(); if(t && t.status==="notDetermined") await P.AdMob.requestTrackingAuthorization(); }
      await P.AdMob.initialize({initializeForTesting:ADS_TESTING}); this.admob = !this.consent || this.consent.canRequestAds !== false; } }catch(e){ console.warn("AdMob init failed", e); }
  },
  async askConsent(A){
    if(!A.requestConsentInfo) return;
    try{ let ci = await A.requestConsentInfo();
      if(ci && ci.isConsentFormAvailable && ci.status==="REQUIRED" && A.showConsentForm) ci = await A.showConsentForm();
      this.consent = ci || null; }catch(e){ console.warn("ad consent", e); }
  },
  /* Settings → Ad privacy choices (shown only where Google says the player must be able to change the choice) */
  privacyOptions(){ return !!(this.consent && this.consent.privacyOptionsRequirementStatus==="REQUIRED"); },
  async showPrivacyOptions(){ const A = this.plugins().AdMob; if(!A || !A.showPrivacyOptionsForm) return; try{ await A.showPrivacyOptionsForm(); const ci = await A.requestConsentInfo(); if(ci){ this.consent = ci; this.admob = ci.canRequestAds !== false; } }catch(e){ toast("The privacy choices couldn't be opened. Try again in a moment."); } },
  hasNoAds(r){ const ent = r && r.customerInfo && r.customerInfo.entitlements && r.customerInfo.entitlements.active || {}; return !!ent.no_ads; },
  /* RevenueCat entitlements: no_ads (non-consumable) and favor (monthly subscription) */
  applyEntitlements(r){ const ent = r && r.customerInfo && r.customerInfo.entitlements && r.customerInfo.entitlements.active || {};
    if(ent.no_ads) S.removeAds = true; S.favor.active = !!ent.favor; if(ent.favor && !S.capes.includes("favor")) S.capes.push("favor"); persist(); },
  async purchase(key){
    const prod = PRODUCTS[key], P = this.plugins();
    if(this.rc){
      try{ let sp = this.store[key];
        if(!sp){ const res = await P.Purchases.getProducts({productIdentifiers:[prod.id], type:prod.sub?"SUBSCRIPTION":"NON_SUBSCRIPTION"}); sp = res && res.products && res.products[0]; if(sp) this.store[key] = sp; }
        if(!sp){ toast("This item isn't available right now. Please try again later."); return false; }
        const r = await P.Purchases.purchaseStoreProduct({product:sp}); if(prod.sub) this.applyEntitlements(r); return true;
      }catch(e){ if(e && (e.userCancelled || e.code==="1" || /cancel/i.test(e.message||""))) return false; toast("The purchase didn't go through. You weren't charged."); return false; }
    }
    if(isNativeApp()){ toast("The store isn't available right now."); return false; }
    return simulateStore(prod, this.price(key));
  },
  async restore(){
    const P = this.plugins();
    if(this.rc){ try{ const r = await P.Purchases.restorePurchases(); this.applyEntitlements(r); if(S.removeAds || S.favor.active) toast("Purchases restored.", "#d0ab62"); else toast("Nothing to restore on this Apple Account.");
        renderAll(); }catch(e){ toast("Couldn't restore purchases. Check your connection and try again."); } return; }
    toast(isNativeApp() ? "The store isn't available right now." : "Test mode: there's nothing to restore.");
  },
  /* resolves true only when the player earned the reward */
  async rewarded(placement){
    if(adFree()) return true;
    if(this.adBusy) return false;
    if(placement!=="revive" && adsLeft()<=0){ toast("That's all of today's videos. They refresh at midnight."); return false; }
    const ok = await this.showAd(placement); if(ok){ adDay().n++; persist(); } return ok;
  },
  async showAd(placement){
    const P = this.plugins();
    if(this.admob){
      this.adBusy = true; const wasRunning = AC && AC.state==="running"; if(wasRunning) AC.suspend().catch(()=>{});
      try{
        await P.AdMob.prepareRewardVideoAd({adId:ADMOB_REWARDED_ID, isTesting:ADS_TESTING});
        return await new Promise(res=>{
          let done = false, earned = false; const hs = [];
          const finish = v=>{ if(done) return; done = true; hs.forEach(h=>h && h.remove && h.remove()); res(v); };
          const on = (ev, fn)=>{ try{ P.AdMob.addListener(ev, fn).then(h=>{ hs.push(h); if(done && h.remove) h.remove(); }); }catch(e){} };
          on("onRewardedVideoAdReward", ()=>{ earned = true; });
          on("onRewardedVideoAdDismissed", ()=>setTimeout(()=>finish(earned), 500));
          on("onRewardedVideoAdFailedToShow", ()=>{ toast("The video couldn't play. Try again in a moment."); finish(false); });
          P.AdMob.showRewardVideoAd().then(()=>{ earned = true; finish(true); }).catch(()=>{ toast("No video available right now. Try again in a moment."); finish(false); });
          setTimeout(()=>finish(earned), 180000);
        });
      }catch(e){ toast("No video available right now. Try again in a moment."); return false; }
      finally{ this.adBusy = false; if(wasRunning && AC) AC.resume().catch(()=>{}); }
    }
    if(isNativeApp()){ toast("No video available right now. Try again in a moment."); return false; }
    return simulateAd(placement);
  }
};
function simulateStore(prod, price){
  return new Promise(res=>{
    const m = openModal(`<div class="modal-title">Test store</div><div class="modal-sub">No real payment happens here. In the iOS app this opens the App Store purchase sheet.</div>
      <div class="shop-item"><div class="si">${art(prod.icon,46)}</div><div class="grow"><div class="st">${prod.name}</div><div class="sd">${prod.desc}</div></div></div>
      <div class="mbtns row"><button class="btn" data-x="no">Cancel</button><button class="btn gold" data-x="yes">Buy ${price}</button></div>`, {noClose:true});
    m.addEventListener("click", ev=>{ const b = ev.target.closest("[data-x]"); if(!b) return; closeModal(m); res(b.dataset.x==="yes"); });
  });
}
function simulateAd(){
  return new Promise(res=>{
    let n = 3; const m = openModal(`<div class="adsim"><div class="modal-sub">Test video. In the iOS app this shows an AdMob rewarded video.</div><div class="cd" id="adcd">3</div><button class="btn sm ghost" data-x="skip" style="margin-top:12px">Close without reward</button></div>`, {noClose:true});
    const iv = setInterval(()=>{ n--; const el = m.querySelector("#adcd"); if(el) el.textContent = n; if(n<=0){ clearInterval(iv); closeModal(m); res(true); } }, 700);
    m.addEventListener("click", ev=>{ if(ev.target.closest("[data-x]")){ clearInterval(iv); closeModal(m); res(false); } });
  });
}
