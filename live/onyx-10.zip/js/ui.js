/* Onyx Vanguard — ui.js
   Menus: modals, the five tabs (Map, Hero, Skills, Quests, Shop), settings and all button actions.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   MODALS / TOASTS / SCREENS
===================================================================== */
/* Review 6: a chest opens on screen: it shakes, bursts open in the item's rarity colour, the item rises, then its stats and Equip */
/* Review 6: tap a market item to see the knight wearing it, beside how he looks now, with the power it adds */
function knightBody(sk){ return World.portrait(g=>{ g.scale(-1,1); World.drawRig(g, sk, {ld:1, th:1.05, ph:-1, bth:1.2}, 0); }, 130, 186, 70, 176, 1.5); }
function openTryOn(src, idx){ const it = Object.assign({}, src, {uid:-7}), prev = S.equip[it.slot], now = knightBody(heroSkin()); S.inv.push(it); const g = powerGain(it); S.equip[it.slot] = it.uid; const wear = knightBody(heroSkin()); S.equip[it.slot] = prev; S.inv.pop();
  const o = S.daily.offers[idx], bought = S.daily.bought.includes(idx);
  openModal(`<div class="modal-title rc${it.r}">${it.name}</div><div class="modal-sub">${RARITY[it.r].name} ${SLOT_DEF[it.slot].name}${it.set?" · Set item":""}</div>
    <div class="tryon"><figure><img src="${now}" alt=""><figcaption>Now</figcaption></figure><span class="to-arrow">${ico("next",22)}</span><figure class="on"><img src="${wear}" alt=""><figcaption>Wearing it</figcaption></figure>
    <div class="to-info"><div class="mstats">${Object.keys(it.stats).map(k=>`<span>${statLine(k,it.stats[k])}</span>`).join("")}</div><div class="cr-gain ${g>0?"gain":"same"}">${g>0?`${ico("up",14)} +${fmtNum(Math.round(g))} Power`:"Not stronger than what you wear"}</div>
    <button class="btn gold" data-act="buyDaily" data-i="${idx}" ${bought||S.gold<o.price?'disabled':''}>${bought?'Sold':`${art("gold",18,"cur")} ${fmt(o.price)}`}</button></div></div>`); }
function chestReveal(it, box){ const col = RARITY[it.r].color, g = powerGain(it), cur = S.equip[it.slot] ? itemById(S.equip[it.slot]) : null; SFX.pick();
  const m = openModal(`<div class="chest-rev" style="--rc:${col}"><div class="cr-stage"><div class="cr-burst"></div><div class="cr-box">${art(box||"chest",120)}</div><img class="cr-item" src="${itemIcon(it)}" alt=""></div>
    <div class="cr-info"><b class="cr-rar rc${it.r}">${RARITY[it.r].name}</b><h3>${it.name}</h3><small>${it.set?"Set item · ":""}${SLOT_DEF[it.slot].name}</small>
    <div class="cr-gain ${g>0?"gain":"same"}">${g>0?`${ico("up",14)} +${fmtNum(Math.round(g))} Power`:cur?"Not stronger than what you wear":""}</div>
    <div class="mbtns row">${g>0?`<button class="btn gold" data-act="equip" data-uid="${it.uid}">Equip</button>`:""}<button class="btn ghost" data-act="openItem" data-uid="${it.uid}">Details</button><button class="btn ghost" data-close>Close</button></div></div></div>`);
  setTimeout(()=>{ SFX.win(); haptic("MEDIUM"); }, 900); return m; }
function openModal(html, opt={}){
  const back = document.createElement("div"); back.className = "modal-back";
  back.innerHTML = `<div class="modal ${opt.wide?'wide':''}" role="dialog" aria-modal="true">${opt.noClose?'':`<button class="mclose" data-close aria-label="Close">${ico("close",20)}</button>`}${html}</div>`;
  if(!opt.noClose){ back.addEventListener("click", e=>{ if(e.target===back || e.target.closest("[data-close]")){ SFX.click(); closeModal(back); } }); }
  if(html.includes('class="modal-body"')) back.firstElementChild.classList.add("split");     // banner and buttons stay put; the body between them scrolls
  $("#modalRoot").appendChild(back); if(back.firstElementChild.classList.contains("split")) scrollHint(back.firstElementChild);
  fitModal(back.firstElementChild); return back;
}
/* Review 12: a modal that is only a little too tall for the screen is shrunk to fit (CSS zoom, down to FIT_MIN) instead of
   scrolling, so card picks, prefight and result screens always show their buttons. Long lists (more than that) still scroll. */
const FIT_MIN = .74;
function fitModal(m){
  const overOf = ()=>{ const body = m.querySelector(":scope > .modal-body"); return body ? body.scrollHeight - body.clientHeight : m.scrollHeight - m.clientHeight; };
  const run = ()=>{ if(!m.isConnected) return; m.style.zoom = ""; let k = 1;
    for(let i=0; i<4; i++){ const over = overOf(); if(over <= 2) break; k *= m.clientHeight / (m.clientHeight + over);      // zoom changes the layout, so measure again
      if(k < FIT_MIN){ m.style.zoom = ""; return; } m.style.zoom = Math.floor(k * 1000) / 1000; }
    if(k < 1) m.classList.remove("more"); };
  requestAnimationFrame(run); setTimeout(run, 380);       // again once art and fonts have settled
}
/* a scrolling modal body says so: a fade and a "More" chip sit over its lower edge until the end is reached */
function scrollHint(modal){
  const body = modal.querySelector(":scope > .modal-body"); if(!body) return;
  const chip = document.createElement("button"); chip.className = "more-chip"; chip.type = "button"; chip.setAttribute("aria-label", "Scroll down for more"); chip.innerHTML = `<span>More</span><i></i>`;
  chip.addEventListener("click", ()=>{ body.scrollBy({top:Math.max(80, body.clientHeight*.7), behavior:"smooth"}); });
  modal.appendChild(chip);
  const upd = ()=>{ const more = body.scrollHeight - body.scrollTop - body.clientHeight > 10; modal.classList.toggle("more", more); chip.style.bottom = (modal.clientHeight - body.offsetTop - body.offsetHeight + 6) + "px"; };
  body.addEventListener("scroll", upd, {passive:true}); upd(); requestAnimationFrame(upd); setTimeout(upd, 350);      // again once images and fonts have settled
}
function closeModal(m){ if(m && m.parentNode) m.parentNode.removeChild(m); }
function closeTopModal(){ const r = $("#modalRoot"); if(r.lastElementChild) r.removeChild(r.lastElementChild); }
function closeAllModals(){ $("#modalRoot").innerHTML = ""; }
function toast(msg, color){
  if(run && !run.over && typeof laneBusy==="function"){ const wait = laneBusy(); if(wait > 80){ const R = run; setTimeout(()=>{ if(run===R) toast(msg, color); }, wait + 60); return; } }
  if(toastQ.some(o=>o.msg===msg) || (toastNow && toastNow.msg===msg)) return;        // the same line is never queued twice
  toastQ.push({msg, color}); if(toastQ.length > TOAST_MAX) toastQ.splice(0, toastQ.length - TOAST_MAX); toastNext(); }
/* Review 5: messages show one at a time. A waiting message shortens the one on screen instead of piling on top of it. */
const TOAST_MAX = 4, TOAST_MS = 2950, TOAST_SHORT = 1500, toastQ = []; let toastNow = null;
function toastNext(){
  if(toastNow){ if(toastQ.length && !toastNow.cut){ toastNow.cut = true; const left = TOAST_SHORT - (performance.now() - toastNow.at); clearTimeout(toastNow.timer); toastNow.timer = setTimeout(toastEnd, Math.max(250, left)); } return; }
  const o = toastQ.shift(); if(!o) return; const root = $("#toastRoot"); root.innerHTML = "";
  const t = document.createElement("div"); t.className = "toast"; if(o.color) t.style.setProperty("--tc", o.color); t.textContent = o.msg; root.appendChild(t);
  toastNow = {el:t, msg:o.msg, at:performance.now(), cut:!!toastQ.length, timer:setTimeout(toastEnd, toastQ.length ? TOAST_SHORT : TOAST_MS)}; }
function toastEnd(){ const n = toastNow; toastNow = null; if(n){ clearTimeout(n.timer); n.el.classList.add("out"); setTimeout(()=>n.el.remove(), 220); } setTimeout(toastNext, 120); }
function showScreen(name){ $("#homeScreen").classList.toggle("active", name==="home"); $("#runScreen").classList.toggle("active", name==="run"); }
let currentTab = "map";
const NAV = {map:["map","Map"], hero:["hero","Hero"], codex:["skills","Skills"], quests:["quests","Quests"], shop:["shop","Shop"]};
const RENDER = {map:()=>renderMap(), hero:()=>renderHero(), codex:()=>renderCodex(), quests:()=>renderQuests(), shop:()=>renderShop()};
function buildChrome(){
  document.querySelectorAll(".nav").forEach(b=>{ const [i,l] = NAV[b.dataset.t]; b.innerHTML = `${art(i,32)}<span>${l}</span>`; });
  $("#hGold").innerHTML = CUR.gold + '<span id="cGold">0</span>'; $("#hOrbs").innerHTML = CUR.orbs + '<span id="cOrbs">0</span>'; $("#hGems").innerHTML = CUR.gems + '<span id="cGems">0</span>';
  $("#gearBtn").innerHTML = ico("settings",20);
  $("#pillGold").insertAdjacentHTML("afterbegin", CUR.gold); $("#pillKills").insertAdjacentHTML("afterbegin", art("skull",18));
  $("#pauseBtn").innerHTML = ico("pause",20); $("#potBtn").insertAdjacentHTML("afterbegin", art("potion",32)); $("#pickBtn").insertAdjacentHTML("afterbegin", art("skills",30));
  $("#loginBtn").innerHTML = art("login",26); $("#treasBtn").innerHTML = art("treasury",26) + '<span class="tamt" id="treasAmt"></span>';
  setInterval(()=>{ if(!run && !document.hidden){ renderStrip(); if(currentTab==="map" && (S.mapLoot||[]).some(l=>l.exp<Date.now())) renderMap(); } }, 30000);
  $("#homeScreen").dataset.tab = currentTab;
}
function setTab(t){ if(t!=="hero") endPreview(); coachClear(); currentTab = t; document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active", b.dataset.t===t)); document.querySelectorAll(".tab").forEach(s=>s.classList.toggle("active", s.id==="tab-"+t)); $("#homeScreen").dataset.tab = t; renderTab(t); }
function renderCurrencies(){ $("#cGold").textContent = fmt(S.gold); $("#cOrbs").textContent = fmt(S.orbs); $("#cGems").textContent = fmt(S.gems); renderStrip(); updateBadges(); }
/* the player strip: your knight, his power and the next goal (replaces the big title) */
let stripPow = 0, stripKey = "";
function knightFace(){ const sk = heroSkin(), key = JSON.stringify([sk.helm, sk.helmD, sk.helmL, sk.plume, sk.crownCol, sk.wingCol, sk.hornCol, sk.glow, sk.acc]);
  if(knightFace.k===key) return knightFace.url; knightFace.k = key;
  return knightFace.url = World.portrait(g=>{ g.scale(-1,1); World.drawRig(g, sk, {ld:1, th:1.05, ph:-1, bth:1.2}, 0); }, 44, 44, 23, 70, .62); }
function renderStrip(){
  const el = $("#pStrip"); if(!el) return; const pw = powerOf(heroStats(null)), ht = heatTitle(), key = `${pw}|${S.oath.max}|${knightFace()}|${S.name}|${ht}`;
  if(key!==stripKey){ stripKey = key; el.innerHTML = `<span class="pface"><img src="${knightFace()}" alt=""></span><span class="ptxt"><small>${knightName()}${ht?` · ${ht}`:S.oath.max>1?` · Tier ${tierName(S.oath.max)}`:""}</small><b>${art("might",16,"cur")} ${fmt(pw)}</b></span>${stripPow && pw>stripPow?`<em class="pup">+${pw-stripPow}</em>`:""}`; stripPow = pw; }
  const lr = loginReady(), T = treasuryState();
  $("#loginBtn").classList.toggle("hide", !S.cleared["0-0"]); $("#loginBtn").classList.toggle("hot", lr);
  // the treasury is taught on the third win (it arrives pre-filled); older saves keep it
  $("#treasBtn").classList.toggle("hide", !S.cleared["0-0"] || (S.stats.wins<3 && !S.tips.c_treasury)); $("#treasBtn").classList.toggle("hot", T.hrs>=1); $("#treasBtn").classList.toggle("full", T.full);
  const ta = $("#treasAmt"); if(ta) ta.textContent = T.gold ? fmt(T.gold) : "";
  const br = $("#boostRow"); if(br) br.innerHTML = Object.keys(BOOSTS).filter(k=>boostLeft(k)>0).map(k=>`<button class="bchip" style="--lc:${BOOSTS[k].col}" data-act="boostInfo" data-k="${k}">${art(BOOSTS[k].icon,20)}<b>${Math.ceil(boostLeft(k)/60e3)}m</b></button>`).join("");
}
function renderAll(){ dailyReset(); renderCurrencies(); renderTab(currentTab); }
function renderTab(t){ setWorldTheme(homeTheme()); RENDER[t](); renderCurrencies(); }
/* red dots / counts on the rail when there's something to do */
/* badge rules: red = something free to claim right now; green arrow = an upgrade you can afford; nothing for passive states */
function updateBadges(){
  const canTrain = META.some(m=>S.meta[m.id]<m.max && S.gold>=trainCost(m)) || SLOTS.some(s=>bestUpgrade(s));
  const canUp = CARDS.some(c=>cardLv(c.id)<CARD_MAX && S.orbs>=orbCost(cardLv(c.id)));
  const free = questsClaimable() + passClaimable();
  const set = (t,on,kind)=>{ const b = document.querySelector(`.nav[data-t="${t}"]`); if(!b) return; let d = b.querySelector(".dot");
    if(on && !d){ d = document.createElement("i"); b.appendChild(d); } else if(!on && d){ d.remove(); d = null; }
    if(d){ d.className = "dot" + (kind==="up" ? " up" : typeof on==="number" ? " n" : ""); d.textContent = kind==="up" ? "▲" : typeof on==="number" ? on : ""; } };
  set("hero", canTrain, "up"); set("codex", canUp, "up"); set("quests", free||false);
  set("shop", (S.cleared["0-0"] && !S.daily.adChest) || (favorActive() && S.favor.gemsDay!==todayKey()));
  set("map", false);
}
/* UPGRADES — judged by the same Power formula the rest of the game uses.
   Per slot, only the single best item counts as an upgrade, and only if it lifts Power by 3% or more
   (an empty slot always counts). Results are cached until the next save. */
const UPGRADE_MIN = .03;
let upCache = {rev:-1, map:{}};
function upgradeMap(){
  if(upCache.rev===gearRev) return upCache.map;
  const map = {}, p0 = powerOf(heroStats(null));
  for(const sl of SLOTS){ const prev = S.equip[sl]; let best = null;
    for(const it of S.inv){ if(it.slot!==sl || it.uid===prev) continue; S.equip[sl] = it.uid; const g = powerOf(heroStats(null)) - p0; if(g>0 && (!best || g>best.gain)) best = {uid:it.uid, gain:g}; }
    S.equip[sl] = prev;
    if(best && (!prev || best.gain >= Math.max(1, p0*UPGRADE_MIN))) map[sl] = best; }
  upCache = {rev:gearRev, map}; return map;
}
const slotUpgrade = sl => upgradeMap()[sl] || null;
function isUpgrade(it){ const u = upgradeMap()[it.slot]; return !!u && u.uid===it.uid; }
function bestUpgrade(slot){ return !!upgradeMap()[slot]; }
/* only used to order the bag */
function itemScore(it){ const s = itemStats(it); return (s.dmg||0)*3 + (s.hp||0)*.25 + (s.armor||0)*1.5 + (s.crit||0) + (s.block||0) + (s.dmgPct||0)*1.4 + (s.hpPct||0)*1.1 + (s.aspd||0)*1.4 + (it.set?4:0); }
/* Equip best: per slot, the item that gives the most Power with everything else as worn; repeated until nothing improves
   (set bonuses can make a second pass worthwhile). Power can only go up. */
function equipBestAll(){
  let n = 0;
  for(let pass=0; pass<3; pass++){ let changed = false;
    for(const sl of SLOTS){ const prev = S.equip[sl]; let bestUid = prev, bestP = powerOf(heroStats(null));
      for(const it of S.inv){ if(it.slot!==sl || it.uid===prev) continue; S.equip[sl] = it.uid; const p = powerOf(heroStats(null)); if(p > bestP){ bestP = p; bestUid = it.uid; } }
      S.equip[sl] = bestUid; if(bestUid!==prev){ changed = true; n++; } }
    if(!changed) break; }
  return n;
}

/* =====================================================================
   MAP TAB — pick the next battle on the painted world map
===================================================================== */
const actUnlocked = a => a===0 || !!S.cleared[`${a-1}-4`];
const levelUnlocked = (a,i) => actUnlocked(a) && (i===0 || !!S.cleared[`${a}-${i-1}`]);
function nextLevel(){ for(let a=0;a<ACTS.length;a++) for(let i=0;i<5;i++) if(!S.cleared[`${a}-${i}`]) return levelUnlocked(a,i) ? {a,i} : null; return null; }
/* the furthest threat reached on any tier (drives loot and reward scaling) */
function maxClearedD(){ let m = 0; for(let t=1;t<=S.oath.max;t++) for(let a=0;a<ACTS.length;a++) for(let i=0;i<5;i++) if(isClearedT(t,a,i)) m = Math.max(m, threatOf(t,a,i)); return m; }
const uiZoom = () => parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--z")) || 1;
let mapKey = "", mapScrolled = "";
/* what the player is working toward next (shown under the Fight button) */
/* short enough to never be cut off on the smallest phone: "Next: <what> → <what it opens>" */
function nextGoal(){
  if(!isOpen("keep")) return {icon:"keep", text:"Wolfwood → the Keep"};
  if(!isOpen("arena")) return {icon:"arena", text:"Bandit Camp → the Arena"};
  if(!S.cleared["0-4"]) return {icon:"raid", text:"Outlaw King → Raid, Endless"};
  if(!S.cleared["1-4"]) return {icon:"frag", text:"Bone Lord → Frostveil, runes"};
  if(!S.cleared["2-4"]) return {icon:"crown", text:"Jarl of Winter → Emberforge"};
  if(!S.cleared["3-4"]) return {icon:"might", text:"Forge Tyrant → Astral Sanctum"};
  if(!S.cleared["4-4"]) return {icon:"tier", text:"Void Herald → Oath Tier II"};
  return {icon:"tier", text:`The Herald → Tier ${tierName(S.oath.max+1)}`};
}
/* the modes dock: what each mode has ready. `ready` = a free reward is waiting (the only thing that earns a red dot);
   `sub` = a labelled count such as "3/3" keys (never a bare number, and never a zero). */
function dockState(k){
  if(k==="arena") return {sub:`${S.arena.tickets}/${ARENA_TICKETS}`, urgent:S.arena.tickets>0, ready:arenaChestReady()};
  if(k==="raid") return {sub:`${S.raid.keys}/${RAID_KEYS}`, urgent:S.raid.keys>0, ready:!S.raid.goal && (S.raid.day||0) >= raidGoal()};
  if(k==="keep"){ const n = S.bounty.list.filter(b=>!b.done).length + S.trials.list.filter(t=>!t.done).length + (weeklyOpen() ? weeklyLeft() : 0); return {sub:n ? `${n} to do` : "", urgent:n>0, ready:false}; }
  if(k==="endless") return {sub:S.endlessBest ? `Wave ${S.endlessBest+1}` : "", urgent:false, ready:false};
  if(k==="challenges"){ const n = CHALLENGES.filter(c=>S.challenges[c.id]).length; return {sub:`${n}/${CHALLENGES.length}`, urgent:false, ready:false}; }
  return {sub:"", urgent:false, ready:false};
}
function powerTag(pw, sp, short){ const c = pw>=sp ? "easy" : pw>=sp*.8 ? "fair" : "hard";
  return `<span class="ptag ${c}" ${short?`aria-label="Your power ${pw}, recommended ${sp}"`:""}>${art("might",16,"cur")} <b>${fmt(pw)}</b><small>${short?"needs":"Recommended"} ${fmt(sp)}</small></span>`; }
const MODE_DOCK = [["keep","Keep"],["arena","Arena"],["raid","Raid"],["endless","Endless"],["challenges","Spire"]];
function renderMap(){
  const tab = $("#tab-map"), T = S.oath.sel = clamp(S.oath.sel||1, 1, S.oath.max);
  if(!tab.querySelector(".map-wrap")) tab.innerHTML = `<div class="map-wrap"><div class="map-scroll"><div class="map-inner"><canvas class="map-bg"></canvas><div class="map-layer"></div></div></div><div class="map-note"></div></div><div class="map-bar"><div class="dock-wrap"><div class="dock"></div></div><div class="map-cta"></div></div>`;
  const inner = tab.querySelector(".map-inner"), cv = tab.querySelector(".map-bg"), scroll = tab.querySelector(".map-scroll");
  const nx = nextLevelT(T), openActs = ACTS.map((_,a)=>a).filter(a=>actUnlockedT(T,a)).length, reached = nx ? nx.a*5+nx.i : ACTS.length*5;
  const h = inner.offsetHeight; if(h) inner.style.width = Math.round(h*MAP_W/MAP_H) + "px";
  if(h){ const pxH = Math.min(820, Math.round(h*uiZoom()*(window.devicePixelRatio||1))), key = `${pxH}|${openActs}|${reached}`;
    if(key!==mapKey){ mapKey = key; paintMap(cv, pxH, {open:openActs, reached}); } }
  const pos = (x,y)=>`left:${x/MAP_W*100}%;top:${y/MAP_H*100}%`;
  let L = "";
  const flat = MAP_NODES.flat();
  ACTS.forEach((act,a)=>act.levels.forEach((ln,i)=>{ const k = a*5+i, [x,y] = MAP_NODES[a][i], nb = [flat[k-1], flat[k+1]].filter(Boolean), up = i!==4 && y < nb.reduce((s,p)=>s+p[1],0)/nb.length;
    const done = isClearedT(T,a,i), unl = levelUnlockedT(T,a,i), open = unl && !done, boss = i===4, locked = !unl, d = threatOf(T,a,i), hb = done ? heatBest(T,a,i) : 0;
    if(locked && !actUnlockedT(T,a) && !boss) return;            // unexplored acts stay under the fog
    L += `<button class="mnode ${done?'done':open?'open':''} ${boss?'boss':''} ${locked?'locked':''} ${up?'lup':''}" style="${pos(x,y)}" data-act="openLevel" data-a="${a}" data-i="${i}" aria-label="${ln}${hb?`, best Heat ${hb}`:""}">
      <span class="gem"><span>${done?ico("check",16):boss?art("skull",24):locked?"":d}</span></span>${hb?`<i class="hbest" title="Your best: Heat ${hb}">${hb}</i>`:""}
      ${open||(boss&&!locked&&!done)?`<span class="nl"><b>${ln}</b>${boss?'Boss':'Threat '+d}</span>`:''}</button>`; }));
  for(const k in MAP_MARKS){ const m = MAP_MARKS[k]; if(!isOpen(k)) continue;
    L += `<button class="mmark" style="${pos(m.x,m.y)}" data-act="mark" data-k="${k}"><span class="mi">${art(m.icon,40)}</span><span class="nl"><b>${m.name}</b></span></button>`; }
  const lnow = Date.now();
  for(const l of (S.mapLoot||[])) if(l.exp>lnow){ const T = TREASURES[l.k];
    L += `<button class="mloot ${T.boost?'boost':''} ${lootFresh.includes(l.id)?'fresh':''}" style="${pos(l.x,l.y)};--lc:${T.boost?BOOSTS[T.boost].col:l.k==='gems'?'#ff6a8a':l.k==='orbs'?'#c9a2ff':'#f2d796'}" data-act="mapLoot" data-id="${l.id}" aria-label="${T.name}"><span class="lg">${art(T.icon,30)}</span><i class="lr"></i></button>`; }
  lootFresh = [];
  if(nx){ const [x,y] = MAP_NODES[nx.a][nx.i]; L += `<div class="mhero" style="${pos(x-44,y-8)}">${art("hero",34)}</div>`; }
  tab.querySelector(".map-layer").innerHTML = L;
  // the knight walks the road to the next node after a win
  const hk = nx ? `${T}|${nx.a}-${nx.i}` : "";
  if(nx && S.mapAt && S.mapAt!==hk && S.mapAt.split("|")[0]===String(T)){ const [pa,pi] = S.mapAt.split("|")[1].split("-").map(Number), from = MAP_NODES[pa] && MAP_NODES[pa][pi], mh = tab.querySelector(".mhero");
    if(from && mh){ const to = mh.getAttribute("style"); mh.setAttribute("style", pos(from[0]-44, from[1]-8)); mh.classList.add("walk"); requestAnimationFrame(()=>requestAnimationFrame(()=>{ mh.setAttribute("style", to); setTimeout(()=>{ SFX.level(); const n = tab.querySelector(`.mnode.open`); if(n) n.classList.add("lit"); }, 1300); })); } }
  if(nx) S.mapAt = hk;
  // bottom bar: the modes dock (always reachable) and the next battle
  // modes with something ready come first; the dock scrolls sideways (with a fade at the edge) when the screen is narrow
  const modes = MODE_DOCK.filter(([k])=>isOpen(k)).map(([k,lab],n)=>({k, lab, n, st:dockState(k)})).sort((a,b)=>(b.st.ready-a.st.ready) || (b.st.urgent-a.st.urgent) || a.n-b.n);
  const dock = tab.querySelector(".dock");
  dock.innerHTML = (S.oath.max>1 ? `<button class="dk tier" data-act="tiers">${art("tier",28)}<span>Tier ${tierName(T)}</span></button>` : "") +
    modes.map(m=>`<button class="dk ${m.st.urgent?'urgent':''}" data-act="mark" data-k="${m.k}" aria-label="${m.lab}${m.st.sub?`, ${m.st.sub}`:""}">${art(MAP_MARKS[m.k].icon,30)}<span>${m.lab}</span>${m.st.sub?`<em>${m.st.sub}</em>`:""}${m.st.ready?'<i class="mdot"></i>':''}</button>`).join("");
  const dw = tab.querySelector(".dock-wrap"), fadeDock = ()=>{ dw.classList.toggle("more", dock.scrollWidth - dock.clientWidth - dock.scrollLeft > 4); dw.classList.toggle("less", dock.scrollLeft > 4); };
  if(!dock._fx){ dock._fx = 1; dock.addEventListener("scroll", fadeDock, {passive:true}); } requestAnimationFrame(fadeDock);
  // weekend events and running offers are announced on the map
  const we = weekendEvent(), live = liveOffers()[0], note = tab.querySelector(".map-note");
  note.innerHTML = (we ? `<button class="mnote" data-act="weekendInfo">${art(we.icon,22)}<b>${we.name}</b></button>` : "") + (live && Monetization.storeReady() ? `<button class="mnote timed" data-act="tab" data-t="shop">${art("crown",22)}<b>${PRODUCTS[TIMED[live].k].name}</b><em>${offerLeft(live)}</em></button>` : "");
  const goal = nextGoal();
  let cta;
  if(nx){ const d = threatOf(T,nx.a,nx.i), pw = powerOf(heroStats(null)), sp = recPower(T, threatOf(1,nx.a,nx.i));
    cta = `<div class="cta-t"><small>${T>1?`Tier ${tierName(T)} · `:""}${ACTS[nx.a].short}-${nx.i+1} · ${nx.i===4?'Boss':'Threat '+d}</small>${ACTS[nx.a].levels[nx.i]}<span class="goal">${art(goal.icon,14)} ${goal.text}</span></div>
      ${powerTag(pw, sp, true)}${cmdOpen() ? `<button class="cmd-mini" data-act="cmdInfo" aria-label="Vanguard Command battles left today">${art("seal",20)}<b>${cmdUnlimited() ? "∞" : cmdLeft()}</b></button>` : ""}<button class="btn gold" data-act="openLevel" data-a="${nx.a}" data-i="${nx.i}">${ico("swords",18)} Fight</button>`; }
  else if(S.oath.max>T) cta = `<div class="cta-t"><small>Tier ${tierName(T)} complete</small>Oath Tier ${tierName(S.oath.max)} awaits</div><button class="btn gold" data-act="setTier" data-t="${S.oath.max}">${art("tier",20)} Go</button>`;
  else cta = `<div class="cta-t"><small>The realm is saved</small>Endless Descent</div><button class="btn gold" data-act="openEndless">${ico("infinity",18)} Descend</button>`;
  tab.querySelector(".map-cta").innerHTML = cta;
  const sk = `${T}|` + (nx ? `${nx.a}-${nx.i}` : "end");
  if(mapScrolled!==sk && inner.offsetWidth){ mapScrolled = sk; const fx = nx ? MAP_NODES[nx.a][nx.i][0] : MAP_MARKS.endless.x;
    requestAnimationFrame(()=>{ scroll.scrollLeft = Math.max(0, fx/MAP_W*inner.offsetWidth - scroll.clientWidth*.45); }); }
}
function openTiers(){
  let h = `<div class="mode-head banner" style="background-image:url(img/vista_frost.jpg)">${art("tier",60)}<div><div class="modal-title">Oath Tiers</div><div class="modal-sub">Every tier is the whole realm again: stronger enemies, better loot and Starmetal from every boss. Mythic items start to drop on Tier II.</div></div></div>`;
  for(let t=1; t<=S.oath.max; t++){ let n = 0; const N = ACTS.length*5; for(let a=0;a<ACTS.length;a++) for(let i=0;i<5;i++) if(isClearedT(t,a,i)) n++;
    h += `<div class="list-row ${S.oath.sel===t?'sel-row':''}"><div class="li">${art("tier",34)}</div><div class="grow"><div class="lt">Oath Tier ${tierName(t)} <small>Threat ${threatOf(t,0,0)}–${threatOf(t,LAST_ACT,4)}</small></div><div class="ld">${n}/${N} levels cleared · suggested power ${recPower(t, 1)}+</div><div class="bar thin"><i style="width:${n/N*100}%"></i></div></div>
      <button class="btn sm ${S.oath.sel===t?'':'gold'}" data-act="setTier" data-t="${t}" ${S.oath.sel===t?'disabled':''}>${S.oath.sel===t?'Current':'Travel'}</button></div>`; }
  h += `<div class="tip">Clear the Herald's Throne on your highest tier to unlock the next one.</div>`;
  closeAllModals(); openModal(h, {wide:true});
}
/* weak / resist chips for an enemy tile (counterplay shown before the fight) */
function modChips(type){ const [w, r] = enemyMods(type);
  return (w.length || r.length) ? `<span class="emods">${w.map(k=>`<i class="wk" style="--tc:${TAGS[ELEM_TAG[k]].color}">${k==="phys"?ico("swords",13):tagIco(ELEM_TAG[k],14)}<b class="ar">${ico("up",12)}</b><u>Weak to ${ELEM_NAME[k]}</u></i>`).join("")}${r.map(k=>`<i class="rs" style="--tc:${TAGS[ELEM_TAG[k]].color}">${k==="phys"?ico("swords",13):tagIco(ELEM_TAG[k],14)}<b class="ar">${ico("down",12)}</b><u>Resists ${ELEM_NAME[k]}</u></i>`).join("")}</span>` : ""; }
let pfHeat = null, pfHorde = false, pfPrep = false;
function openPrefight(cfg){
  let a, i, d, title, sub, lore; const campaign = cfg.mode==="campaign";
  // a save from before Vanguard Command meets the daily allowance the first time a battle is opened: the card shows alone,
  // and the prefight screen opens when it is closed (never both at once, never on top of the map at launch)
  if(campaign && cmdOpen() && !S.tips.cmd && !run){ S.tips.cmd = 1; persist(); closeAllModals(); cmdThen = cfg; openCommandSheet("unlock"); return; }
  if(cfg.mode==="challenge"){ const ch = CHALLENGES.find(c=>c.id===cfg.id); a = ch.act; i = ch.lvl; d = ch.d; title = ch.name; sub = `Challenge · Threat ${d}`; lore = `${ch.desc} Reward on first clear: ${ch.reward.orbs} Orbs and ${ch.reward.gems} Gems.`; }
  else { a = cfg.a; i = cfg.i; const t = cfg.tier||1; d = threatOf(t,a,i); title = ACTS[a].levels[i]; sub = `${t>1?`Oath Tier ${tierName(t)} · `:""}Act ${ACTS[a].short} · ${i===4?'Boss':'Threat '+d}${isClearedT(t,a,i)?' · Cleared':''}`; lore = (i===4 ? `Boss battle. Defeat ${ENEMY[ACTS[a].boss].name} to finish the act.` : ACTS[a].lore) + (t>1 ? ` Tier ${tierName(t)}: every elite carries a trait and bosses enrage when wounded.` : ""); }
  const act = ACTS[a]; const types = [...new Set(act.pool)].filter(t=>!(ENEMY[t].big && a===0 && i<2)); if(i===4) types.unshift(act.boss);      // the boss leads the row, so it is on screen even when the row wraps
  // Heat: the last one used, or what the last result suggests
  const hOpen = campaign && heatOpen(), hMax = hOpen ? heatMax() : 0, sug = hOpen ? heatSuggest(cfg.tier||1, a, i) : {h:0}, carry = hOpen ? heatTarget(cfg.tier||1, a, i) : 0;
  // the Heat is pre-selected from the knight's Power and the last result; the player's own choice stands once he changes it
  if(!hOpen) pfHeat = 0; else if(pfHeat===null || cfg.heat===undefined) pfHeat = clamp(cfg.heat!==undefined ? cfg.heat : sug.h, 0, hMax);
  const heat = clamp(pfHeat, 0, hMax); cfg = Object.assign({}, cfg, {heat});
  const we = campaign ? weekendEvent() : null, horde = !!(we && we.id==="horde" && pfHorde); if(campaign){ if(horde) cfg.mods = {hordeWk:true}; else delete cfg.mods; }
  const st = heroStats(null), pw = powerOf(st), sp = heatPower(cfg.mode==="challenge" ? suggestedPower(d) : recPower(cfg.tier||1, threatOf(1,a,i)), heat), res = campaign ? resolveFor(cfg.tier||1, a, i) : 0;
  const banList = S.bans.map(id=>CARD_BY[id]).filter(Boolean);
  const heroFoe = i===4 ? act.boss : act.pool[(i+1) % act.pool.length];
  const best = campaign ? heatBest(cfg.tier||1, a, i) : 0, oaths = oathsOpen(), cj = JSON.stringify(cfg).replace(/'/g,"&#39;");
  const heatBox = hOpen ? `<div class="heat-box"><div class="hb-top">${art("heat",30)}<div class="grow"><b>Heat ${heat}</b><small>${heat ? `Enemies ×${heatMul(heat) >= 10 ? Math.round(heatMul(heat)) : r1(heatMul(heat))} HP and damage · <em>+${Math.round((heatLoot(heat)-1)*100)}% gold and orbs</em>` : "Standard difficulty. Raise the Heat for richer loot."}</small></div>
        <div class="stepper"><button data-act="pfHeat" data-v="${heat-1}" data-cfg='${cj}' ${heat<=0?'disabled':''} aria-label="Lower Heat">−</button><button data-act="pfHeat" data-v="${heat+1}" data-cfg='${cj}' ${heat>=hMax?'disabled':''} aria-label="Raise Heat">+</button></div></div>
      <div class="hb-sub">${best?`Your best here: Heat ${best}. `:""}${
        sug.why==="down" && heat>sug.h ? `<button class="linkbtn inline" data-act="pfHeat" data-v="${sug.h}" data-cfg='${cj}'>Too hot? Step down to Heat ${sug.h}</button>`
        : sug.why==="down" && heat===sug.h && sug.from>heat ? `Stepped down from Heat ${sug.from} after that loss.`
        : heat>0 && heat===sug.h && (sug.why==="up" || sug.why==="ease") ? `Chosen from your Power and your last battles. <button class="linkbtn inline" data-act="pfHeat" data-v="0" data-cfg='${cj}'>Back to Heat 0</button>`
        : heat<carry ? `<button class="linkbtn inline glow-t" data-act="pfHeat" data-v="${carry}" data-cfg='${cj}'>Your Power can carry Heat ${carry}</button>`
        : !heatCounts(cfg.tier||1, a, i) ? `Old ground: wins here pay the Heat bonus but do not unlock a higher Heat.`
        : heat>=HEAT.max ? `Heat ${HEAT.max} is the summit of the ladder.` : heat>=hMax ? `Win at Heat ${hMax} to unlock more. A clean win unlocks several steps.` : `Unlocked up to Heat ${hMax}.`}</div></div>` : "";
  const oathBox = oaths.length ? `<div class="h2">Starting oath <small>one perk for this battle</small></div><div class="oath-row"><button class="oath ${!S.oathSel||!OATHS[S.oathSel]?'on':''}" data-act="pfOath" data-v="" data-cfg='${cj}'>None</button>${oaths.map(k=>`<button class="oath ${S.oathSel===k?'on':''}" data-act="pfOath" data-v="${k}" data-cfg='${cj}' aria-label="${OATHS[k].name}">${art(OATHS[k].icon,22)}<span>${OATHS[k].name.replace("Oath of ","")}</span></button>`).join("")}</div>${S.oathSel && OATHS[S.oathSel] && OATHS[S.oathSel].test() ? `<div class="mute oath-t">${OATHS[S.oathSel].text}.</div>` : ""}` : "";
  const oathOn = S.oathSel && OATHS[S.oathSel] && OATHS[S.oathSel].test() ? OATHS[S.oathSel].name : "";
  const prepLine = [oathOn || (oaths.length ? "No starting oath" : ""), S.loadouts.some(Boolean) ? "loadouts" : "", `${S.bans.length} disabled skill${S.bans.length===1?"":"s"}`, "abilities"].filter(Boolean).join(" · ");
  const html = `<div class="mode-head banner tall" style="background-image:url(${IMG("foe_"+heroFoe)})">${i===4?art("skull",46):art("battle",46)}<div><div class="modal-title">${title}</div><div class="modal-sub">${sub}</div></div></div>
    <div class="modal-body"><div class="pf-cols"><div>
      <div class="modal-sub" style="text-align:left;margin:0 0 8px">${lore}</div>
      <div class="h2">Enemies <small>tap for details</small></div>
      <div class="enemy-row">${types.map(t=>`<button class="etile ${ENEMY[t].boss?'boss':''}" data-act="enemyInfo" data-t="${t}" data-d="${d}"><img src="${enemyPortrait(t)}" alt=""><div>${ENEMY[t].name}</div>${modChips(t)}</button>`).join("")}</div>
      ${pfPrep ? `<div class="h2">Abilities <small>your first two skill types at 2 skills</small></div>
      <div class="ab-row">${SYN_TAGS.map(t=>`<button class="abchip" style="--tc:${TAGS[t].color}" data-act="abilInfo" data-t="${t}">${art(ABILITIES[t].icon,24)}<span>${ABILITIES[t].name}</span></button>`).join("")}</div>` : ""}
    </div><div>
      <div class="pow" style="margin-top:0">${powerTag(pw, sp)}${pw<sp*.8?`<div class="pow-tip">This one will be hard. Train or forge in the Hero tab first${heat?", or lower the Heat":""}.</div>`:""}${res?`<div class="pow-tip good">${art("vigor",14)} Resolve +${res}% damage and health from your earlier tries.</div>`:""}</div>
      ${heatBox}
      ${we && we.id==="horde" ? `<button class="set-row horde ${horde?'on':''}" data-act="pfHorde" data-cfg='${cj}'>${art("horde",26)}<span class="grow">Horde weekend<small>+2 enemies in every pack · double gold and orbs</small></span><span class="toggle ${horde?'on':''}"><i></i><span>${horde?'On':'Off'}</span></span></button>` : ""}
      <button class="pf-prep ${pfPrep?'on':''}" data-act="pfPrep" data-cfg='${cj}' aria-expanded="${pfPrep}">${art("skills",22)}<span class="grow"><b>Prepare</b><small>${prepLine}</small></span>${ico(pfPrep?"up":"down",16)}</button>
      ${pfPrep ? `${oathBox}
      ${S.loadouts.some(Boolean) ? `<div class="h2">Loadout <small>gear and disabled cards</small></div><div class="oath-row">${[0,1].map(k=>S.loadouts[k] ? `<button class="oath ${loadoutWorn(k)?'on':''}" data-act="pfLoad" data-i="${k}" data-cfg='${cj}'>${ico("shirt",16)}<span>${LOADOUT_NAMES[k]} set</span></button>` : "").join("")}</div>` : ""}
      <div class="h2">Disabled cards <small>${S.bans.length}/${MAX_BANS}</small></div>
      <div class="row" style="flex-wrap:wrap">${banList.length?banList.map(c=>`<span class="chip on" style="--tc:${TAGS[c.tag].color}">${c.name}</span>`).join(""):'<span class="mute" style="font-size:13px">None. Disabled cards never show up in battle.</span>'}</div>
      <button class="btn sm ghost" style="margin-top:8px" data-act="editBans" data-cfg='${cj}'>Choose skills to disable</button>` : ""}
    </div></div></div>
    <div class="mbtns row"><button class="btn gold big" data-act="startLevel" data-cfg='${cj}'>${ico("swords",20)} Start battle${heat?` · Heat ${heat}`:""}</button></div>`;
  const keep = $("#modalRoot .modal-body"), top = keep ? keep.scrollTop : 0;
  closeAllModals(); const m = openModal(html, {wide:true}); if(top){ const mb = m.querySelector(".modal-body"); if(mb){ mb.scrollTop = top; mb.dispatchEvent(new Event("scroll")); } }
}
/* Vanguard Command: what it is, how many battles are left, and how to get more (never a hard error) */
let cmdThen = null, cmdAfter = null;      // what waits behind the Command card: a prefight screen, or the next step after a battle
function cmdResume(){ const f = cmdAfter; cmdAfter = null; const cfg = cmdThen; cmdThen = null; if(f){ f(); return; } if(cfg && !run) openPrefight(cfg); }
/* speed or an auto mode was asked for in a battle without Command */
function cmdGate(why){ const R = run;
  if(!cmdOpen()){ toast("Speed and auto modes unlock when the Outlaw King falls.", "#d9c2ff"); return; }
  if(R && R.cmdAsked){ toast("No Vanguard Command battles left today. Tap the seal for more.", "#d9c2ff"); return; }
  if(R) R.cmdAsked = true; openCommandSheet(why); }
function openCommandSheet(why){
  const R = run; if(R && !R.over) R.paused = true;
  const un = cmdUnlimited(), left = cmdLeft(), ads = cmdAdsLeft(), store = Monetization.storeReady();
  const open = cmdOpen(), unlock = why==="unlock";
  const head = unlock ? "Vanguard Command unlocked" : !open ? "Vanguard Command" : why==="speed" ? "Speed is part of Vanguard Command" : why==="pick" ? "Auto-pick is part of Vanguard Command" : why==="cast" ? "Auto-cast is part of Vanguard Command" : "Vanguard Command";
  const state = !open ? "Speed and auto modes unlock when the Outlaw King falls." : un ? "Unlimited. Thank you for supporting the Vanguard." : left>0 ? `<b>${left}</b> of ${cmdCap()} battles left today. A battle only counts if you use speed or an auto mode.` : "No Vanguard Command battles left today. They refresh at midnight.";
  const html = `<div class="mode-head">${art("seal",52)}<div><div class="modal-title">${head}</div><div class="modal-sub">${unlock ? (un ? "Speed and auto modes are yours, in every battle." : `Speed and auto modes are yours: ${CMD_FREE} battles a day, free.`) : state}</div></div></div>
    <div class="modal-body">
    <div class="cmd-feats"><div>${art("tempest",30)}<b>Speed ×2 and ×3</b><small>tap the speed button</small></div><div>${art("skills",30)}<b>Auto-pick</b><small>hold the skill button</small></div><div>${art("ab_meteor",30)}<b>Auto-cast</b><small>hold an ability</small></div></div>
    <div class="set-box cmd-how">${ico("info",14)}<span>Hold a button for a moment to make it automatic; hold again to take it back. ×1, tapping abilities and potions are always free.</span></div>
    <div class="mbtns cmd-btns">
      ${open && !un && !unlock && ads>0 ? `<button class="btn teal" data-act="cmdAd">${ico("video",18)} Watch a video · +${CMD_PER_AD} battles <small>${ads} left today</small></button>` : ""}
      ${!un && !unlock && store && S.cleared["0-4"] ? `<button class="btn gold" data-act="iap" data-k="seal" data-cmd="1">${art("seal",20)} Commander's Seal · ${Monetization.price("seal")} <small>unlimited, forever · no videos</small></button>
        <button class="btn purple" data-act="iap" data-k="favor" data-cmd="1">${art("crown",20)} Vanguard's Favor · ${Monetization.price("favor")}/month <small>unlimited · renews monthly, cancel anytime</small></button>` : ""}</div>
    ${!un && !unlock && store && S.cleared["0-4"] ? `<div class="fv-legal" style="padding:8px 0 0">Vanguard's Favor renews automatically each month at the price shown until you cancel in iOS Settings → Apple Account → Subscriptions. <button class="linkbtn inline" data-act="terms">Terms of Use</button> · <button class="linkbtn inline" data-act="privacy">Privacy</button></div>` : ""}
    </div>
    <div class="mbtns row"><button class="btn ${cmdThen || unlock ? "gold" : "ghost"}" data-act="cmdClose">${R ? "Back to the battle" : cmdThen ? "Continue to the battle" : unlock ? "Onward" : "Close"}</button></div>`;
  openModal(html, {noClose:true, wide:true}).firstElementChild.classList.add("cmd-sheet");
}
/* after a campaign battle: naming, one lesson per win, the moment offers, auto-salvage */
function afterBattle(R){
  const sal = autoSalvage(R.rewards && R.rewards.item ? R.rewards.item.uid : 0); if(sal){ persist(); renderCurrencies(); setTimeout(()=>toast(`Auto-salvaged ${sal.n} spare item${sal.n>1?"s":""}: +${fmt(sal.gold)} gold, +${sal.dust} dust`, "#d0ab62"), 900); }
  const seq = [];
  if(!S.name && S.stats.wins>=1 && !S.tips.named) seq.push(next=>openNameModal(next));
  // beating the Outlaw King gives something: Vanguard Command unlocks, on the map, before any offer
  if(cmdOpen() && !S.tips.cmd) seq.unshift(next=>{ S.tips.cmd = 1; persist(); cmdAfter = next; openCommandSheet("unlock"); });
  if(R.storyAct!=null) seq.unshift(next=>showStory(R.storyAct, next));        // the act's closing page comes first, alone
  if(R.firstBossWin){ seq.push(next=>offerPopup("boss", next)); }
  seq.push(next=>{ coachNext(); next(); });
  let k = 0; const step = ()=>{ const f = seq[k++]; if(f) setTimeout(()=>f(step), k===1 ? 500 : 250); }; step();
}
/* THE STORY: one page when an act ends (its boss as the picture, three lines that arrive one by one) and a longer one at the end */
let storyAfter = null;
function showStory(a, after){
  const P = ACT_END[a]; if(!P || S.tips["story_"+a]){ if(after) after(); return; } S.tips["story_"+a] = 1; persist(); storyAfter = after || null;
  const act = ACTS[a], nxt = ACTS[a+1];
  closeAllModals();
  openModal(`<div class="story ${P.end?'end':''}" style="background-image:url(${IMG(P.end ? "vista_"+act.theme : "foe_"+act.boss)})"><div class="story-in">
      <small>${P.end ? "The end of the first road" : `${act.name.replace(": ", " · ")} · complete`}</small><b>${P.title}</b>
      ${P.lines.map((l,k)=>`<p style="animation-delay:${.5 + k*1.15}s">${l}</p>`).join("")}
      <div class="mbtns row" style="animation-delay:${.6 + P.lines.length*1.15}s"><button class="btn gold big" data-act="storyDone">${P.end ? "The road goes on" : nxt ? `On to ${nxt.name.replace(/^Act [IV]+: /, "")}` : "Onward"}</button></div></div></div>`, {noClose:true, wide:true});
  SFX.syn(); Music.duck(true); setTimeout(()=>Music.duck(false), 4000);
}
function openBanEditor(cfg){
  const html = `<div class="modal-title">Disable cards</div><div class="modal-sub">Tap up to ${MAX_BANS} cards to keep them out of your offers. ${S.bans.length}/${MAX_BANS} disabled.</div>
    <div class="ban-grid">${CARDS.map(c=>`<button class="ban ${S.bans.includes(c.id)?'off':''}" style="--tc:${TAGS[c.tag].color}" data-act="toggleBanPF" data-id="${c.id}" data-cfg='${JSON.stringify(cfg)}'>${art(c.icon,34)}${c.name}</button>`).join("")}</div>
    <div class="mbtns row"><button class="btn gold" data-act="backPrefight" data-cfg='${JSON.stringify(cfg)}'>Done</button></div>`;
  closeAllModals(); openModal(html, {wide:true, noClose:true});
}
function toggleBan(id){
  const i = S.bans.indexOf(id);
  if(i>=0) S.bans.splice(i,1); else { if(S.bans.length>=MAX_BANS){ toast(`You can disable up to ${MAX_BANS} cards. Enable one first.`); return false; } S.bans.push(id); }
  persist(); return true;
}
function openChallenges(){
  if(!isOpen("challenges")){ toast(UNLOCK.challenges.how); return; }
  const done = CHALLENGES.filter(c=>S.challenges[c.id]).length, capeGot = S.capes.includes("emberc");
  const html = `<div class="mode-head banner" style="background-image:url(img/vista_frost.jpg)">${art("challenges",60)}<div><div class="modal-title">Trial Spire</div><div class="modal-sub">Seven floors, each a battle with a twist. Every floor pays out once; the Emberfall cape waits at the top.</div></div></div>
    <div class="spire">${CHALLENGES.map((c,k)=>`<span class="sp-step ${S.challenges[c.id]?'done':''}" title="${c.name}">${S.challenges[c.id]?ico("check",13):k+1}</span>`).join('<i></i>')}<i></i><span class="sp-cape ${capeGot?'done':''}"><span class="cape-sw big" style="background:linear-gradient(${CAPES.emberc.c},${CAPES.emberc.d})"></span><small>${capeGot?"Yours":`${done}/${CHALLENGES.length}`}</small></span></div>
    <div class="modal-body">
    ${CHALLENGES.map((c,k)=>{ const open = actUnlockedT(1, c.act); return `<div class="list-row ${open?'':'dimmed'}"><div class="li">${art(c.icon,34)}</div><div class="grow"><div class="lt">${k+1}. ${c.name} <small>Act ${ACTS[c.act].short} · Threat ${c.d}</small> ${S.challenges[c.id]?`<span style="color:var(--green)">${ico("check",14)}</span>`:''}</div><div class="ld">${c.desc}</div>${S.challenges[c.id]?'':rchips(c.reward, 18, 'sm')}</div>
      <button class="btn sm ${S.challenges[c.id]||!open?'':'gold'}" data-act="openChallenge" data-id="${c.id}" ${open?'':'disabled'}>${!open?`Reach Act ${ACTS[c.act].short}`:S.challenges[c.id]?'Replay':'Fight'}</button></div>`; }).join("")}</div>`;
  closeAllModals(); openModal(html, {wide:true});
}
function openEndless(){
  if(!isOpen("endless")){ toast(UNLOCK.endless.how); return; }
  // the board is honest about what it is: ghost knights (computer-controlled) whose graves stand in the Descent.
  // Real ranks (friends and the world) live on Game Center when the player is signed in.
  const board = boardAround(rivals().map(r=>({name:r.name, v:r.wave})).concat([{name:knightName(), v:S.endlessBest, you:true}]), 6).map(r=>({name:r.name, wave:r.v, you:r.you, rank:r.rank}));
  const gc = !!GameCenter.player;
  const html = `<div class="mode-head banner" style="background-image:url(img/vista_astral.jpg)">${art("endless",60)}<div><div class="modal-title">The Endless Descent</div><div class="modal-sub">Fight down through the Emberforge Caldera and the Astral Sanctum. Enemies grow stronger every wave and a boss guards every 10th.</div></div></div>
    <div class="modal-body">
      <div class="end-best">${art("trophy",34)}<div class="grow"><b>Your best: ${S.endlessBest ? `${S.endlessBest} wave${S.endlessBest===1?"":"s"} cleared` : "not yet set"}</b><small>${gc ? "Your rank among friends and the world is on Game Center." : "Every 25 waves pays Sigil shards the first time you reach them."}</small></div>${gc?`<button class="btn sm gold" data-act="gcBoard" data-lb="endless">${art("trophy",18)} Game Center ranks</button>`:""}</div>
      <div class="stat-lines board"><div class="bh">Ghost knights of the realm · computer-controlled, their graves mark the way down</div>${board.map(r=>`<div class="${r.you?'you':''}"><span>${r.rank}. ${r.name}</span><span>Wave ${r.wave}</span></div>`).join("")}</div>
    </div>
    <div class="mbtns row"><button class="btn gold big" data-act="startEndless">${ico("infinity",20)} Descend</button></div>`;
  closeAllModals(); openModal(html);
}

/* =====================================================================
   HERO TAB — the knight in the middle, gear around him, inventory right beside
===================================================================== */
let invFilter = "all", heroView = "inv";
const SLOT_ICON = {weapon:"edge", helm:"helm", armor:"shirt", shield:"ironskin", ring:"ring"};
/* Review 5: rarity is shown by colour AND by pips in the corner of every item tile (1 Common ... 6 Ancient) */
const rpips = r => `<span class="rpips" aria-hidden="true">${"<i></i>".repeat((r|0)+1)}</span>`;
function slotHTML(s){
  const it = equipped(s), up = bestUpgrade(s);
  return it ? `<button class="dslot rb${it.r} ${invFilter===s?'sel':''}" data-act="slotTap" data-s="${s}" aria-label="${RARITY[it.r].name}: ${it.name}"><img src="${itemIcon(it)}" alt="">${rpips(it.r)}${it.upg?`<span class="up">+${it.upg}</span>`:''}${up?'<span class="arrow">▲</span>':''}</button>`
    : `<button class="dslot empty ${invFilter===s?'sel':''}" data-act="slotTap" data-s="${s}">${ico(SLOT_ICON[s],22)}${up?'<span class="arrow">▲</span>':''}<span class="sn">${SLOT_DEF[s].name}</span></button>`;
}
function renderHero(){
  const st = heroStats(null), g = st.sets, cape = CAPES[S.cape], canBest = SLOTS.some(bestUpgrade), ro = runesOpen();
  if(!ro && heroView==="runes") heroView = "inv";
  const sets = Object.keys(g).filter(k=>g[k]>=1), pv = skinPreview && SKINS[skinPreview] ? skinPreview : null, need = pv ? Math.max(0, SKINS[pv].price - S.gems) : 0;
  const canBuyGems = Monetization.storeReady() && S.cleared["0-4"];
  let h = `<div class="doll ${pv?'pv':''}">
    <div class="doll-pow"><small>Power</small><b id="dollPow">${powerOf(st)}</b></div>
    ${canBest && !pv?`<button class="btn sm gold glow best-btn" data-act="equipBest">${ico("check",14)} Equip best</button>`:""}
    <div class="doll-l">${slotHTML("helm")}${slotHTML("armor")}${slotHTML("ring")}</div>
    <div class="doll-r">${slotHTML("weapon")}${slotHTML("shield")}<button class="dslot cape-slot" data-act="wardrobe" aria-label="Wardrobe"><span class="cape-sw" style="background:linear-gradient(${cape.c},${cape.d})"></span><span class="sn">${ico("hanger",11)} Style</span></button></div>
    ${sets.length && !pv ? `<div class="doll-sets">${sets.map(k=>`<button class="dset ${g[k]>=2?'on':''}" style="--sc:${SET_GLOW[k]}" data-act="setInfo" data-k="${k}">${SETS[k].name} <b>${g[k]}/3</b></button>`).join("")}</div>` : ""}
    ${pv ? `<div class="pv-bar"><b>${SKINS[pv].name}</b><small>Trying it on. Looks never change your stats.</small><div class="row">
        ${need>0 ? (canBuyGems ? `<button class="btn sm gold" data-act="getGems" data-need="${need}">Get ${fmt(need)} gems</button>` : `<button class="btn sm" disabled>${fmt(need)} gems short</button>`) : `<button class="btn sm gold glow" data-act="buySkinDo" data-k="${pv}">${art("gems",16,"cur")} ${SKINS[pv].price} · Buy</button>`}
        <button class="btn sm ghost" data-act="pvWalk" aria-label="Walk">${ico("play",12)}<span> Walk</span></button><button class="btn sm ghost" data-act="pvEnd">Take off</button></div></div>`
    : `<button class="doll-stats" data-act="statsInfo" aria-label="All stats">
      <span><small>HP</small><b>${fmt(st.maxHp)}</b></span><span><small>Damage</small><b>${Math.round(st.dmg)}</b></span><span><small>Speed</small><b>${(1/st.atkInterval).toFixed(2)}</b></span><span><small>Crit</small><b>${r1(st.crit)}%</b></span><span><small>Armor</small><b>${st.armor}</b></span><span><small>Block</small><b>${r1(st.block)}%</b></span><i>${ico("info",14)}</i></button>`}
  </div>`;
  h += `<div class="hero-panel"><div class="seg">
      <button class="${heroView==='inv'?'on':''}" data-act="heroView" data-v="inv">Inventory <small>${S.inv.length}</small></button>
      ${ro?`<button class="${heroView==='runes'?'on':''}" data-act="heroView" data-v="runes">Runes${RUNE_KEYS.some(t=>(S.frags[t]||0)>=FRAGS_PER_RUNE || [0,1,2,3].some(l=>runeCount(t,l)>=RUNES_TO_MERGE))?'<i class="pip"></i>':''}</button>`:""}
      <button class="${heroView==='train'?'on':''}" data-act="heroView" data-v="train">Training${META.some(m=>S.meta[m.id]<m.max && S.gold>=trainCost(m))?'<i class="pip"></i>':''}</button></div>`;
  if(heroView==="inv"){
    const filters = ["all", ...SLOTS];
    h += `<div class="filters">${filters.map(f=>`<button class="fchip ${invFilter===f?'on':''}" data-act="invFilter" data-f="${f}" aria-label="${f==="all"?"All items":SLOT_DEF[f].name}">${f==="all"?'All':ico(SLOT_ICON[f],18)}${f!=="all"&&bestUpgrade(f)?'<i class="pip up"></i>':''}</button>`).join("")}<button class="fchip lo-btn" data-act="loadouts" aria-label="Loadouts">${ico("shirt",16)} Loadouts</button></div>`;
    const activeSets = Object.keys(g).filter(k=>g[k]>=1);
    if(activeSets.length) h += `<div class="sets-mini">${activeSets.map(k=>`<span class="${g[k]>=2?'on':''}"><b>${SETS[k].name} ${g[k]}/3</b>${g[k]>=2?` · ${g[k]>=3?SETS[k].b3:SETS[k].b2}`:` · (2) ${SETS[k].b2}`}</span>`).join("")}</div>`;
    const inv = S.inv.filter(it=>invFilter==="all" || it.slot===invFilter).sort((a,b)=> (isEquipped(b)-isEquipped(a)) || (isUpgrade(b)-isUpgrade(a)) || b.r-a.r || itemScore(b)-itemScore(a));
    h += inv.length ? `<div class="inv">${inv.map(it=>`<button class="itile rb${it.r} ${isEquipped(it)?'is-eq':''}" data-act="openItem" data-uid="${it.uid}" aria-label="${RARITY[it.r].name}: ${it.name}"><img src="${itemIcon(it)}" alt="">${rpips(it.r)}${it.upg?`<span class="up">+${it.upg}</span>`:''}${it.set?'<span class="setdot"></span>':''}${it.perk?`<span class="pkdot" style="--tc:${TAGS[PERKS[it.perk].tag].color}"></span>`:''}${(it.sock||[]).length?`<span class="socks-mini">${it.sock.map(rn=>`<i class="${rn?'on':''}" ${rn?`style="--rc:${RUNES[rn.t].color}"`:''}></i>`).join("")}</span>`:''}${isEquipped(it)?'<span class="eq">Worn</span>':isUpgrade(it)?'<span class="arrow">▲</span>':''}</button>`).join("")}</div>`
      : `<div class="empty-note">No ${invFilter==="all"?"items":SLOT_DEF[invFilter].name.toLowerCase()+"s"} yet. Win battles, open chests or visit the Shop's daily market.</div>`;
    const junk = S.inv.filter(it=>it.r===0 && spareItem(it) && !isUpgrade(it));
    if(junk.length) h += `<button class="btn sm ghost wide" style="margin-top:10px" data-act="salvageCommons">Salvage ${junk.length} spare Common item${junk.length>1?'s':''} · +${fmt(junk.reduce((a,it)=>a+salvageValue(it),0))} gold, +${junk.reduce((a,it)=>a+salvageDust(it),0)} dust</button>`;
    h += `<div class="salv"><span class="grow">Auto-salvage after battles<small>Spare items that are not upgrades become gold and dust</small></span><button class="toggle ${S.autoSalv.c?'on':''}" data-act="autoSalv" data-r="c" aria-label="Auto-salvage Common items"><i></i><span>Common</span></button><button class="toggle ${S.autoSalv.r?'on':''}" data-act="autoSalv" data-r="r" aria-label="Auto-salvage Rare items"><i></i><span>Rare</span></button></div>`;
  } else if(heroView==="runes"){
    h += `<div class="res-row"><span>${art("frag",20,"cur")} ${fragTotal()} <small>Fragments</small></span><span>${art("dust",20,"cur")} ${fmt(S.dust)} <small>Dust</small></span></div>`;
    h += `<div class="rune-how" aria-label="${FRAGS_PER_RUNE} fragments forge a rune. ${RUNES_TO_MERGE} runes of one rank merge into the next. Runes go into the rune slots of an item."><span>${art("frag",26)}<b>×${FRAGS_PER_RUNE}</b></span>${ico("next",14)}<span>${art("rune_fury",28)}<b>I</b></span>${ico("next",14)}<span>${art("rune_fury",22)}<b>×${RUNES_TO_MERGE}</b></span>${ico("next",14)}<span>${art("rune_fury",28)}<b>II</b></span>${ico("next",14)}<span class="slot"><i></i><b>item</b></span></div>`;
    h += RUNE_KEYS.map(t=>{ const R = RUNES[t], L = STAT_LABEL[R.stat], f = S.frags[t]||0;
      return `<div class="rune-row" style="--rc:${R.color}"><div class="rh">${art("rune_"+t,40)}<div><b>${R.name}</b><small>${L[1]} +${R.per.join(" / ")}${L[0]}</small></div></div>
        <div class="rf"><span>${art("frag",16,"cur")} ${f}/${FRAGS_PER_RUNE}</span><button class="btn sm purple" data-act="forgeRune" data-t="${t}" ${f<FRAGS_PER_RUNE?'disabled':''}>Forge</button></div>
        <div class="rr">${[0,1,2,3,4].map(l=>{ const n = runeCount(t,l); return `<button class="rank ${n?'has':''}" data-act="mergeRune" data-t="${t}" data-l="${l}" ${l<4&&n>=RUNES_TO_MERGE?'':'disabled'} aria-label="${R.name} ${ROMAN[l]}"><em>${ROMAN[l]}</em><b>×${n}</b>${l<4&&n>=RUNES_TO_MERGE?'<i>Merge</i>':''}</button>`; }).join("")}</div></div>`; }).join("");
  } else {
    const freeRank = !S.tips.trained;
    h += `<div class="mute" style="font-size:12.5px;margin:2px 2px 8px">Permanent upgrades, paid with gold.${freeRank?" <b style=\"color:var(--green)\">Your first rank is free.</b>":""}</div>`;
    const p0 = powerOf(st);
    h += META.map(m=>{ const lv = S.meta[m.id], max = lv>=m.max, cost = trainCost(m), n10 = trainPlan(m, 10), nMax = trainPlan(m, 999);
      const gain = max ? 0 : (S.meta[m.id]++, powerOf(heroStats(null)) - p0 + (S.meta[m.id]--, 0));
      return `<div class="list-row train"><div class="li">${art(m.icon,36)}</div><div class="grow"><div class="lt">${m.name} <small>${lv}/${m.max}</small></div><div class="ld" aria-label="${m.desc}"><b class="tr-v">${m.short}</b>${gain>0?` <span class="pgain">${art("might",13,"cur")} +${gain}</span>`:""}</div><div class="bar thin"><i style="width:${lv/m.max*100}%"></i></div></div>
      <div class="tbtns"><button class="btn sm gold price ${freeRank&&!max?'glow':''}" data-act="buyMeta" data-id="${m.id}" ${max||S.gold<cost?'disabled':''}>${max?'Max':freeRank?'Free':S.gold<cost?`Need ${fmt(cost-S.gold)}`:`${CUR.gold} ${fmt(cost)}`}</button>
        ${!max && !freeRank && n10.n>1?`<button class="btn sm ghost" data-act="trainN" data-id="${m.id}" data-n="10">×${n10.n}<small>${fmt(n10.cost)}</small></button>`:""}
        ${!max && !freeRank && nMax.n>10?`<button class="btn sm ghost" data-act="trainN" data-id="${m.id}" data-n="999">Max<small>×${nMax.n}</small></button>`:""}</div></div>`; }).join("");
  }
  h += `</div>`;
  const keep = $("#tab-hero .hero-panel"), top = keep ? keep.scrollTop : 0;
  $("#tab-hero").innerHTML = h;
  if(top) $("#tab-hero .hero-panel").scrollTop = top;
  heroAnchor = null;
}
/* the first training rank a player ever buys is free (taught after the second win) */
const trainCost = m => S.tips.trained ? metaCost(m) : 0;
/* LOADOUTS: two saved sets of gear and disabled cards, one tap before a fight */
const LOADOUT_NAMES = ["Boss", "Farm"];
function saveLoadout(i){ S.loadouts[i] = {equip:Object.assign({}, S.equip), bans:S.bans.slice()}; persist(); }
function useLoadout(i){ const L = S.loadouts[i]; if(!L) return false;
  for(const s of SLOTS){ const uid = L.equip[s]; if(uid && itemById(uid)) S.equip[s] = uid; else if(!uid) S.equip[s] = null; }
  S.bans = (L.bans||[]).filter(id=>CARD_BY[id] && !CARD_BY[id].evo && !CARD_BY[id].legend).slice(0, MAX_BANS); persist(); heroChanged(true); return true; }
function loadoutWorn(i){ const L = S.loadouts[i]; return !!L && SLOTS.every(s=>(L.equip[s]||null)===(S.equip[s]||null)) && (L.bans||[]).slice().sort().join()===S.bans.slice().sort().join(); }
function openLoadouts(){
  const rows = [0,1].map(i=>{ const L = S.loadouts[i], items = L ? SLOTS.map(s=>itemById(L.equip[s])).filter(Boolean) : [], worn = loadoutWorn(i), nb = L ? (L.bans||[]).length : 0;
    return `<div class="list-row lo ${worn?'sel-row':''}"><div class="grow"><div class="lt">${LOADOUT_NAMES[i]} set ${L?`<small>${items.length} item${items.length===1?"":"s"} · ${nb} disabled card${nb===1?"":"s"}${worn?" · wearing now":""}</small>`:"<small>empty</small>"}</div>
        <div class="lo-items">${items.map(it=>`<span class="itile rb${it.r}"><img src="${itemIcon(it)}" alt="">${rpips(it.r)}</span>`).join("") || '<span class="mute">Saves the gear you are wearing and your disabled cards.</span>'}</div></div>
      <div class="tbtns"><button class="btn sm ghost" data-act="loSave" data-i="${i}">Save current</button><button class="btn sm gold" data-act="loUse" data-i="${i}" ${L && !worn?'':'disabled'}>Equip</button></div></div>`; }).join("");
  closeAllModals(); openModal(`<div class="modal-title">Loadouts</div><div class="modal-sub">Two saved sets of gear and disabled cards. Switch with one tap here or before a fight.</div>${rows}`, {wide:true});
}
/* where the knight stands on the Hero tab, in world pixels (the doll is laid out by CSS; the canvas follows it) */
let heroAnchor = null;
function heroDollX(){
  if(heroAnchor!=null) return heroAnchor;
  const d = $("#tab-hero .doll"), c = $("#world"); if(!d || !c) return null;
  const r = d.getBoundingClientRect(), cr = c.getBoundingClientRect(); if(!r.width || !cr.width) return null;
  return heroAnchor = ((r.left + r.width/2) - cr.left)/cr.width*World.W;
}
function openItem(uid, opt={}){
  const it = itemById(uid); if(!it) return;
  const st = itemStats(it), cur = equipped(it.slot), eq = isEquipped(it), fg = opt.forged || null;
  const cmp = (!eq && cur && !fg) ? itemStats(cur) : null;
  const keys = new Set([...Object.keys(st), ...(cmp?Object.keys(cmp):[])]);
  const lines = [...keys].map(k=>{ const v = st[k]||0; let diff = "";
    if(fg && fg.before[k]!==undefined && Math.abs(v - fg.before[k]) >= .05){ const L = STAT_LABEL[k], f = x => L[0]==="%" ? r1(x) : Math.round(x); return `<div class="fg-line"><span>${L[1]}</span><span><s>+${f(fg.before[k])}${L[0]}</s> <b class="up-g">+${f(v)}${L[0]}</b></span></div>`; }
    if(cmp){ const dv = v - (cmp[k]||0); if(Math.abs(dv)>=.05){ const L = STAT_LABEL[k]; diff = ` <span class="${dv>0?'up-g':'dn-r'}">${dv>0?'▲':'▼'} ${L[0]==="%"?r1(Math.abs(dv)):Math.round(Math.abs(dv))}</span>`; } }
    return v ? `<div><span>${statLine(k,v)}</span><span>${diff}</span></div>` : `<div class="mute"><span>${STAT_LABEL[k][1]}</span><span>${diff}</span></div>`; }).join("");
  let setBox = "";
  if(it.set){ const S_ = SETS[it.set], n = heroStats(null).sets[it.set]||0;
    setBox = `<div class="set-box"><b>${S_.name}</b> <span class="mute">(${n}/3 equipped · ${S_.slots.map(s=>SLOT_DEF[s].name).join(", ")})</span><br><span class="${n>=2?'on':'off'}">(2) ${S_.b2}</span><br><span class="${n>=3?'on':'off'}">(3) ${S_.b3}</span></div>`; }
  const power = it.power ? `<div class="power-box">${art("ancient",30)}<span><b>Ancient power</b>${ANCIENTS[it.slot].text}</span></div>` : "";
  const P = it.perk && PERKS[it.perk], perk = P ? `<div class="perk-box" style="--tc:${TAGS[P.tag].color}">${art(TAGS[P.tag].icon,30)}<span><b>${P.tag==="core" ? "Build effect" : `${TAGS[P.tag].name} build effect`}</b>${P.text}</span></div>` : "";
  const socks = (it.sock||[]).length ? `<div class="socks"><span class="sl">Sockets</span>${it.sock.map((rn,i)=>rn ? `<button class="sock filled" style="--rc:${RUNES[rn.t].color}" data-act="sock" data-uid="${uid}" data-i="${i}">${art("rune_"+rn.t,30)}<span><b>${RUNES[rn.t].name} ${ROMAN[rn.lv]}</b><small>${runeLine(rn)}</small></span></button>`
      : `<button class="sock" data-act="sock" data-uid="${uid}" data-i="${i}"><span>+</span><small>Add rune</small></button>`).join("")}</div>` : (runesOpen() ? `<div class="socks none">No sockets. Rare and better items have sockets; Ascend adds more.</div>` : "");
  const fc = forgeCost(it), sv = salvageValue(it), sd = salvageDust(it), tc = transmuteCost(it), ac = ASCEND_COST[it.r], fmax = it.upg>=FORGE_MAX;
  const pg = eq ? 0 : powerGain(it);
  const cmpHead = cmp ? `<div class="cmp-with"><img src="${itemIcon(cur)}" alt=""><span>▲▼ compared with your <b class="rc${cur.r}">${cur.name}${cur.upg?` +${cur.upg}`:''}</b>${pg ? ` · <b class="${pg>0?'up-g':'dn-r'}">${pg>0?'+':''}${pg} power</b>` : ""}</span></div>` : "";
  const html = `<div class="item-cols"><div>
    <div class="item-head"><div class="big rb${it.r} ${fg?'hammered':''}"><img src="${itemIcon(it)}" alt="">${rpips(it.r)}${fg?`<span class="hammer">${ico("anvil",30)}</span><i class="spk"></i>`:""}</div>
      <div><div class="item-name rc${it.r}">${it.name}${it.upg?` +${it.upg}`:''}</div><div class="dim" style="font-size:13px">${RARITY[it.r].name} ${SLOT_DEF[it.slot].name} · Item level ${Math.round(it.il)}</div>${fg?`<div class="up-g" style="font-size:13px;font-weight:600">Forged${fg.gain>0?` · +${fg.gain} power`:""}</div>`:eq?`<div style="color:var(--green);font-size:13px;font-weight:600">${ico("check",14)} Equipped</div>`:isUpgrade(it)?`<div style="color:var(--green);font-size:13px;font-weight:600">▲ Upgrade for you</div>`:''}</div></div>
    ${power}${perk}<div class="stat-lines">${lines}</div>${cmpHead}${socks}${setBox}</div>
    <div class="item-side">${eq?`<button class="btn wide" data-act="unequip" data-uid="${uid}">Unequip</button>`:`<button class="btn gold big wide" data-act="equip" data-uid="${uid}">Equip</button>`}
    <div class="craft">
      <button class="cbtn" data-act="forge" data-uid="${uid}" ${fmax||S.gold<fc?'disabled':''}>${art("might",30)}<b>${fmax?'Fully forged':`${it.upg>=10?'Master forge':'Forge'} +${it.upg+1}`}</b><small>${fmax?`Max (+${FORGE_MAX})`:`${CUR.gold} ${fmt(fc)} · +12% stats`}</small></button>
      <button class="cbtn" data-act="transmute" data-uid="${uid}" ${it.r===0||S.dust<tc?'disabled':''}>${art("transmute",30)}<b>Transmute</b><small>${it.r===0?'Rare and up':`${art("dust",14,"cur")} ${tc} · reroll bonus stats`}</small></button>
      <button class="cbtn" data-act="ascend" data-uid="${uid}" ${!ac||S.star<(ac?ac.star:0)||S.dust<(ac?ac.dust:0)?'disabled':''}>${art("ascend",30)}<b>${ac?`Ascend to ${RARITY[it.r+1].name}`:'Max rarity'}</b><small>${ac?`${art("starmetal",14,"cur")} ${ac.star} · ${art("dust",14,"cur")} ${ac.dust}`:it.r===5?'Ancient relic':'Mythic is the highest'}</small></button>
      <button class="cbtn red" data-act="salvage" data-uid="${uid}" ${eq||it.r===5?'disabled':''}>${art("dust",30)}<b>Salvage</b><small>${it.r===5?'Relics are kept':eq?'Unequip first':`+${sv} gold · +${sd} dust`}</small></button>
    </div><div class="res-row res-mini"><span>${art("dust",16,"cur")} ${fmt(S.dust)} dust</span><span>${art("starmetal",16,"cur")} ${S.star} Starmetal</span></div></div></div>`;
  closeAllModals(); const m = openModal(html, {wide:true});
  if(fg) setTimeout(()=>{ if(m.parentNode && $("#modalRoot").lastElementChild===m) openItem(uid); }, 1500);     // the before and after numbers show for a moment, then the normal view
}
function openRunePicker(uid, idx){
  const it = itemById(uid); if(!it) return; const cur = it.sock[idx];
  const opts = []; for(const t of RUNE_KEYS) for(let l=4;l>=0;l--) if(runeCount(t,l)>0) opts.push([t,l]);
  const html = `<div class="modal-title">Socket ${idx+1}</div><div class="modal-sub">${cur?`Holding ${RUNES[cur.t].name} ${ROMAN[cur.lv]}. Swap it or take it out; runes are never lost.`:"Choose a rune to set into this socket."}</div>
    ${opts.length ? `<div class="rune-pick">${opts.map(([t,l])=>`<button class="rp" style="--rc:${RUNES[t].color}" data-act="setRune" data-uid="${uid}" data-i="${idx}" data-t="${t}" data-l="${l}">${art("rune_"+t,36)}<b>${RUNES[t].name} ${ROMAN[l]}</b><small>${runeLine({t,lv:l})} · ×${runeCount(t,l)}</small></button>`).join("")}</div>`
      : `<div class="empty-note">You have no runes yet. Forge them from fragments in Hero → Runes.</div>`}
    <div class="mbtns row">${cur?`<button class="btn red" data-act="unsock" data-uid="${uid}" data-i="${idx}">Take out</button>`:""}<button class="btn" data-act="backItem" data-uid="${uid}">Back</button></div>`;
  closeAllModals(); openModal(html, {wide:true});
}
function trainPlan(m, n){ let lv = S.meta[m.id], gold = S.gold, cost = 0, k = 0;
  while(k<n && lv<m.max){ const c = metaCostAt(m, lv); if(gold<c) break; gold -= c; cost += c; lv++; k++; } return {n:k, cost}; }
function openStats(){ const st = heroStats(null);
  const row = (l,v)=>`<div><span>${l}</span><b>${v}</b></div>`;
  openModal(`<div class="modal-title">${knightName()}</div><div class="modal-sub">Power ${powerOf(st)}. Power weighs what your knight deals each second against what he can take, so every stat counts.</div>
    <div class="stat-lines two">${row("Health",fmt(st.maxHp))}${row("Damage",Math.round(st.dmg))}${row("Attacks per second",(1/st.atkInterval).toFixed(2))}${row("Critical chance",r1(st.crit)+"%")}${row("Critical damage","×"+st.critMult)}${row("Armor",`${st.armor} (−${Math.round(st.armor/(st.armor+60)*100)}%)`)}${row("Block chance",r1(st.block)+"%")}${row("Potions",`${st.potions} × ${Math.round(st.potionHeal)}%`)}${st.goldPct?row("Gold found","+"+Math.round(st.goldPct)+"%"):""}</div>`); }
let lookTab = "capes";
function openCapes(){ openWardrobe(); }
function openWardrobe(){
  const skins = `<div class="capes skins"><button class="cape-card ${!S.skin?'on':''}" data-act="setSkin" data-k=""><span class="skin-pv">${art("knightchest",48)}</span><b>Your gear</b><small>${!S.skin?'Wearing':'Show your armour'}</small></button>${Object.keys(SKINS).map(k=>{ const K = SKINS[k], own = S.skins.includes(k);
      return `<button class="cape-card ${S.skin===k?'on':''}" data-act="${own?'setSkin':'trySkin'}" data-k="${k}"><span class="skin-pv" style="--g1:${K.look.armL};--g2:${K.look.armD};--g3:${K.look.glow}"><img src="${skinPortrait(k)}" alt=""></span><b>${K.name}</b><small>${own?(S.skin===k?'Wearing':'Tap to wear'):`${art("gems",14,"cur")} ${K.price} · tap to try on`}</small></button>`; }).join("")}</div>`;
  const lg = leagueOf(S.arena.best), canTrim = lg.min >= LEAGUES[1].min, trimOn = S.trim==="league" && canTrim;
  const capes = `<div class="capes">${Object.keys(CAPES).map(k=>{ const c = CAPES[k], own = S.capes.includes(k);
      return `<button class="cape-card ${S.cape===k?'on':''} ${own?'':'locked'}" data-act="setCape" data-k="${k}"><span class="cape" style="background:linear-gradient(${c.c},${c.d})">${own?'':ico("lock",16)}</span><b>${c.name}</b><small>${own?(S.cape===k?'Wearing':'Tap to wear'):c.how}</small></button>`; }).join("")}</div>
    ${isOpen("arena") ? `<button class="set-row trim-row" data-act="toggleTrim" ${canTrim?'':'disabled'}>${art("trophy",24)}<span class="grow">League trim<small>${canTrim ? `Your cape is edged in ${lg.name} league colours` : "Reach the Silver league in the Arena to edge your cape in league colours"}</small></span><span class="toggle ${trimOn?'on':''}"><i ${canTrim?`style="background:${lg.color}"`:''}></i><span>${trimOn?'On':'Off'}</span></span></button>` : ""}`;
  const html = `<div class="modal-title">Style</div><div class="modal-sub">Capes and skins never change your stats. Your knight wears them in every battle.</div>
    <div class="seg"><button class="${lookTab==='capes'?'on':''}" data-act="lookTab" data-v="capes">Capes</button><button class="${lookTab==='skins'?'on':''}" data-act="lookTab" data-v="skins">Armour skins</button></div>
    ${lookTab==="skins"?skins:capes}`;
  closeAllModals(); openModal(html, {wide:true});
}
const SKIN_PV = {};
function skinPortrait(k){ const key = k + "|" + S.cape; if(SKIN_PV[key]) return SKIN_PV[key]; const prev = S.skin, pp = skinPreview; S.skin = k; skinPreview = null; let url = "";
  try{ const sk = heroSkin(); url = World.portrait(g=>{ g.scale(-1,1); World.drawRig(g, sk, {ld:1, th:1.05, ph:-1, bth:1.2}, 0); }, 96, 96, 52, 92, 88/150); }catch(e){ console.error(e); }
  S.skin = prev; skinPreview = pp; return SKIN_PV[key] = url; }
/* try a skin on: the live knight on the Hero tab wears it and walks a few steps; nothing is bought until the player says so */
function trySkin(k){ if(!SKINS[k]) return; skinPreview = k; closeAllModals(); heroView = "inv"; if(currentTab!=="hero") setTab("hero"); else renderHero(); heroChanged(true); home.pvWalk = 2.8; }
function endPreview(){ if(!skinPreview) return; skinPreview = null; home.pvWalk = 0; heroChanged(false); }

/* =====================================================================
   SKILLS TAB
===================================================================== */
let codexTag = "all";
function renderCodex(){
  const tags = [...SYN_TAGS, "core"], nSp = EVOS.length + LEGENDS.length, nFound = S.found.filter(id=>CARD_BY[id]).length;
  let h = `<div class="panel-full"><div class="filters codex-f"><button class="fchip ${codexTag==='all'?'on':''}" data-act="codexTag" data-t="all">All</button>${tags.map(t=>`<button class="fchip ${codexTag===t?'on':''}" style="--tc:${TAGS[t].color}" data-act="codexTag" data-t="${t}">${tagIco(t,16)}${TAGS[t].name}</button>`).join("")}<button class="fchip ${codexTag==='special'?'on':''}" style="--tc:#f2c14e" data-act="codexTag" data-t="special">${art("crown",16,"tagi")}Rare <small>${nFound}/${nSp}</small></button></div>
    <div class="dim codex-hint">Your knight earns skill cards by levelling up in battle. Two cards of a tag unlock its synergy and its ability; three complete it. Upgrade cards with Orbs to make them stronger every time they're offered. Tap ${ico("ban",12)} to keep a card out of your offers (up to ${MAX_BANS}).</div>`;
  for(const t of (codexTag==="all" ? tags : codexTag==="special" ? [] : [codexTag])){
    const T = TAGS[t], isSyn = t!=="core";
    h += `<div class="tag-head" style="--tc:${T.color}"><b>${tagIco(t,18)} ${T.name}</b>${isSyn?`<span>(2) ${synLine(t,2)}</span><span>(3) ${synLine(t,3)}</span>`:'<span>Cards without a synergy</span>'}</div>`;
    if(isSyn){ const A = ABILITIES[t], n = S.mastery[t]||0, rk = masteryRank(t), nextAt = MASTERY_AT[rk], alt = !!S.synAlt[t];
      h += `<div class="tag-sub" style="--tc:${T.color}"><div class="ts-ab">${art(A.icon,30)}<span><b>Ability: ${A.name}</b>${A.text} · recharges in ${A.cd}s</span></div>
        <div class="ts-ms"><span><b>Mastery ${rk ? ["I","II","III"][rk-1] : "–"}</b>${n} win${n===1?"":"s"} with ${T.name} III${nextAt?` · next rank at ${nextAt}`:""}</span>
        ${rk>=1 ? `<button class="toggle ${alt?'on':''}" data-act="synAlt" data-t="${t}" aria-label="Switch the ${T.name} III synergy"><i></i><span>${alt?'Variant':'Classic'}</span></button><em>${alt ? `Classic (3): ${T.s3}` : `Variant (3): ${T.a3}`}</em>` : `<em>${ico("lock",11)} Mastery I (${MASTERY_AT[0]} wins) unlocks a variant: ${T.a3}</em>`}</div></div>`; }
    h += `<div class="codex-grid">`;
    h += CARDS.filter(c=>c.tag===t).map(c=>{ const lv = cardLv(c.id), max = lv>=CARD_MAX, cost = orbCost(lv), banned = S.bans.includes(c.id), ev = EVO_OF[c.id];
      return `<div class="codex-card ${banned?'banned':''}" style="--tc:${T.color}"><div class="ci">${art(c.icon,48)}</div>
        <div class="grow"><div class="lt">${c.name}</div><div class="lvpips ${lv>5?'hi':''}" aria-label="Level ${lv} of ${CARD_MAX}">${lv>5 ? `<b>${"★".repeat(lv-5)}</b>${"★".repeat(10-lv)}` : `${"★".repeat(lv)}<span class="off">${"★".repeat(5-lv)}</span>`}<small>Lv ${lv}</small></div><div class="ld">${c.text(c.v(1,cardMult(c.id)))}</div>${ev?`<div class="evo-l">${S.found.includes(ev.id) ? `Evolves into ${ev.name}` : "Can evolve with the right gear"}</div>`:""}
        <button class="btn sm purple wide" style="margin-top:7px" data-act="upCard" data-id="${c.id}" ${max||S.orbs<cost?'disabled':''}>${max?'Max level':S.orbs<cost?`Need ${CUR.orbs} ${cost-S.orbs} more`:`Upgrade · ${CUR.orbs} ${cost}`}</button></div>
        ${banned?'<span class="ban-badge">Disabled</span>':''}<button class="banbtn ${banned?'on':''}" data-act="toggleBan" data-id="${c.id}" aria-label="${banned?'Disabled: tap to allow in offers':'Tap to disable in offers'}">${ico("ban",14)}</button></div>`; }).join("");
    h += `</div>`;
  }
  if(codexTag==="all" || codexTag==="special"){
    const sp = (c, needTxt, tagsHtml)=>{ const f = S.found.includes(c.id); return `<div class="codex-card special ${f?'':'unk'}" style="--tc:#f2c14e"><div class="ci">${art(c.icon,48)}</div>
      <div class="grow"><div class="lt">${f ? c.name : "Undiscovered"}</div><div class="sp-tags">${tagsHtml}</div>${f?`<div class="ld">${c.desc}</div>`:""}<div class="need">${needTxt}</div></div></div>`; };
    h += `<div class="tag-head" style="--tc:#f2c14e"><b>${art("crown",18,"tagi")} Evolutions</b><span>A card plus the right gear becomes something new. Offered with a gold frame.</span></div><div class="codex-grid">${EVOS.map(e=>sp(e, `Needs: ${e.need}`, `<span style="color:${TAGS[e.tag].color}">${tagIco(e.tag,13)} ${CARD_BY[e.base].name}</span>`)).join("")}</div>`;
    h += `<div class="tag-head" style="--tc:#ffb347"><b>${art("crown",18,"tagi")} Legendary cards</b><span>Offered once both of their tags are in your build, with 3 cards between them.</span></div><div class="codex-grid">${LEGENDS.map(l=>sp(l, `Needs: ${l.tags.map(t=>TAGS[t].name).join(" and ")}, 3 cards between them`, l.tags.map(t=>`<span style="color:${TAGS[t].color}">${tagIco(t,13)} ${TAGS[t].name}</span>`).join(" + "))).join("")}</div>`;
  }
  h += `</div>`;
  const keep = $("#tab-codex .panel-full"), top = keep ? keep.scrollTop : 0;
  $("#tab-codex").innerHTML = h; if(top) $("#tab-codex .panel-full").scrollTop = top;
}

/* =====================================================================
   QUESTS TAB
===================================================================== */
let questView = "quests";
/* ---------- shared visual pieces ---------- */
const IMG = n => `img/${n}.jpg`;
const RKEY = {gold:"gold", orbs:"orbs", gems:"gems", dust:"dust", star:"starmetal", frags:"frag", sigil:"sigil"};
const RNAME = {gold:"Gold", orbs:"Orbs", gems:"Gems", dust:"Arcane Dust", star:"Starmetal", frags:"Rune fragments", sigil:"Ancient Sigil"};
/* a bundle as a row of icon chips: art + amount (no words) */
function rchips(b, size, cls){ const order = ["sigil","gems","gold","orbs","star","frags","dust"];
  return `<div class="rchips ${cls||''}">${order.filter(k=>b[k]).map(k=>`<span class="rchip" title="${RNAME[k]}">${art(RKEY[k], size||24)}<b>${fmt(b[k])}</b></span>`).join("")}</div>`; }
const fslot = (icon, size, cls) => `<span class="fslot ${cls||''}">${art(icon, size||40)}</span>`;
function pbar(n, need, cls){ const f = clamp(n/need, 0, 1); return `<div class="pbar ${cls||''} ${f>=1?'pdone':''}"><i style="width:${f*100}%"></i><span>${fmt(n)} / ${fmt(need)}</span></div>`; }
function renderQuests(){
  dailyReset();
  if(questView==="pass"){ renderPass(); return; }
  const rw = questReward(), list = S.quests.list, nClaimed = list.filter(q=>q.claimed).length, allClaimed = list.every(q=>q.claimed);
  let h = `${questSeg()}<div class="qwrap">`;
  if(questView==="journey"){
    const js = JOURNEY.map(j=>({j, s:journeyState(j)})).sort((a,b)=>((b.s.done&&!b.s.claimed)-(a.s.done&&!a.s.claimed)) || (a.s.claimed-b.s.claimed) || (b.s.v/b.j.need - a.s.v/a.j.need));
    const nJ = JOURNEY.filter(j=>S.journey[j.id]).length, nReady = js.filter(x=>x.s.done && !x.s.claimed).length;
    h += `<div class="qcol"><div class="qhead"><div><b>Journey</b><small>${nReady ? `<em class="rdy">${nReady} reward${nReady===1?"":"s"} to claim</em>` : "Lifetime milestones that pay gems"}</small></div><div class="qcount">${art("trophy",26)}<b>${nJ}</b>/${JOURNEY.length} claimed</div></div><div class="jgrid">`;
    h += js.map(({j,s})=>`<div class="jcard ${s.claimed?'claimed':s.done?'ready':''}">${fslot(j.icon,34,'sm')}<div class="qmain"><div class="qt">${j.name}</div><div class="qd">${j.text}</div>${j.need>1&&!s.claimed?pbar(s.v, j.need, 'thin'):''}</div>
      <div class="qact">${s.claimed?`<span class="done-badge sm">${ico("check",16)}</span>`:s.done?`<button class="btn sm gold glow" data-act="claimJourney" data-id="${j.id}">${art("gems",18,"cur")} ${j.gems}</button>`:`<span class="rchip">${art("gems",18)}<b>${j.gems}</b></span>`}</div></div>`).join("");
    h += `</div></div></div>`;
  } else {
    h += `<div class="qcol"><div class="qhead"><div><b>Daily quests</b><small>New quests in ${msToMidnight()}</small></div><div class="qdots">${list.map(q=>`<i class="${q.claimed?'on':''}"></i>`).join("")}</div></div><div class="qgrid">`;
    h += list.map(q=>{ const Q = QUEST_BY[q.id]; if(!Q) return ""; const n = questProg(q), done = n>=Q.need;
      return `<div class="qcard ${q.claimed?'claimed':done?'ready':''}">${fslot(Q.icon,38)}<div class="qmain"><div class="qt">${Q.text(Q.need)}</div>${rchips({gold:rw.gold, orbs:rw.orbs}, 18, 'sm')}${pbar(n, Q.need)}</div>
        <div class="qact">${q.claimed?`<span class="done-badge">${ico("check",20)}</span>`:done?`<button class="btn sm gold glow" data-act="claimQuest" data-id="${q.id}">Claim</button>`:`<button class="btn sm ghost go" data-act="go" data-q="${Q.id}">Go ${ico("play",12)}</button>`}</div></div>`; }).join("");
    h += `</div><div class="qchest ${S.quests.bonus?'claimed':allClaimed?'ready':''}"><div class="qc-art">${art("gemchest",76)}</div><div class="qmain"><div class="qt">Daily chest</div><div class="qd">Finish all ${list.length} daily quests to open it.</div>${pbar(nClaimed, list.length, 'gold')}</div>
        ${rchips({gems:DAILY_BONUS_GEMS}, 26, 'big')}<span class="rchip big">${art("knightchest",26)}<b>Rare item</b></span>
        <div class="qact">${S.quests.bonus?`<span class="done-badge">${ico("check",20)}</span>`:`<button class="btn ${allClaimed?'gold glow':'ghost'}" data-act="claimBonus" ${allClaimed?'':'disabled'}>Open</button>`}</div></div></div></div>`;
  }
  const keep = $("#tab-quests .qcol"), top = keep && keep.dataset.v===questView ? keep.scrollTop : 0;
  $("#tab-quests").innerHTML = h; const qc = $("#tab-quests .qcol"); if(qc){ qc.dataset.v = questView; qc.scrollTop = top; }
}

/* =====================================================================
   SHOP TAB
===================================================================== */
function ensureDaily(){
  const k = todayKey(); if(S.daily.date===k && S.daily.offers.length) return;
  const il = Math.max(1, maxClearedD()+1);
  const setPiece = genItem(il, 1, null, true), a = genItem(il, 0), b = genItem(il, 1);
  S.daily = {date:k, offers:[setPiece,a,b].map(it=>({item:it, price:Math.round(60*(1+it.r*1.6)*(1+it.il*.1))})), bought:[], adChest:false}; persist();
}
function msToMidnight(){ const n = new Date(), m = new Date(n); m.setHours(24,0,0,0); const s = Math.floor((m-n)/1000); return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m`; }
function passPremiumTotal(){ const t = {}; for(let lv=1; lv<=PASS_LEVELS; lv++){ const r = passReward(lv, true); for(const k in r) t[k] = (t[k]||0) + r[k]; } return t; }
/* a premium offer as a painted card: scene, ribbon, contents as icon chips, price.
   `why` = a running moment offer (TIMED in modes.js): the card then shows its timer, what the goods are worth
   bought separately and the item the shop never sells. */
function offerContents(k, why){
  const p = PRODUCTS[k], T = why && offerLive(why) ? TIMED[why] : null, c = Object.assign({}, k==="pass" ? passPremiumTotal() : p.contents || {});
  if(T && T.bonus) for(const b in T.bonus) c[b] = (c[b]||0) + T.bonus[b];
  return c;
}
function offerCard(k, why){
  const p = PRODUCTS[k], T = why && offerLive(why) ? TIMED[why] : null, owned = (k==="seal" && S.removeAds) || (k==="pass" && S.pass.prem);
  const extras = [p.extra, T && T.cape ? `${CAPES[T.cape].name} cape · only in this offer` : ""].filter(Boolean);
  const body = k==="seal" ? `<div class="odesc">${art("seal",30)} Unlimited Vanguard Command and every reward without the video. Yours forever.</div>`
    : `${rchips(offerContents(k, why), 30, 'big')}${extras.map(x=>`<div class="oextra">${art("crown",18)} ${x}</div>`).join("")}${k==="pass"?`<div class="oextra">${passDaysLeft()} days left · ${seasonNow().name}</div>`:""}`;
  const rib = T ? `${offerLeft(why)} left` : k==="pass" ? `Season ${S.pass.season+1}` : p.ribbon;
  return `<div class="offer ${k==="vanguard"||T?'hero':''}"><div class="oimg" style="background-image:url(${IMG(p.img)})">${rib?`<span class="ribbon ${T?'time':''}">${T?ico("clock",12)+" ":""}${rib}</span>`:""}<div class="oname">${art(p.icon,40)}<b>${p.name}</b></div></div>
    <div class="obody">${body}${T && T.value ? `<div class="oval">${T.value} if bought separately</div>` : ""}<button class="btn gold oprice" data-act="iap" data-k="${k}" ${T?`data-why="${why}"`:""} ${owned?'disabled':''}>${owned?'Owned':Monetization.price(k)}</button></div></div>`;
}
/* the best offer running right now, as one wide banner at the very top of the shop: a live 48-hour offer if there is one,
   otherwise one of the standing bundles (it changes every day) */
function shopHero(){
  const live = liveOffers()[0]; let k, why = null;
  if(live){ k = TIMED[live].k; why = live; }
  else { const pool = [!S.starterBought && "squire", "vanguard", !S.pass.prem && "pass", !S.removeAds && !favorActive() && "seal"].filter(Boolean); k = pool[Math.floor(Date.now()/864e5) % pool.length]; }
  const p = PRODUCTS[k], T = why ? TIMED[why] : null, contents = offerContents(k, why);
  const line = T ? T.sub : k==="seal" ? "Unlimited Vanguard Command and no videos, forever." : k==="pass" ? seasonNow().line : p.desc;
  return `<div class="shero ${T?'timed':''}" style="background-image:url(${IMG(p.img)})"><div class="sh-in">${art(p.icon,52)}<div class="grow"><small>${T ? `${ico("clock",12)} ${offerLeft(why)} left · 48 hours only` : "Featured today"}</small><b>${p.name}</b><span class="sh-l">${line}</span>
      <div class="sh-c">${Object.keys(contents).length ? rchips(contents, 22) : ""}${T && T.cape ? `<span class="oextra">${art("crown",16)} ${CAPES[T.cape].name} cape · only here</span>` : ""}</div></div>
    <div class="sh-buy">${T && T.value ? `<em>${T.value} if bought separately</em>` : ""}<button class="btn gold oprice" data-act="iap" data-k="${k}" ${why?`data-why="${why}"`:""}>${Monetization.price(k)}</button></div></div></div>`;
}
function favorCard(){ const on = favorActive(), got = S.favor.gemsDay===todayKey(), sp = Monetization.store.favor, ip = sp && sp.introPrice;
  const trial = !on && ip && +ip.price===0 ? `Free for ${ip.periodNumberOfUnits||3} ${String(ip.periodUnit||"day").toLowerCase()}${(ip.periodNumberOfUnits||3)>1?"s":""}, then ${Monetization.price("favor")} a month` : "";
  return `<div class="favor" style="background-image:url(${IMG("banner_sigil")})"><div class="fv-in">${art("crown",46)}<div class="grow"><b>Vanguard's Favor</b><small>Monthly membership</small>
    <ul>${S.removeAds && !on ? `<li class="have">${ico("check",14)} Unlimited Vanguard Command and no videos: yours already, with the Commander's Seal</li>` : `<li>${art("seal",16,"cur")} Unlimited Vanguard Command</li><li>${art("noads",16,"cur")} Every reward without videos</li>`}<li>${art("gems",16,"cur")} ${FAVOR_GEMS} gems every day</li><li>${art("treasury",16,"cur")} Treasury earns 50% more</li><li><span class="cape-sw" style="background:linear-gradient(${CAPES.favor.c},${CAPES.favor.d})"></span> ${CAPES.favor.name} cape</li></ul></div>
    <div class="fv-buy">${on ? `<button class="btn gold glow" data-act="favorGems" ${got?'disabled':''}>${got?'Claimed today':`Claim ${art("gems",16,"cur")} ${FAVOR_GEMS}`}</button><small>Active${S.favor.until?` until ${new Date(S.favor.until).toLocaleDateString()}`:""}</small>`
      : `<button class="btn gold oprice" data-act="iap" data-k="favor">${Monetization.price("favor")}<small>/ month</small></button>${trial?`<small>${trial}</small>`:""}`}</div></div>
    <div class="fv-legal">Renews automatically each month at the price shown until you cancel. Cancel anytime in iOS Settings → Apple Account → Subscriptions at least 24 hours before renewal. Payment is charged to your Apple Account. <button class="linkbtn inline" data-act="terms">Terms of Use</button> · <button class="linkbtn inline" data-act="privacy">Privacy</button></div></div>`; }
function sinkCard(k){ const G = GEM_SINKS[k], left = sinkLeft(k), ok = G.can();
  return `<div class="mcard"><div class="mi">${art(G.icon,58)}</div><div class="mt">${G.name}</div>${ok ? `<span class="left-b" aria-label="${left} left today">${ico("clock",12)}<b>${left}</b></span>` : `<div class="ms">Not unlocked yet</div>`}<div class="mstats"></div>
    <button class="btn sm purple wide" data-act="buySink" data-k="${k}" ${!ok||left<=0||S.gems<G.price?'disabled':''}>${art("gems",18,"cur")} ${G.price}</button></div>`; }
/* the weekly Sale: one Epic item at half its gold price (Monday to Sunday) */
function ensureSale(){ const wk = weekKey(); if(S.sale.week===wk && S.sale.item) return;
  const it = genItem(Math.max(2, maxClearedD()+2), 2); S.sale = {week:wk, item:it, price:Math.round(60*(1+it.r*1.6)*(1+it.il*.1)), bought:false}; persist(); }
function gemCard(k){ const p = PRODUCTS[k], first = !S.firstBuy[k];
  return `<div class="mcard gem ${p.ribbon?'best':''}">${first?'<span class="ribbon sm x2">2× first time</span>':p.ribbon?`<span class="ribbon sm">${p.ribbon}</span>`:''}<div class="mi">${art(p.icon,66)}</div><div class="mt big">${art("gems",22,"cur")} ${(p.gems*(first?2:1)).toLocaleString("en-US")}</div><div class="ms">${first?`<s>${p.gems.toLocaleString("en-US")}</s> · `:""}${p.name}</div><div class="mstats"></div><button class="btn sm gold wide" data-act="iap" data-k="${k}">${Monetization.price(k)}</button></div>`; }
function renderShop(){
  ensureDaily(); ensureSale();
  const store = Monetization.storeReady(), paid = store && S.cleared["0-4"];     // the featured banner waits for the first boss; the store sections below are open from the start
  let h = `<div class="panel-full shop">`;
  // 1. one banner with the best offer running now, then everything that is free
  if(paid) h += shopHero();
  h += `<div class="shop-h"><b>Daily market</b><small>restocks in ${msToMidnight()}</small></div><div class="market">`;
  h += `<div class="mcard free"><span class="ribbon sm">Free</span><div class="mi">${art("chest",60)}</div><div class="mt">Free daily chest</div><div class="ms">A random item, once a day</div><div class="mstats"></div>
      <button class="btn sm teal wide ${S.daily.adChest?'':'glow'}" data-act="adChest" ${S.daily.adChest?'disabled':''}>${S.daily.adChest?'Claimed':(adFree()?'Open':`${ico("video",16)} Open`)}</button></div>`;
  if(favorActive()) h += `<div class="mcard free"><span class="ribbon sm">Favor</span><div class="mi">${art("gems",60)}</div><div class="mt">${FAVOR_GEMS} gems</div><div class="ms">Vanguard's Favor daily gift</div><div class="mstats"></div><button class="btn sm gold wide" data-act="favorGems" ${S.favor.gemsDay===todayKey()?'disabled':''}>${S.favor.gemsDay===todayKey()?'Claimed':'Claim'}</button></div>`;
  const sl = S.sale, sit = sl.item, half = Math.round(sl.price/2);
  h += `<div class="mcard rb${sit.r} sale ${sl.bought?'sold':''}"><span class="ribbon sm">Sale · half price</span><button class="mi rb${sit.r}" data-act="previewSale"><img src="${itemIcon(sit)}" alt="">${rpips(sit.r)}${sit.set?'<span class="setdot"></span>':''}</button>
      <div class="mt rc${sit.r}">${sit.name}</div><div class="ms">${RARITY[sit.r].name} ${SLOT_DEF[sit.slot].name} · this week only</div>
      <div class="mstats">${Object.keys(sit.stats).slice(0,2).map(k=>`<span>${statLine(k,sit.stats[k])}</span>`).join("")}${sit.perk?`<span class="pk">${PERKS[sit.perk].text}</span>`:""}</div>
      <button class="btn sm gold wide" data-act="buySale" ${sl.bought||S.gold<half?'disabled':''}>${sl.bought?'Sold':`<s>${fmt(sl.price)}</s> ${art("gold",18,"cur")} ${fmt(half)}`}</button></div>`;
  h += S.daily.offers.map((o,idx)=>{ const it = o.item, bought = S.daily.bought.includes(idx);
    return `<div class="mcard rb${it.r} ${bought?'sold':''}"><button class="mi rb${it.r}" data-act="previewDaily" data-i="${idx}"><img src="${itemIcon(it)}" alt="">${rpips(it.r)}${it.set?'<span class="setdot"></span>':''}</button>
      <div class="mt rc${it.r}">${it.name}</div><div class="ms">${RARITY[it.r].name} ${SLOT_DEF[it.slot].name}${it.set?' · Set':''}</div>
      <div class="mstats">${Object.keys(it.stats).slice(0,3).map(k=>`<span>${statLine(k,it.stats[k])}</span>`).join("")}</div>
      <button class="btn sm gold wide" data-act="buyDaily" data-i="${idx}" ${bought||S.gold<o.price?'disabled':''}>${bought?'Sold':`${art("gold",18,"cur")} ${fmt(o.price)}`}</button></div>`; }).join("");
  h += `</div>`;
  // 2. spend gems
  h += `<div class="shop-h"><b>Spend gems</b><small>you have ${art("gems",16,"cur")} ${fmt(S.gems)}</small></div><div class="market">
    <div class="mcard"><div class="mi">${art("orbpouch",62)}</div><div class="mt">Orb pouch</div>${rchips({orbs:30},24)}<div class="mstats"></div><button class="btn sm purple wide" data-act="gemBuy" data-k="orbs" ${S.gems<120?'disabled':''}>${art("gems",18,"cur")} 120</button></div>
    <div class="mcard"><div class="mi">${art("knightchest",62)}</div><div class="mt">Knight's chest</div><div class="ms">One random item. Your odds:</div><div class="mstats odds">${chestOdds().map(o=>`<span class="rc${o.r}">${o.name} <b>${o.pct}</b></span>`).join("")}</div><button class="btn sm purple wide" data-act="gemBuy" data-k="chest" ${S.gems<250?'disabled':''}>${art("gems",18,"cur")} 250</button></div>
    ${["haul","ticket","key"].filter(k=>GEM_SINKS[k].can()).map(sinkCard).join("")}
    <div class="mcard"><div class="mi">${art("crown",58)}</div><div class="mt">Armour skins</div><div class="ms">${Object.keys(SKINS).length} looks to try on</div><div class="mstats"></div><button class="btn sm purple wide" data-act="wardrobe" data-v="skins">View</button></div></div>`;
  // 3. paid offers: always in the Shop for a player who goes looking (pop-ups and timed offers still wait for the first boss)
  if(store){
    h += `<div class="shop-h"><b>Gems</b><small>every pack is doubled the first time you buy it</small></div><div class="market gemgrid">${GEM_SHOWN.map(gemCard).join("")}</div>`;
    const feat = [!S.starterBought && ["squire"], ["vanguard", "boss"], isOpen("arena") && ["arenapack", "arena"], !S.pass.prem && ["pass"], ["sigil"], !S.removeAds && !favorActive() && ["seal"]].filter(Boolean);     // a Favor member already has everything the Seal gives
    h += `<div class="shop-h"><b>Bundles</b></div><div class="offers">${feat.map(f=>offerCard(f[0], f[1])).join("")}</div>`;
    h += `<div class="shop-h"><b>Membership</b></div>${favorCard()}`;
    h += armoryHTML();
  } else if(S.sigils) h += armoryHTML();
  if(store) h += `<button class="btn ghost wide" data-act="restore" style="margin-top:12px">Restore purchases</button>`;
  h += `</div>`;
  const keep = $("#tab-shop .panel-full"), top = keep ? keep.scrollTop : 0;
  $("#tab-shop").innerHTML = h; if(top) $("#tab-shop .panel-full").scrollTop = top;
}
/* "Get N gems": the smallest pack that covers a shortfall, one tap from wherever the gems were missing */
function openGemOffer(need){
  const k = packFor(need), p = PRODUCTS[k], first = !S.firstBuy[k];
  openModal(`<div class="modal-title">You need ${fmt(need)} more gems</div><div class="modal-sub">This is the smallest pack that covers it${first?". It is doubled because it is your first time buying it":""}.</div>
    <div class="market one">${gemCard(k).replace('data-act="iap"', 'data-act="iap" data-then="close"')}</div>
    <div class="mbtns row"><button class="btn ghost" data-close>Not now</button><button class="btn" data-act="tab" data-t="shop" data-close>See every pack</button></div>`);
}
function openSettings(){
  const cloud = !!onyxNative() && Cloud.on;
  const html = `<div class="modal-title">Settings</div>
    <div class="settings">
      <button class="set-row" data-act="toggleSound">${ico(S.sound?"sound":"mute",20)}<span class="grow">Sound</span><span class="toggle ${S.sound?'on':''}"><i></i><span>${S.sound?'On':'Off'}</span></span></button>
      <label class="set-row">${ico("music",20)}<span class="grow">Music</span><input type="range" class="vol" min="0" max="100" step="5" value="${Math.round((S.music??.6)*100)}" data-inp="musicVol" aria-label="Music volume"></label>
      <label class="set-row">${ico("sound",20)}<span class="grow">Effects</span><input type="range" class="vol" min="0" max="100" step="5" value="${Math.round(sfxVolume()*100)}" data-inp="sfxVol" aria-label="Effects volume"></label>
      <button class="set-row" data-act="toggleHaptics">${ico("vibrate",20)}<span class="grow">Vibration</span><span class="toggle ${S.haptics?'on':''}"><i></i><span>${S.haptics?'On':'Off'}</span></span></button>
      <button class="set-row" data-act="toggleCalm">${ico("eye",20)}<span class="grow">Reduce screen shake<small>Softer shakes and no freeze-frames on heavy hits${!S.calmSet && calmOn() ? ". On because your phone's Reduce Motion is on" : ""}</small></span><span class="toggle ${calmOn()?'on':''}"><i></i><span>${calmOn()?'On':'Off'}</span></span></button>
      <button class="set-row" data-act="toggleBig">${ico("text",20)}<span class="grow">Larger text<small>Menus 15% larger</small></span><span class="toggle ${S.bigText?'on':''}"><i></i><span>${S.bigText?'On':'Off'}</span></span></button>
      <button class="set-row" data-act="toggleLefty">${ico("hand",20)}<span class="grow">Left-handed<small>Mirrors the battle controls</small></span><span class="toggle ${S.lefty?'on':''}"><i></i><span>${S.lefty?'On':'Off'}</span></span></button>
      <button class="set-row" data-act="cycleQuality">${ico("sparkles",20)}<span class="grow">Graphics<small>Auto lowers quality if the game runs slowly</small></span><b>${({auto:"Auto",high:"High",low:"Battery saver"})[S.quality]||"Auto"}</b></button>
      ${S.cleared["0-0"]?`<button class="set-row" data-act="rename">${ico("helm",20)}<span class="grow">Knight's name<small>${knightName()}</small></span><b>Change</b></button>`:""}
      <button class="set-row" data-act="cmdInfo">${art("seal",22)}<span class="grow">Vanguard Command<small>${cmdOpen() ? "Speed ×2 and ×3, auto-pick and auto-cast. In battle: tap the speed button, hold a button to make it automatic." : "Speed and auto modes unlock when the Outlaw King falls."}</small></span><b>${!cmdOpen() ? ico("lock",14) : cmdUnlimited() ? "Unlimited" : `${cmdLeft()}/${cmdCap()}`}</b></button>
      ${cmdOpen() ? `<button class="set-row sub" data-act="setAutoPick">${art("skills",22)}<span class="grow">Auto-pick skills<small>Same as holding the skill button in battle</small></span><span class="toggle ${S.autoPick?'on':''}"><i></i><span>${S.autoPick?'On':'Off'}</span></span></button>
      <button class="set-row sub" data-act="setAutoCast">${art("ab_meteor",22)}<span class="grow">Auto-cast abilities<small>Same as holding each ability button in battle</small></span><span class="toggle ${SYN_TAGS.every(t=>S.autoAb[t])?'on':''}"><i></i><span>${SYN_TAGS.every(t=>S.autoAb[t])?'On':SYN_TAGS.some(t=>S.autoAb[t])?'Some':'Off'}</span></span></button>` : ""}
      <button class="set-row" data-act="privacy">${ico("info",20)}<span class="grow">Privacy</span></button>
      ${Monetization.privacyOptions()?`<button class="set-row" data-act="adPrivacy">${ico("info",20)}<span class="grow">Ad privacy choices<small>Change what you agreed to for ads</small></span></button>`:""}
      <button class="set-row" data-act="terms">${ico("info",20)}<span class="grow">Terms of Use</span></button>
      ${GameCenter.ready?`<button class="set-row" data-act="gcDash">${art("trophy",22)}<span class="grow">Game Center<small>${GameCenter.player?`Signed in as ${GameCenter.player.name||"you"} · leaderboards and achievements`:"Not signed in. Sign in from iOS Settings → Game Center"}</small></span></button>`:""}
      ${onyxNative()?`<div class="set-row">${ico("check",20)}<span class="grow">iCloud save<small>${Cloud.on?(Cloud.tooBig?"On, but this save is too large to upload. Salvage spare items to fix it.":Cloud.last?`On · last saved ${new Date(Cloud.last).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}`:"On · your progress follows your Apple Account"):"Off. Sign in to iCloud in iOS Settings to keep your progress safe"}</small></span></div>`:""}
      ${SUPPORT_EMAIL?`<button class="set-row" data-act="contact">${ico("info",20)}<span class="grow">Contact us<small>Report a bug or send us a message</small></span></button>`:""}
      ${Monetization.storeReady()?`<button class="set-row" data-act="restore">${ico("check",20)}<span class="grow">Restore purchases</span></button>`:''}
      <button class="set-row danger" data-act="resetAsk">${ico("trash",20)}<span class="grow">Reset progress</span></button>
    </div>
    <div class="legal">Onyx Vanguard ${versionLabel()}. Font: Source Serif 4, SIL Open Font License. ${cloud ? "Progress is saved on this device and in your iCloud." : "Progress is saved on this device."}</div>`;
  closeAllModals(); openModal(html); bindTesterHold();
}
/* long-press the version line (about 1 s) to mark this device as a tester: it is left out of the player numbers */
function bindTesterHold(){
  const el = document.querySelector(".modal .legal"); if(!el) return; let tm = 0;
  const go = ()=>{ S.tester = !S.tester; S.testerSet = true; persist(); Telemetry.ping(true); Monetization.markTester(); toast(S.tester ? "Tester mode on. This device is left out of the player numbers." : "Tester mode off.", "#d0ab62"); haptic("MEDIUM"); };
  const start = ()=>{ clearTimeout(tm); tm = setTimeout(go, 1000); }, stop = ()=>clearTimeout(tm);
  el.addEventListener("touchstart", start, {passive:true}); el.addEventListener("touchend", stop); el.addEventListener("touchcancel", stop);
  el.addEventListener("mousedown", start); el.addEventListener("mouseup", stop); el.addEventListener("mouseleave", stop);
}
const versionLabel = () => `${APP_VERSION} · content ${CONTENT_VERSION}`;
/* SAVE RESCUE (Review 5): shown once at launch when the main save could not be read. Nothing is thrown away: the unreadable
   copy is kept aside, and the player is told plainly what happened. */
function openSaveRescue(){
  if(saveState==="rescued"){ const when = saveRescueAt ? new Date(saveRescueAt).toLocaleString([], {dateStyle:"medium", timeStyle:"short"}) : "";
    openModal(`<div class="modal-title">Your save was restored</div><div class="confirm-text">The game could not read your latest save, so it loaded the backup copy${when ? ` from <b>${when}</b>` : ""}. A few minutes of play may be missing.</div>
      <div class="confirm-text">Purchases are safe: use Restore purchases in Settings if anything is missing.</div><div class="mbtns row"><button class="btn gold" data-act="rescueOk">Continue</button></div>`, {noClose:true}); }
  else if(saveState==="lost"){
    openModal(`<div class="modal-title">Your save could not be read</div><div class="confirm-text">The save on this device is damaged and there is no backup copy, so the game has started a new knight.${Cloud.on ? " If you use iCloud, your progress will be offered back in a moment." : ""}</div>
      <div class="confirm-text">The Commander's Seal and Vanguard's Favor come back with Restore purchases in Settings. ${SUPPORT_EMAIL ? `For anything else, write to ${SUPPORT_EMAIL} and mention version ${versionLabel()}.` : ""}</div><div class="mbtns row"><button class="btn gold" data-act="rescueOk">Continue</button></div>`, {noClose:true}); }
}
function openPrivacy(){
  openModal(`<div class="modal-title">Privacy</div>
    <div class="confirm-text" style="text-align:left;font-size:13.5px">
    <p>Your progress is saved on this device and, if you use iCloud, in your own iCloud account so it follows you to your other devices. We don't run accounts or collect your name, email or location. The name you give your knight stays in your save. Game Center (if you're signed in) receives your leaderboard scores and achievements.</p>
    <p>Rewarded videos are provided by Google AdMob, which may use your device's advertising identifier to show and measure ads if you allow it. You can say no when asked, or change it anytime in iOS Settings → Privacy & Security → Tracking. The <b>Commander's Seal</b> and <b>Vanguard's Favor</b> skip every video.</p>
    <p>Purchases are processed by Apple. RevenueCat receives an anonymous purchase record so your purchases can be restored.</p>
    <p>Full policy: ${PRIVACY_URL ? `<a href="${PRIVACY_URL}" target="_blank" rel="noopener" style="color:var(--gold)">${PRIVACY_URL}</a>` : "see the App Store listing."}</p></div>`);
}

/* =====================================================================
   ACTIONS
===================================================================== */
const parseCfg = el => JSON.parse(el.dataset.cfg);
const ACTIONS = {
  tab:(d)=>{ if(d.t===currentTab) return; SFX.click(); setTab(d.t); },
  openLevel:(d)=>{ SFX.click(); const a = +d.a, i = +d.i, t = S.oath.sel; if(!levelUnlockedT(t,a,i)){ toast(actUnlockedT(t,a) ? "Clear the level before this one first." : `Defeat ${ENEMY[ACTS[a-1].boss].name} to reach ${ACTS[a].name.replace(/^Act [IV]+: /,"")}.`); return; }
    if(t===1 && a===0 && i<4 && !S.cleared["0-4"]){ closeAllModals(); startRun({mode:"campaign", a, i, tier:1}); return; }   // early levels: tap and fight
    pfHeat = null; pfHorde = false; pfPrep = false; openPrefight({mode:"campaign", a, i, tier:t}); },
  tiers:()=>{ SFX.click(); openTiers(); },
  setTier:(d)=>{ SFX.click(); S.oath.sel = +d.t; persist(); closeAllModals(); renderMap(); toast(`Oath Tier ${tierName(+d.t)}`, "#c9a2ff"); },
  mark:(d)=>{ SFX.click(); if(d.k==="arena" && isOpen("arena") && !S.offers.arena && Monetization.storeReady() && S.cleared["0-4"]){ closeAllModals(); offerPopup("arena", openArena); return; } ({arena:openArena, raid:openRaid, challenges:openChallenges, endless:openEndless, keep:openKeep})[d.k](); },
  openChallenges:()=>{ SFX.click(); openChallenges(); },
  openChallenge:(d)=>{ SFX.click(); openPrefight({mode:"challenge", id:d.id}); },
  openEndless:()=>{ SFX.click(); openEndless(); },
  startEndless:()=>{ SFX.click(); closeAllModals(); startRun({mode:"endless"}); },
  startLevel:(d,el)=>{ SFX.click(); const cfg = parseCfg(el); closeAllModals();
    if(cfg.mode==="challenge"){ const ch = CHALLENGES.find(c=>c.id===cfg.id); startRun({mode:"challenge", id:ch.id, a:ch.act, i:ch.lvl, d:ch.d, mods:ch.mods, title:ch.name}); }
    else { const heat = heatOpen() ? clamp(cfg.heat|0, 0, heatMax()) : 0; S.heat.sel = heat; S.heat.own = heatOpen() && heat < heatTarget(cfg.tier||1, cfg.a, cfg.i); const c2 = {mode:"campaign", a:cfg.a, i:cfg.i, tier:cfg.tier||1, heat}; if(cfg.mods && cfg.mods.hordeWk && weekendEvent() && weekendEvent().id==="horde") c2.mods = {hordeWk:true}; startRun(c2); } },
  pfHeat:(d,el)=>{ SFX.click(); pfHeat = clamp(+d.v, 0, heatMax()); const cfg = parseCfg(el); cfg.heat = pfHeat; openPrefight(cfg); },
  pfHorde:(d,el)=>{ SFX.click(); pfHorde = !pfHorde; openPrefight(parseCfg(el)); },
  pfPrep:(d,el)=>{ SFX.click(); pfPrep = !pfPrep; openPrefight(parseCfg(el)); },
  pfOath:(d,el)=>{ SFX.click(); S.oathSel = d.v; persist(); openPrefight(parseCfg(el)); },
  abilInfo:(d)=>{ const A = ABILITIES[d.t]; toast(`${A.name} (${TAGS[d.t].name}): ${A.text}. Recharges in ${A.cd}s.`, TAGS[d.t].color); },
  editBans:(d,el)=>{ SFX.click(); openBanEditor(parseCfg(el)); },
  toggleBanPF:(d,el)=>{ if(toggleBan(d.id)){ SFX.click(); openBanEditor(parseCfg(el)); } },
  backPrefight:(d,el)=>{ SFX.click(); openPrefight(parseCfg(el)); },
  toggleBan:(d)=>{ if(toggleBan(d.id)){ SFX.click(); renderCodex(); } },
  codexTag:(d)=>{ SFX.click(); codexTag = d.t; renderCodex(); $("#tab-codex .panel-full").scrollTop = 0; },
  enemyInfo:(d)=>{ const T = ENEMY[d.t], sc = enemyScaling(+d.d), [w, r] = enemyMods(d.t);
    toast(`${T.name}: ${T.trait}. About ${Math.round(T.hp*sc.hp)} HP, ${Math.round(T.dmg*sc.dmg)} damage per hit.${w.length?` Weak to ${w.map(k=>ELEM_NAME[k]).join(" and ")}.`:""}${r.length?` Resists ${r.map(k=>ELEM_NAME[k]).join(" and ")}.`:""}`, T.boss?"#ff5a6e":"#d0ab62"); },
  upCard:(d)=>{ const lv = cardLv(d.id), c = orbCost(lv); if(lv>=CARD_MAX || S.orbs<c) return; S.orbs -= c; S.cardLv[d.id] = lv+1; S.stats.cardUps++; persist(); SFX.level(); toast(`${CARD_BY[d.id].name} upgraded to level ${lv+1}`, "#c9a2ff"); renderCodex(); renderCurrencies(); },
  buyMeta:(d)=>{ const m = META.find(x=>x.id===d.id), c = trainCost(m); if(S.meta[m.id]>=m.max || S.gold<c) return; S.gold -= c; S.meta[m.id]++; S.tips.trained = 1; persist(); SFX.coin(); renderHero(); renderCurrencies(); },
  heroView:(d)=>{ SFX.click(); heroView = d.v; renderHero(); $("#tab-hero .hero-panel").scrollTop = 0; },
  invFilter:(d)=>{ SFX.click(); invFilter = d.f; heroView = "inv"; renderHero(); $("#tab-hero .hero-panel").scrollTop = 0; },
  slotTap:(d)=>{ SFX.click(); const it = equipped(d.s);
    if(invFilter!==d.s || heroView!=="inv"){ invFilter = d.s; heroView = "inv"; renderHero(); $("#tab-hero .hero-panel").scrollTop = 0; if(!it && !S.inv.some(i=>i.slot===d.s)) toast(`No ${SLOT_DEF[d.s].name.toLowerCase()} yet. Win battles or visit the Shop's daily market.`); }
    else if(it) openItem(it.uid); },
  capes:()=>{ SFX.click(); openWardrobe(); },
  wardrobe:(d)=>{ SFX.click(); if(d.v) lookTab = d.v; openWardrobe(); },
  lookTab:(d)=>{ SFX.click(); lookTab = d.v; openWardrobe(); },
  statsInfo:()=>{ SFX.click(); openStats(); },
  equipBest:()=>{ const p0 = powerOf(heroStats(null)), n = equipBestAll(); if(!n) return; persist(); SFX.pick(); haptic("MEDIUM"); heroChanged(true); renderHero(); renderCurrencies(); toast(`Equipped ${n} better item${n>1?"s":""} · +${powerOf(heroStats(null)) - p0} power`, "#5bd26a"); },
  trainN:(d)=>{ const m = META.find(x=>x.id===d.id); if(!m) return; const p0 = powerOf(heroStats(null)); let k = 0;
    while(k < +d.n && S.meta[m.id] < m.max){ const c = metaCost(m); if(S.gold < c) break; S.gold -= c; S.meta[m.id]++; k++; }
    if(!k) return; persist(); SFX.coin(); toast(`${m.name} +${k} ranks · +${powerOf(heroStats(null))-p0} power`, "#d0ab62"); renderHero(); renderCurrencies(); },
  trySkin:(d)=>{ SFX.click(); trySkin(d.k); },
  pvWalk:()=>{ SFX.click(); home.pvWalk = 2.8; },
  pvEnd:()=>{ SFX.click(); endPreview(); lookTab = "skins"; renderHero(); openWardrobe(); },
  getGems:(d)=>{ SFX.click(); openGemOffer(+d.need); },
  buySkinDo:(d)=>{ if(!buySkin(d.k)) return; skinPreview = null; SFX.win(); haptic("HEAVY"); heroChanged(true); home.pvWalk = 2.8; toast(`${SKINS[d.k].name} is yours`, "#c9a2ff"); renderCurrencies(); if(currentTab==="hero") renderHero(); },
  setSkin:(d)=>{ if(d.k && !S.skins.includes(d.k)) return; endPreview(); S.skin = d.k; persist(); SFX.click(); heroChanged(true); lookTab = "skins"; openWardrobe(); if(currentTab==="hero") renderHero(); },
  toggleTrim:()=>{ S.trim = S.trim==="league" ? "" : "league"; persist(); SFX.click(); heroChanged(true); openWardrobe(); },
  setInfo:(d)=>{ const T = SETS[d.k], n = heroStats(null).sets[d.k]||0; toast(`${T.name} ${n}/3 · (2) ${T.b2} · (3) ${T.b3}`, SET_GLOW[d.k]); },
  loadouts:()=>{ SFX.click(); openLoadouts(); },
  loSave:(d)=>{ saveLoadout(+d.i); SFX.pick(); toast(`${LOADOUT_NAMES[+d.i]} set saved`, "#d0ab62"); openLoadouts(); },
  loUse:(d)=>{ if(!useLoadout(+d.i)) return; SFX.pick(); haptic("LIGHT"); toast(`${LOADOUT_NAMES[+d.i]} set equipped`, "#5bd26a"); openLoadouts(); renderHero(); renderCurrencies(); },
  pfLoad:(d,el)=>{ if(!useLoadout(+d.i)) return; SFX.pick(); renderCurrencies(); openPrefight(parseCfg(el)); },
  autoSalv:(d)=>{ S.autoSalv[d.r] = !S.autoSalv[d.r]; persist(); SFX.click(); renderHero(); },
  synAlt:(d)=>{ if(masteryRank(d.t)<1) return; S.synAlt[d.t] = !S.synAlt[d.t]; persist(); SFX.click(); renderCodex(); },
  buySink:(d)=>{ const G = GEM_SINKS[d.k]; if(!buySink(d.k)) { if(G && S.gems<G.price) toast(`You need ${G.price - S.gems} more gems.`); return; } SFX.coin(); toast(`${G.name} bought`, "#c9a2ff"); renderCurrencies(); if(currentTab==="shop") renderShop(); else if(currentTab==="quests") renderQuests(); },
  favorGems:()=>{ if(!claimFavorGems()) return; SFX.coin(); toast(`+${FAVOR_GEMS} gems from Vanguard's Favor`, "#6ab8ff"); renderCurrencies(); if(currentTab==="shop") renderShop(); },
  go:(d)=>{ SFX.click(); const dest = ({syn2:"map", dry:"map", heat:"map", stop:"map", focus:"map", kills:"map", wins:"map", events:"map", elites:"map", potions:"map", gold:"map", forge:"hero", cardup:"codex", duels:"arena", raid:"raid", waves:"endless"})[d.q] || "map";
    if(dest==="arena") { setTab("map"); openArena(); } else if(dest==="raid"){ setTab("map"); openRaid(); } else if(dest==="endless"){ setTab("map"); openEndless(); }
    else { if(dest==="hero"){ heroView = "inv"; invFilter = "all"; } setTab(dest); if(dest==="hero") toast("Tap an item, then Forge."); if(dest==="map"){ const nx = nextLevel(); if(nx) setTimeout(()=>{ const n = document.querySelector(".mnode.open"); if(n) n.classList.add("ping"); }, 50); } } },
  terms:()=>{ SFX.click(); window.open(TERMS_URL, "_blank"); },
  contact:()=>{ SFX.click(); openContact(); },
  contactCancel:()=>{ SFX.click(); closeAllModals(); },
  contactKind:(d)=>{ SFX.click(); contactKind = d.k; document.querySelectorAll(".ct-kind button").forEach(b=>b.classList.toggle("on", b.dataset.k===d.k)); const t = $("#ctText"); if(t) t.placeholder = CONTACT_KINDS[d.k].hint; },
  contactSend:()=>{ const t = $("#ctText"), msg = t ? t.value.trim() : "";
    if(msg.length < 3){ toast("Write a few words first", "#d0ab62"); return; }
    SFX.pick(); const K = CONTACT_KINDS[contactKind], info = $("#ctInfo") && $("#ctInfo").checked ? "\n\n— Game info (helps us fix bugs) —\n" + contactInfo() : "";
    window.open(`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`[${K.tag}] Onyx Vanguard ${versionLabel()}`)}&body=${encodeURIComponent(msg + info)}`, "_blank");
    S.contactDraft = ""; persist(); closeAllModals(); toast("Your mail app opened with the message. Tap Send there.", "#8fd3a0"); },
  support:()=>{ SFX.click(); if(SUPPORT_EMAIL) window.open(`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent("Onyx Vanguard "+versionLabel())}`, "_blank"); },
  setCape:(d)=>{ if(!S.capes.includes(d.k)){ toast(`${CAPES[d.k].name}: ${CAPES[d.k].how}`); return; } S.cape = d.k; persist(); SFX.click(); heroChanged(true); openCapes(); if(currentTab==="hero") renderHero(); },
  openItem:(d)=>{ SFX.click(); if(run){ const it = itemById(+d.uid); if(it) toast(`${it.name}: ${Object.keys(it.stats).map(k=>statLine(k,it.stats[k])).join(", ")}`, RARITY[it.r].color); return; } openItem(+d.uid); },
  equip:(d)=>{ const it = itemById(+d.uid); if(!it) return; S.equip[it.slot] = it.uid; persist(); SFX.pick(); haptic("LIGHT"); closeAllModals(); heroChanged(true); renderHero(); renderCurrencies(); },
  unequip:(d)=>{ const it = itemById(+d.uid); if(!it) return; S.equip[it.slot] = null; persist(); SFX.click(); closeAllModals(); heroChanged(false); renderHero(); renderCurrencies(); },
  forge:(d)=>{ const it = itemById(+d.uid); if(!it) return; const c = forgeCost(it); if( it.upg>=FORGE_MAX || S.gold<c) return; const before = itemStats(it), p0 = powerOf(heroStats(null));
    S.gold -= c; it.upg++; S.stats.forges++; persist(); SFX.forge(); haptic("MEDIUM"); setTimeout(()=>SFX.forge(), 260);
    openItem(it.uid, {forged:{before, gain:powerOf(heroStats(null)) - p0}}); renderHero(); renderCurrencies(); },       // the hammer falls and the numbers change in front of the player
  salvage:(d)=>{ const it = itemById(+d.uid); if(!it || isEquipped(it)) return; if(it.r===5) return; const v = salvageValue(it), du = salvageDust(it); (it.sock||[]).forEach((rn,i)=>{ if(rn) unsocket(it,i); }); S.inv = S.inv.filter(i=>i.uid!==it.uid); S.gold += v; S.dust += du; persist(); SFX.coin(); toast(`Salvaged: +${v} gold, +${du} Arcane Dust`, "#d0ab62"); closeAllModals(); renderHero(); renderCurrencies(); },
  salvageCommons:()=>{ const junk = S.inv.filter(it=>it.r===0 && spareItem(it) && !isUpgrade(it)); if(!junk.length) return; const v = junk.reduce((a,it)=>a+salvageValue(it),0);
    const du = junk.reduce((a,it)=>a+salvageDust(it),0); S.inv = S.inv.filter(it=>!junk.includes(it)); S.gold += v; S.dust += du; persist(); SFX.coin(); toast(`Salvaged ${junk.length} items: +${fmt(v)} gold, +${du} Arcane Dust`, "#d0ab62"); renderHero(); renderCurrencies(); },
  forgeRune:(d)=>{ if(forgeRune(d.t)){ persist(); SFX.forge(); haptic("MEDIUM"); toast(`Forged ${RUNES[d.t].name} I`, RUNES[d.t].color); renderHero(); } },
  mergeRune:(d)=>{ if(mergeRune(d.t, +d.l)){ persist(); SFX.level(); haptic("MEDIUM"); toast(`Merged into ${RUNES[d.t].name} ${ROMAN[+d.l+1]}`, RUNES[d.t].color); renderHero(); } },
  sock:(d)=>{ SFX.click(); openRunePicker(+d.uid, +d.i); },
  setRune:(d)=>{ const it = itemById(+d.uid); if(socketRune(it, +d.i, d.t, +d.l)){ persist(); SFX.forge(); haptic("LIGHT"); heroChanged(false); openItem(it.uid); renderHero(); } },
  unsock:(d)=>{ const it = itemById(+d.uid); if(unsocket(it, +d.i)){ persist(); SFX.click(); openItem(it.uid); renderHero(); } },
  backItem:(d)=>{ SFX.click(); openItem(+d.uid); },
  transmute:(d)=>{ const it = itemById(+d.uid), c = it && transmuteCost(it); if(!it || it.r===0 || S.dust<c) return; S.dust -= c; transmute(it); persist(); SFX.forge(); haptic("MEDIUM"); toast("Bonus stats rerolled", "#6ab8ff"); openItem(it.uid); renderHero(); },
  ascend:(d)=>{ const it = itemById(+d.uid), c = it && ASCEND_COST[it.r]; if(!it || !c || S.star<c.star || S.dust<c.dust) return; S.star -= c.star; S.dust -= c.dust; ascend(it); persist(); SFX.syn(); haptic("HEAVY"); toast(`${it.name} is now ${RARITY[it.r].name}`, RARITY[it.r].color); heroChanged(true); openItem(it.uid); renderHero(); },
  buyDaily:(d)=>{ const idx = +d.i, o = S.daily.offers[idx]; if(!o || S.daily.bought.includes(idx) || S.gold<o.price) return; S.gold -= o.price; const it = Object.assign({}, o.item, {uid:S.uid++}); S.inv.push(it); S.daily.bought.push(idx); persist(); SFX.coin(); closeAllModals(); toast(`${it.name} added to your inventory`, RARITY[it.r].color); renderShop(); renderCurrencies(); },
  buySale:()=>{ const sl = S.sale, half = Math.round(sl.price/2); if(!sl.item || sl.bought || S.gold<half) return; S.gold -= half; const it = Object.assign({}, sl.item, {uid:S.uid++}); S.inv.push(it); sl.bought = true; persist(); SFX.coin(); toast(`${it.name} added to your inventory`, RARITY[it.r].color); renderShop(); renderCurrencies(); },
  previewSale:()=>{ const it = S.sale.item; if(it) toast(`${it.name}: ${Object.keys(it.stats).map(k=>statLine(k,it.stats[k])).join(", ")}${it.perk?`. ${PERKS[it.perk].text}.`:""}`, RARITY[it.r].color); },
  previewDaily:(d)=>{ const o = S.daily.offers[+d.i]; if(!o) return; SFX.click(); openTryOn(o.item, +d.i); },
  adChest: async ()=>{ if(S.daily.adChest) return; const ok = await Monetization.rewarded("daily_chest"); if(!ok || S.daily.adChest) return; S.daily.adChest = true; const it = genItem(Math.max(1,maxClearedD()+1), 0); S.inv.push(it); persist(); chestReveal(it, "chest"); renderShop(); renderCurrencies(); },
  gemBuy:(d)=>{ if(d.k==="orbs"){ if(S.gems<120) return; S.gems -= 120; S.orbs += 30; toast("+30 Orbs", "#c9a2ff"); }
    else { if(S.gems<250) return; S.gems -= 250; const it = genItem(chestIl(), CHEST_MIN_R); S.inv.push(it); persist(); chestReveal(it, "knightchest"); }
    persist(); SFX.coin(); renderShop(); renderCurrencies(); },
  iap: async (d,el)=>{ if(el.dataset.busy) return; el.dataset.busy = 1;
    try{ const ok = await Monetization.purchase(d.k); if(!ok) return; PRODUCTS[d.k].grant();
      const why = d.why, T = why && TIMED[why];                       // a running 48-hour offer adds what the shop never sells
      if(T && T.k===d.k && offerLive(why)){ if(T.bonus) grantBundle(T.bonus); if(T.cape && !S.capes.includes(T.cape)) S.capes.push(T.cape); S.offers[why].bought = true; }
      persist(); SFX.win(); haptic("HEAVY"); toast(`Thank you! ${PRODUCTS[d.k].name} delivered.`, "#d0ab62"); heroChanged(false);
      if(run){ if(d.cmd){ run.command = cmdLeft() > 0; updateCmdHud(); buildAbilBar(); closeTopModal(); if(!run.cardModal && !run.eventModal && !run.over) run.paused = false; } return; }
      if(d.then==="close" || d.cmd) closeTopModal();
      renderAll(); if(d.cmd) cmdResume(); if(el.dataset.offer){ closeTopModal(); const f = offerAfter; offerAfter = null; if(f) f(); } } finally { delete el.dataset.busy; } },
  restore:()=>{ Monetization.restore(); },
  settings:()=>{ SFX.click(); openSettings(); },
  toggleSound:()=>{ S.sound = !S.sound; persist(); if(S.sound){ ac(); SFX.click(); } Music.volume(); openSettings(); },
  toggleCalm:()=>{ S.calm = !calmOn(); S.calmSet = true; persist(); World.setCalm(calmOn()); applyComfort(); SFX.click(); openSettings(); },
  toggleBig:()=>{ S.bigText = !S.bigText; persist(); applyComfort(); SFX.click(); heroAnchor = null; mapKey = ""; openSettings(); renderTab(currentTab); },
  toggleLefty:()=>{ S.lefty = !S.lefty; persist(); applyComfort(); SFX.click(); hudCache = {}; if(run) measureHud(); openSettings(); },
  storyDone:()=>{ SFX.click(); closeTopModal(); const f = storyAfter; storyAfter = null; if(f) f(); },
  rescueOk:()=>{ SFX.click(); const lost = saveState==="lost"; saveState = "ok"; persist(); backupSave(true); closeAllModals(); if(lost && !run && !S.cleared["0-0"]) startRun({mode:"campaign", a:0, i:0, tier:1}); },
  adPrivacy:()=>{ SFX.click(); Monetization.showPrivacyOptions(); },
  toggleHaptics:()=>{ S.haptics = !S.haptics; persist(); haptic("MEDIUM"); SFX.click(); openSettings(); },
  cycleQuality:()=>{ const order = ["auto","high","low"]; S.quality = order[(order.indexOf(S.quality)+1)%3]; persist(); applyQuality(); SFX.click(); openSettings(); },
  privacy:()=>{ SFX.click(); openPrivacy(); },
  resetAsk:()=>{ openModal(`<div class="modal-title">Reset progress?</div><div class="confirm-text">This deletes your gear, gold, upgrades and cleared levels on this device${Cloud.on?' and in iCloud':''}. </div><div class="confirm-text"><b>Purchases:</b> only the Commander's Seal and Vanguard's Favor come back with Restore purchases. Gems, the Oath Pass, Ancient relics and bundle capes you paid for are deleted for good and can't be restored or refunded here.</div><div class="confirm-text">This can't be undone.</div>
    <div class="mbtns row"><button class="btn" data-close>Keep my progress</button><button class="btn red" data-act="resetDo">Delete everything</button></div>`); },
  resetDo: async ()=>{ try{ for(const k of [SAVE_KEY, SAVE_BAK, SAVE_PRE, SAVE_BROKEN]) localStorage.removeItem(k); }catch(e){} S = defaultSave(); if(Cloud.on){ S.savedAt = Date.now(); try{ await Cloud.push(); }catch(e){} } location.reload(); },
  // modes
  openArena:()=>{ SFX.click(); openArena(); },
  duel:(d)=>{ SFX.click(); startDuel(+d.i); },
  reOpps:()=>{ SFX.click(); genOpps(); openArena(); },
  adTicket: async ()=>{ if(S.arena.adTicket) return; const ok = await Monetization.rewarded("arena_ticket"); if(!ok || S.arena.adTicket) return; S.arena.adTicket = true; S.arena.tickets++; persist(); openArena(); },
  openRaid:()=>{ SFX.click(); openRaid(); },
  oppCard:(d)=>{ const c = CARD_BY[d.id]; if(c) toast(`${c.name} (${TAGS[c.tag].name}): ${c.text(c.v(2,1))}`, TAGS[c.tag].color); },
  arenaChest:()=>{ if(!arenaChestReady()) return; const b = arenaChest(); S.arena.week = weekKey(); const got = grantBundle(b); SFX.win(); haptic("HEAVY"); renderCurrencies(); openArena(); toast(`${leagueOf(S.arena.trophies).name} league chest: +${b.gems} gems, +${b.orbs} orbs, +${fmt(b.gold)} gold`, "#f2c14e"); },
  raidChest:()=>{ const R_ = S.raid; if(R_.goal || (R_.day||0) < raidGoal()) return; R_.goal = true; const b = {gold:Math.round(150 + 40*Math.max(1, maxClearedD())), orbs:6, frags:runesOpen() ? 3 : 0}; grantBundle(b); SFX.win(); haptic("MEDIUM"); renderCurrencies(); openRaid(); toast(`Raid chest: +${fmt(b.gold)} gold, +${b.orbs} orbs${b.frags?`, +${b.frags} fragments`:""}`, "#f2c14e"); },
  weekendInfo:()=>{ SFX.click(); const we = weekendEvent(); if(!we) return; if(we.id==="rush"){ openRush(); return; } toast(`${we.name}: ${we.text}`, "#f2c14e"); },
  rushGo:()=>{ const we = weekendEvent(); if(!we || we.id!=="rush") return; SFX.click(); closeAllModals(); startRun({mode:"rush"}); },
  streakFix: async (d)=>{ if(!streakFixable()) return; if(d.how==="gems"){ if(S.gems < STREAK_FIX_GEMS) return; S.gems -= STREAK_FIX_GEMS; } else { const ok = await Monetization.rewarded("streak"); if(!ok || !streakFixable()) return; }
    fixStreak(); SFX.level(); renderCurrencies(); openLogin(); toast(`Streak restored: ${S.login.streak} days and counting`, "#f2c14e"); },
  raidGo:()=>{ SFX.click(); startRaid(); },
  claimQuest:(d)=>{ claimQuest(d.id); renderQuests(); renderCurrencies(); },
  claimBonus:()=>{ claimDailyBonus(); renderQuests(); renderCurrencies(); },
  claimJourney:(d)=>{ claimJourney(d.id); renderQuests(); renderCurrencies(); },
  // run
  pickCard:(d)=>{ const R = run; if(!R || !R.cardModal) return; const id = R.offer[+d.k]; if(!id) return; SFX.pick(); applyCard(id); closeModal(R.cardModal); R.cardModal = null; R.pendingLv--; R.first = false;
    if(R.pendingLv>0) setTimeout(()=>{ if(run===R && !R.over) openCardPick(); }, 160); else R.paused = false; updatePickBtn(); Music.duck(false); },
  openPick:()=>{ const R = run; if(R && !R.over && R.pendingLv<=0 && !$("#modalRoot").children.length){ toast(R.command ? (autoPickOn(R) ? "Skills are picked automatically. Hold to choose them yourself." : "No skill waiting. Hold this button to pick skills automatically.") : "No skill waiting yet.", "#f2d796"); return; }
    if(!R || R.over || R.pendingLv<=0 || (R.cardModal && R.cardModal.parentNode) || $("#modalRoot").children.length) return; SFX.click(); Music.duck(true); openCardPick(); },
  reroll: async ()=>{ const R = run; if(!R || R.rerolling) return; R.rerolling = true;
    try{ if(R.rerolls>0) R.rerolls--; else { const ok = await Monetization.rewarded("card_reroll"); if(!ok) return; }
      if(run!==R || R.over) return; closeModal(R.cardModal); R.cardModal = null; openCardPick(); } finally { R.rerolling = false; } },
  pause:()=>{ if(!run || run.over || run.paused) return; openPause(); },
  resume:()=>{ closeTopModal(); if(run && !run.cardModal && !run.eventModal) run.paused = false; },
  abandon:()=>{ if(!run) return; if(run.time < 20) run.noResolve = true; closeAllModals(); run.cardModal = null; run.eventModal = null; run.paused = false; defeat(); },
  potion:()=>{ if(!run || run.over || run.paused) return; if(!drinkPotion()) toast(run.potions<=0 ? "No potions left." : "You're already at full health.", "#ff6a7a"); },
  /* x1 is free for everyone; x2 and x3 are part of Vanguard Command (Review 5) */
  speed:()=>{ const R = run; if(!R) return; SFX.click();
    if(!R.command){ if(R.speed!==1){ R.speed = 1; setSpeedBtn(); } cmdGate("speed"); return; }
    R.speed = R.speed===1 ? 2 : R.speed===2 ? 3 : 1; if(R.speed>1) useCommand(R); setSpeedBtn(); updateCmdHud(); },
  /* HOLD actions (see the pointer handlers below): a held button switches between manual and automatic */
  holdPick:(d,el)=>{ const R = run; if(!R || R.over) return; if(!R.command){ cmdGate("pick"); return; }
    setAutoPick(!S.autoPick); el.classList.toggle("auto", autoPickOn(R)); toast(S.autoPick ? "Skills: automatic. Hold again to choose them yourself." : "Skills: you choose. They wait on this button.", "#f2d796"); },
  holdAbil:(d,el)=>{ const R = run; if(!R || R.over) return; const a = R.abil[+d.k]; if(!a) return; if(!R.command){ cmdGate("cast"); return; }
    S.autoAb[a.tag] = !S.autoAb[a.tag]; persist(); SFX.pick(); haptic("LIGHT"); el.classList.toggle("auto", !!S.autoAb[a.tag]);
    toast(`${ABILITIES[a.tag].name}: ${S.autoAb[a.tag] ? "automatic" : "by hand"}`, TAGS[a.tag].color); },
  /* the same two switches as plain rows in Settings, for players who cannot hold a button */
  setAutoPick:()=>{ setAutoPick(!S.autoPick); openSettings(); },
  setAutoCast:()=>{ const on = !SYN_TAGS.every(t=>S.autoAb[t]); for(const t of SYN_TAGS) S.autoAb[t] = on; persist(); SFX.click(); haptic("LIGHT"); if(run) buildAbilBar(); openSettings(); },
  cast:(d)=>{ const R = run; if(!R || R.over || R.paused) return; const k = +d.k, a = R.abil[k]; if(!a) return;
    if(a.cd > 0){ toast(`${ABILITIES[a.tag].name} is ready in ${Math.ceil(a.cd)}s`, TAGS[a.tag].color); return; }
    if(!castAbility(k)) toast("No enemy in reach. Save it for the fight.", TAGS[a.tag].color); },
  cmdInfo:()=>{ SFX.click(); openCommandSheet("info"); },
  cmdAd: async ()=>{ if(cmdAdsLeft()<=0) return; const ok = await Monetization.rewarded("command"); if(!ok) return; const C = cmdDay(); C.bonus += CMD_PER_AD; C.ads++; persist(); SFX.level(); if(run){ run.command = true; updateCmdHud(); buildAbilBar(); } closeTopModal(); if(run && !run.cardModal && !run.eventModal) run.paused = false; toast(`Vanguard Command: +${CMD_PER_AD} battles today`, "#c9a2ff"); if(!run){ renderAll(); cmdResume(); } },
  cmdClose:()=>{ SFX.click(); closeTopModal(); if(run && !run.cardModal && !run.eventModal && !run.over) run.paused = false; cmdResume(); },
  skipIntro:()=>{ if(run && run.intro) run.intro.t = run.intro.dur; },
  synInfo:(d)=>{ const T = TAGS[d.t], n = tagCount(d.t), ab = run && run.abil.find(a=>a.tag===d.t); toast(`${T.name} ${Math.min(n,3)}/3 · (2) ${synLine(d.t,2)}${n>=2?" ✓":""} · (3) ${synLine(d.t,3)}${n>=3?" ✓":""}${ab?` · Ability: ${ABILITIES[d.t].name}`:""}`, T.color); },
  focusInfo:()=>{ toast(`Focused Oath: your build uses two tags or fewer, so you deal +${FOCUS_DMG}% damage. A third tag ends it.`, "#f2c14e"); },
  cardInfo:(d)=>{ const c = CARD_BY[d.id], r = run.cards[d.id]; toast(c.evo || c.legend ? `${c.name}: ${c.desc}` : `${c.name} rank ${r}: ${c.text(c.v(r, cardMult(d.id)))}`, c.evo||c.legend ? "#f2c14e" : TAGS[c.tag].color); },
  /* the "next step" on the defeat screen: done in one tap, then the screen shows the next one */
  stepDo:(d)=>{ const R = run; if(!R || !R.over) return; bankDefeat(R);
    if(d.kind==="equip"){ const it = itemById(+d.uid); if(it){ S.equip[it.slot] = it.uid; heroChanged(true); SFX.pick(); } }
    else if(d.kind==="train"){ const m = META.find(x=>x.id===d.id), c = m && metaCost(m); if(m && S.gold>=c && S.meta[m.id]<m.max){ S.gold -= c; S.meta[m.id]++; SFX.coin(); } }
    else if(d.kind==="forge"){ const it = itemById(+d.uid), c = it && forgeCost(it); if(it && S.gold>=c && it.upg<FORGE_MAX){ S.gold -= c; it.upg++; S.stats.forges++; SFX.forge(); } }
    else if(d.kind==="card"){ const lv = cardLv(d.id), c = orbCost(lv); if(lv<CARD_MAX && S.orbs>=c){ S.orbs -= c; S.cardLv[d.id] = lv+1; S.stats.cardUps++; SFX.level(); } }
    persist(); haptic("LIGHT"); showResult(false); },
  doubleLoot: async (d,el)=>{ const R = run; if(!R || R.doubled || R.doubling) return; R.doubling = true; const ok = await Monetization.rewarded("double_loot"); R.doubling = false; if(!ok || run!==R || R.doubled) return;
    R.doubled = true; S.gold += R.rewards.gold; S.orbs += R.rewards.orbs; persist(); SFX.coin(); toast(`Doubled: +${fmt(R.rewards.gold)} gold, +${R.rewards.orbs} orbs`, "#d0ab62"); el.disabled = true; el.textContent = "Doubled"; },
  claim:()=>{ SFX.click(); finishRun(); },
  nextLevel:(d)=>{ SFX.click(); const R = run; if(R && (R.firstBossWin || R.storyAct!=null)){ finishRun(); return; } const cfg = {mode:"campaign", a:+d.a, i:+d.i, tier:+d.t||1};
    if(S.cleared["0-4"]){ finishRun(); pfHeat = null; pfHorde = false; openPrefight(cfg); return; }                // past Act I every battle starts from its prefight screen (Heat, oath, enemies)
    cfg.heat = 0; finishRun({then:()=>startRun(cfg)}); },
  retry:(d)=>{ SFX.click(); const R = run; if(!R) return; const cfg = Object.assign({}, R.cfg); if(d && d.heat!==undefined){ cfg.heat = +d.heat; S.heat.sel = cfg.heat; } finishRun({then:()=>startRun(cfg)}); },
  upgradeNow:()=>{ SFX.click(); finishRun(); const meta = META.some(m=>S.meta[m.id]<m.max && S.gold>=metaCost(m)), gear = SLOTS.some(bestUpgrade);
    if(gear || meta){ heroView = gear ? "inv" : "train"; invFilter = "all"; setTab("hero"); } else setTab("codex"); },
  equipLoot:(d,el)=>{ const it = itemById(+d.uid); if(!it) return; S.equip[it.slot] = it.uid; persist(); SFX.pick(); haptic("LIGHT"); heroChanged(true); if(run) run.hv.skin = heroSkin(); el.disabled = true; el.innerHTML = `${ico("check",14)} Equipped`; },
  revive: async (d)=>{ const R = run; if(!R || R.revived || R.reviving || R.banked) return; R.reviving = true;
    const free = !!(d && d.free && R.freeRevive);              // the first defeat ever: "The Vanguard never falls twice"
    const ok = free ? true : await Monetization.rewarded("revive"); R.reviving = false; if(!ok || run!==R || R.revived) return;
    R.freeRevive = false;
    R.revived = true; R.over = false; R.result = null; R.pendingDefeatRewards = false; R.hero.hp = R.st.maxHp*(free ? 1 : .5); R.immune = 2; R.hv.dead = 0; R.hv.flash = 0;
    if(R.mode==="campaign" || R.mode==="challenge"){ const key = `${R.cfg.tier||1}:${R.cfg.a}-${R.cfg.i}`; if(S.fails[key]>0) S.fails[key]--; }
    run.enemies.forEach(e=>{ if(!e.dead && e.x - R.hero.x < 50) e.x += 30; });
    closeModal(R.resultModal); document.body.classList.remove("run-done"); World.beam(World.HX, "#ffe07a", 44, .9); SFX.holy(); R.paused = false; Music.duck(false); },
  retreat:()=>{ SFX.click(); finishRun(); },
  evChoose:(d)=>{ SFX.click(); chooseEvent(d.v); }
};
function setAutoPick(on){ S.autoPick = !!on; persist(); SFX.pick(); haptic("LIGHT"); const R = run; if(R){ updatePickBtn(); if(autoPickOn(R) && R.pendingLv>0 && !R.over && !R.paused) autoPickAll(); } }
function openPause(){
  const R = run; R.paused = true;
  const cards = Object.keys(R.cards).map(id=>{ const c = CARD_BY[id], sp = c.evo || c.legend; return `<div class="list-row" style="border-left:3px solid ${sp?"#f2c14e":TAGS[c.tag].color}"><div class="li">${art(c.icon,34)}</div><div class="grow"><div class="lt">${c.name} <span class="lvpips">${sp?(c.evo?"Evolution":"Legendary"):"◆".repeat(R.cards[id])}</span></div><div class="ld">${sp?c.desc:c.text(c.v(R.cards[id],cardMult(id)))}</div></div></div>`; }).join("") || '<div class="mute" style="text-align:center">No skills yet.</div>';
  const syns = SYN_TAGS.filter(t=>tagCount(t)>=2).map(t=>`<div style="color:${TAGS[t].color};font-size:13px;margin:2px 0">${tagIco(t,14)} ${TAGS[t].name} ${tagCount(t)>=3?"III":"II"}: ${synLine(t,2)}${tagCount(t)>=3?" · "+synLine(t,3):""}</div>`).join("");
  const B = Object.keys(R.buffs||{}).filter(k=>R.buffs[k]).map(k=>{ const b = BLESSINGS.find(x=>x.id===k); return b ? `${b.name.replace("Blessing of ","")} (${b.text})` : k==="whet" ? "Whetstone (+10% damage)" : ""; }).filter(Boolean);
  const st = R.st, give = R.mode==="arena" ? "Forfeit" : R.mode==="raid" || R.mode==="weekly" ? "End attempt" : "Give up";
  const sn = synState(R);
  const html = `<div class="modal-title">Paused</div><div class="modal-sub">${R.sub ? R.sub+" · " : ""}${R.title}${R.mode==="weekly" ? ` · rung ${(R.rungN||0)+1}` : R.mode!=="arena"&&R.mode!=="raid"?` · Threat ${R.d}`:""}${R.heat?` · Heat ${R.heat}`:""}<br>Level ${R.lvl} · ${Math.round(st.dmg)} damage · ${fmt(st.maxHp)} health · ${st.armor} armor · ${r1(st.crit)}% crit</div>
    ${syns||sn.focus?`<div class="set-box" style="margin-bottom:10px">${syns}${sn.focus?`<div style="color:#f2d796;font-size:13px;margin:2px 0">Focused Oath: +${FOCUS_DMG}% damage (two tags or fewer)</div>`:""}</div>`:""}
    ${R.abil.length?`<div class="set-box" style="margin-bottom:10px">${R.abil.map(a=>`<div style="color:${TAGS[a.tag].color};font-size:13px;margin:2px 0"><b>${ABILITIES[a.tag].name}</b>: ${ABILITIES[a.tag].text} (${Math.round(a.max)}s)</div>`).join("")}</div>`:""}${B.length?`<div class="set-box" style="margin-bottom:10px">Blessings: ${B.join(", ")}</div>`:""}${cards}
    <div class="mbtns row"><button class="btn gold" data-act="resume">${ico("play",18)} Resume</button><button class="btn ghost" data-act="toggleSoundRun">${ico(S.sound?"sound":"mute",18)} ${S.sound?'Sound':'Muted'}</button>${R.mode==="campaign"||R.mode==="challenge"?`<button class="btn ghost" data-act="retryAsk">${ico("dice",16)} Restart</button>`:""}<button class="btn red" data-act="abandon">${give}</button></div>`;
  openModal(html, {noClose:true});
}
ACTIONS.retryAsk = ()=>{ const R = run; if(!R) return; SFX.click(); const cfg = Object.assign({}, R.cfg); closeAllModals(); R.cardModal = null; R.eventModal = null; run = null; S.pendingRun = null; persist(); startRun(cfg); };
ACTIONS.toggleSoundRun = (d,el)=>{ S.sound = !S.sound; persist(); if(S.sound) ac(); Music.volume(); el.innerHTML = `${ico(S.sound?"sound":"mute",18)} ${S.sound?'Sound':'Muted'}`; };

/* HOLD TO MAKE IT AUTOMATIC (Review 5). A button with data-hold="action" runs that action after HOLD_MS under the finger;
   a shorter press is an ordinary tap (the click still fires), so a quick cast is never swallowed and a hold never casts.
   The ring inside the button (.hring) fills while it is held. */
const HOLD_MS = 600; let holdNow = null;
function holdStop(){ if(!holdNow) return; clearTimeout(holdNow.t); holdNow.el.classList.remove("holding"); holdNow = null; }
document.addEventListener("pointerdown", e=>{ const b = e.target.closest && e.target.closest("[data-hold]"); holdStop(); if(!b || b.disabled) return; delete b.dataset.held;
  const h = holdNow = {el:b, x:e.clientX, y:e.clientY, t:setTimeout(()=>{ if(holdNow!==h) return; holdNow = null; b.classList.remove("holding"); if(!b.isConnected) return;
    b.dataset.held = "1"; const fn = ACTIONS[b.dataset.hold]; if(fn){ try{ fn(b.dataset, b); }catch(err){ console.error(err); } } }, HOLD_MS)};
  b.classList.add("holding"); });
document.addEventListener("pointermove", e=>{ if(holdNow && Math.hypot(e.clientX - holdNow.x, e.clientY - holdNow.y) > 18) holdStop(); });
for(const ev of ["pointerup", "pointercancel"]) document.addEventListener(ev, holdStop);
document.addEventListener("contextmenu", e=>{ if(e.target.closest && e.target.closest("[data-hold]")) e.preventDefault(); });
const SPEND_ACTS = new Set(["gemBuy","buySink","buyDaily","buySale","buySkinDo","upCard","claimRelic"]); let lastSpend = 0;
document.addEventListener("click", e=>{
  const b = e.target.closest("[data-act]"); if(!b || b.disabled) return;
  if(b.dataset.held){ delete b.dataset.held; return; }      // the press was a hold: it already did its job
  if(SPEND_ACTS.has(b.dataset.act)){ const now = performance.now(); if(now - lastSpend < 450) return; lastSpend = now; }      // a second tap on a re-rendered buy button is not a second purchase
  const fn = ACTIONS[b.dataset.act]; if(fn){ try{ fn(b.dataset, b); }catch(err){ console.error(err); } }
});
document.addEventListener("pointerdown", ()=>{ if(S.sound){ ac(); Music.resume(); } });
document.addEventListener("input", e=>{ const k = e.target.dataset && e.target.dataset.inp; if(k==="musicVol"){ S.music = clamp(+e.target.value/100, 0, 1); Music.volume(S.music); } else if(k==="sfxVol"){ setSfxVolume(+e.target.value/100); } });
document.addEventListener("change", e=>{ if(e.target.dataset && e.target.dataset.inp==="sfxVol" && S.sound){ ac(); SFX.coin(); } });
document.addEventListener("change", e=>{ if(e.target.dataset && e.target.dataset.inp) persist(); });
$("#synBanner").addEventListener("animationend", e=>e.currentTarget.classList.remove("show"));
document.addEventListener("visibilitychange", ()=>{ if(document.hidden){ checkpointRun(); if(run && !run.over && run.mode==="endless" && (run.cleared||0) > S.endlessBest) S.endlessBest = run.cleared;      /* iOS may kill a hidden app: the record is kept */ scheduleNotifs(); if(Cloud.on) setTimeout(()=>Cloud.push(), 60); if(run && !run.over && !run.paused) openPause(); persist(); if(AC && AC.state==="running") AC.suspend().catch(()=>{}); } else { if(S.pendingRun){ S.pendingRun = null; persist(); } }      /* the app came back: the battle is still here */
  if(!document.hidden && !run && !$("#modalRoot").children.length){ renderAll(); } });
window.addEventListener("resize", ()=>{ clearTimeout(window.__rz); window.__rz = setTimeout(()=>{ World.resize(); hudCache = {}; heroAnchor = null; if(!run) renderTab(currentTab); }, 120); });

/* =====================================================================
   VANGUARD KEEP — bounties and daily trials
===================================================================== */
let keepTab = "bounty";
const rwMini = b => rchips(b, 20);
const AFFIX_TIP = {vampiric:"Shield cards cut its healing", shielded:"Bleed and Burn get past its shield", enraged:"Keep an ability for its last half", thorned:"Lightning and burns are not reflected", frenzied:"Shield and Holy outlast it", colossal:"Bleed and Burn wear it down"};
function bountyTip(b){ const [w] = enemyMods(b.type), el = w.filter(k=>k!=="phys")[0]; return `${AFFIX_TIP[b.aff[b.aff.length-1]]}${el ? `. Weak to ${ELEM_NAME[el]}` : ""}.`; }
const AFFIX_ICON = {vampiric:"bloodprice", shielded:"bulwark", enraged:"frenzy", thorned:"thorns", frenzied:"tempest", colossal:"vigor"};
function powColor(pw, sp){ return pw>=sp ? "var(--green)" : pw>=sp*.8 ? "var(--gold-l)" : "var(--red)"; }
function openKeep(){
  if(!isOpen("keep")){ toast(UNLOCK.keep.how); return; }
  dailyReset();
  const pw = powerOf(heroStats(null));
  let body = "";
  if(keepTab==="weekly"){}
  else if(keepTab==="bounty"){
    body = `<div class="kgrid">${S.bounty.list.map((b,i)=>{ const sp = suggestedPower(b.d) + b.stars*15;
      return `<div class="kcard ${b.done?'done':''}"><div class="kimg" style="background-image:url(${IMG("foe_"+b.type)})"><span class="wanted">Wanted</span><span class="kstars">${"★".repeat(b.stars)}<i>${"★".repeat(3-b.stars)}</i></span>
          <span class="kprize">${b.reward.gems ? `${art("gems",18)}<b>${b.reward.gems}</b>` : b.reward.star ? `${art("starmetal",18)}<b>${b.reward.star}</b>` : `${art("gold",18)}<b>${fmt(b.reward.gold)}</b>`}</span>
          <div class="kname">${b.name}</div>${b.done?`<div class="kstamp">Claimed</div>`:""}</div>
        <div class="kbody"><div class="kaff">${b.aff.map(a=>`<button class="affix" data-act="affixInfo" data-a="${a}">${art(AFFIX_ICON[a],18)}${AFFIXES[a].name}</button>`).join("")}</div>
        <div class="kpow"><span>Threat <b>${b.d}</b></span><span>Power <b style="color:${powColor(pw,sp)}">${pw}</b>/${sp}</span></div>
        <div class="ktip">${art("skills",16)}<span>${bountyTip(b)}</span></div>
        ${rchips(b.reward, 20)}${b.mythic?`<div class="kx">${art("mythic",16)} 25% chance of a Mythic item</div>`:""}
        <button class="btn sm ${b.done?'':'gold'} wide" data-act="hunt" data-i="${i}" ${b.done?'disabled':''}>${b.done?`${ico("check",14)} Claimed`:`${art("bounty",18)} Hunt`}</button></div></div>`; }).join("")}</div>`;
  } else {
    body = `<div class="kgrid">${S.trials.list.map((t,i)=>{ const sp = suggestedPower(t.d) + t.n*10;
      return `<div class="kcard ${t.done?'done':''}"><div class="kimg" style="background-image:url(${IMG("vista_"+ACTS[t.a].theme)})"><span class="wanted trial" aria-label="${["Hard","Harder","Brutal"][t.n-1]}">${art("skull",15).repeat(t.n)}</span>
          <div class="krules">${t.rules.map(r=>`<span>${art(TRIAL_RULES[r].icon,34)}</span>`).join("")}</div>
          <div class="kname">${ACTS[t.a].levels[t.i]}<small>${t.tier>1?`Tier ${tierName(t.tier)} · `:""}Act ${ACTS[t.a].short}</small></div>${t.done?`<div class="kstamp">Complete</div>`:""}</div>
        <div class="kbody"><div class="rules">${t.rules.map(r=>`<div><b>${TRIAL_RULES[r].name}</b><span>${r==="oneTag"?`Only ${TAGS[t.mods.oneTag].name} and Core skills`:TRIAL_RULES[r].text}</span></div>`).join("")}</div>
        <div class="kpow"><span>Threat <b>${t.d}</b></span><span>Power <b style="color:${powColor(pw,sp)}">${pw}</b>/${sp}</span></div>
        ${rchips(t.reward, 20)}
        <button class="btn sm ${t.done?'':'gold'} wide" data-act="trialGo" data-i="${i}" ${t.done?'disabled':''}>${t.done?`${ico("check",14)} Complete`:`${art("trial",18)} Start`}</button></div></div>`; }).join("")}</div>`;
  }
  if(keepTab==="weekly" && !weeklyOpen()) keepTab = "bounty";
  if(keepTab==="weekly") body = weeklyBody();
  const html = `<div class="mode-head banner ${keepTab==="weekly"?"slim":""}" style="background-image:url(img/banner_keep.jpg)">${art("keep",keepTab==="weekly"?40:60)}<div><div class="modal-title">Vanguard Keep</div><div class="modal-sub">Daily tests of your build · new in ${msToMidnight()} · no revives</div></div></div>
    <div class="seg"><button class="${keepTab==='bounty'?'on':''}" data-act="keepTab" data-v="bounty">${art("bounty",20)} Bounties <small>${S.bounty.list.filter(b=>!b.done).length}</small></button><button class="${keepTab==='trial'?'on':''}" data-act="keepTab" data-v="trial">${art("trial",20)} Daily trials <small>${S.trials.list.filter(t=>!t.done).length}</small></button>${weeklyOpen() ? `<button class="${keepTab==='weekly'?'on':''}" data-act="keepTab" data-v="weekly">${art("trophy",20)} Weekly trial <small>${weeklyLeft()}</small></button>` : ""}</div><div class="modal-body">${body}</div>${keepTab==="weekly" ? `<div class="mbtns row">${GameCenter.player ? `<button class="btn ghost" data-act="gcBoard" data-lb="weekly">${art("trophy",18)} Game Center ranks</button>` : ""}<button class="btn gold big" data-act="weeklyGo" ${weeklyLeft()>0?'':'disabled'}>${art("trial",22)} ${weeklyLeft()>0 ? "Climb the ladder" : "Back tomorrow"}</button></div>` : ""}`;
  closeAllModals(); openModal(html, {wide:true});
}

/* the Vanguard's Trial: this week's ladder, its rule, the player's best, the goals and the board */
function weeklyBody(){
  const U = weeklyState(), sp = weeklySpec(), act = ACTS[sp.a], left = weeklyLeft(), RL = TRIAL_RULES[sp.rule], gc = !!GameCenter.player;
  const board = boardAround(weeklyGhosts().concat([{name:knightName(), v:U.best, you:true}]), 4);
  return `<div class="wk-wrap"><div class="wk-main" style="background-image:url(${IMG("vista_"+act.theme)})"><div class="wk-in">
      <small>This week · ends in ${msToMonday()}</small><b>${act.name.replace(/^Act [IV]+: /, "")}</b>
      <span class="wk-rule">${art(RL.icon,26)}<span><b>${RL.name}</b>${sp.rule==="oneTag" ? `Only ${TAGS[sp.mods.oneTag].name} and Core skills` : RL.text}</span></span>
      <span class="wk-how">The same ladder for every knight: each pack is a rung. Enemies grow, and after ${Math.round(WEEKLY.tireAt/60)} minutes the knight tires.</span></div></div>
    <div class="wk-side">
      <div class="wk-best">${art("trophy",34)}<div class="grow"><b>${U.best ? `Rung ${U.best}` : "No climb yet"}</b><small>your best this week</small></div><span class="left-b" aria-label="${left} attempts left today">${art("trial",16)}<b>${left}/${WEEKLY.tries}</b></span></div>
      <div class="wk-goals">${WEEKLY.goals.map(([at,b])=>`<div class="${U.got.includes(at)?'got':''}"><span>Rung ${at}</span>${U.got.includes(at) ? `<span class="done-badge sm">${ico("check",14)}</span>` : rchips(b, 18, 'sm')}</div>`).join("")}</div>
      <div class="stat-lines board"><div class="bh">Knights of the realm (computer-controlled)</div>${board.map(r=>`<div class="${r.you?'you':''}"><span>${r.rank}. ${r.name}</span><span>Rung ${r.v}</span></div>`).join("")}</div>
    </div></div>`;
}
/* =====================================================================
   DAILY REWARD CALENDAR + TREASURY
===================================================================== */
function openLogin(got){
  const ready = loginReady(), today = S.login.day, cells = LOGIN.map((L,i)=>{ const b = loginReward(i), claimed = ready ? i<today : i<today || (today===0 && S.login.last===todayKey());
    const isToday = ready && i===today, main = b.gems?"gems":b.star?"starmetal":b.frags?"frag":b.dust?"dust":b.orbs?"orbs":"gold";
    const amt = b[main==="starmetal"?"star":main==="frag"?"frags":main];
    return `<div class="day ${claimed?'claimed':''} ${isToday?'today':''} ${i===6?'grand':''}"><small>Day ${i+1}</small><div class="di">${i===6?art("treasury",58):art(main,42)}</div>${i===6?rchips(b,16,'tiny'):`<b>×${fmt(amt)}</b>`}${claimed?`<span class="ck">${ico("check",14)}</span>`:""}</div>`; }).join("");
  const broken = streakBroken(), fix = streakFixable(), run7 = S.login.streak>0 ? 7 - S.login.streak%7 : 7;
  const html = `<div class="mode-head banner" style="background-image:url(${IMG("vista_verdant")})">${art("login",54)}<div><div class="modal-title">Daily reward</div><div class="modal-sub">Come back every day. Day 7 is the grand chest, and every 7th day in a row pays +${STREAK_BONUS_GEMS} gems.${S.login.streak>1 && !broken?` <b>${S.login.streak}-day streak</b>${ready?"":` · ${run7===7?7:run7} to the bonus`}.`:""}</div></div></div>
    ${broken ? `<div class="streak-fix"><span class="grow"><b>Your ${S.login.streak}-day streak is broken</b><small>${fix ? "You can restore it once a week and keep counting." : "You already restored a streak this week, so it starts again from day 1."}</small></span>${fix ? `<button class="btn sm purple" data-act="streakFix" data-how="gems" ${S.gems<STREAK_FIX_GEMS?'disabled':''}>${art("gems",16,"cur")} ${STREAK_FIX_GEMS}</button>${adsLeft()>0 ? `<button class="btn sm teal" data-act="streakFix" data-how="ad">${adFree()?"":ico("video",16)} Restore</button>` : ""}` : ""}</div>` : ""}
    ${S.login.graced && !ready ? `<div class="streak-fix ok"><span class="grow"><b>${S.login.streak}-day streak kept</b><small>You missed a day. One missed day a week is forgiven.</small></span></div>` : ""}
    <div class="days">${cells}</div>${got?`<div class="reward-row">${got}</div>`:""}
    <div class="mbtns row">${ready?`<button class="btn gold big glow" data-act="claimLogin">Claim day ${today+1}</button>`:`<button class="btn" data-close>Come back tomorrow</button>`}</div>`;
  closeAllModals(); openModal(html, {wide:true});
}
function openTreasury(got){
  const T = treasuryState();
  const html = `<div class="mode-head banner" style="background-image:url(img/vista_verdant.jpg)">${art("treasury",60)}<div><div class="modal-title">Treasury</div><div class="modal-sub">Your keep earns gold, Arcane Dust and rune fragments while you're away, up to ${TREASURY_CAP_H} hours. The further you've fought, the more it earns.</div></div></div>
    <div class="raid-hp"><div class="bb gold"><i style="width:${T.hrs/TREASURY_CAP_H*100}%"></i></div><span>${Math.floor(T.hrs)}h ${Math.floor(T.hrs%1*60)}m${T.full?" · full":""}</span></div>
    <div class="reward-row">${got || (rewardTile(CUR.gold, fmt(T.gold), "Gold") + rewardTile(art("dust",32), T.dust, "Arcane Dust") + rewardTile(art("frag",32), T.frags, T.frags===1?"Fragment":"Fragments"))}</div>
    <div class="mbtns row"><button class="btn gold" data-act="claimTreasury" ${T.hrs<1/12||got?'disabled':''}>${got?'Collected':'Collect'}</button></div>`;
  closeAllModals(); openModal(html);
}
Object.assign(ACTIONS, {
  keepTab:(d)=>{ SFX.click(); keepTab = d.v; openKeep(); },
  affixInfo:(d)=>{ const A = AFFIXES[d.a]; toast(`${A.name}: this champion ${A.text}.`, "#ff9a7a"); },
  hunt:(d)=>{ SFX.click(); startBounty(+d.i); },
  trialGo:(d)=>{ SFX.click(); startTrial(+d.i); },
  weeklyGo:()=>{ SFX.click(); startWeekly(); },
  login:()=>{ SFX.click(); openLogin(); },
  claimLogin:()=>{ const got = claimLogin(); if(!got) return; SFX.win(); haptic("MEDIUM"); openLogin(got); renderCurrencies(); if(currentTab==="map") renderMap(); },
  treasury:()=>{ SFX.click(); openTreasury(); },
  claimTreasury:()=>{ const got = claimTreasury(); if(!got) return; SFX.coin(); openTreasury(got); renderCurrencies(); if(currentTab==="map") renderMap(); if(!S.notif) setTimeout(askNotifs, 900); }
});

/* =====================================================================
   OATH PASS (Quests tab)
===================================================================== */
function questSeg(){ const pc = passClaimable(), dq = S.quests.list.filter(q=>!q.claimed && questDone(q)).length + (!S.quests.bonus && S.quests.list.length && S.quests.list.every(q=>q.claimed) ? 1 : 0),
    jq = JOURNEY.filter(j=>{ const x = journeyState(j); return x.done && !x.claimed; }).length;
  const tab = (v, icon, label, n)=>`<button class="${questView===v?'on':''}" data-act="questView" data-v="${v}">${art(icon,22)} ${label}${n?` <i class="cnt">${n}</i>`:''}</button>`;
  return `<div class="qseg seg">${tab("quests","quests","Daily",dq)}${tab("journey","trophy","Journey",jq)}${tab("pass","pass","Oath Pass",pc)}</div>`; }
function passCell(lv, prem){
  const b = passReward(lv, prem), L = passLevel(), got = (prem ? S.pass.cp : S.pass.cf).includes(lv), can = lv<=L && !got && (!prem || S.pass.prem);
  if(b.cape){ const C = CAPES[b.cape]; return `<button class="pcell ${prem?'prem':''} ${got?'got':''} ${can?'can':''} ${prem&&!S.pass.prem?'lock':''} big" data-act="claimPass" data-l="${lv}" data-p="${prem?1:0}" ${can?'':'disabled'}><span class="cape-sw big" style="background:linear-gradient(${C.c},${C.d})"></span><b>Cape</b>${got?`<span class="ck">${ico("check",12)}</span>`:prem&&!S.pass.prem?`<span class="ck">${ico("lock",11)}</span>`:""}</button>`; }
  const key = b.sigil?"sigil":b.gems?"gems":b.star?"starmetal":b.frags?"frag":b.dust?"dust":b.orbs?"orbs":"gold";
  const amt = b.sigil||b.gems||b.star||b.frags||b.dust||b.orbs||b.gold;
  const icon = key==="gems"?CUR.gems:key==="orbs"?CUR.orbs:key==="gold"?CUR.gold:art(key,24);
  return `<button class="pcell ${prem?'prem':''} ${got?'got':''} ${can?'can':''} ${prem&&!S.pass.prem?'lock':''} ${b.sigil?'big':''}" data-act="claimPass" data-l="${lv}" data-p="${prem?1:0}" ${can?'':'disabled'}>
    ${art(key,32)}<b>${fmt(amt)}</b>${got?`<span class="ck">${ico("check",12)}</span>`:prem&&!S.pass.prem?`<span class="ck">${ico("lock",11)}</span>`:""}</button>`;
}
function renderPass(){
  passSeason();
  const L = passLevel(), xpIn = S.pass.xp - L*PASS_XP, maxed = L>=PASS_LEVELS;
  const SN = seasonNow(), SC = CAPES[SN.cape];
  let h = `${questSeg()}<div class="pass-wrap" style="--sc:${SN.col}"><div class="pass-head" style="background-image:url(${IMG(SN.img)})">${art("pass",54)}<div class="grow"><div class="lt">Season ${S.pass.season+1}: ${SN.name}</div><div class="sline">${SN.line}</div>
      <div class="ld">Level <b>${L}</b>/${PASS_LEVELS} · ${maxed?'max level':`${xpIn}/${PASS_XP} XP`} · ${passDaysLeft()} days left <button class="linkbtn inline" data-act="passInfo">${ico("info",14)} How it works</button></div>
      <div class="bar thin"><i style="width:${maxed?100:xpIn/PASS_XP*100}%"></i></div></div>
      ${S.pass.prem ? `<div class="prem-on">${art("sigil",22)} Premium active</div>` : (Monetization.storeReady() ? `<button class="btn gold price" data-act="iap" data-k="pass">Unlock premium · ${Monetization.price("pass")}</button>` : "")}</div>
    <div class="pass-hl"><div class="hl">${art("sigil",26)}<b>Lv 30</b><small>Ancient Sigil</small></div><div class="hl"><span class="cape-sw" style="background:linear-gradient(${SC.c},${SC.d})"></span><b>Lv 20</b><small>${SC.name} cape</small></div>
      ${!maxed && GEM_SINKS.passxp.can()?`<button class="btn sm purple" data-act="buySink" data-k="passxp" ${S.gems<GEM_SINKS.passxp.price||sinkLeft("passxp")<=0?'disabled':''}>+1 level · ${art("gems",16,"cur")} ${GEM_SINKS.passxp.price}</button>`:""}</div>
    <div class="ptrack-wrap ${S.pass.prem?'prem-on':''}"><div class="plabels"><span>Free</span><span></span><span>Premium</span></div><div class="ptrack">${Array.from({length:PASS_LEVELS},(_,k)=>{ const lv = k+1;
      return `<div class="pcol ${lv<=L?'reached':''}">${passCell(lv,false)}<span class="plv">${lv}</span>${passCell(lv,true)}</div>`; }).join("")}</div></div>
    </div>`;
  $("#tab-quests").innerHTML = h;
  const tr = $("#tab-quests .ptrack"); if(tr){ const first = tr.querySelector(".pcell.can") || tr.children[Math.max(0,L-2)]; if(first) tr.parentNode.scrollLeft = Math.max(0, (first.closest(".pcol")||first).offsetLeft - 60); }
}

/* =====================================================================
   ANCIENT ARMORY (Shop)
===================================================================== */
function armoryHTML(){
  const store = Monetization.storeReady();
  return `<div class="shop-h"><b>Ancient Armory</b><small>relics of the First King · only from Ancient Sigils</small></div>
    <div class="armory-top" style="background-image:url(${IMG("banner_sigil")})"><div class="at-in">${art("sigil",54)}<div class="grow"><b>${S.sigils} Ancient Sigil${S.sigils===1?"":"s"}</b><small>One Sigil buys one Ancient relic. You choose exactly which.</small><span class="shards">${art("sigil",16,"cur")} Shards ${S.shards||0}/${SHARDS_PER_SIGIL} <em>from raids, 3★ bounties and Endless records</em></span></div>${store?`<button class="btn gold oprice" data-act="iap" data-k="sigil">${art("sigil",20)} ${Monetization.price("sigil")}</button>`:""}</div></div>
    <div class="armory">${SLOTS.map(sl=>{ const A = ANCIENTS[sl], prev = {slot:sl, r:5, name:A.name, set:null};
      return `<div class="relic"><div class="ri"><img src="${itemIcon(prev)}" alt=""></div><div class="rt rc5">${A.name}</div><div class="rsub">Ancient ${SLOT_DEF[sl].name} · 3 sockets</div><div class="sd">${A.text}</div>
        ${ownsAncient(sl) ? `<button class="btn sm wide" disabled>${ico("check",14)} Owned</button>` : `<button class="btn sm teal wide" data-act="claimRelic" data-s="${sl}" ${S.sigils>0?'':'disabled'}>${art("sigil",16)} Claim</button>`}</div>`; }).join("")}</div>`;
}
Object.assign(ACTIONS, {
  questView:(d)=>{ SFX.click(); questView = d.v; renderQuests(); },
  passInfo:()=>{ SFX.click(); openModal(`<div class="modal-title">Oath Pass</div><div class="confirm-text" style="text-align:left;font-size:14px">
    <p>Earn pass XP from everything you do: battles won (+${PASS_XP_FOR.win}), daily quests (+${PASS_XP_FOR.quest}), bounties and trials (+${PASS_XP_FOR.bounty}), arena duels (+${PASS_XP_FOR.duel}), raid attempts (+${PASS_XP_FOR.raid}) and every 5 Endless waves (+${PASS_XP_FOR.waves5}). Every ${PASS_XP} XP is a level.</p>
    <p>The free lane is for everyone. The premium lane adds an Ancient Sigil at level 30, the season's cape at level 20, Gems, Starmetal, fragments and Arcane Dust.</p>
    <p>A season lasts ${PASS_DAYS} days, then a new one starts from level 0 with its own theme and cape. This one is ${seasonNow().name}.</p></div>`); },
  claimPass:(d)=>{ const got = claimPass(+d.l, d.p==="1"); if(!got) return; SFX.coin(); haptic("LIGHT"); toast("Oath Pass reward claimed", "#c9a2ff"); renderQuests(); renderCurrencies(); },
  claimRelic:(d)=>{ if(ownsAncient(d.s)) return; const it = claimAncient(d.s); if(!it) return; SFX.syn(); haptic("HEAVY"); toast(`${it.name} claimed. It's in your inventory.`, RARITY[5].color); renderShop(); renderCurrencies(); openItem(it.uid); }
});

ACTIONS.offerLater = ()=>{ SFX.click(); closeTopModal(); const f = offerAfter; offerAfter = null; if(f) f(); };
/* Game Center + iCloud (see modes.js) */
Object.assign(ACTIONS, {
  gcDash:()=>{ SFX.click(); GameCenter.show("dashboard"); },
  gcBoard:(d)=>{ SFX.click(); GameCenter.show("leaderboards", d.lb); },
  cloudUse:()=>{ const c = Cloud.pendingSave; closeTopModal(); if(c) Cloud.restore(c); },
  cloudKeep:()=>{ closeTopModal(); Cloud.pendingSave = null; persist(); Cloud.queue(true); toast("Kept this device's progress. It's now saved to iCloud.", "#6ab8ff"); }
});
/* map treasures (see modes.js) */
Object.assign(ACTIONS, {
  mapLoot:(d,el)=>{ const got = claimMapLoot(d.id); if(!got) return; if(got.expired){ toast("That treasure has faded."); renderMap(); return; }
    el.classList.add("taken"); el.disabled = true; haptic("MEDIUM");
    if(got.boost){ const B = BOOSTS[got.boost]; SFX.syn(); toast(`${B.name}: ${B.short} for ${Math.round(boostLeft(got.boost)/60e3)} min`, B.col); }
    else { SFX.coin(); setTimeout(()=>SFX.coin(), 120); const k = Object.keys(got.bundle)[0]; toast(`${TREASURES[k==="frags"?"frags":k] ? TREASURES[k].name : "Treasure"}: +${fmt(got.bundle[k])} ${({gold:"gold",orbs:"orbs",gems:"gems",frags:"rune fragments"})[k]}`, "#f2d796"); }
    const lay = el.parentNode; if(lay){ const f = document.createElement("div"); f.className = "lootfx"; f.style.cssText = el.getAttribute("style"); f.innerHTML = got.boost ? art(BOOSTS[got.boost].icon,26) + `<b>${BOOSTS[got.boost].short}</b>` : `<b>+${fmt(Object.values(got.bundle)[0])}</b>`; lay.appendChild(f); setTimeout(()=>f.remove(), 1300); }
    setTimeout(()=>{ el.remove(); }, 450); renderCurrencies(); },
  boostInfo:(d)=>{ const B = BOOSTS[d.k]; toast(`${B.name}: ${B.text}. ${Math.ceil(boostLeft(d.k)/60e3)} min left.`, B.col); }
});
/* notification opt-in (see modes.js) */
Object.assign(ACTIONS, {
  notifYes: async ()=>{ closeTopModal(); const N = notifPlugin(); if(!N) return; try{ const r = await N.requestPermissions(); S.notif = r && r.display==="granted" ? "yes" : "no"; }catch(e){ S.notif = "no"; } persist(); scheduleNotifs(); },
  notifNo:()=>{ closeTopModal(); S.notif = "no"; persist(); }
});

/* Contact us (Review 11): a bug report, a message or an idea, sent as an email the player's Mail app opens ready to send.
   Game info (versions, device, progress, recent errors) is attached when the box is ticked. No server is involved. */
const CONTACT_KINDS = { bug:{label:"Bug report", tag:"Bug", hint:"What happened, and what were you doing just before?"},
  msg:{label:"Message", tag:"Message", hint:"Write to us"}, idea:{label:"Idea", tag:"Idea", hint:"What would make the game better?"} };
let contactKind = "bug";
function contactInfo(){
  const done = Object.keys(S.cleared || {}).length;
  return [`Version ${versionLabel()}`, `Device: ${navigator.userAgent}`, `Screen: ${screen.width}x${screen.height} @${devicePixelRatio}`,
    `Levels cleared: ${done} · Power ${Math.round(powerOf(heroStats(null)))} · Heat best ${S.heat ? S.heat.max : 0}`,
    `Quality: ${S.quality} · Battles ${S.stats.runs} · Wins ${S.stats.wins}`,
    ...(window.__ovErrors || []).slice(-5).map(e=>"Error: " + e)].join("\n");
}
function openContact(){
  closeAllModals();      // never two titled modals on top of each other (it opens from Settings)
  contactKind = "bug";
  const K = CONTACT_KINDS;
  openModal(`<div class="modal-title">Contact us</div><div class="modal-body">
    <div class="seg ct-kind">${Object.entries(K).map(([k,v])=>`<button data-act="contactKind" data-k="${k}" class="${k===contactKind?"on":""}">${v.label}</button>`).join("")}</div>
    <textarea id="ctText" class="ct-text" maxlength="2000" placeholder="${K[contactKind].hint}"></textarea>
    <label class="ct-info"><input type="checkbox" id="ctInfo" checked> Attach game info (version, device, progress)</label></div>
    <div class="mbtns row"><button class="btn ghost" data-act="contactCancel">Cancel</button><button class="btn gold" data-act="contactSend">Send</button></div>`);
  const t = $("#ctText"); if(t){ t.value = S.contactDraft || ""; t.addEventListener("input", ()=>{ S.contactDraft = t.value; }); }
}
