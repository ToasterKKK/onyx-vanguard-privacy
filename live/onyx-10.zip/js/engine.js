/* Onyx Vanguard — engine.js
   Battle engine: game loop, combat, skills, card picks, HUD, victory/defeat.
   Game logic works in world units (1 unit = PX logical pixels); scene.js paints it.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   RUN ENGINE
===================================================================== */
const PX = 4;                        // logical pixels per world unit
const HERO_FRONT = 13, RUN_SPEED = 64, AGGRO = 95, MAX_PACK = 5;
const PACK_GAP = 150, EVENT_GAP = 110;  // world units between the end of one stop and the next: only one pack is ever in view
/* walk-cycle radians per pixel travelled, so planted feet match the ground; running takes longer strides */
const strideK = run => 1/(15.8 + 7.4*run);
let run = null;
let camPx = 0;                       // camera offset in logical px (hero stands at World.HX)
const sxOf = xu => xu*PX - camPx;    // world units -> screen px

/* Enemy strength by threat. ENEMY_HP / ENEMY_DMG lift every level to match what synergy payoffs and abilities give the player. */
const ENEMY_HP = 1.35, ENEMY_DMG = 1.10;
function enemyScaling(d){ return { hp:(1 + .42*(d-1) + .032*(d-1)*(d-1))*ENEMY_HP, dmg:1.45*(1 + .25*(d-1))*ENEMY_DMG }; }
/* Pack variety from the shared rig: each member of a pack gets its own tint, size and (for rig mobs) helm, weapon or shield,
   so no two enemies standing together look the same. k = position in the pack. */
const VARY_TINT = [["#000000",.16],["#ffffff",.12],["#6a4a2a",.2],["#2a3a5a",.2],["#4a2a3a",.18]];
function varyLook(look, k){
  const tint = VARY_TINT[(k + Math.floor(Math.random()*VARY_TINT.length)) % VARY_TINT.length], mixk = c => World.mix(c, tint[0], tint[1]*rand(.6,1));
  if(look.kind==="creature"){ const m = Object.assign({}, look.m); for(const f of ["d","l","leafL","leafD","moss"]) if(m[f]) m[f] = mixk(m[f]); return Object.assign({}, look, {m}); }
  const sk = Object.assign({}, look.skin);
  for(const f of ["armD","armL","robe","cape","capeD","tabard","rags"]) if(sk[f]) sk[f] = mixk(sk[f]);
  const melee = !look.style || look.style==="swing", v = (k + Math.floor(Math.random()*3)) % 3;
  if(melee && sk.weapon && v>0){ const types = ["sword","axe","mace"].filter(t=>t!==sk.weapon.type); if(["sword","axe","mace"].includes(sk.weapon.type)) sk.weapon = Object.assign({}, sk.weapon, {type:types[v-1], len:null}); }
  if(sk.body==="armor" && (sk.helm==="horned" || sk.helm==="greathelm")){ if(k%2===1){ sk.helm = sk.helm==="horned" ? "greathelm" : "horned"; if(!sk.hornCol) sk.hornCol = "#d8ccb0"; if(sk.helm==="greathelm" && sk.cape) sk.plume = sk.cape; } }
  if(sk.body==="bone") sk.brokenHelm = k%2 ? 1 : 0;
  if(sk.shield && k%3===2) delete sk.shield;
  return Object.assign({}, look, {skin:sk});
}
function visScale(T, elite){ if(T.scale>=2.5) return 1.5; let s = T.boss ? Math.min(1.55, 1 + ((T.scale||1)-1)*.6) : 1; if(elite) s *= 1.12; return s; }
function mkEnemy(type, x, d, opt={}){
  const T = opt.T || ENEMY[type], sc = enemyScaling(d), elite = !!opt.elite;
  let hp = opt.hp || T.hp*sc.hp, dmg = opt.dmg || T.dmg*sc.dmg;
  if(elite){ hp*=3; dmg*=1.45; }
  if(T.boss && !opt.hp){ const bd = Math.min(d, 25); hp*=1.05 + .016*bd; dmg*=1.05 + .006*bd; }   // act bosses are the wall at the end of each act
  const plain = !T.boss && !elite && !opt.look;
  let look = opt.look || (elite && LOOKS[type].elite) || LOOKS[type]; const vs = visScale(T, elite);
  if(plain) look = varyLook(look, opt.k||0);
  else if(elite && !opt.look && look.kind==="rig"){ look = Object.assign({}, look, {skin:Object.assign({spikes:1, acc:look.skin.acc||"fur"}, look.skin)}); }   // elites wear an extra armour piece
  const e = { type, T, x, hp, maxHp:hp, dmg, atk:T.atk, atkT:T.atk*rand(.4,1), spd:T.spd*rand(.9,1.1), ranged:!!T.ranged, hw:look.w*vs,
    xp:T.xp*(elite?4:1)*(1+.03*(d-1)), gold:T.gold*(elite?4:1)*(1+.12*(d-1)), boss:!!T.boss, elite, aggro:false,
    flash:0, kb:0, walk:Math.random()*6, walkAmt:0, moving:false, animP:null, postT:null, phase:Math.random()*6,
    bleedDps:0, bleedT:0, burnDps:0, burnT:0, dotAcc:0, dotTick:0, stun:0, mod:T.mod||null,
    dead:false, deathT:0, name:(elite?"Elite ":"")+T.name, look, vis:null, v:null, projH:look.projH||62 };
  e.vis = World.makeVis(look, Math.floor(Math.random()*1000));
  const sc2 = plain ? vs*[1, .93, 1.07, .96, 1.04][(opt.k||0)%5]*rand(.985, 1.015) : vs;
  e.v = { x:0, vis:e.vis, scale:sc2, name:e.name, elite, boss:e.boss, phase:e.phase };
  return e;
}
function makePack(pool, size, allowBig){
  const list = []; let bigs = 0;
  for(let k=0;k<size;k++){ let t = pick(pool); if(ENEMY[t].big){ if(bigs>=1 || !allowBig) t = pool[0]; else bigs++; } list.push({type:t}); }
  return list;
}
function pickEvent(prev){
  const keys = Object.keys(EVENTS).filter(k=>k!==prev && EVENTS[k].w>0); let tot = keys.reduce((a,k)=>a+EVENTS[k].w,0), x = Math.random()*tot;
  for(const k of keys){ x -= EVENTS[k].w; if(x<=0) return k; } return keys[0];
}
/* A level is a line of stops: enemy packs (1–5 enemies that wait for you) and, every couple of packs, an event. */
const k0 = w => w%2;
const HEAVY_FROM = 3, HEAVY_EVERY = 6.5, HEAVY_WARN = 1.3, HEAVY_MULT = 2.2;
/* BOSS RUSH (weekend event): every act boss the player has beaten, back to back, each a little stronger than the last.
   A spring stands between them. The score is the number of bosses brought down. */
const RUSH_LEN = 12;
function rushLadder(){
  const acts = ACTS.map((_,a)=>a).filter(a=>S.cleared[`${a}-4`]); if(!acts.length) acts.push(0);
  const base = Math.max(threatOf(1, acts[0], 4), maxClearedD() - 3);
  return Array.from({length:RUSH_LEN}, (_,k)=>({a:acts[k % acts.length], d:base + k*2}));
}
function buildRushStops(L){
  const stops = [];
  L.forEach((b,k)=>{ const act = ACTS[b.a];
    stops.push({kind:"pack", list:[{type:act.pool[0]},{type:act.boss, boss:true}], boss:true, d:b.d, extra:{theme:act.theme, wave:k+1}});
    if(k < L.length-1) stops.push({kind:"event", type:"heal"}); });
  return stops;
}
/* a bounty: two packs, then the champion with an escort */
function buildBountyStops(b){
  const act = ACTS[b.act], stops = [];
  for(let w=0; w<2; w++) stops.push({kind:"pack", list:makePack(act.pool, 3 + w, true)});
  stops.push({kind:"pack", list:[{type:act.pool[0]},{type:b.type, champ:true}], boss:true});
  return stops;
}
function buildCampaignStops(a, i, mods){
  const act = ACTS[a], stops = []; let nP = i===4 ? 6 : 6 + i; if(mods && mods.horde) nP += 3;
  // Review 3: levels in Acts III-V are one pack shorter (they ran over two minutes for a new player); the gold of the missing pack is spread over the rest
  if(a>=2 && nP>5){ stops.goldK = nP/(nP-1); nP--; }
  let prevEv = null, evN = 0; const forks = !(a===0 && i<2);
  for(let w=0; w<nP; w++){
    let size = Math.min(MAX_PACK, 2 + Math.floor(((i===4?2:i) + w)/3) + (mods && (mods.horde || mods.hordeWk) ? 2 : 0));
    const list = makePack(act.pool, size, !(i<1 && w<2) && !(a===0 && i<2));
    if(i===2 && w===nP-1){ list.length = Math.min(list.length, MAX_PACK-1); list.push({type:act.pool[0], elite:true}); }
    if(i===3 && w===nP-1){ list.length = Math.min(list.length, MAX_PACK-1); list.push({type:act.pool[1], elite:true}); }
    // Review 5: one pack in the middle of a stage can really kill. Its elite winds up a heavy blow (a closing ring warns of it;
    // an ability cast inside the ring interrupts it). Not on the first three stages of the game and not on boss stages.
    if(w===Math.floor(nP/2) && i<4 && a*5+i >= HEAVY_FROM && !list.some(e=>e.elite)){ list.length = Math.min(list.length, MAX_PACK-1); list.push({type:act.pool[0], elite:true, heavy:true}); }
    if(mods && mods.elite && !list.some(e=>e.elite)){ list.length = Math.min(list.length, MAX_PACK-1); list.push({type:act.pool[k0(w)], elite:true}); }
    stops.push({kind:"pack", list});
    const last = w===nP-1;
    if(!last && !(mods && mods.noEvents) && (w===1 || (w>1 && (w-1)%2===0))){
      // the road forks twice a level (after the tutorial levels): hunt an elite or pray, trade or dig
      if(forks && evN<2) stops.push({kind:"event", type:"fork", fork:evN===0 ? "hunt" : "trade", prop:"fork"});
      else { const ev = pickEvent(prevEv); prevEv = ev; stops.push({kind:"event", type:ev}); }
      evN++; }
  }
  if(i===4){ if(!(mods && mods.noEvents)) stops.push({kind:"event", type:Math.random()<.5?"heal":"shrine"}); stops.push({kind:"pack", list:[{type:act.pool[0]},{type:act.pool[2]},{type:act.boss, boss:true}], boss:true}); }
  return stops;
}
/* =====================================================================
   THE VANGUARD'S TRIAL (Review 5): one ladder a week, the same for every player. The realm, the rule and every pack come from the
   week's seed, so two knights who compare scores climbed the same ladder. The score is the number of rungs (packs) cleared.
   Enemies grow by WEEKLY.grow a rung from rung WEEKLY.growFrom, and after WEEKLY.tireAt seconds the knight tires (enemies hit
   harder every second), so a run always ends and cannot be stalled. WEEKLY.tries attempts a day; the week's best counts.
===================================================================== */
const WEEKLY = {len:60, d0:5, dStep:.5, growFrom:12, grow:1.10, tireAt:300, tire:.015, tries:3, gold:.5,
  rules:["dry","glass","haste","elite","oneTag","fragile","horde"], goals:[[10,{gems:25}],[20,{gems:40,star:2}],[30,{gems:60,star:3}]]};
function weeklySpec(wk){
  wk = wk || weekKey(); const r = seeded(hashStr("weekly" + wk)), a = Math.floor(r()*ACTS.length), rule = WEEKLY.rules[Math.floor(r()*WEEKLY.rules.length)], mods = {};
  mods[rule] = rule==="oneTag" ? SYN_TAGS[Math.floor(r()*SYN_TAGS.length)] : true;
  return {wk, a, rule, mods, seed:hashStr("weeklyS" + wk)};
}
function buildWeeklyStops(spec){
  const r = seeded(spec.seed), act = ACTS[spec.a], out = [], pk = arr => arr[Math.floor(r()*arr.length)];
  for(let n=1; n<=WEEKLY.len; n++){ const boss = n%10===0; let list;
    if(boss) list = [{type:act.pool[0]}, {type:act.boss, boss:true}];
    else { const size = Math.min(MAX_PACK, 2 + Math.floor(n/4) + (spec.mods.horde ? 2 : 0)); list = []; let bigs = 0;
      for(let k=0;k<size;k++){ let t = pk(act.pool); if(ENEMY[t].big){ if(bigs>=1 || n<3) t = act.pool[0]; else bigs++; } list.push({type:t}); }
      if(n%5===0 || spec.mods.elite){ list.length = Math.min(list.length, MAX_PACK-1); list.push({type:act.pool[n%2], elite:true}); } }
    out.push({kind:"pack", list, boss, rung:n});
    if(n%5===0 && n<WEEKLY.len) out.push({kind:"event", type:"heal"}); }
  return out;
}
const weeklyMul = n => Math.pow(WEEKLY.grow, Math.max(0, n - WEEKLY.growFrom));
/* rungs are placed a few at a time, as the knight climbs (sixty packs at once would be three hundred painted enemies) */
function spawnWeekly(){
  const R = run, W = R.wk;
  while(W.i < W.list.length && R.nextX < R.hero.x + 420){ const st = W.list[W.i++];
    if(st.kind==="pack"){ const n = st.rung, d = WEEKLY.d0 + (n-1)*WEEKLY.dStep; R.nextX = placeStop(R, st, R.nextX, d, {rung:n}); const k = weeklyMul(n);
      for(const en of st.enemies){ if(k!==1){ en.hp *= k; en.maxHp *= k; en.dmg *= k; } en.gold *= WEEKLY.gold; } }
    else R.nextX = placeStop(R, st, R.nextX, 1); }
  if(W.i >= W.list.length && R.levelEnd > 1e8) R.levelEnd = R.stops[R.stops.length-1].end + 70;
}
/* a run whose score is how far it got: the boss rush and the weekly trial (no revives; the result screen is modeEnd) */
const ladderMode = R => R.mode==="rush" || R.mode==="weekly";
function placeStop(R, st, x, d, extra){
  st.x = x;
  if(st.kind==="pack"){ st.list.sort((a,b)=>(!!(ENEMY[a.type]&&ENEMY[a.type].ranged) - !!(ENEMY[b.type]&&ENEMY[b.type].ranged)) || (!!a.boss - !!b.boss) || (!!a.champ - !!b.champ));
    let px = x; st.enemies = st.list.map((e,k)=>{ const rng = ENEMY[e.type] && ENEMY[e.type].ranged, gap = k ? (rng ? 34 : 27) : 0; px += gap + (e.boss||e.champ ? 10 : 0);
      const en = e.champ ? mkChampion(R.cfg.b, px, d) : mkEnemy(e.type, px, d, Object.assign({k}, e)); Object.assign(en, extra||{}); en.stop = st; if(e.heavy){ en.heavy = true; en.mt = HEAVY_EVERY*.45; }
      if(R.mods && R.mods.haste) en.atk /= 1.35; R.enemies.push(en); return en; });
    st.end = px; R.stops.push(st); return st.end + PACK_GAP; }
  st.done = false; st.open = 0; st.end = x; R.stops.push(st); return x + EVENT_GAP;
}
const zoneOf = w => ENDLESS_ZONES[Math.floor((w-1)/10) % ENDLESS_ZONES.length];
function themeFor(cfg){ return cfg.mode==="endless" ? ENDLESS_ZONES[0].theme : ACTS[cfg.a].theme; }
const XP_BASE4 = 96;      // XP for the first four level-ups on the base curve (12 + 20 + 28 + 36)
const PICK_CAP = 5;       // level-ups per battle; XP past that turns into gold
const FIRST_XP = 1;       // a battle starts with no skill: the first kill is the first level-up, and with it the first pick (START_PICKS lists the modes that open with skills in hand)
const START_PICKS = {arena:3, raid:3, weekly:3, rush:3};
function startRun(cfg){
  document.body.classList.remove("run-done");
  const mods = cfg.mods || {}; skinPreview = null;
  let theme, d, stops = [], title, sub;
  if(cfg.mode==="endless"){ theme = ENDLESS_ZONES[0].theme; d = 1; title = "Endless Descent"; sub = ENDLESS_ZONES[0].name; }
  else if(cfg.mode==="arena"){ theme = ["verdant","gothic","frost"][cfg.opp.seed%3]; d = Math.max(1, maxClearedD()); title = cfg.opp.name; sub = `Arena · ${leagueOf(S.arena.trophies).name} league`; }
  else if(cfg.mode==="raid"){ theme = raidBoss().theme; d = Math.max(1, maxClearedD()); title = raidBoss().name; sub = `Raid · Tier ${S.raid.tier+1}`; }
  else if(cfg.mode==="rush"){ const L = rushLadder(); theme = ACTS[L[0].a].theme; d = L[0].d; stops = buildRushStops(L); title = "Boss rush"; sub = "Weekend event"; }
  else if(cfg.mode==="weekly"){ theme = ACTS[cfg.spec.a].theme; d = WEEKLY.d0; title = "The Vanguard's Trial"; sub = "Weekly trial"; }
  else if(cfg.mode==="bounty"){ const b = cfg.b; theme = ACTS[b.act].theme; d = b.d; stops = buildBountyStops(b); title = b.name; sub = `Bounty · ${"★".repeat(b.stars)}`; }
  else { const t = cfg.tier || 1; theme = ACTS[cfg.a].theme; d = cfg.d || threatOf(t, cfg.a, cfg.i); stops = buildCampaignStops(cfg.a, cfg.i, mods); title = cfg.title || ACTS[cfg.a].levels[cfg.i];
    sub = cfg.mode==="challenge" ? "Challenge" : cfg.mode==="trial" ? "Daily trial" : `${t>1?`Oath Tier ${tierName(t)} · `:""}Act ${ACTS[cfg.a].short} · Level ${cfg.i+1}`; }
  const heat = cfg.mode==="campaign" ? clamp(cfg.heat|0, 0, HEAT.max) : 0;
  const command = cmdLeft() > 0;                    // Vanguard Command (x2, x3, auto-pick, auto-cast) is decided at the start and never switched off mid-battle
  let prevSpeed = clamp((run && run.speed) || S.lastSpeed || 1, 1, 3); if(!command) prevSpeed = 1;
  run = { cfg, mode:cfg.mode, mods, theme, d, title, sub, heat, command, time:0, speed:prevSpeed, paused:true, over:false,
    cards:{}, coreTo:{}, tagSeq:[], lvl:1, xp:0, xpNeed:12, xpK:1, picks:0, pendingLv:0, first:true, rerolls:1, offer:[], kills:0, gold:0, hitCount:0,
    enemies:[], proj:[], graves:[], holyUsed:false, revived:false, abil:[], immune:0, dance:0, barrier:0, bleedHeal:0,
    t:{light:0, fireball:0, chain:0, stormset:0, firestorm:0}, pendingTwin:-1, oathN:0, wave:0, waveX:[], levelEnd:0, stops:[], buffs:{}, event:null, whirlN:0,
    hero:{x:0, v:0, hp:1, atkT:.3, state:"run", inCombat:false, potionCd:0, animP:null, postT:null},
    hv:{x:0, skin:heroSkin(), walk:0, walkAmt:0, runAmt:0, atk:null, flash:0, kb:0, equip:0, dead:0, victory:false, shieldUp:0} };
  if(mods.oneTag) run.oneTag = mods.oneTag;
  if(cfg.mode==="campaign") run.resolve = resolveFor(cfg.tier||1, cfg.a, cfg.i);   // Vanguard's Resolve: each loss on a level makes the next try a little easier
  run.st = heroStats(run);
  run.hero.hp = mods.lastBreath ? 1 : run.st.maxHp;
  run.potions = mods.dry ? 0 : run.st.potions;
  run.dmgTakenMult = mods.glass ? 2 : 1; run.dmgDealtMult = mods.glass ? 2 : 1;
  applyOath(run);
  const firstEver = tutorialRun(run) && cfg.i===0 && !S.cleared["0-0"];
  if(cfg.mode==="endless"){
    run.nextX = 120; run.prevEv = null; for(let k=0;k<3;k++) spawnEndlessWave();
    run.graves = [];
  } else if(cfg.mode==="weekly"){
    run.wk = {spec:cfg.spec, list:buildWeeklyStops(cfg.spec), i:0}; run.nextX = 120; run.levelEnd = 1e9; run.rungN = 0; spawnWeekly();
    run.xpK = 1; run.xpNeed = 26; run.pickCap = 0; run.lvl = 3; run.pendingLv = START_PICKS.weekly;       // like the boss rush: three skills to start, then one every few rungs
  } else if(cfg.mode==="arena" || cfg.mode==="raid"){
    const e = cfg.mode==="arena" ? mkRival(cfg.opp, 120) : mkRaidBoss(130);
    const st = {kind:"pack", list:[{}], boss:true, x:e.x, end:e.x, enemies:[e]}; e.stop = st; run.enemies.push(e); run.stops.push(st);
    run.waveX = [e.x]; run.levelEnd = e.x; run.lvl = 3; run.pendingLv = START_PICKS[cfg.mode]; run.timeLeft = RAID_TIME; run.raidDmg = 0;
  } else {
    let x = firstEver ? INTRO_WALK : 120; for(const st of stops) x = placeStop(run, st, x, st.d || d, st.extra);
    if(stops.goldK) for(const e of run.enemies) if(!e.boss) e.gold = Math.round(e.gold*stops.goldK);
    const t = cfg.tier || 1, tm = t>1 ? {hp:Math.pow(2.3, t-1), dmg:Math.pow(1.65, t-1)} : null, tr = cfg.mode==="trial" ? 1 + .08*(cfg.tr ? cfg.tr.n : 1) : 1;
    const hm = (tm?tm.hp:1)*tr*heatMul(heat), dm = (tm?tm.dmg:1)*(1 + (tr-1)*.6)*heatMul(heat);
    if(hm!==1 || dm!==1) for(const e of run.enemies){ e.hp *= hm; e.maxHp *= hm; e.dmg *= dm; }
    run.mult = {hp:hm, dmg:dm};
    if(t===1 && cfg.mode==="campaign" && cfg.a===0 && (cfg.i===2 || cfg.i===3)){ for(const e of run.enemies) e.dmg *= .88; run.mult.dmg *= .88; }   // the first real fights forgive a knight who has not trained yet
    if(cfg.a===LAST_ACT && cfg.i<4 && (cfg.mode==="campaign" || cfg.mode==="trial")){ for(const e of run.enemies){ e.hp *= ACT5_HP; e.maxHp *= ACT5_HP; } run.mult.hp *= ACT5_HP; }      // Review 5: V-1 to V-4 were easier than Act IV
    if(t>1) tierRules(run, t);
    if(mods.timed) run.timeLeft = 28 + stops.filter(s=>s.kind==="pack").length*7;
    run.waveX = run.stops.filter(s=>s.kind==="pack").map(s=>s.end);
    run.levelEnd = run.stops[run.stops.length-1].end + 70;
    // pacing: the same four level-ups in every level, however long it is (the fifth is the cap; XP past it becomes gold)
    const totXp = run.enemies.reduce((a,e)=>a + (e.boss ? 0 : e.xp), 0);
    run.xpK = Math.max(.7, totXp*.72/XP_BASE4); run.xpNeed = Math.round((cfg.a===0 && cfg.i<4 && t===1 ? 7 : 12)*run.xpK); run.pickCap = PICK_CAP;
    if(cfg.mode==="rush"){ run.xpK = 1; run.xpNeed = 26; run.pickCap = 0; run.lvl = 3; run.pendingLv = START_PICKS.rush; run.rushN = 0; }      // a rush starts with three skills; every boss is worth about one more
  }
  /* every ordinary battle (campaign, bounty, trial, challenge, Endless) opens with no skill: the knight fights, the first kill levels him up and the first pick follows.
     The level after that costs what the first level used to, so a battle still gives the same number of picks. A mode or a map can still hand out skills at the start (START_PICKS, mods.startPick). */
  if(mods.startPick && !run.pendingLv){ run.pendingLv = mods.startPick; }
  if(!run.pendingLv){ run.lvlOff = 1; run.xpFirst = run.xpNeed; run.xpNeed = FIRST_XP; }
  run.boost = activeBoosts(); LUCK = !!run.boost.luck;
  if(run.speed>1) useCommand(run);
  S.stats.runs++; persist();
  showScreen("run"); setWorldTheme(theme);
  buildHudStatic(); hudCache = {}; updateHud(true);
  setSpeedBtn(); $("#synBanner").classList.remove("show"); updatePickBtn(); laneReset();
  if(firstEver){ // the knight marches in while the story is told; his first kill brings the first pick
    run.paused = false; run.introWalk = true;
    caption("The King rode out on the Kingsroad and never returned.", 3400); const Rc = run; setTimeout(()=>{ if(run===Rc && !Rc.over) caption("You are the last knight of his Onyx Vanguard. Find him.", 3400); }, 3600); }
  const R0 = run; setTimeout(()=>{ if(run===R0 && !R0.over){ R0.introWalk = false; if(R0.pendingLv>0) openCardPick(); else if(!$("#modalRoot").children.length) R0.paused = false; } }, firstEver ? 7400 : 500);
}
const ACT5_HP = 1.10;
const INTRO_WALK = 400;   // where the first pack stands on the very first battle (the knight walks there during the captions)
/* Vanguard's Resolve: +6% damage and health per loss on a level, up to +30% */
function resolveFor(t, a, i){ return Math.min(30, ((S.fails||{})[`${t}:${a}-${i}`]||0)*6); }
/* Oath Tier II and above: one new rule per run so the second lap is a different game.
   Every elite carries an affix, and every act boss enrages below 30% health. */
function tierRules(R, t){
  const keys = Object.keys(AFFIXES);
  for(const e of R.enemies){ if(e.elite && !e.aff){ e.aff = [keys[Math.floor(Math.random()*keys.length)]]; applyAffix(e); e.name = e.v.name = `${AFFIXES[e.aff[0]].name} ${e.T.name}`; }
    if(e.boss) e.rage = 1; }
}
function applyAffix(e){ const a = e.aff || []; if(a.includes("colossal")){ e.hp *= 1.6; e.maxHp *= 1.6; } if(a.includes("frenzied")) e.atk /= 1.3; if(a.includes("shielded")) e.blockPct = 25; }
/* Review 5: the Descent has a bottom. Past wave ENDLESS.from every wave multiplies enemy health and damage by ENDLESS.grow, so the
   enemies outgrow the knight and a run ends (measured: between waves 50 and 90). Gold flattens the deeper it goes, and the
   Season Pass takes at most ENDLESS.passDay points a day from here, so a long run is a score, not a gold farm. */
const ENDLESS = {from:20, grow:1.06, gold:[[50,1],[100,.5],[Infinity,.25]], passDay:100};
const endlessMul = w => Math.pow(ENDLESS.grow, Math.max(0, w - ENDLESS.from));
const endlessGoldK = w => ENDLESS.gold.find(g=>w <= g[0])[1];
/* the gold a run's cleared waves pay at the end: 10 a wave, on the same flattening curve */
function endlessWaveGold(n){ let g = 0; for(let w=1; w<=n; w++) g += 10*endlessGoldK(w); return Math.round(g); }
function endlessScale(e, w){ const k = endlessMul(w); if(k!==1){ e.hp *= k; e.maxHp *= k; e.dmg *= k; } e.gold *= endlessGoldK(w); }
function spawnEndlessWave(){
  const R = run; R.wave++; const w = R.wave; if(R.bossMusic){ R.bossMusic = false; Music.play(MUSIC_FOR[R.theme] || "battle_gothic"); } const d = 1 + (w-1)*.5;
  const zone = zoneOf(w);
  let list;
  if(w%10===0) list = [{type:zone.pool[1]},{type:zone.boss,boss:true}];
  else { list = makePack(zone.pool, Math.min(MAX_PACK, 2 + Math.floor(w/4)), w%10>=3); if(w%5===0){ list.length = Math.min(list.length, MAX_PACK-1); list.push({type:zone.pool[1], elite:true}); } }
  const st = {kind:"pack", list, boss:w%10===0, wave:w};
  R.nextX = placeStop(R, st, R.nextX, d, {wave:w, theme:zone.theme});
  for(const e of st.enemies) endlessScale(e, w);
  R.waveX.push(st.end);
  // graves of rivals who fell at this wave
  for(const rv of rivals()) if(rv.wave===w) R.graves.push({name:rv.name, x:st.end + 40 + R.graves.length%3*14, wave:w});
  if(S.endlessBest===w) R.graves.push({name:"You", x:st.end + 60, wave:w, you:true});
  if(w%3===0 && w%10!==9){ const ev = pickEvent(R.prevEv); R.prevEv = ev; R.nextX = placeStop(R, {kind:"event", type:ev}, R.nextX, d); }
}
function rivals(){
  const base = Math.max(8, S.endlessBest);
  return RIVAL_NAMES.map(n=>{ const h = hashStr(n); return {name:n, wave:Math.max(3, Math.round(base*(.5 + (h%100)/100*.85)))}; }).sort((a,b)=>b.wave-a.wave);
}

/* ---------- WORLD THEME (one live theme at a time; a short fade hides the rebuild) ---------- */
function setWorldTheme(key){
  Music.play(run ? (run.bossMusic ? "boss" : MUSIC_FOR[key] || "battle_verdant") : "menu");
  if(World.theme===key) return;
  const f = $("#fade"); f.classList.add("on");
  World.setTheme(key);
  requestAnimationFrame(()=>requestAnimationFrame(()=>f.classList.remove("on")));
}

/* ---------- LOOP ---------- */
let lastT = 0, loopErrors = 0;
const home = { camX:0, walk:0, t:0, hv:null, equip:0 };
function frame(t){
  requestAnimationFrame(frame);
  const dt = Math.min(.05, ((t-lastT)/1000) || 0); lastT = t;
  if(document.hidden) return;
  perfSample(dt);
  try{
    if(run){
      let gdt = 0;
      if(!run.paused && !run.over){
        if(run.intro){ tickIntro(dt); }
        else if(run.hitstop > 0){ run.hitstop -= dt; }
        else { const k = run.slow > 0 ? .3 : 1; if(run.slow > 0) run.slow -= dt; for(let i=0;i<run.speed && !run.over && !run.intro;i++) update(dt*k); gdt = dt*run.speed*k; }
        if(run && run.wantPick && !run.over){ const why = run.wantPick; run.wantPick = null; if(run.pendingLv>0 && !run.intro){ if(autoPickOn(run)) autoPickAll(); else if(!$("#modalRoot").children.length) openCardPick(why); } } }
      else if(run.over){ updateOver(dt); gdt = dt; }
      renderRun(dt, gdt, t/1000); updateHud(false);
    } else if($("#homeScreen").classList.contains("active")) renderHome(dt, t/1000);
  }catch(e){ if(loopErrors++ < 5) console.error("frame error", e); }
}

/* the fallen never pile up: every enemy drops, fades and leaves the battle within CORPSE_T */
const CORPSE_T = .9;      // seconds a fallen enemy stays in the battle: it drops, fades and is gone (scene.js CORPSE_FADE), so nothing lies in the way of the fight
function keepEnemy(e){ return !e.dead || e.deathT < CORPSE_T; }
function aliveSorted(){ const a = run.enemies.filter(e=>!e.dead); a.sort((p,q)=>p.x-q.x); return a; }
function heroAtkDur(){ return Math.min(.62, run.st.atkInterval*.9*(run.dance>0 ? .5 : 1)); }
const inView = e => { const x = sxOf(e.x); return x > -20 && x < World.W + 20; };
function update(dt){
  const R = run, h = R.hero, st = R.st;
  R.time += dt;
  if(R.mode==="endless" && h.x > R.nextX - 300) spawnEndlessWave();
  if(R.mode==="weekly"){ spawnWeekly();
    if(R.time > WEEKLY.tireAt){ R.tire = 1 + (R.time - WEEKLY.tireAt)*WEEKLY.tire; if(!R.tireSaid){ R.tireSaid = true; caption("The knight tires. Enemies hit harder every second.", 3200, "#ffb0a0"); } } }
  if(R.mode==="endless" || R.mode==="rush"){
    const near = R.enemies.find(e=>!e.dead && e.x - h.x < 60);
    if(near && near.theme && near.theme!==R.theme){ R.theme = near.theme; setWorldTheme(R.theme); if(R.mode==="endless") toast(`${zoneOf(near.wave).name}`, "#d0ab62"); }
  }
  const alive = aliveSorted();
  const front = alive.find(e=>e.x > h.x-4);
  const gap = front ? (front.x - front.hw) - (h.x + HERO_FRONT) : 1e9;
  const ev = R.stops.find(st=>st.kind==="event" && !st.done && st.x > h.x - 2);
  const evGap = ev ? ev.x - 17 - h.x : 1e9;
  // a merchant is only worth a stop if the knight can afford something: decided while the stop is still off-screen
  if(ev && !ev.chk && (evGap > 150 || evGap <= 0)){ ev.chk = true; if(ev.type==="merchant" && R.gold < merchantPrices(R).potion){ ev.type = Math.random()<.5 ? "chest" : "heal"; hudCache = {}; buildHudStatic(); } }
  const wasCombat = h.inCombat;
  h.inCombat = gap <= 5;
  // the knight runs from stop to stop and slows down just before arriving
  let target = Math.min(gap - 5, evGap);
  if(R.event) target = 0;
  if(!h.inCombat && evGap <= 0 && !R.event && gap > evGap) startEvent(ev);
  if(!h.inCombat && !R.event && target > 0){
    const want = RUN_SPEED * clamp(target/26, .3, 1) * (R.introWalk ? .6 : 1);
    h.v = lerp(h.v, want, 1 - Math.exp(-dt*7)); h.x += Math.min(h.v*dt, target); h.state = "run"; h.atkT = Math.min(h.atkT, .3);
  } else { h.v = lerp(h.v, 0, 1 - Math.exp(-dt*14)); h.state = h.inCombat ? "fight" : "idle"; }
  // smart pick timing: queued picks open when a pack is down and the road is calm, and always before a boss
  if(R.pendingLv > 0 && !R.wantPick && !R.event){
    const nextBoss = front && front.stop && front.stop.boss && !front.aggro && gap < AGGRO + 30 && !R.bossPrep;
    if(nextBoss){ R.bossPrep = true; R.wantPick = "boss"; }
    else if(wasCombat && !h.inCombat && gap > 30 && alive.length) R.wantPick = "calm";          // never after the last enemy: a pick with nothing left to fight is wasted
  }
  if(R.event) tickEvent(dt);
  camPx = h.x*PX - World.HX;
  h.atkT -= dt;
  const dur = heroAtkDur();
  if(h.postT!=null){ h.postT += dt; if(h.postT >= dur*.5) h.postT = null; }
  if(h.frozen > 0){ h.frozen -= dt; h.atkT = Math.max(h.atkT, .15); R.hv.flash = Math.max(R.hv.flash, .35); }
  if(h.inCombat && h.atkT<=0){ heroAttack(front); h.atkT = st.atkInterval*(R.dance>0 ? .5 : 1); }
  h.animP = (h.inCombat && h.atkT <= dur*.5) ? clamp(.5 - h.atkT/dur, 0, .5) : (h.postT!=null ? .5 + h.postT/dur : null);
  if(R.pendingTwin>=0){ R.pendingTwin -= dt; if(R.pendingTwin<0 && front && !front.dead && h.inCombat){ strike(front, true); } }
  h.potionCd = Math.max(0, h.potionCd - dt);
  const hv = R.hv; hv.flash = Math.max(0, hv.flash - dt*6); hv.kb *= Math.exp(-dt*9); hv.shieldUp = Math.max(R.immune>0 ? .8 : 0, hv.shieldUp - dt*3);
  const moving = h.state==="run" && h.v > 2, runA = clamp((h.v - 12)/(RUN_SPEED - 12), 0, 1);
  hv.walkAmt = lerp(hv.walkAmt, moving ? 1 : 0, 1 - Math.exp(-dt*10)); hv.runAmt = lerp(hv.runAmt, moving ? runA : 0, 1 - Math.exp(-dt*8));
  if(moving) hv.walk += h.v*dt*PX*strideK(hv.runAmt);
  tickSkills(dt, alive, front, gap);
  tickAbilities(dt, alive, front);
  for(let k=0;k<alive.length;k++){
    const e = alive[k]; if(e.dead) continue;
    // enemies hold their ground and wait for the knight to come to them
    if(!e.aggro && e.x - h.x < AGGRO){ e.aggro = true; if(e.boss) bossArrives(e); }
    if(e.stun > 0){ e.stun -= dt; e.flash = Math.max(e.flash, .3); }
    if(e.boss && e.aggro && BOSS_MECH[e.type] && !(e.stun>0) && !e.tele) BOSS_MECH[e.type](e, dt, R);
    if(e.rival && e.aggro) rivalMech(e, dt, R);
    if(e.heavy && e===front && gap <= 8 && !(e.stun>0) && !e.tele){ e.mt += dt; if(e.mt >= HEAVY_EVERY){ e.mt = 0; telegraph(e, HEAVY_WARN, "#ffb84a", heavyBlow); } }
    if(e.tele) tickTele(e, dt, R);
    if(e.rage===1 && e.hp < e.maxHp*.3){ e.rage = 2; e.atk /= 1.4; World.num(sxOf(e.x), World.GY - World.enemyTop(e.v) - 26, "ENRAGED", "hurt"); World.ring(sxOf(e.x), World.GY - 60*World.CS, "#ff4a3a", true); }
    const eg = (e.x - e.hw) - (h.x + HERO_FRONT);
    const reach = e.ranged ? 60 : 5;
    const edur = Math.min(.7, e.atk*.85);
    if(e.postT!=null){ e.postT += dt; if(e.postT >= edur*.5) e.postT = null; }
    const canHit = e.aggro && eg <= reach && (e.ranged || e===front) && !(e.stun>0) && !(e.guard>0);
    if(canHit){ e.atkT -= dt * (e.aff && e.aff.includes("enraged") && e.hp < e.maxHp*.5 ? 1.6 : 1) * (e.frenzy>0 ? 2 : 1); if(e.atkT <= 0){ enemyAttack(e); e.atkT = e.atk; e.postT = 0; } }
    e.animP = (canHit && e.atkT <= edur*.5) ? clamp(.5 - e.atkT/edur, 0, .5) : (e.postT!=null ? .5 + e.postT/edur : null);
    // enemies waiting their turn shift their weight and edge forward instead of standing frozen
    const waiting = e.aggro && !canHit && !e.ranged && !(e.stun>0) && !e.T.big; e.walkAmt = lerp(e.walkAmt||0, waiting ? .22 : 0, 1 - Math.exp(-dt*6)); if(waiting) e.walk += dt*(3.2 + (e.phase%1)*1.4);
    if(e.bleedT>0 || e.burnT>0){
      if(e.bleedT>0){ e.dotAcc += e.bleedDps*dt; e.bleedT -= dt; if(e.bleedT<=0) e.bleedDps = 0; }
      if(e.burnT>0){ e.burnAcc = (e.burnAcc||0) + e.burnDps*dt; e.burnT -= dt; if(e.burnT<=0) e.burnDps = 0; if(Math.random()<dt*6) World.spark(sxOf(e.x)+rand(-10,10), World.GY-rand(20,90)*e.v.scale, "#ff8a2a"); }
      e.dotTick += dt;
      if(e.dotTick >= .5){ e.dotTick = 0; if(e.dotAcc>=1){ const a = e.dotAcc; e.dotAcc = 0; damageEnemy(e, a, "bleed"); } if(!e.dead && e.burnAcc>=1){ const a = e.burnAcc; e.burnAcc = 0; damageEnemy(e, a, "burn"); } }
    }
    e.flash = Math.max(0, e.flash - dt*6); e.kb *= Math.exp(-dt*9);
  }
  if(R.bleedHeal >= st.maxHp*.03){ heal(R.bleedHeal); R.bleedHeal = 0; }       // Martyr's Blood heals in readable chunks
  for(const e of R.enemies) if(e.dead) e.deathT += dt;
  R.enemies = R.enemies.filter(keepEnemy);
  // projectiles (x in world units)
  for(const p of R.proj){
    p.x += p.vx*dt; p.life -= dt;
    if(p.kind==="arrow" || p.kind==="orb"){ if(p.x <= h.x + 8){ p.life = 0; hitHero(p.dmg, p.src, false); } }
    else if(p.kind==="fireball"){ const tg = p.target; if(!tg || tg.dead){ p.life = 0; continue; }
      if(p.x >= tg.x - tg.hw){ p.life = 0; damageEnemy(tg, p.dmg, "fire"); const x = sxOf(tg.x), y = World.GY - 70*World.CS; World.hit(x, y, "#ff8a2a", true); World.burst(x, y, "#ffb04a", 18, 200);
        const al = aliveSorted(); const nx = al.find(o=>o!==tg && o.x > tg.x); if(nx) damageEnemy(nx, p.dmg*.5, "fire"); SFX.fire(); } }
  }
  R.proj = R.proj.filter(p=>p.life>0);
  // potion
  if(h.hp < st.maxHp*.4 && R.potions>0 && h.potionCd<=0 && h.hp>0) drinkPotion();
  if(h.hp<=0){
    if(hasPower("heart") && !R.heartUsed){ R.heartUsed = true; h.hp = st.maxHp*.5; World.num(World.HX, World.GY-150*World.CS, "DAWN", "lvl"); World.beam(World.HX, "#ffcf7a", 44, .9); SFX.holy(); }
    else if(syn("holy",3) && !synAlt("holy") && !R.holyUsed){ R.holyUsed = true; h.hp = st.maxHp*.3; World.num(World.HX, World.GY-150*World.CS, "SAVED", "lvl"); World.beam(World.HX, "#ffe07a", 40, .8); SFX.holy(); }
    else { defeat(); return; }
  }
  if(R.mods.timed && R.mode!=="raid"){ R.timeLeft -= dt; if(R.timeLeft<=0){ R.timeLeft = 0; R.timeUp = true; toast("Time's up", "#ff6a7a"); defeat(); return; } }
  if(R.mode==="raid" && R.enemies.some(e=>e.aggro)){ R.timeLeft -= dt; if(R.timeLeft<=0){ R.timeLeft = 0; victory(); return; } }
  if((R.mode==="arena" || R.mode==="raid") && !R.enemies.some(e=>!e.dead)){ victory(); return; }
  if(R.mode!=="endless" && !R.enemies.some(e=>!e.dead) && h.x >= R.levelEnd){ victory(); }
}
const modOf = (e, el) => (e.mod && e.mod[el]) || 1;
/* =====================================================================
   EVENTS (stops between fights)
===================================================================== */
function startEvent(ev){
  const R = run; R.event = {ev, t:0, phase:0}; SFX.pick(); S.stats.events++;
  const E = EVENTS[ev.type];
  World.num(sxOf(ev.x + 6), World.GY - 108*World.CS, E.name, "info");
}
function tickEvent(dt){
  const R = run, E = R.event, ev = E.ev; E.t += dt;
  ev.open = Math.min(1, ev.open + dt*2.2);
  if(E.phase===0 && E.t > .45){ E.phase = 1; resolveEvent(ev); }
  if(E.phase===2 && E.t > E.until){ ev.done = true; R.event = null; }
}
function endEvent(delay){ const R = run; if(!R || !R.event) return; R.event.phase = 2; R.event.until = R.event.t + (delay||.6); }
const merchantPrices = R => ({potion:30 + R.d*6, whet:55 + R.d*10});
function chestLoot(ev){
  const R = run, x = sxOf(ev.x), d = R.d, rich = ev.rich ? 1.6 : 1;      // a hidden chest (chosen at a fork) holds more
  const g = Math.round((25 + d*10 + Math.random()*d*6)*rich); R.gold += g; SFX.coin(); World.coins(x, World.GY-40, 8); World.num(x, World.GY-120, "+"+g, "gold");
  World.burst(x, World.GY-40, "#ffd86a", 24, 180, {up:60}); ev.open = Math.max(ev.open||0, .01);
  if(Math.random() < (ev.rich ? .55 : .3)){ const it = genItem(Math.max(1, d), 0); S.inv.push(it); invGuard(); persist(); setTimeout(()=>lootToast(R, `Found: ${it.name}`, RARITY[it.r].color, true), 400); }
  else if(Math.random() < .5){ R.potions++; setTimeout(()=>lootToast(R, "Found a potion", "#ff6a7a"), 400); }
  if(Math.random() < .45){ rollFrags(1); R.frags = (R.frags||0) + 1; if(runesOpen()) setTimeout(()=>lootToast(R, "Found a rune fragment", "#c9a2ff"), 900); }
}
function resolveEvent(ev){
  const R = run, h = R.hero, st = R.st, x = sxOf(ev.x);
  if(ev.type==="merchant" && R.gold < merchantPrices(R).potion) ev.type = "chest";        // never a wasted stop
  if(ev.type==="heal"){
    const amt = st.maxHp*.3; heal(amt); SFX.holy(); World.beam(x, "#8affc8", 40, 1.1); World.burst(World.HX, World.GY-60*World.CS, "#8affc8", 30, 140, {up:80, g:20, life:1});
    endEvent(1.0);
  } else if(ev.type==="chest"){ chestLoot(ev); endEvent(1.0); }
  else openEventModal(ev);
}
function openEventModal(ev){
  const R = run; R.paused = true; const E = EVENTS[ev.type];
  let opts = "", head = E.name, sub = E.text;
  if(ev.type==="fork"){
    const P = merchantPrices(R), poor = R.gold < P.potion, nextPack = R.stops.find(s=>s.kind==="pack" && s.x > ev.x);
    if(ev.fork==="hunt"){ R.eventOffer = ["elite","shrine"];
      opts = `<button class="ev-opt" data-act="evChoose" data-v="elite" ${nextPack?'':'disabled'}>${art("horde",56)}<b>Hunt the elite</b><span>A hard fight: an elite joins the next pack. It drops an item and extra gold.</span></button>
        <button class="ev-opt" data-act="evChoose" data-v="shrine">${art("ev_shrine",56)}<b>Visit the shrine</b><span>Choose one blessing for this battle.</span></button>`; }
    else { R.eventOffer = [poor ? "chest" : "merchant", "chest"];
      opts = `<button class="ev-opt" data-act="evChoose" data-v="merchant" ${poor?'disabled':''}>${art("ev_merchant",56)}<b>Find the merchant</b><span>${poor ? `You carry ${fmt(R.gold)} gold. His cheapest ware costs ${P.potion}.` : `Potions and whetstones. You carry ${fmt(R.gold)} gold.`}</span></button>
        <button class="ev-opt" data-act="evChoose" data-v="chest">${art("chest",56)}<b>Dig up the hidden chest</b><span>More gold, and a good chance of gear.</span></button>`; }
  } else if(ev.type==="shrine"){
    const pool = BLESSINGS.slice().sort(()=>Math.random()-.5).slice(0,2); R.eventOffer = pool.map(b=>b.id);
    opts = pool.map(b=>`<button class="ev-opt" data-act="evChoose" data-v="${b.id}">${art(b.icon,56)}<b>${b.name}</b><span>${b.text}</span></button>`).join("");
  } else if(ev.type==="altar"){
    const cost = Math.round(R.hero.hp*.25);
    opts = `<button class="ev-opt" data-act="evChoose" data-v="blood">${art("ev_altar",56)}<b>Offer blood</b><span>Lose ${cost} HP. Gain a skill card.</span></button>
      <button class="ev-opt" data-act="evChoose" data-v="leave">${art("hero",56)}<b>Walk on</b><span>Keep your health.</span></button>`;
  } else if(ev.type==="merchant"){
    const P = merchantPrices(R);
    opts = `<button class="ev-opt" data-act="evChoose" data-v="potion" ${R.gold<P.potion?'disabled':''}>${art("potion",56)}<b>Potion</b><span>+1 potion · ${CUR.gold} ${P.potion}</span></button>
      <button class="ev-opt" data-act="evChoose" data-v="whet" ${R.gold<P.whet?'disabled':''}>${art("edge",56)}<b>Whetstone</b><span>+10% damage this battle · ${CUR.gold} ${P.whet}</span></button>
      <button class="ev-opt" data-act="evChoose" data-v="leave">${art("ev_merchant",56)}<b>Move on</b><span>You carry ${fmt(R.gold)} gold.</span></button>`;
  }
  R.eventModal = openModal(`<div class="ev-head">${art(E.icon,70)}<div><div class="modal-title">${head}</div><div class="modal-sub">${sub}</div></div></div><div class="ev-opts">${opts}</div>`, {noClose:true, wide:true});
}
/* the elite from a fork joins the next pack; it carries a guaranteed item and triple gold */
function addForkElite(ev){
  const R = run, st = R.stops.find(s=>s.kind==="pack" && s.x > ev.x); if(!st) return;
  const base = R.mode==="endless" ? zoneOf(R.wave).pool[0] : ACTS[R.cfg.a] ? ACTS[R.cfg.a].pool[0] : st.enemies[0].type, src = st.enemies[0];
  const e = mkEnemy(base, st.end + 30, R.d, {elite:true}); e.stop = st; e.prize = true; e.gold *= 3; if(src && src.rung) e.rung = src.rung;
  if(R.mult){ e.hp *= R.mult.hp; e.maxHp *= R.mult.hp; e.dmg *= R.mult.dmg; } if(R.mods && R.mods.haste) e.atk /= 1.35; if(src && src.wave){ e.wave = src.wave; e.theme = src.theme; if(R.mode==="endless") endlessScale(e, src.wave); }
  st.enemies.push(e); R.enemies.push(e); const was = st.end; st.end = e.x;
  const k = R.waveX.indexOf(was); if(k>=0) R.waveX[k] = st.end;
  if(R.mode!=="endless" && R.stops[R.stops.length-1]===st) R.levelEnd = st.end + 70;
}
function chooseEvent(v){
  const R = run; if(!R || !R.event) return; const ev = R.event.ev, st = R.st;
  closeModal(R.eventModal); R.eventModal = null; R.paused = false;
  if(ev.type==="fork"){
    if(v==="shrine" || v==="merchant"){ ev.type = v; SFX.click(); openEventModal(ev); return; }
    if(v==="elite"){ addForkElite(ev); SFX.boss(); World.num(World.HX + 40, World.GY - 130*World.CS, "An elite waits ahead", "info"); }
    else { ev.type = "chest"; ev.rich = true; chestLoot(ev); }
    endEvent(.7); return;
  }
  if(ev.type==="shrine"){ R.buffs[v] = (R.buffs[v]||0) + 1; const prev = st.maxHp; R.st = heroStats(R); if(v==="vigor") R.hero.hp = R.st.maxHp; else if(R.st.maxHp>prev) R.hero.hp += R.st.maxHp-prev;
    SFX.syn(); World.beam(sxOf(ev.x), "#c9a2ff", 34, 1); World.ring(World.HX, World.GY-60*World.CS, "#c9a2ff", true); buildHudStatic(); }
  else if(ev.type==="altar" && v==="blood"){ const cost = Math.round(R.hero.hp*.25); R.hero.hp -= cost; World.num(World.HX-10, World.GY-118*World.CS, "-"+cost, "hurt"); World.burst(sxOf(ev.x), World.GY-50, "#ff2a3a", 26, 160, {up:60}); SFX.hurt();
    R.pendingLv++; R.bonusPick = (R.bonusPick||0) + 1; setTimeout(()=>{ if(run===R && !R.over) openCardPick(); }, 350); }
  else if(ev.type==="merchant" && v==="potion"){ const p = merchantPrices(R).potion; if(R.gold>=p){ R.gold -= p; R.potions++; SFX.coin(); } }
  else if(ev.type==="merchant" && v==="whet"){ const p = merchantPrices(R).whet; if(R.gold>=p){ R.gold -= p; R.buffs.whet = (R.buffs.whet||0)+1; R.st = heroStats(R); SFX.forge(); } }
  endEvent(.5);
}
/* ---------- boss mechanics: each act boss has one signature move, telegraphed a second ahead ---------- */
const BOSS_LINES = {
  banditKing:"“The King's road is mine now, little knight.”",
  boneLord:"“The dead serve me. Soon, so will you.”",
  jarl:"“Winter takes everything. It will take you.”",
  forgeTyrant:"“Burn, and be reforged.”",
  voidHerald:"“The Council sees you, Vanguard.”"
};
function warnOver(x, y, col){ World.num(x, y, "!", "crit", .6); World.ring(x, y + 10, col || "#ff5a4a", true); SFX.boss(); }
/* TELEGRAPHED ATTACKS (Review 5): a heavy move is announced by a ring that closes on the enemy for `dur` seconds, then fn(e, R) lands.
   Any ability cast while the ring is closing interrupts the move and stuns the enemy for TELE_STUN seconds, so a hand that times
   its abilities beats auto-cast, which fires as soon as an ability is ready. */
const TELE_STUN = 2;
function telegraph(e, dur, col, fn, line){
  const R = run; e.tele = {t:0, dur, col:col||"#ff5a4a", fn}; warnOver(sxOf(e.x), World.GY - World.enemyTop(e.v) - 30, col);
  if(line && !(R.said && R.said[line])){ (R.said = R.said || {})[line] = 1; caption(line, 2200, "#ffb0a0"); }
  if(R.abil.length && !S.tips.tele){ S.tips.tele = 1; persist(); caption("The ring is closing: cast an ability now to interrupt the blow.", 3000, "#f2d796"); }
}
function tickTele(e, dt, R){ const T = e.tele; if(e.dead){ e.tele = null; return; } if(e.stun > 0) return;
  T.t += dt; if(T.t >= T.dur){ e.tele = null; T.fn(e, R); } }
const teleOpen = R => !!R && R.enemies.some(e=>e.tele && !e.dead && e.aggro);
/* called when an ability is cast: every closing ring on the field is broken */
function interruptTele(R){ let n = 0;
  for(const e of R.enemies){ if(!e.tele || e.dead) continue; e.tele = null; e.stun = Math.max(e.stun||0, TELE_STUN); e.atkT = Math.max(e.atkT, e.atk*.6); n++;
    const x = sxOf(e.x); World.num(x, World.GY - World.enemyTop(e.v) - 34, "INTERRUPTED", "lvl"); World.ring(x, World.GY - 60*World.CS, "#ffe9a8", true); World.burst(x, World.GY - 70*World.CS, "#ffe9a8", 18, 220); }
  if(n){ SFX.block(); haptic("HEAVY"); R.interrupts = (R.interrupts||0) + n; S.stats.interrupts = (S.stats.interrupts||0) + n; World.shake(5*shakeK()); }
  return n; }
function heavyBlow(e, R){ if(e.dead) return; const x = World.HX; e.postT = 0; World.shake(8*shakeK()); SFX.slam(); World.burst(x + 20, World.GY - 50*World.CS, "#ffb84a", 22, 240, {a:Math.PI, spread:1.4}); hitHero(e.dmg*HEAVY_MULT, e, true); }
function summon(R, e, type, n, dx){ const d = R.d; for(let k=0;k<n;k++){ const m = mkEnemy(type, e.x + dx + k*14, d, {k}); m.aggro = true; m.xp = 0; m.gold = 1; m.stop = e.stop; if(e.rung) m.rung = e.rung;
  if(R.mult){ m.hp *= R.mult.hp; m.maxHp *= R.mult.hp; m.dmg *= R.mult.dmg; } R.enemies.push(m);
  World.beam(sxOf(m.x), "#b58cff", 20, .4); } }
const TYRANT_SLAM = 1.25;     // the Forge Tyrant's ground slam, as a multiple of his normal hit (was 1.5: the Act IV wall)
const BOSS_MECH = {
  banditKing(e, dt, R){ if(!e.m1 && e.hp < e.maxHp*.5){ e.m1 = 1; telegraph(e, 1.4, "#ff5a4a", (e, R)=>summon(R, e, "archer", 2, 26), "The Outlaw King calls his archers!"); } },
  boneLord(e, dt, R){ e.mt = (e.mt||0) + dt; if(e.mt > 7.8){ e.mt = 0; if(R.enemies.filter(o=>!o.dead).length < 4) telegraph(e, 1.2, "#b58cff", (e, R)=>summon(R, e, "skeleton", 1, -20), "The Bone Lord raises the dead!"); } },
  jarl(e, dt, R){ e.mt = (e.mt||0) + dt;
    if(e.mt > 8.8){ e.mt = 0; telegraph(e, 1.2, "#8ff0ff", (e, R)=>{ World.burst(World.HX, World.GY - 60*World.CS, "#dff6ff", 26, 180); World.ring(World.HX, World.GY - 60*World.CS, "#8ff0ff", true);
      if(R.immune > 0) World.num(World.HX, World.GY - 130*World.CS, "RESISTED", "block"); else { R.hero.frozen = 1.2; World.num(World.HX, World.GY - 130*World.CS, "FROZEN", "zap"); } }, "The Jarl draws the winter in!"); } },
  forgeTyrant(e, dt, R){ e.mt = (e.mt||0) + dt;
    if(e.mt > 7.8){ e.mt = 0; telegraph(e, 1.2, "#ff8a2a", (e, R)=>{ World.burst(World.HX, World.GY, "#ff8a2a", 30, 260, {a:-Math.PI/2, spread:1.2}); World.shake(8); hitHero(e.dmg*TYRANT_SLAM, e, false, true); }, "The Tyrant raises his molten blade!"); } },
  voidHerald(e, dt, R){ for(const [k,f] of [["m1",.66],["m2",.33]]) if(!e[k] && e.hp < e.maxHp*f){ e[k] = 1; telegraph(e, 1.3, "#ff4fd8", (e, R)=>summon(R, e, "acolyte", 2, 26), "The Herald calls the Council's acolytes!"); } }
};
/* A rival knight in the Arena fights with one ability from the tag he favours (shown before the duel). It is always
   telegraphed a second ahead, so a well-timed Shield Wall or Divine Shield turns it aside. */
const RIVAL_MOVE = {
  fire:{name:"Meteor", col:"#ff8a2a", hit(e, R){ World.burst(World.HX, World.GY - 40, "#ff8a2a", 30, 260, {a:-Math.PI/2, spread:1.4}); World.shake(7); SFX.fire(); hitHero(e.dmg*2.2, e, false, true); }},
  storm:{name:"Thunderclap", col:"#7ee0ff", hit(e, R){ World.bolt(World.HX, "#8ff0ff"); SFX.zap(); hitHero(e.dmg*1.2, e, false, true); if(!(R.immune>0)){ R.hero.frozen = 1; World.num(World.HX, World.GY - 130*World.CS, "STUNNED", "zap"); } }},
  bleed:{name:"Rend", col:"#ff5a64", hit(e, R){ SFX.crit(); hitHero(e.dmg*2, e, true, true); }},
  blade:{name:"Blade Dance", col:"#dfe6f2", hit(e, R){ e.frenzy = 3; World.ring(sxOf(e.x), World.GY - 60*World.CS, "#dfe6f2", true); SFX.swing(); }},
  holy:{name:"Divine Light", col:"#ffe07a", hit(e, R){ e.hp = Math.min(e.maxHp, e.hp + e.maxHp*.1); World.beam(sxOf(e.x), "#ffe07a", 30, .7); World.num(sxOf(e.x), World.GY - World.enemyTop(e.v) - 14, "+"+fmtNum(Math.round(e.maxHp*.1)), "heal"); SFX.holy(); }},
  shield:{name:"Shield Wall", col:"#5aa0ff", hit(e, R){ e.guard = 2.5; World.ring(sxOf(e.x), World.GY - 60*World.CS, "#9ad0ff", true); SFX.block(); }}
};
function rivalMech(e, dt, R){
  const M = RIVAL_MOVE[e.move]; if(!M) return; e.mt = (e.mt||0) + dt; if(e.frenzy>0) e.frenzy -= dt; if(e.guard>0) e.guard -= dt;
  if(e.tele || e.stun > 0) return;
  if(e.mt > 9.8){ e.mt = 0; telegraph(e, 1.2, M.col, (e, R)=>M.hit(e, R)); World.num(sxOf(e.x), World.GY - World.enemyTop(e.v) - 52, M.name, "info"); }
}
/* ---------- boss entrance: the fight holds for a moment while the camera pushes in and the name card shows ---------- */
function bossArrives(e){
  const R = run; SFX.boss(); World.shake(7); R.bossMusic = true; Music.play("boss");
  if(R.mode==="arena" || R.mode==="raid"){ return; }                      // duels and raids start at once; the boss bar names the foe
  const seen = S.tips["boss_"+e.type], line = BOSS_LINES[e.type] || (e.aff ? e.aff.map(a=>AFFIXES[a].name).join(" · ") : "");
  S.tips["boss_"+e.type] = 1;
  R.intro = {t:0, dur:seen ? 1.5 : 2.4, e};
  const el = $("#bossIntro"); if(el){ el.innerHTML = `<div class="bi-bar top"></div><div class="bi-card"><small>${R.mode==="bounty" ? "Wanted" : R.mode==="rush" ? `Boss rush · ${(R.rushN||0)+1}` : R.mode==="weekly" ? `The Vanguard's Trial · rung ${e.rung||""}` : `Act ${ACTS[R.cfg.a] ? ACTS[R.cfg.a].short : ""} boss`}</small><b>${e.name}</b>${line?`<i>${line}</i>`:""}</div><div class="bi-bar bot"></div>`; el.classList.add("show"); }
  laneHold(R.intro.dur*1000 + 200); $("#runScreen").classList.add("intro");
}
function tickIntro(dt){
  const R = run, I = R.intro; I.t += dt;
  if(I.t >= I.dur){ R.intro = null; const el = $("#bossIntro"); if(el) el.classList.remove("show"); $("#runScreen").classList.remove("intro"); }
}
/* ---------- ONE MESSAGE LANE: captions, boss cards and toasts never stack on top of each other ----------
   Captions own the lane while they show; toasts raised meanwhile wait their turn (see toast() in ui.js). */
let laneUntil = 0;
function laneHold(ms){ laneUntil = Math.max(laneUntil, performance.now() + ms); }
function laneReset(){ laneUntil = 0; $("#runScreen").classList.remove("intro"); const el = $("#caption"); if(el) el.classList.remove("show"); const bi = $("#bossIntro"); if(bi) bi.classList.remove("show"); }
const laneBusy = () => Math.max(0, laneUntil - performance.now());
/* Loot messages never cover a boss fight or a skill choice: while a boss is on the field, or a card or event
   screen is open, they wait, and show once the way is clear.
   If the battle ends first, only item finds are shown (over the result screen); potions and fragments are already counted there. */
const bossUp = R => !!R && R.enemies.some(e=>e.boss && e.aggro && !e.dead);
const lootWait = R => bossUp(R) || !!R.intro || !!R.cardModal || !!R.eventModal;
function lootToast(R, msg, col, item){
  if(run!==R || (R.over && !item)) return;
  if(!R.over && lootWait(R)){ (R.lootQ = R.lootQ || []).push({msg, col, item:!!item}); return; }
  toast(msg, col);
}
function flushLoot(R){
  const q = R && R.lootQ; if(!q || !q.length) return; R.lootQ = [];
  const show = R.over ? q.filter(o=>o.item) : q;
  show.slice(-2).forEach((o,k)=>setTimeout(()=>{ if(run===R) toast(o.msg, o.col); }, (R.over ? 1400 : 300) + k*700));
}
/* short story captions over the battle */
function caption(text, ms, col){ const el = $("#caption"); if(!el) return; ms = ms || 3000;
  const wait = laneBusy(); if(wait > 60){ laneHold(wait + ms); setTimeout(()=>showCaption(text, ms, col), wait); return; }
  laneHold(ms); showCaption(text, ms, col); }
function showCaption(text, ms, col){ const el = $("#caption"); if(!el) return; el.innerHTML = `<span style="${col?`color:${col}`:""}">${text}</span>`; el.classList.remove("show"); void el.offsetWidth; el.classList.add("show"); clearTimeout(caption._t); caption._t = setTimeout(()=>el.classList.remove("show"), ms); }
function drinkPotion(){
  const R = run, h = R.hero, st = R.st; if(R.potions<=0 || h.potionCd>0 || h.hp>=st.maxHp || h.hp<=0) return false;
  R.potions--; S.stats.potions++; R.potUsed = (R.potUsed||0) + 1; h.potionCd = 2.5; heal(st.maxHp*st.potionHeal/100); SFX.potion(); haptic("LIGHT");
  World.burst(World.HX, World.GY-70*World.CS, "#ff6a7a", 22, 120, {up:60, g:40, life:.8}); World.ring(World.HX, World.GY-60*World.CS, "#ff6a7a", true);
  return true;
}
function updateOver(dt){
  const R = run, hv = R.hv;
  if(R.result==="defeat") hv.dead = Math.min(1.4, hv.dead + dt);
  hv.walkAmt = lerp(hv.walkAmt, 0, 1 - Math.exp(-dt*8)); hv.flash = Math.max(0, hv.flash - dt*6);
  for(const e of R.enemies){ e.walkAmt = lerp(e.walkAmt, 0, 1 - Math.exp(-dt*8)); e.flash = Math.max(0, e.flash - dt*6); if(e.dead) e.deathT += dt; }
  R.enemies = R.enemies.filter(keepEnemy);
}
function tickSkills(dt, alive, front, gap){
  const R = run, h = R.hero, st = R.st;
  const engaged = front && gap < 110;
  if(cv("light")){ R.t.light += dt; if(R.t.light >= (hasPerk("light_fast") ? 3.5 : 5)){ R.t.light = 0; if(h.hp < st.maxHp || R.cards.leg_sanct){ heal(st.maxHp*cv("light")/100); World.beam(World.HX, "#ffe07a", 30, .6); } } }
  if(cv("fireball") && engaged){ const cd = 4*(syn("fire",3) && !synAlt("fire") ? .5 : 1); R.t.fireball += dt;
    if(R.t.fireball >= cd){ R.t.fireball = 0; const n = hasPerk("fb_twin") ? 2 : 1;
      for(let k=0;k<n;k++) R.proj.push({kind:"fireball", x:h.x+10-k*14, h:70+k*10, vx:150, target:front, dmg:st.dmg*cv("fireball")/100*R.dmgDealtMult, life:3, col:"#ff8a2a"}); SFX.fire(); } }
  if(cv("chain") && engaged){ const cd = 3.5*(syn("storm",2)?.75:1); R.t.chain += dt;
    if(R.t.chain >= cd){ R.t.chain = 0; const crown = !!R.cards.evo_crown, n = (crown ? 6 : 3) + stormX() + (hasPerk("chain_plus")?2:0);
      const tg = alive.filter(e=>e.x>h.x-4 && e.x-h.x<160).slice(0,n); lightning(tg, st.dmg*cv("chain")/100); if(crown) tg.forEach(e=>{ if(!e.dead) e.stun = Math.max(e.stun, e.boss ? .25 : .5); }); } }
  if(setN("storm")>=3 && engaged){ R.t.stormset += dt; if(R.t.stormset >= 5){ R.t.stormset = 0; lightning(alive.filter(e=>e.x>h.x-4).slice(0,2 + stormX()), st.dmg*1.2); } }
  if(R.cards.evo_firestorm && engaged){ R.t.firestorm += dt; if(R.t.firestorm >= 6){ R.t.firestorm = 0; const tg = alive.filter(inView); if(tg.length){ SFX.fire(); World.shake(6);
    tg.forEach(e=>{ const x = sxOf(e.x); World.beam(x, "#ff8a2a", 22, .45); World.burst(x, World.GY - 30, "#ffb04a", 16, 220, {a:-Math.PI/2, spread:1.6}); const dm = st.dmg*2.5*R.dmgDealtMult; damageEnemy(e, dm, "fire"); applyBurn(e, dm*.6); }); } } }
}
function heroAttack(e){ const R = run; SFX.swing(); strike(e, false); R.hero.postT = 0;
  if(hasPower("oathblade") && ++R.oathN % 4===0){ const tg = aliveSorted().filter(o=>sxOf(o.x) < World.W + 20); World.whirl(World.HX + 40, World.GY - 55*World.CS, "#9affea"); World.shake(4); SFX.holy();
    tg.forEach(o=>{ World.slash(sxOf(o.x), World.GY - 60*World.CS, "#9affea"); damageEnemy(o, R.st.dmg*.6*R.dmgDealtMult, "holy"); }); }
  if(cv("whirl") && ++R.whirlN % (hasPerk("whirl_fast") ? 4 : 5)===0){ const near = aliveSorted().filter(o=>o.x - R.hero.x < 55); World.whirl(World.HX, World.GY - 55*World.CS, "#bff4ff"); SFX.zap(); near.forEach(o=>damageEnemy(o, R.st.dmg*cv("whirl")/100*R.dmgDealtMult, "whirl")); } const tw = cv("twin"); if(tw && Math.random()*100 < tw) R.pendingTwin = .16; }
function strike(e, isTwin){
  const R = run, st = R.st; if(!e || e.dead) return;
  let dmg = st.dmg * rand(.9,1.1) * R.dmgDealtMult;
  const crit = Math.random()*100 < st.crit || (isTwin && hasPerk("twin_crit")) || R.sureCrit; R.sureCrit = false; if(crit) dmg *= st.critMult;
  if(e.hp/e.maxHp < (hasPerk("exec_wide") ? .5 : .35)) dmg *= 1 + cv("execute")/100;
  if(e.bleedT>0){ dmg *= 1 + cv("hemorrhage")/100; if(syn("bleed",3) && !synAlt("bleed")) dmg *= 1.2; }
  R.hitCount++;
  damageEnemy(e, dmg, crit ? "crit" : "hit");
  if(isTwin){ R.hero.postT = 0; }
  if(cv("smite") && R.hitCount%(hasPerk("smite_fast") ? 3 : 4)===0){ const sd = st.dmg*cv("smite")/100*R.dmgDealtMult;
    if(R.cards.evo_judge){ const tg = aliveSorted().filter(inView); tg.forEach(o=>{ damageEnemy(o, sd, "holy"); World.beam(sxOf(o.x), "#ffe07a", 20, .4, World.GY - 220); }); if(tg.length){ SFX.holy(); World.shake(3); } }
    else if(!e.dead){ damageEnemy(e, sd, "holy"); World.beam(sxOf(e.x), "#ffe07a", 18, .35, World.GY - 190); SFX.holy(); } }
  const behind = aliveSorted().filter(o=>o!==e && o.x > e.x);
  if(cv("cleave") && behind[0] && behind[0].x - e.x < 40){ const o = behind[0]; damageEnemy(o, dmg*cv("cleave")/100, "cleave"); World.slash(sxOf(o.x), World.GY - 60*World.CS, R.hv.skin.weapon.glow||"#ffffff"); }
  if(cv("pierce") && behind.length){ const tgts = behind.filter(o=>o.x - e.x < 75); if(tgts.length){ World.thrust(sxOf(e.x), sxOf(tgts[tgts.length-1].x), World.GY - 62*World.CS, "#dfe6f2"); tgts.forEach(o=>damageEnemy(o, dmg*cv("pierce")/100, "pierce")); } }
  if(cv("serrated")){ applyBleed(e, dmg*cv("serrated")/100*(isTwin && R.cards.evo_cuts ? 3 : 1)); }      // Thousand Cuts: the extra strike re-applies Bleed at double strength
  let ig = cv("ember") + (setN("ember")>=3 ? 20 : 0);
  if(crit && R.cards.leg_molten) applyBurn(e, dmg*1.2);
  else if(ig && Math.random()*100 < Math.min(80, ig)) applyBurn(e, dmg*.6);
  if(crit && cv("static")){ const al = aliveSorted().filter(o=>o.x>=e.x-1).slice(0, 2 + stormX()); lightning(al, st.dmg*cv("static")/100); }
  if(crit){ haptic("MEDIUM"); World.shake(5); if(syn("blade",3) && synAlt("blade")) heal(st.maxHp*.02); }
}
function applyBleed(e, total){ if(e.dead) return; const mult = syn("bleed",2) ? 1.4 : 1, base = 3 + (hasPerk("bleed_long") ? 2 : 0); e.bleedDps = Math.min(e.bleedDps + total/3*mult, e.maxHp); e.bleedT = Math.min(base + 3, Math.max(base, e.bleedT + 1)); }      // fresh wounds lengthen the bleed (up to +3s) instead of only resetting it
function applyBurn(e, total){ if(e.dead) return; if(!(e.burnT>0)) SFX.burn(); const mult = syn("fire",2) ? 1.5 : 1; e.burnDps = Math.min(e.burnDps + total/3*mult, e.maxHp); e.burnT = 3 + (hasPerk("burn_long") ? 2 : 0); }
/* Storm III: two extra targets, or (mastery variant) harder hits */
const stormX = () => syn("storm",3) && !synAlt("storm") ? 2 : 0;
function lightning(targets, dmg){ if(!targets.length) return; const R = run; SFX.zap(); const k = syn("storm",3) && synAlt("storm") ? 1.35 : 1;
  targets.forEach(t=>{ World.bolt(sxOf(t.x), "#8ff0ff"); const d = dmg*k*R.dmgDealtMult*(R.cards.leg_plasma && t.burnT>0 ? 1.3 : 1); damageEnemy(t, d, "zap");
    if(R.cards.leg_plasma) applyBurn(t, d*.6); if(R.cards.leg_static) applyBleed(t, d*.5); }); World.shake(3); }
const NUMKIND = {cleave:"dmg",pierce:"dmg",whirl:"zap",crit:"crit",hit:"dmg",holy:"holy",fire:"fire",burn:"burn",bleed:"bleed",zap:"zap",thorn:"thorn",blast:"blast"};
function damageEnemy(e, amt, kind){
  if(e.dead) return; const R = run;
  const x = sxOf(e.x), top = World.enemyTop(e.v);
  if(e.guard > 0){ World.num(x, World.GY - top*.82, "GUARD", "block", 0, e); return; }
  const m = modOf(e, ELEM[kind] || "phys"); amt = Math.max(1, Math.round(amt*m));
  if(e.blockPct && (kind==="hit"||kind==="crit") && Math.random()*100 < e.blockPct){ World.num(x, World.GY - top*.82, "BLOCK", "block", 0, e); World.block(x - 18, World.GY - top*.5); SFX.block(); return; }
  if(e.raid) R.raidDmg += Math.min(amt, Math.max(0, e.hp));
  if(e.aff && e.aff.includes("thorned") && (kind==="hit"||kind==="crit") && R.hero.hp>0 && !(R.immune>0)){ const rf = Math.max(1, Math.round(amt*.15)); R.hero.hp -= rf; World.num(World.HX - 20, World.GY - 104*World.CS, "-"+rf, "thorn"); }
  e.hp -= amt;
  if(kind==="bleed" && R.cards.leg_martyr) R.bleedHeal += amt*.2;
  if(kind==="hit"||kind==="crit"){ e.flash = e.boss ? .5 : 1; e.kb = kind==="crit" ? 12 : 6;
    World.hit(x - 10, World.GY - top*.5, R.hv.skin.weapon.glow || "#ffffff", kind==="crit"); SFX[kind==="crit"?"crit":"hit"](); }
  else e.flash = Math.max(e.flash, .5);
  // one growing number per target (hits merge), crits stand alone; weak / resisted hits read at a glance
  World.dmgNum(e, x + rand(-10,10), World.GY - top*.82 - rand(0,8), amt, m<1 ? "resist" : (NUMKIND[kind]||"dmg"), clamp((amt/Math.max(1,R.st.dmg) - .8)/3, 0, 1) + (m>1 ? .35 : 0));
  if(kind==="crit") R.hitstop = Math.max(R.hitstop||0, .05*shakeK());
  if(e.hp<=0) killEnemy(e);
}
function killEnemy(e){
  const R = run, st = R.st; e.dead = true; e.deathT = 0; R.kills++; S.stats.kills++; if(e.elite) S.stats.elites++;
  R.hitstop = Math.max(R.hitstop||0, (e.boss ? .22 : e.elite ? .12 : .08)*shakeK());
  const g = Math.max(1, Math.round(e.gold*(1+st.goldPct/100))); R.gold += g;
  syncEnemyView(e);
  const x = sxOf(e.x);
  World.kill(e.v); World.coins(x, World.GY - 40, Math.min(8, 2 + Math.round(g/4)));
  SFX.death();   // Review 6: the coins fly to the counter; no "+8" number over the body setTimeout(()=>SFX.coin(), 220);
  if(e.bleedT>0 && cv("bloodprice")) heal(st.maxHp*cv("bloodprice")/100);
  if(e.bleedT>0 && e.bleedDps>0 && syn("bleed",3) && synAlt("bleed")){ const nx = aliveSorted().find(o=>o!==e && o.x > e.x - 1 && o.x - e.x < 60); if(nx){ nx.bleedDps = Math.min(nx.bleedDps + e.bleedDps, nx.maxHp); nx.bleedT = Math.max(nx.bleedT, 3); World.slash(sxOf(nx.x), World.GY - 60*World.CS, "#ff5a64"); } }
  if(e.bleedT>0 && hasPerk("rend_fast")) for(const a of R.abil) a.cd = Math.max(0, a.cd - 2);
  if(e.burnT>0 && cv("inferno")){ World.burst(x, World.GY-60, "#ff8a2a", 26, 220); World.ring(x, World.GY-60, "#ff8a2a", true); const nx = aliveSorted().filter(o=>o.x>e.x).slice(0,2); nx.forEach(o=>damageEnemy(o, st.dmg*cv("inferno")/100*R.dmgDealtMult, "blast")); }
  if(e.elite && Math.random() < .35){ const f = rollFrags(1); R.frags = (R.frags||0) + 1; if(runesOpen()) World.num(x, World.GY - World.enemyTop(e.v) - 44, "+1 fragment", "info"); }
  if(e.prize){ const it = genItem(Math.max(1, R.d + 1), 1); S.inv.push(it); invGuard(); persist(); setTimeout(()=>lootToast(R, `The elite dropped ${it.name}`, RARITY[it.r].color, true), 500); }
  if(e.boss){ S.stats.bosses++; World.shake(12); haptic("HEAVY"); World.burst(x, World.GY-80, "#f2c14e", 40, 280);
    if(R.mode==="rush"){ R.rushN = (R.rushN||0) + 1; R.bossMusic = false; R.bossPrep = false; Music.play(MUSIC_FOR[R.theme] || "battle_gothic"); hudCache = {}; }
    if(R.mode==="weekly"){ R.bossMusic = false; R.bossPrep = false; Music.play(MUSIC_FOR[R.theme] || "battle_gothic"); } }
  if(R.mode==="weekly" && e.rung && !R.enemies.some(o=>!o.dead && o.rung===e.rung)){ R.rungN = Math.max(R.rungN||0, e.rung); if(R.rungN > weeklyState().best && !R.bestSaid){ R.bestSaid = true; World.num(World.HX, World.GY - 168*World.CS, "New best", "lvl"); } }
  gainXp(e.xp);
  if(R.mode==="endless" && e.wave && !R.enemies.some(o=>!o.dead && o.wave===e.wave)){ R.cleared = Math.max(R.cleared||0, e.wave); }
  // the last blow of a level lands in slow motion
  if(R.mode!=="endless" && !R.over && !R.enemies.some(o=>!o.dead)){ R.slow = Math.max(R.slow||0, e.boss ? .9 : .5); }
}
function enemyAttack(e){
  const R = run;
  if(e.ranged){ R.proj.push({kind:e.look.proj||"arrow", x:e.x - e.hw - 2, h:e.projH*e.v.scale, vx:-140, dmg:e.dmg, src:e, life:3, col:e.vis.m ? e.vis.m.eye : (e.vis.skin.weapon.glow||"#ffffff")}); if(e.look.proj==="orb") SFX.cast(); else SFX.arrow(); }
  else hitHero(e.dmg, e, true);
  if(e.vis.C && e.vis.type==="golem"){ SFX.slam(); World.shake(6); const x = sxOf(e.x) - 50; World.burst(x, World.GY, "#b8a89a", 14, 140, {a:-Math.PI/2, spread:2, g:300}); World.ring(x, World.GY, e.vis.m.crack, false, true); }
}
function hitHero(raw, src, melee){
  const R = run, h = R.hero, st = R.st; if(R.over) return; if(R.tire) raw *= R.tire;
  const hx = World.HX, hy = World.GY - 60*World.CS;
  if(R.immune > 0){ World.num(hx - 8, World.GY - 125*World.CS, "IMMUNE", "block"); World.block(hx + 24, hy); R.hv.shieldUp = 1; return; }
  if(Math.random()*100 < st.block){ World.num(hx - 8, World.GY - 125*World.CS, "BLOCK", "block"); World.block(hx + 24, hy); R.hv.shieldUp = 1; SFX.block(); if(syn("shield",3)){ if(synAlt("shield")){ if(src && !src.dead && src.hp!==undefined) src.stun = Math.max(src.stun||0, src.boss ? .5 : 1); } else heal(st.maxHp*.02); } if(hasPerk("block_heal")) heal(st.maxHp*.03);
    if(R.cards.evo_bastion) addBarrier(st.maxHp*.1, .3);
    if(R.cards.leg_riposte && src && !src.dead && src.hp!==undefined){ R.sureCrit = true; damageEnemy(src, st.dmg*2*R.dmgDealtMult, "thorn"); World.slash(sxOf(src.x), World.GY - 60*World.CS, "#dfe6f2"); }
    if(hasPower("aegis") && src && !src.dead && src.hp!==undefined) damageEnemy(src, raw*1.5, "thorn"); return; }
  const red = st.armor/(st.armor+60);
  if(src && src.burnT>0 && syn("fire",3) && synAlt("fire")) raw *= .8;
  let dmg = Math.max(1, Math.round(raw*(1-red)*R.dmgTakenMult));
  if(R.barrier > 0){ const ab = Math.min(R.barrier, dmg); R.barrier -= ab; dmg -= ab; World.num(hx - 8, World.GY - 125*World.CS, "-"+fmtNum(Math.round(ab)), "block"); if(dmg<=0){ R.hv.shieldUp = 1; return; } }
  h.hp -= dmg; R.hv.flash = 1; R.hv.kb = -6; SFX.hurt(); World.shake(3);
  if(src && src.aff && src.aff.includes("vampiric") && !src.dead){ src.hp = Math.min(src.maxHp, src.hp + dmg*.3); }
  World.hurt(hx + 10, hy); World.num(hx - 14 + rand(-6,6), World.GY - 118*World.CS, "-"+fmtNum(dmg), "hurt");
  if(melee && cv("thorns") && src && !src.dead) damageEnemy(src, (raw + st.dmg*.5)*cv("thorns")/100*(syn("shield",3) && !synAlt("shield") ? 2 : 1)*(hasPerk("thorns_plus")?1.5:1), "thorn");
}
/* a barrier soaks damage before health (Bastion, Sanctuary); cap = share of max HP */
function addBarrier(amt, cap){ const R = run; R.barrier = Math.min(R.st.maxHp*cap, (R.barrier||0) + amt); }
function heal(amt){
  const R = run, h = R.hero, st = R.st; amt *= syn("holy",2) ? 1.25 : 1; amt = Math.round(amt);
  const before = h.hp; h.hp = Math.min(st.maxHp, h.hp + amt); const got = Math.round(h.hp - before);
  if(R.cards.leg_sanct && amt > got) addBarrier(amt - got, .2);
  if(syn("holy",3) && synAlt("holy")) addBarrier(amt*.5, .2);
  if(got>0) World.num(World.HX + 6, World.GY - 132*World.CS, "+"+fmtNum(got), "heal");
}
function gainXp(x){
  const R = run; if(hasPower("eternity")) x *= 1.2; if(R.boost && R.boost.xp) x *= 1.5;
  if(R.pickCap && R.lvl - 1 >= R.pickCap){ R.gold += Math.ceil(x); return; }          // past the cap, experience is paid out as gold
  R.xp += x; let up = false;
  while(R.xp >= R.xpNeed){ R.xp -= R.xpNeed; R.lvl++; const L = R.lvl - (R.lvlOff||0); R.xpNeed = L<=1 ? R.xpFirst : Math.round((8 + 5*L + L*L*.5)*(R.xpK||1)); R.pendingLv++; up = true; if(R.pickCap && R.lvl - 1 >= R.pickCap){ R.gold += Math.ceil(R.xp); R.xp = 0; break; } }
  if(up && !R.over){ SFX.level(); haptic("MEDIUM"); World.ring(World.HX, World.GY - 60*World.CS, "#cda6ff", true); if(!(R.lvlTxt > R.time - 1.2)){ R.lvlTxt = R.time; World.num(World.HX, World.GY - 150*World.CS, "LEVEL UP", "lvl"); }
    if(autoPickOn(R)) setTimeout(()=>{ if(run===R && !R.over) autoPickAll(); }, 380);
    else if(tutorialRun(R) || R.first) setTimeout(()=>{ if(run===R && !R.over && !R.paused && R.pendingLv>0 && !R.intro && !R.event) openCardPick(); else updatePickBtn(); }, 380);      // the first skill of a battle opens by itself; later ones wait on the button
    else updatePickBtn(); }
}
/* =====================================================================
   ACTIVE ABILITIES — two buttons earned from the build: the first two tags to reach 2 cards grant theirs.
   Tapping is free for everyone; auto-cast is part of Vanguard Command.
===================================================================== */
const shakeK = () => calmOn() ? .4 : 1;
function grantAbility(tag){
  const R = run, A = ABILITIES[tag]; if(!A || R.abil.length >= MAX_ABIL || R.abil.some(a=>a.tag===tag)) return false;
  R.abil.push({tag, cd:0, max:A.cd*(hasPerk("abil_fast") ? .85 : 1)}); buildAbilBar();
  setTimeout(()=>{ if(run===R && !R.over) World.num(World.HX, World.GY - 168*World.CS, A.name + " ready", "lvl"); }, 900);      // after LEVEL UP has drifted off
  if(!R.command && cmdOpen() && S.autoAb[tag] && !R.cmdNote){ R.cmdNote = true; caption("No Vanguard Command battles left today: tap your abilities yourself.", 3200, "#d9c2ff"); }
  if(!S.tips.abil){ S.tips.abil = 1; persist(); caption(`New ability: ${A.name}. Tap its button when you need it.`, 3600, TAGS[tag].color); }
  else if(R.command && !S.tips.hold){ S.tips.hold = 1; persist(); caption("Hold a button to make it automatic.", 3600, "#f2d796"); }      // taught once, the first time an ability appears after Command unlocks
  return true;
}
function abilTargets(R){ return aliveSorted().filter(e=>e.aggro && inView(e)); }
function castAbility(k){
  const R = run, a = R && R.abil[k]; if(!a || a.cd > 0 || R.over || R.paused || R.hero.hp <= 0) return false;
  const A = ABILITIES[a.tag], st = R.st, h = R.hero, tg = abilTargets(R), hx = World.HX, hy = World.GY - 60*World.CS;
  if(!A.def && (a.tag==="blade" ? !h.inCombat : a.tag==="storm" ? !tg.some(e=>e.x - h.x < 80) : !tg.length)) return false;                 // nothing to hit: keep it for the fight
  a.cd = a.max; R.slow = Math.max(R.slow||0, .2); haptic("MEDIUM"); R.abilUsed = (R.abilUsed||0) + 1;
  if(a.tag==="fire"){ SFX.fire(); SFX.slam(); World.shake(9*shakeK());
    tg.forEach(e=>{ const x = sxOf(e.x); World.beam(x, "#ff8a2a", 34, .6); World.burst(x, World.GY - 20, "#ffb04a", 26, 280, {a:-Math.PI/2, spread:1.8}); World.ring(x, World.GY - 10, "#ff8a2a", true, true); damageEnemy(e, st.dmg*3*R.dmgDealtMult, "fire"); }); }
  else if(a.tag==="storm"){ SFX.zap(); SFX.slam(); World.shake(7*shakeK()); World.ring(hx, hy, "#8ff0ff", true); World.ring(hx + 30, World.GY, "#8ff0ff", true, true);
    tg.filter(e=>e.x - h.x < 80).forEach(e=>{ World.bolt(sxOf(e.x), "#8ff0ff"); damageEnemy(e, st.dmg*1.5*R.dmgDealtMult, "zap"); if(!e.dead) e.stun = Math.max(e.stun, e.boss ? 1.2 : 2); }); }
  else if(a.tag==="bleed"){ const e = tg[0]; SFX.crit(); World.slash(sxOf(e.x), World.GY - 60*World.CS, "#ff5a64"); World.burst(sxOf(e.x), World.GY - 60*World.CS, "#ff2a3a", 26, 220);
    e.bleedDps = Math.min(e.bleedDps + st.dmg*6*R.dmgDealtMult/3, e.maxHp); e.bleedT = Math.max(e.bleedT, 3 + (hasPerk("bleed_long") ? 2 : 0)); e.flash = 1; }
  else if(a.tag==="blade"){ R.dance = 4; SFX.swing(); SFX.level(); World.whirl(hx, hy, "#dfe6f2"); World.ring(hx, hy, "#ffffff", true); }
  else if(a.tag==="holy"){ R.immune = Math.max(R.immune, 3); heal(st.maxHp*.15); SFX.holy(); World.beam(hx, "#ffe07a", 46, .9); World.ring(hx, hy, "#ffe07a", true); }
  else if(a.tag==="shield"){ R.immune = Math.max(R.immune, 3.5); SFX.block(); SFX.slam(); tg.filter(e=>e.x - h.x < 90).forEach(e=>{ damageEnemy(e, st.dmg*1.5*R.dmgDealtMult, "hit"); if(!e.dead) e.stun = Math.max(e.stun, e.boss ? .6 : 1.2); }); World.ring(hx, hy, "#9ad0ff", true); World.ring(hx, World.GY, "#9ad0ff", true, true); }
  World.num(hx, World.GY - 168*World.CS, A.name, "lvl");
  interruptTele(R);
  hudCache.ab = null; return true;
}
function tickAbilities(dt, alive, front){
  const R = run; if(R.immune > 0) R.immune -= dt; if(R.dance > 0) R.dance -= dt;
  if(!R.abil.length) return;
  for(let k=0;k<R.abil.length;k++){ const a = R.abil[k];
    if(a.cd > 0){ a.cd -= dt; if(a.cd <= 0){ a.cd = 0; SFX.ready(); } continue; }
    if(!autoCastOn(R, a.tag)) continue;
    // auto-cast: attacks as soon as the knight is fighting, shields once he is hurt. Close to good play, never better.
    const def = ABILITIES[a.tag].def;
    if(R.hero.inCombat && (!def || R.hero.hp < R.st.maxHp*.7)){ if(castAbility(k)) useCommand(R); }
  }
}
function fmtNum(n){ return n >= 10000 ? (n/1000).toFixed(1)+"K" : n.toLocaleString("en-US"); }

/* ---------- RENDER ---------- */
function syncEnemyView(e){
  const v = e.v; v.x = sxOf(e.x); v.atk = e.animP; v.walk = e.walk; v.walkAmt = e.walkAmt; v.flash = e.flash; v.kb = e.kb;
  v.tele = e.tele && !e.dead ? clamp(e.tele.t/e.tele.dur, .001, 1) : 0; v.teleCol = e.tele ? e.tele.col : null;
  v.dead = e.dead ? e.deathT/CORPSE_T : 0; v.hpFrac = e.hp/e.maxHp; v.aggro = e.aggro; v.bleed = e.bleedT>0; v.burn = e.burnT>0;
  return v;
}
const _view = { camX:0, camV:0, hero:null, enemies:[], projs:[], graves:[], finishX:null, t:0 };
function renderRun(dt, gdt, t){
  const R = run, h = R.hero, hv = R.hv;
  camPx = h.x*PX - World.HX;
  hv.x = World.HX; hv.atk = R.over ? null : h.animP; if(R.over) hv.runAmt = 0; hv.equip = Math.max(0, hv.equip - dt*1.4);
  hv.victory = R.over && R.result==="victory";
  const es = _view.enemies; es.length = 0;
  const list = R.enemies.slice().sort((a,b)=>a.x-b.x);
  for(const e of list) es.push(syncEnemyView(e));
  const ps = _view.projs; ps.length = 0;
  for(const p of R.proj) ps.push({x:sxOf(p.x), h:p.h, kind:p.kind, col:p.col, vx:p.vx});
  const gs = _view.graves; gs.length = 0;
  for(const g of R.graves) gs.push({x:sxOf(g.x), name:g.name, wave:g.wave, you:g.you});
  _view.finishX = R.mode!=="endless" ? sxOf(R.levelEnd) : null;
  const pr = _view.props = _view.props || []; pr.length = 0;
  for(const st of R.stops) if(st.kind==="event"){ const x = sxOf(st.x + 6); if(x > -160 && x < World.W + 160) pr.push({x, type:st.prop||st.type, open:st.open, done:st.done}); }
  // boss entrance: the camera pushes in on the boss
  _view.stage = false; if(R.intro){ const I = R.intro, k = Math.sin(clamp(I.t/I.dur,0,1)*Math.PI); _view.zoom = 1 + .16*k; _view.zx = lerp(World.W*.5, sxOf(I.e.x), .6); _view.zy = World.GY - 70; } else _view.zoom = 1;
  _view.camX = camPx; _view.camV = (!R.paused && !R.over) ? h.v*PX*R.speed : 0;
  _view.hero = hv; _view.t = t;
  World.frame(_view, dt, gdt);
}
const HERO_STAGE = 1.5;
function renderHome(dt, t){
  if(currentTab==="map") return;          // the painted map covers the world; save the battery
  if(!home.hv || home.dirty){ home.hv = {x:World.HX, skin:heroSkin(), walk:home.walk, walkAmt:1, atk:null, flash:0, kb:0, equip:home.hv?home.hv.equip:0, dead:0, victory:false, shieldUp:0}; home.dirty = false; }
  if(home.pvWalk > 0) home.pvWalk -= dt;                       // trying a skin on: the knight walks a few steps on the spot
  const hv = home.hv, onDoll = currentTab==="hero", still = onDoll && !(home.pvWalk > 0);
  const ax = onDoll ? heroDollX() : null;
  hv.x = Math.round(ax!=null ? ax : World.W*.22);
  hv.walkAmt = lerp(hv.walkAmt, still ? 0 : 1, 1 - Math.exp(-dt*8));
  const sp = 64*hv.walkAmt;
  home.camX += sp*dt; hv.walk += dt*sp*PX*strideK(0); hv.equip = Math.max(0, hv.equip - dt*1.2);
  /* Review 6: on the Hero tab the knight stands larger on a quiet stage (no landscape behind him) */
  _view.stage = onDoll; _view.zoom = onDoll ? (innerHeight < 400 ? HERO_STAGE - .15 : HERO_STAGE) : 1; _view.zx = hv.x; _view.zy = World.GY + 6;
  _view.camX = home.camX; _view.camV = sp; _view.hero = hv; _view.enemies.length = 0; _view.projs.length = 0; _view.graves.length = 0; if(_view.props) _view.props.length = 0; _view.finishX = null; _view.t = t;
  World.frame(_view, dt, dt);
}
function heroChanged(flash){ home.dirty = true; if(flash && home.hv){ home.hv.equip = 1; } if(run) run.hv.skin = heroSkin(); }

/* =====================================================================
   CARD PICK / SYNERGY
===================================================================== */
/* a payoff is only offered once its enabler is in the build */
const CARD_NEEDS = { hemorrhage:R=>R.cards.serrated, bloodprice:R=>R.cards.serrated, inferno:R=>R.cards.ember || setN("ember")>=3 };
const tutorialRun = R => R.mode==="campaign" && (R.cfg.tier||1)===1 && R.cfg.a===0 && R.cfg.i<=1 && S.stats.runs<=3;
/* offers are only steered on the first two levels of the game; after that the deck is honest and rerolls and bans are real decisions */
const guidedRun = R => R.mode==="campaign" && (R.cfg.tier||1)===1 && R.cfg.a===0 && R.cfg.i<=1;
const OWNED_TAG_W = .5, EVO_BASE_W = 9;
/* evolutions and legendary cards the build has earned and not yet taken */
function specialOffers(R){
  const out = [];
  for(const e of EVOS) if(!R.cards[e.id] && (R.cards[e.base]||0) >= 1 && e.gear(R)) out.push(e.id);
  for(const l of LEGENDS) if(!R.cards[l.id] && l.tags.every(t=>tagCount(t, R) >= 1) && l.tags.reduce((n,t)=>n + tagCount(t, R), 0) >= LEGEND_CARDS && (!R.oneTag)) out.push(l.id);
  return out;
}
function offerCards(){
  const R = run; let want = hasPower("eternity") ? 4 : 3; if(R.picks===0 && hasPerk("first_four")) want = 4; if(R.picks===0 && R.oath==="sight") want = 4;
  const pool = CARDS.filter(c=>!S.bans.includes(c.id) && (R.cards[c.id]||0) < 3 && (!R.oneTag || c.tag===R.oneTag || c.tag==="core") && (!CARD_NEEDS[c.id] || CARD_NEEDS[c.id](R)));
  const owned = SYN_TAGS.filter(t=>tagCount(t)>0);
  // first battle ever: three enablers that work right away, then a sure path to the first synergy
  if(tutorialRun(R) && R.cfg.i===0){
    if(R.picks===0){ const ids = ["edge","ember","chain"].filter(id=>pool.some(c=>c.id===id)); if(ids.length===3) return ids.concat(want>3?["keen"]:[]); }
    if(R.picks===1 && owned.length){ const same = pool.filter(c=>c.tag===owned[0] && !R.cards[c.id]).slice(0,2).map(c=>c.id); if(same.length){ const rest = pool.filter(c=>!same.includes(c.id) && c.tag==="core").slice(0,want-same.length).map(c=>c.id); return same.concat(rest); } }
  }
  const chosen = [];
  // an earned evolution or legendary card always takes the first seat of the next offer
  const sp = specialOffers(R); if(sp.length) chosen.push(sp[Math.floor(Math.random()*sp.length)]);
  const weightOf = c => { let w = 1; if(c.tag!=="core" && tagCount(c.tag)>0) w += OWNED_TAG_W; if(R.cards[c.id]) w += .6;
    const ev = EVO_OF[c.id]; if(ev && !R.cards[c.id] && !R.cards[ev.id] && ev.gear(R)) w += EVO_BASE_W;          // the gear for its evolution is worn: the card answers
    return w; };
  const avail = pool.slice();
  while(chosen.length<want && avail.length){ const tot = avail.reduce((a,c)=>a+weightOf(c),0); let x = Math.random()*tot, idx = 0;
    for(let i=0;i<avail.length;i++){ x -= weightOf(avail[i]); if(x<=0){ idx = i; break; } } chosen.push(avail.splice(idx,1)[0].id); }
  // on the first two levels every offer carries a card for a tag you already hold
  if(guidedRun(R) && owned.length && !chosen.some(id=>owned.includes(CARD_BY[id].tag))){ const alt = avail.filter(c=>owned.includes(c.tag)); if(alt.length) chosen[chosen.length-1] = pick(alt).id; }
  while(chosen.length<Math.min(3,want)) chosen.push("_heal");
  return chosen;
}
/* how well a card fits the build (used by auto-pick and the "fits your build" hint) */
function cardFit(id, R){
  if(id==="_heal") return R.hero.hp < R.st.maxHp*.45 ? 4 : 0; const c = CARD_BY[id]; if(c.evo || c.legend) return 30;
  const own = R.cards[id]||0, n = c.tag!=="core" ? tagCount(c.tag, R) : 0, tags = SYN_TAGS.filter(t=>tagCount(t, R)>0).length;
  if(c.tag==="core"){ if(own) return 1.2; if(id==="greed") return 1; const mt = mainTag(R), mn = mt ? tagCount(mt, R) : 0; return mn===1 || mn===2 ? 8 + mn : 2; }
  if(!own) return n===1 || n===2 ? 10 + n : n===0 ? (tags<2 ? 5 : .6) : 4;
  return 3 + (EVO_OF[id] ? 1 : 0);
}
const autoPickOn = R => !!(S.autoPick && R && R.command);
/* each ability is automatic or not on its own (S.autoAb[tag], switched by holding its button); only in battles that have Command */
const autoCastOn = (R, tag) => !!(R && R.command && S.autoAb && S.autoAb[tag]);
/* auto-pick (Vanguard Command): the card that best fits the build */
function autoPickAll(){
  const R = run; let n = 0; if(R.pendingLv>0) useCommand(R);
  while(R.pendingLv>0 && n++<10){ const off = offerCards();
    const id = off.slice().sort((a,b)=>(cardFit(b,R)+Math.random()*.3)-(cardFit(a,R)+Math.random()*.3))[0]; applyCard(id); R.pendingLv--; R.first = false;
    toast(`Auto-picked: ${id==="_heal"?"Field Rations":CARD_BY[id].name}`, id==="_heal"?"#5bd26a":TAGS[CARD_BY[id].tag].color); }
  updatePickBtn();
}
/* the skill button. Tap: open the waiting skills. Hold: switch auto-pick. Once Command is unlocked it stays on screen (dimmed when
   nothing waits), so there is always something to hold. */
function updatePickBtn(){ const R = run, b = $("#pickBtn"); if(!b || !R) return; const n = R.over ? 0 : R.pendingLv;
  b.classList.toggle("show", n>0 || (cmdOpen() && !R.over)); b.classList.toggle("idle", n<=0); b.classList.toggle("auto", autoPickOn(R));
  if(!b.querySelector(".hring")) b.insertAdjacentHTML("beforeend", HOLD_RING);
  const c = b.querySelector("b"); if(c) c.textContent = n; }
const tagIco = (t, size) => art(TAGS[t].icon, size||14, "tagi");
/* Review 6: key words in colour on a card: numbers and percentages gold, status words in their own colour */
const KW = {Bleed:"#ff6a6a", bleed:"#ff6a6a", Burn:"#ff9a3a", burn:"#ff9a3a", burns:"#ff9a3a", Stun:"#9ad0ff", stun:"#9ad0ff", stuns:"#9ad0ff", Block:"#9ad0ff", block:"#9ad0ff", barrier:"#9ad0ff", heal:"#6af08a", heals:"#6af08a", HP:"#6af08a", critical:"#ffd24a", crit:"#ffd24a", lightning:"#b9a4ff", poison:"#8ad86a"};
const KW_RE = new RegExp(`(<[^>]+>)|([+\u2212-]?\\d+(?:\\.\\d+)?%?(?:\\s?s\\b)?)|\\b(${Object.keys(KW).join("|")})\\b`, "g");
function kw(t){ return String(t).replace(KW_RE, (m, tagm, num, w)=> tagm ? tagm : num ? `<b class="kw">${num}</b>` : `<b class="kw" style="color:${KW[w]}">${w}</b>`); }
function cardHTML(id, k){
  if(id==="_heal") return `<button class="skill-card" style="--tc:#5bd26a" data-act="pickCard" data-k="${k}"><div class="sc-art">${art("heal",112)}</div><div class="sc-name">Field Rations</div><div class="sc-desc">${kw("Restore 35% HP")}</div></button>`;
  const c = CARD_BY[id];
  if(c.evo || c.legend){ const tag = TAGS[c.tag];
    return `<button class="skill-card special ${c.evo?'evo':'legend'}" style="--tc:${c.evo?'#f2c14e':tag.color}" data-act="pickCard" data-k="${k}">
      <span class="new-badge gold">${c.evo?'Evolution':'Legendary'}</span><div class="sc-art">${art(c.icon,112)}</div>
      <div class="sc-name">${c.name}</div><div class="sc-tag" style="color:${c.evo?TAGS[c.tag].color:tag.color}">${c.evo ? `${tagIco(c.tag)} ${CARD_BY[c.base].name} evolved` : c.tags.map(t=>`${tagIco(t)} ${TAGS[t].name}`).join(" + ")}</div>
      <div class="sc-desc">${kw(c.desc)}</div></button>`; }
  const r = run.cards[id]||0, nr = r+1, tag = TAGS[c.tag], val = c.v(nr, cardMult(id));
  let hint = "";
  if(c.tag==="core"){ const mt = run.coreTo[id] || mainTag(run), T2 = mt && TAGS[mt];
    if(r>0) hint = T2 ? `<div class="syn-hint mute">Counts as ${T2.name}</div>` : "";
    else if(!mt) hint = `<div class="syn-hint mute">Joins your first skill type</div>`;
    else { const after = tagCount(mt) + 1, ab = ABILITIES[mt], canAb = run.abil.length < MAX_ABIL && !run.abil.some(a=>a.tag===mt);
      hint = after===2 ? `<div class="syn-hint" style="color:${T2.color}">Counts as ${T2.name}: unlocks ${T2.name} II${canAb?` <b>+ ${ab.name}</b>`:""}</div>` : after===3 ? `<div class="syn-hint" style="color:${T2.color}">Counts as ${T2.name}: unlocks ${T2.name} III</div>` : `<div class="syn-hint" style="color:${T2.color}">Counts as ${T2.name} ${Math.min(after,3)}/3</div>`; } }
  if(c.tag!=="core"){
    const wait = r===0 ? Object.keys(run.coreTo).filter(k=>run.coreTo[k]==="").length : 0;      // Core skills waiting for a type join this one
    const n = tagCount(c.tag), after = n + (r===0?1:0) + (run.tagSeq.length ? 0 : wait), ab = ABILITIES[c.tag], canAb = run.abil.length < MAX_ABIL && !run.abil.some(a=>a.tag===c.tag);
    if(r===0 && n<2 && after>=3) hint = `<div class="syn-hint" style="color:${tag.color}">Unlocks ${tag.name} III: ${synLine(c.tag,3)}${canAb?`<br><b>+ ability: ${ab.name}</b>`:""}</div>`;
    else if(r===0 && after===2) hint = `<div class="syn-hint" style="color:${tag.color}">Unlocks ${tag.name} II: ${synLine(c.tag,2)}${canAb?`<br><b>+ ability: ${ab.name}</b>`:""}</div>`;
    else if(r===0 && after===3) hint = `<div class="syn-hint" style="color:${tag.color}">Unlocks ${tag.name} III: ${synLine(c.tag,3)}</div>`;
    else { const ev = EVO_OF[id]; hint = `<div class="syn-hint mute">${tag.name} cards ${Math.min(after,3)}/3${ev && !run.cards[ev.id] && ev.gear(run) ? ` · <b style="color:#f2c14e">evolves into ${ev.name}</b>` : ""}</div>`; }
  }
  const pips = "◆".repeat(nr) + `<span class="off">${"◆".repeat(3-nr)}</span>`;
  return `<button class="skill-card ${r===0?"fresh":"rankup"}" style="--tc:${tag.color}" data-act="pickCard" data-k="${k}">
    ${r===0?'<span class="new-badge">New</span>':'<span class="new-badge up">Rank up</span>'}
    <div class="sc-art">${art(c.icon,112)}</div>
    <div class="sc-name">${c.name}</div><div class="sc-tag" style="color:${tag.color}">${tagIco(c.tag)} ${tag.name}</div>
    <div class="sc-desc">${kw(c.text(val))}</div><div class="pips">${pips}</div>${hint}</button>`;
}
function openCardPick(why){
  const R = run; if(!R || R.over) return; if(R.cardModal && R.cardModal.parentNode) return; if(R.pendingLv<=0) return;
  R.paused = true; R.offer = offerCards();
  if(R.first) SFX.pick();
  const boss = why==="boss";
  const title = R.first ? "Choose your first skill" : boss ? "Prepare for the boss" : `Level ${R.lvl - R.pendingLv + 1}`;
  const sn = synState(R), focusNote = sn.focus ? `Focused Oath is active (+${FOCUS_DMG}% damage): keep to ${sn.tags===2?"these two tags":"two tags or fewer"}.` : sn.tags>2 ? `Three tags in the build: Focused Oath (+${FOCUS_DMG}% damage) is off.` : "";
  const sub = R.first ? "Your knight fights on his own. Your choices shape him. Two cards of one tag unlock its synergy and an ability." : boss ? `${R.pendingLv} skill${R.pendingLv>1?"s":""} waiting. Take them before the fight.` : focusNote || "Pick one skill. Cards that share a tag unlock synergies.";
  const html = `<div class="modal-title">${title}</div><div class="modal-sub">${sub}</div>
    <div class="card-row">${R.offer.map((id,k)=>cardHTML(id,k)).join("")}</div>
    <div class="mbtns center"><button class="btn ghost" data-act="reroll">${ico("dice",18)} ${R.rerolls>0 ? `Reroll (${R.rerolls} free)` : (adFree() ? "Reroll" : "Reroll · watch ad")}</button></div>`;
  R.cardModal = openModal(html, {noClose:true, wide:true, center:true}); Music.duck(true);
}
function applyCard(id){
  const R = run, h = R.hero; R.picks = (R.picks||0) + 1;
  if(id==="_heal"){ heal(R.st.maxHp*.35); return; }
  const C = CARD_BY[id], tag = C.tag; const was = synState(R).n, prevMax = R.st.maxHp, wasFocus = synState(R).focus;
  R.cards[id] = (R.cards[id]||0) + 1;
  coreBind(R, id);
  R.st = heroStats(R);
  if(R.st.maxHp > prevMax) h.hp += R.st.maxHp - prevMax; else if(h.hp > R.st.maxHp) h.hp = R.st.maxHp;
  if(id==="flask" && !R.mods.dry) R.potions++;
  if(C.evo || C.legend){ discover(id); showSpecialBanner(C); R.slow = .55; buildHudStatic(); return; }
  // a synergy can be reached by the skill itself or by a Core skill that joined its type
  const now = synState(R).n; let banner = false;
  for(const t of SYN_TAGS){ const b = was[t], a = now[t]; if(a===b) continue;
    if(b<2 && a>=2) grantAbility(t);
    if((b<3 && a>=3) || (b<2 && a>=2)){ showSynBanner(t, a>=3 ? 3 : 2); R.slow = .55; banner = true; } }
  const nowFocus = synState(R).focus;
  if(nowFocus && !wasFocus && !banner) World.num(World.HX, World.GY - 168*World.CS, "Focus bonus", "lvl");
  buildHudStatic();
}
/* Core skills join a skill type: the one held most when the Core skill is picked. A Core skill picked before any type is held
   waits and joins the first type that arrives. Once joined it stays, so a synergy is never lost by a later pick. */
function coreBind(R, id){
  const C = CARD_BY[id]; if(!C || C.evo || C.legend) return;
  if(C.tag==="core"){ if(R.coreTo[id]===undefined || R.coreTo[id]==="") R.coreTo[id] = mainTag(R); return; }
  if(!SYN_TAGS.includes(C.tag)) return;
  if(!R.tagSeq.includes(C.tag)) R.tagSeq.push(C.tag);
  for(const k in R.coreTo) if(R.coreTo[k]==="") R.coreTo[k] = C.tag;
}
/* the Skills tab shows evolutions and legendary cards as silhouettes until the player has found them once */
function discover(id){ if(!S.found.includes(id)){ S.found.push(id); persist(); } }
function showSynBanner(tag, n){
  const T = TAGS[tag], el = $("#synBanner");
  el.style.setProperty("--tc", T.color);
  const cp = $("#caption"); if(cp) cp.classList.remove("show");
  el.innerHTML = `<div class="sb">${tagIco(tag,22)} ${T.name} synergy ${n===2?"II":"III"}</div><div class="sbd">${synLine(tag, n)}</div>`;
  el.classList.remove("show"); void el.offsetWidth; el.classList.add("show"); SFX.syn(); haptic("HEAVY"); laneHold(2300);
}
function showSpecialBanner(C){
  const el = $("#synBanner"); el.style.setProperty("--tc", "#f2c14e");
  el.innerHTML = `<div class="sb">${C.evo ? "Evolution" : "Legendary"}: ${C.name}</div><div class="sbd">${C.desc}</div>`;
  el.classList.remove("show"); void el.offsetWidth; el.classList.add("show"); SFX.syn(); haptic("HEAVY"); laneHold(2300);
}

/* =====================================================================
   HUD
===================================================================== */
function buildHudStatic(){
  const R = run;
  // the stage card is one line plus the progress dots; the threat number lives on the pause screen
  $("#hudLevel").textContent = R.mode==="campaign" ? `${ACTS[R.cfg.a].short}-${R.cfg.i+1} ${R.title}` : R.title;
  const hn = $("#heroName"); if(hn) hn.textContent = knightName();
  let rl = $("#hudRules"); if(!rl){ rl = document.createElement("div"); rl.id = "hudRules"; $(".stage-card").appendChild(rl); }
  const chips = [];
  if(R.heat) chips.push(`<span class="heat" title="Enemies are stronger; gold and orbs are richer">${art("heat",16)}Heat ${R.heat}</span>`);
  if(R.mode==="trial" || R.mode==="weekly") for(const r in R.mods) if(TRIAL_RULES[r]) chips.push(`<span title="${TRIAL_RULES[r].text}">${art(TRIAL_RULES[r].icon,16)}${r==="oneTag"?`Only ${TAGS[R.mods.oneTag].name}`:TRIAL_RULES[r].name}</span>`);
  if(R.mode==="bounty") for(const a of R.cfg.b.aff) chips.push(`<span title="${AFFIXES[a].text}">${art("frenzy",16)}${AFFIXES[a].name}</span>`);
  if(R.resolve) chips.push(`<span class="boost" title="Each loss on this level makes the next try easier">${art("vigor",16)}Resolve +${R.resolve}%</span>`);
  for(const k in (R.boost||{})) if(R.boost[k]) chips.push(`<span class="boost">${art(BOOSTS[k].icon,16)}${BOOSTS[k].short}</span>`);
  rl.innerHTML = chips.join(""); rl.style.display = chips.length ? "" : "none";
  const segs = $("#hudProg");
  if(R.mode==="campaign" || R.mode==="challenge" || R.mode==="trial" || R.mode==="bounty"){
    const bossLvl = (R.mode!=="challenge" && R.cfg.i===4) || R.mode==="bounty";
    const packs = R.stops.filter(s=>s.kind==="pack"), lastPack = packs[packs.length-1];
    segs.innerHTML = R.stops.map(s=> s.kind==="event" ? `<span class="evm" data-x="${s.x}">${art(EVENTS[s.prop||s.type].icon,16)}</span>`
      : (bossLvl && s===lastPack) ? `<span class="boss">${art("skull",16)}</span>` : `<i><b></b></i>`).join("");
  } else if(R.mode==="endless" || R.mode==="weekly") segs.innerHTML = Array.from({length:10},()=>`<i><b></b></i>`).join("");
  else segs.innerHTML = "";
  const sn = synState(R); let syns = "";
  for(const t of SYN_TAGS){ const n = sn.n[t]; if(!n) continue; syns += `<button class="chip ${n>=2?'on':''}" style="--tc:${TAGS[t].color}" data-act="synInfo" data-t="${t}">${tagIco(t,14)}${TAGS[t].name} ${Math.min(n,3)}/3</button>`; }
  if(sn.focus) syns += `<button class="chip on focus" style="--tc:#f2c14e" data-act="focusInfo">Focused +${FOCUS_DMG}%</button>`;
  $("#hudSyn").innerHTML = syns;
  const ids = Object.keys(R.cards), compact = ids.length > 5;
  $("#hudCards").className = compact ? "compact" : "";
  $("#hudCards").innerHTML = ids.map(id=>{ const c = CARD_BY[id], sp = c.evo || c.legend; return `<button class="hud-mini ${sp?'special':''}" style="--tc:${sp?'#f2c14e':TAGS[c.tag].color}" data-act="cardInfo" data-id="${id}" aria-label="${c.name}">${art(c.icon, compact?28:34)}<span class="mp">${sp?"★":"◆".repeat(R.cards[id])}</span></button>`; }).join("");
  buildAbilBar(); updateCmdHud(); measureHud();
}
/* the ring every hold-to-toggle button carries: it fills while the finger is held and turns slowly once the button is automatic */
const HOLD_RING = `<svg class="hring" viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="18.5" pathLength="100"/></svg>`;
/* the two ability buttons above the card tray. Tap: cast now. Hold: switch that ability between manual and automatic (Review 5). */
function buildAbilBar(){
  const R = run, el = $("#abilBar"); if(!el || !R) return;
  if(!R.abil.length){ el.innerHTML = ""; el.className = ""; return; }
  el.className = "has" + (teleOpen(R) ? " window" : "");
  el.innerHTML = R.abil.map((a,k)=>{ const A = ABILITIES[a.tag], auto = autoCastOn(R, a.tag);
    return `<button class="abil ${auto?'auto':''}" id="abil${k}" style="--tc:${TAGS[a.tag].color}" data-act="cast" data-hold="holdAbil" data-k="${k}" aria-label="${A.name}: ${A.text}. ${auto?'Automatic':'Manual'}; hold to switch">${art(A.icon,46)}<i class="cdm"></i><em></em>${HOLD_RING}<span>${A.name}</span></button>`; }).join("");
  hudCache.ab = null;
}
function setSpeedBtn(){ const b = $("#speedBtn"), R = run; if(!b || !R) return; b.innerHTML = "×" + R.speed + (R.command ? "" : `<i class="lk">${ico("lock",10)}</i>`); b.classList.toggle("locked", !R.command); b.classList.toggle("cmd3", R.speed>1); }
/* the Command chip next to the speed button: the seal and the battles left (tap for details) */
function updateCmdHud(){
  const R = run, chip = $("#cmdChip"); if(!R || !chip) return;
  const un = cmdUnlimited(), left = cmdLeft(), open = cmdOpen();
  chip.innerHTML = `${art("seal",22)}<b>${!open ? ico("lock",12) : un ? "∞" : left}</b>`; chip.setAttribute("aria-label", !open ? "Vanguard Command unlocks when the Outlaw King falls" : un ? "Vanguard Command: unlimited" : `Vanguard Command: ${left} battles left today`);
  chip.classList.toggle("empty", open && !un && !R.command); chip.classList.toggle("locked", !open); chip.classList.toggle("live", !!R.cmdUsed);
  setSpeedBtn(); updatePickBtn();
}
/* where floating combat text may go: below the top HUD and right of the stage card, in world pixels */
function measureHud(){
  const c = $("#world"), card = $(".hud-tl"), tr = $(".hud-tr"); if(!c || !card) return;
  const cr = c.getBoundingClientRect(), r = card.getBoundingClientRect(), r2 = tr ? tr.getBoundingClientRect() : r; if(!cr.height || !r.height) return;
  const bb = $("#bossBar"), bbB = bb && bb.classList.contains("show") ? bb.getBoundingClientRect().bottom : 0;        // the boss bar sits in a second row under the HUD
  const k = World.H/cr.height; World.setTextBounds(Math.round((Math.max(r.bottom, r2.bottom, bbB) - cr.top)*k) + 8, 16, World.W - 16);
}
let hudCache = {};
function updateHud(force){
  const R = run, h = R.hero, st = R.st;
  const hp = Math.max(0, Math.ceil(h.hp)), pct = clamp(h.hp/st.maxHp,0,1)*100;
  const set = (k,v,fn)=>{ if(force || hudCache[k]!==v){ hudCache[k]=v; fn(v); } };
  set("hp", hp+"/"+st.maxHp, v=>{ $("#hpText").textContent = `${fmt(hp)} / ${fmt(st.maxHp)}`; $("#hpFill").style.width = pct+"%"; $("#hpFill").classList.toggle("low", pct<35); });
  set("bar", Math.round(clamp((R.barrier||0)/st.maxHp,0,1)*100), v=>{ const b = $("#barFill"); if(b) b.style.width = v+"%"; });
  set("imm", R.immune>0 ? 1 : R.dance>0 ? 2 : 0, v=>{ const bx = $(".hpbox"); if(bx){ bx.classList.toggle("immune", v===1); bx.classList.toggle("dance", v===2); } });
  set("potwarn", (pct<35 && R.potions>0 && h.hp>0) ? 1 : 0, v=>{ $("#potBtn").classList.toggle("warn", !!v); });
  set("xp", Math.round(R.xp/R.xpNeed*100), v=>{ $("#xpFill").style.width = v+"%"; });
  set("lv", R.lvl, v=>{ $("#hudLv").textContent = v; });
  set("pot", R.potions, v=>{ $("#potN").textContent = v; $("#potBtn").classList.toggle("empty", v<=0); });
  set("gold", R.gold, v=>{ $("#runGold").textContent = fmt(v); });
  set("kills", R.kills, v=>{ $("#runKills").textContent = v; });
  const wv = $("#hudWave");
  if(R.mode==="raid"){ set("wave", Math.ceil(R.timeLeft), v=>{ wv.innerHTML = `<b class="${v<=10?'warn':''}">${Math.floor(v/60)}:${String(v%60).padStart(2,"0")}</b> · ${fmt(R.raidDmg)} damage`; }); }
  else if(R.mode==="arena"){ set("wave", 1, ()=>{ wv.textContent = `${S.arena.trophies} trophies`; }); }
  else if(R.mode==="weekly"){ const segs = $("#hudProg").children;
    set("prog", (R.rungN||0) + "|" + (R.tire ? 1 : 0), ()=>{ const done = (R.rungN||0)%10; for(let i=0;i<segs.length;i++){ const b = segs[i].firstChild; if(b && b.style) b.style.width = i<done ? "100%" : "0%"; }
      wv.innerHTML = `Rung ${(R.rungN||0)+1} · Best ${Math.max(weeklyState().best, R.rungN||0)}${R.tire ? ` · <b class="warn">tiring</b>` : ""}`; }); }
  else if(R.mode!=="endless"){
    const passed = R.waveX.filter(x=>h.x >= x + 10).length, segs = $("#hudProg").querySelectorAll("i"), evs = $("#hudProg").querySelectorAll(".evm");
    set("prog", Math.round(clamp(h.x/R.levelEnd,0,1)*100) + "|" + passed, ()=>{
      for(let i=0;i<segs.length;i++){ const b = segs[i].firstChild; if(!b) continue; const x0 = i ? R.waveX[i-1] : 0, x1 = R.waveX[i]; b.style.width = clamp((h.x - x0)/(x1 - x0),0,1)*100 + "%"; }
      evs.forEach(el=>el.classList.toggle("done", h.x >= +el.dataset.x - 9)); });
    if(R.mods.timed) set("wave", "t"+Math.ceil(R.timeLeft), ()=>{ const v = Math.ceil(R.timeLeft); wv.innerHTML = `<b class="${v<=20?'warn':''}">${Math.floor(v/60)}:${String(v%60).padStart(2,"0")}</b> left`; });
    else if(R.mode==="rush") set("wave", "r"+(R.rushN||0), ()=>{ wv.textContent = `Bosses down: ${R.rushN||0} · Best ${S.rush.best||0}`; });
    else set("wave", R.mode, ()=>{ wv.textContent = ""; });
  } else {
    const cur = (R.cleared||0)+1, segs = $("#hudProg").children;
    set("prog", cur, v=>{ const done = (R.cleared||0)%10; for(let i=0;i<segs.length;i++){ const b = segs[i].firstChild; if(b && b.style) b.style.width = i<done ? "100%" : "0%"; } wv.textContent = `Wave ${v} · Best ${S.endlessBest}`; });
  }
  // ability cooldowns
  if(R.abil.length){ const key = R.abil.map(a=>Math.ceil(a.cd*4)).join("|") + (R.paused?"p":"");
    set("ab", key, ()=>{ R.abil.forEach((a,k)=>{ const el = $("#abil"+k); if(!el) return; const p = a.cd>0 ? a.cd/a.max : 0; el.classList.toggle("ready", p<=0); el.style.setProperty("--p", (p*100).toFixed(1)+"%"); const em = el.querySelector("em"); if(em) em.textContent = a.cd>0 ? Math.ceil(a.cd) : ""; }); }); }
  set("tele", teleOpen(R) ? 1 : 0, v=>{ const ab = $("#abilBar"); if(ab) ab.classList.toggle("window", !!v); });
  // boss bar
  const boss = R.enemies.find(e=>e.boss && e.aggro && !e.dead);
  if(R.lootQ && R.lootQ.length && !lootWait(R)) flushLoot(R);
  set("boss", boss ? Math.ceil(boss.hp/boss.maxHp*200) : -1, v=>{ const bb = $("#bossBar"), was = bb.classList.contains("show"); if(v<0){ bb.classList.remove("show"); if(was) measureHud(); return; } bb.classList.add("show"); if(!was) measureHud(); $("#bossName").textContent = boss.name; $("#bossFill").style.width = (v/2)+"%"; });
  // coins fly to the gold counter
  if(force || !hudCache._ct){ const r = $("#pillGold").getBoundingClientRect(); if(r.width){ World.setCoinTarget((r.left + 14)/window.innerWidth*World.W, (r.top + r.height/2)/window.innerHeight*World.H); hudCache._ct = 1; } }
}

/* =====================================================================
   RUN END
===================================================================== */
function victory(){
  const R = run; if(R.over) return; R.over = true; R.result = "victory"; R.hpLeft = clamp(R.hero.hp/R.st.maxHp, 0, 1);
  closeAllModals(); laneReset(); flushLoot(R);
  if(R.mode==="arena" || R.mode==="raid" || ladderMode(R)){ modeEnd(R, true); return; }
  SFX.win(); haptic("HEAVY"); S.stats.wins++; passXP(PASS_XP_FOR.win);
  { const sn = synState(R), n2 = SYN_TAGS.filter(t=>sn.n[t]>=2).length;                       // the day's choice quests
    if(n2>=2) S.stats.syn2 = (S.stats.syn2||0) + 1; if(sn.tags===1 && Object.keys(R.cards).length>=3) S.stats.focusWins = (S.stats.focusWins||0) + 1;
    if(!R.potUsed && !R.mods.dry && R.st.potions>0) S.stats.dryWins = (S.stats.dryWins||0) + 1; if(R.mode==="campaign" && (R.heat||0)>=1) S.stats.heatWins = (S.stats.heatWins||0) + 1; }
  World.ring(World.HX, World.GY - 60*World.CS, "#f2c14e", true); World.burst(World.HX, World.GY - 110*World.CS, "#ffd86a", 30, 220, {up:80, g:140, life:1});     // the knight raises his sword
  if(R.pendingLv > 0){ R.gold += R.pendingLv*(10 + R.d*4); R.pendingLv = 0; updatePickBtn(); }      // skills never chosen are paid out in gold
  const t = R.cfg.tier || 1, d = R.d, first = R.mode==="campaign" && !isClearedT(t, R.cfg.a, R.cfg.i);
  const isBoss = (R.mode==="campaign" || R.mode==="trial") && R.cfg.i===4, heat = R.heat||0, hk = heatLoot(heat), ev = weekendEvent();
  const rw = { gold: Math.round((R.gold + 30 + d*14)*hk), orbs: Math.round((2 + Math.floor(d/3) + (first?5:0) + (isBoss?3:0))*(isBoss?2:1)*hk), gems: (first && isBoss) ? (t===1 ? 50 : 25) : 0, item:null, unlocks:[],
    frags:(R.frags||0) + (isBoss ? 3 : Math.random()<.4 ? 1 : 0), star: isBoss ? t : 0, dust: 0 };
  if(R.mods.hordeWk){ rw.gold *= 2; rw.orbs *= 2; rw.unlocks.push("Horde weekend: gold and orbs doubled"); }
  if(rw.frags > (R.frags||0)) rollFrags(rw.frags - (R.frags||0));
  if(R.mode==="trial" || R.mode==="bounty") finishSpecial(R, rw);
  if(R.mode==="challenge"){ const ch = CHALLENGES.find(c=>c.id===R.cfg.id); if(!S.challenges[ch.id]){ rw.orbs += ch.reward.orbs; rw.gems += ch.reward.gems; S.challenges[ch.id] = true; rw.unlocks.push(`Challenge complete: ${ch.name}`); }
    if(CHALLENGES.every(c=>S.challenges[c.id]) && !S.capes.includes("emberc")){ S.capes.push("emberc"); rw.unlocks.push("New cape: Emberfall"); } }
  // the very first win always drops a ring: an empty slot, so the first Equip is a clear upgrade
  const it = (S.stats.wins===1 && !S.equip.ring) ? genItem(d, 0, "ring") : lootDrop(R, d, isBoss); S.inv.push(it); rw.item = it;
  if(R.mode==="campaign" && t>1){ setClearedT(t, R.cfg.a, R.cfg.i);
    if(isBoss && R.cfg.a===LAST_ACT && S.oath.max===t){ S.oath.max = t+1; rw.unlocks.push(`Oath Tier ${tierName(t+1)} unlocked: the whole map again, stronger foes, better loot`); } }
  if(R.mode==="campaign" && t===1){ S.cleared[`${R.cfg.a}-${R.cfg.i}`] = true;
    if(isBoss && R.cfg.a===LAST_ACT && S.oath.max===1){ S.oath.max = 2; rw.unlocks.push("Oath Tier II unlocked: the whole map again, stronger foes, better loot"); }
    if(isBoss){ const cape = ["royal","ashen","sun","forge","starborn"][R.cfg.a]; if(!S.capes.includes(cape)){ S.capes.push(cape); rw.unlocks.push(`New cape: ${CAPES[cape].name}`); }
      if(R.cfg.a===0 && first) rw.unlocks.push("Heat unlocked: choose how hard each battle is, for richer loot");
      if(R.cfg.a<LAST_ACT){ if(first) S.selAct = R.cfg.a+1; rw.unlocks.push(`${ACTS[R.cfg.a+1].name} unlocked`); }
      if(first) R.storyAct = R.cfg.a; } }
  if(R.mode==="campaign") heatWon(R, rw);
  masteryWon(R, rw);
  S.gold += rw.gold; S.orbs += rw.orbs; S.gems += rw.gems; S.star += rw.star; S.dust += rw.dust; invGuard(); persist();
  R.rewards = rw; R.firstBossWin = R.mode==="campaign" && t===1 && R.cfg.a===0 && isBoss && first; R.bossWin = isBoss && R.mode==="campaign";
  setTimeout(()=>{ if(run===R) showResult(true); }, 1500);
}
function defeat(){
  const R = run; if(R.over) return; R.over = true; R.result = "defeat"; R.hero.hp = 0; R.intro = null;
  closeAllModals(); laneReset(); flushLoot(R);
  if(R.mode==="arena" || R.mode==="raid" || ladderMode(R)){ modeEnd(R, false); return; }
  SFX.lose(); haptic("HEAVY");
  setTimeout(()=>{ if(run===R) showResult(false); }, 1100);
}
/* What a won battle drops. Bosses, daily trials and bounties never give a Common item. Review 5: a boss beaten at Heat has a real
   chance of a Legendary (HEAT_LOOT.leg a Heat step, up to .cap), and from Heat 10 a small chance of a Mythic, so a late battle
   can still surprise. Mythic never drops below Heat 10 on Tier I. */
const HEAT_LOOT = {leg:.04, cap:.6, mythFrom:10, myth:.02, mythStep:.006};
function lootDrop(R, d, isBoss){
  const special = R.mode==="trial" || R.mode==="bounty", h = R.mode==="campaign" ? (R.heat||0) : 0; let minR = (isBoss || special) ? 1 : 0;
  if(isBoss && h>0){ if(h >= HEAT_LOOT.mythFrom && Math.random() < HEAT_LOOT.myth + HEAT_LOOT.mythStep*(h - HEAT_LOOT.mythFrom)) minR = 4; else if(Math.random() < Math.min(HEAT_LOOT.cap, HEAT_LOOT.leg*h)) minR = 3; }
  return genItem(d + Math.min(8, Math.floor(h/2)), minR);
}
function rewardTile(icon, val, label, cls){ return `<div class="reward ${cls||''}">${icon}<b>${val}</b><small>${label}</small></div>`; }
function itemTile(it){ return `<button class="reward item rb${it.r}" data-act="openItem" data-uid="${it.uid}"><img src="${itemIcon(it)}" alt=""><b class="rc${it.r}">${RARITY[it.r].name}</b><small>${it.set?"Set item":SLOT_DEF[it.slot].name}</small></button>`; }
/* how much power an item would add if worn */
function powerGain(it){ if(!it || isEquipped(it)) return 0; const prev = S.equip[it.slot], p0 = powerOf(heroStats(null)); S.equip[it.slot] = it.uid; const p1 = powerOf(heroStats(null)); S.equip[it.slot] = prev; return p1 - p0; }
/* the dropped item as the finale of the victory screen: its art, the power it adds, and Equip right there */
function lootReveal(it){ if(!it) return ""; const g = powerGain(it);
  return `<div class="loot rb${it.r}" style="--rc:${RARITY[it.r].color}"><div class="loot-art"><img src="${itemIcon(it)}" alt=""></div><div class="grow"><div class="lt rc${it.r}">${it.name}</div><div class="ld">${RARITY[it.r].name} ${SLOT_DEF[it.slot].name}${g>0?` · <b class="up-g">+${g} power</b>`:""}</div></div>
    ${g>0?`<button class="btn sm gold" data-act="equipLoot" data-uid="${it.uid}">Equip</button>`:`<button class="btn sm ghost" data-act="openItem" data-uid="${it.uid}">View</button>`}</div>`; }
function questLine(){ const q = S.quests.list.find(x=>!x.claimed && QUEST_BY[x.id] && questProg(x) < QUEST_BY[x.id].need) || S.quests.list.find(x=>!x.claimed);
  if(!q) return ""; const Q = QUEST_BY[q.id], n = questProg(q); return `<div class="qline">${art(Q.icon,20)} ${Q.text(Q.need)} <b>${fmt(Math.min(n,Q.need))}/${fmt(Q.need)}</b>${n>=Q.need?' · ready to claim':''}</div>`; }
function nextAfter(R){ if(R.mode!=="campaign") return null; const t = R.cfg.tier||1, nx = nextLevelT(t); return nx ? {a:nx.a, i:nx.i, tier:t} : null; }
/* upgrades the player can buy right now (training ranks, better gear, card levels) */
function upgradesAvailable(){ return META.filter(m=>S.meta[m.id]<m.max && S.gold>=metaCost(m)).length + SLOTS.filter(s=>bestUpgrade(s)).length + Math.min(3, CARDS.filter(c=>cardLv(c.id)<CARD_MAX && S.orbs>=orbCost(cardLv(c.id))).length); }
/* THE NEXT STEP — after a defeat the game names one concrete thing the player can afford right now and does it in one tap.
   Order: wear better gear, then the best power for the gold (a training rank or a forge), then a card they just used. */
function nextStep(R){
  const p0 = powerOf(heroStats(null));
  let best = null; for(const sl of SLOTS){ const u = slotUpgrade(sl); if(u && (!best || u.gain > best.gain)) best = u; }
  if(best){ const it = itemById(best.uid); return {kind:"equip", uid:it.uid, icon:`<img src="${itemIcon(it)}" alt="">`, text:`Equip ${it.name}`, gain:best.gain, btn:"Equip"}; }
  let buy = null;
  for(const m of META){ if(S.meta[m.id]>=m.max) continue; const c = metaCost(m); if(S.gold < c) continue; S.meta[m.id]++; const g = powerOf(heroStats(null)) - p0; S.meta[m.id]--; if(g>0 && (!buy || g/c > buy.v)) buy = {v:g/c, kind:"train", id:m.id, icon:art(m.icon,34), text:`Train ${m.name}`, gain:g, cost:c, cur:"gold"}; }
  for(const sl of SLOTS){ const it = equipped(sl); if(!it || it.upg>=FORGE_MAX) continue; const c = forgeCost(it); if(S.gold < c) continue; it.upg++; const g = powerOf(heroStats(null)) - p0; it.upg--; if(g>0 && (!buy || g/c > buy.v)) buy = {v:g/c, kind:"forge", uid:it.uid, icon:`<img src="${itemIcon(it)}" alt="">`, text:`Forge ${it.name} to +${it.upg+1}`, gain:g, cost:c, cur:"gold"}; }
  if(buy){ buy.btn = `${CUR.gold} ${fmt(buy.cost)}`; return buy; }
  const used = Object.keys((R && R.cards)||{}).filter(id=>CARD_BY[id] && !CARD_BY[id].evo && !CARD_BY[id].legend).sort((a,b)=>R.cards[b]-R.cards[a]);
  const cu = used.concat(CARDS.map(c=>c.id)).find(id=>cardLv(id)<CARD_MAX && S.orbs>=orbCost(cardLv(id)));
  if(cu){ const c = CARD_BY[cu]; return {kind:"card", id:cu, icon:art(c.icon,34), text:`Upgrade ${c.name} to level ${cardLv(cu)+1}`, note:"stronger every time it is offered", cost:orbCost(cardLv(cu)), btn:`${CUR.orbs} ${orbCost(cardLv(cu))}`}; }
  return null;
}
function stepHTML(R){
  const st = nextStep(R);
  if(st) return `<div class="step"><span class="step-i">${st.icon}</span><div class="grow"><small>Next step</small><b>${st.text}</b>${st.gain?`<em class="up-g">+${st.gain} power</em>`:st.note?`<em>${st.note}</em>`:""}</div><button class="btn sm gold" data-act="stepDo" data-kind="${st.kind}" data-id="${st.id||""}" data-uid="${st.uid||""}">${st.btn}</button></div>`;
  return `<div class="step tipstep"><span class="step-i">${art("skills",34)}</span><div class="grow"><small>Next step</small><b>${buildAdvice(R)}</b></div></div>`;
}
/* when nothing is affordable: a build suggestion from what this level's enemies are weak to */
function buildAdvice(R){
  if(R && R.heat>0) return `Step down to Heat ${R.heat-1}, or change your build.`;
  const act = R && R.cfg && ACTS[R.cfg.a]; const weak = {};
  if(act) for(const t of new Set(act.pool.concat(R.cfg.i===4 ? [act.boss] : []))) for(const el of enemyMods(t)[0]) weak[el] = (weak[el]||0) + 1;
  const top = Object.keys(weak).filter(k=>k!=="phys").sort((a,b)=>weak[b]-weak[a])[0];
  const sn = R ? synState(R) : null;
  if(top) return `These enemies are weak to ${ELEM_NAME[top]}. Build ${TAGS[ELEM_TAG[top]].name} cards and keep to two tags.`;
  if(sn && sn.tags>2) return "Keep to two tags: Focused Oath adds +20% damage and both synergies grow faster.";
  return "Stack two tags to unlock their synergies and both abilities.";
}
function showResult(won){
  const R = run; if(!R) return; Music.duck(true); document.body.classList.add("run-done"); countRunGold(R);     // the skill bar and synergy chips step back behind the result card
  const time = `${Math.floor(R.time/60)}:${String(Math.floor(R.time%60)).padStart(2,"0")}`;
  if(won){
    const rw = R.rewards, nx = nextAfter(R), veryFirst = S.stats.wins===1 && R.mode==="campaign";
    const tiles = [rewardTile(CUR.gold, fmt(rw.gold), "Gold"), rewardTile(CUR.orbs, rw.orbs, "Orbs"), rw.gems?rewardTile(CUR.gems, rw.gems, "Gems"):"", rw.frags && runesOpen()?rewardTile(art("frag",32), rw.frags, rw.frags===1?"Fragment":"Fragments"):"", rw.star?rewardTile(art("starmetal",32), rw.star, "Starmetal"):"", rw.dust?rewardTile(art("dust",32), rw.dust, "Dust"):"", rw.extra||""].filter(Boolean);
    const heatLine = R.heat ? ` · Heat ${R.heat} (+${Math.round((heatLoot(R.heat)-1)*100)}% gold and orbs)` : "";
    const html = `<div class="modal-title big">Victory</div><div class="modal-sub">${R.title} cleared · ${R.kills} enemies · ${time}${heatLine}${veryFirst?`<br><i>The trail of the vanished King leads on.</i>`:""}</div>
      <div class="vic-row"><div class="reward-row">${tiles.join("")}</div>${lootReveal(rw.item)}</div>
      ${rw.unlocks.map(u=>`<div class="unlock">${ico("star",14)} ${u}</div>`).join("")}${questLine()}
      <div class="mbtns row"><button class="btn purple" data-act="doubleLoot">${adFree()?"":ico("video",18)} Double loot</button>
        ${R.bossWin && canShare() ? `<button class="btn ghost" data-act="shareWin">${ico("star",16)} Share</button>` : ""}
        ${nx && !veryFirst?`<button class="btn ghost" data-act="claim">Map</button><button class="btn gold" data-act="nextLevel" data-a="${nx.a}" data-i="${nx.i}" data-t="${nx.tier}">${ico("swords",18)} Next level</button>`:`<button class="btn gold" data-act="claim">${veryFirst?"To the map":"Continue"}</button>`}</div>`;
    R.resultModal = openModal(html, {noClose:true, center:true, wide:!!rw.item});
    tiles.forEach((_,k)=>setTimeout(()=>SFX.coin(), 120 + k*90)); if(rw.item) setTimeout(()=>{ SFX.pick(); if(rw.item.r>=3) haptic("HEAVY"); }, 200 + tiles.length*90);
  } else {
    const endless = R.mode==="endless", waves = R.cleared||0;
    let rw;
    if(!R.pendingDefeatRewards){          // computed once (the screen can be rebuilt after a "next step")
      if(endless){ const newBest = waves > S.endlessBest; if(newBest){ const shards = Math.floor(waves/25) - Math.floor(S.endlessBest/25); if(shards>0) addShards(shards*2); S.endlessBest = waves; }
        const was = R.wavesBanked||0; S.stats.waves += waves - was; passXPEndless((Math.floor(waves/5) - Math.floor(was/5))*PASS_XP_FOR.waves5); R.wavesBanked = waves;      // after a revive only the new waves count
        rw = {gold: R.gold + endlessWaveGold(waves), orbs: Math.floor(waves/2), gems:0, item: waves>=5 ? genItem(1+waves*.5, waves>=15?1:0) : null, newBest, unlocks:[]};
        if(S.endlessBest>=15 && !S.capes.includes("frost")){ S.capes.push("frost"); rw.unlocks.push("New cape: Frostbound"); } persist(); }
      else { // a loss still counts: everything looted plus a share of the level's reward for how far you got
        const prog = clamp(R.hero.x/R.levelEnd, 0, 1), d = R.d;
        rw = {gold: R.gold + Math.round((30 + d*14)*prog*.6), orbs: Math.floor(R.kills/6) + Math.round((2 + d/3)*prog), gems:0, item:null, unlocks:[]};
        const key = `${R.cfg.tier||1}:${R.cfg.a}-${R.cfg.i}`; S.fails = S.fails || {}; if(!R.noResolve) S.fails[key] = (S.fails[key]||0) + 1; R.failsHere = S.fails[key]||0;       // giving up in the first seconds earns no Resolve
        if(R.mode==="campaign") heatLost(R); }
      R.rewards = rw; R.pendingDefeatRewards = true;
    } else rw = R.rewards;
    const ups = upgradesAvailable(), canRevive = !R.revived && !R.banked && R.mode!=="trial" && R.mode!=="bounty";
    if(canRevive && !S.tips.fall && !endless){ S.tips.fall = 1; R.freeRevive = true; persist(); }      // the first defeat ever: the revive is free (this once)
    const firstFall = canRevive && !!R.freeRevive;
    const aid = !endless && R.failsHere>=2 && Monetization.storeReady() && !S.starterBought && !S.offersSeen.aid && S.cleared["0-4"];
    const nextRes = R.mode==="campaign" ? resolveFor(R.cfg.tier||1, R.cfg.a, R.cfg.i) : 0;
    const html = `<div class="modal-title big red">You have fallen</div>
      <div class="modal-sub">${endless ? `Reached wave ${waves+1}${rw.newBest?" · New best!":` · Your best: wave ${S.endlessBest+1}`}` : `${Math.round(clamp(R.hero.x/R.levelEnd,0,1)*100)}% of ${R.title} · ${time}`}${firstFall?`<br><i>“The Vanguard never falls twice.”</i>`:""}</div>
      <div class="def-cols"><div><div class="keep-h">You keep</div><div class="reward-row">${rewardTile(CUR.gold, fmt(rw.gold), "Gold")}${rewardTile(CUR.orbs, rw.orbs, "Orbs")}${rw.item?itemTile(rw.item):""}</div></div>
        <div class="def-side">${!endless ? `<div id="stepBox">${stepHTML(R)}</div>` : ""}
          ${nextRes ? `<div class="resolve-line">${art("vigor",18)} Next try: <b>+${nextRes}% Resolve</b> (damage and health)</div>` : ""}
          ${R.mode==="campaign" && R.heat>0 ? `<button class="linkbtn heat-down" data-act="retry" data-heat="${heatLower(R.heat)}">${art("heat",16)} Too hot? Retry at Heat ${heatLower(R.heat)}</button>` : ""}
          ${R.timeUp?`<div class="tip">The clock ran out. Faster skills (Tempest, Twin Strike) help against the clock.</div>`:""}</div></div>
      ${rw.unlocks.map(u=>`<div class="unlock">${ico("star",14)} ${u}</div>`).join("")}
      ${aid?`<div class="aid" style="background-image:url(img/banner_squire.jpg)"><div class="aid-in"><b>Knight's aid</b><span>A one-time boost to get past this wall.</span>${rchips(PRODUCTS.squire.contents, 22)}</div><button class="btn gold" data-act="iap" data-k="squire">${Monetization.price("squire")}</button></div>`:""}
      <div class="mbtns row">${canRevive?`<button class="btn green ${firstFall?'glow':'countdown'}" data-act="revive" ${firstFall?'data-free="1"':''}>${firstFall ? "Rise again · free" : `${adFree()?"":ico("video",18)} Revive`}</button>`:""}
      ${!endless && ups?`<button class="btn" data-act="upgradeNow">${art("might",20)} Upgrades <i class="cnt">${ups>9?"9+":ups}</i></button>`:""}
      ${R.mode==="campaign"||R.mode==="challenge"?`<button class="btn ${firstFall?'':'gold'}" data-act="retry">${ico("play",16)} Retry</button>`:""}
      ${endless && rw.newBest && canShare() ? `<button class="btn ghost" data-act="shareWin">${ico("star",16)} Share</button>` : ""}
      <button class="btn ghost" data-act="retreat">Camp</button></div>`;
    if(aid){ S.offersSeen.aid = 1; persist(); }
    closeModal(R.resultModal);
    R.resultModal = openModal(html, {noClose:true, center:true, wide:true});
    const rb = R.resultModal.querySelector(".countdown"); if(rb) setTimeout(()=>rb.classList.add("late"), 5000);
  }
}
/* a leaderboard slice around the player: the top entry, then the player with neighbours they can beat */
function boardAround(list, n){ list.sort((a,b)=>b.v-a.v); list.forEach((r,i)=>r.rank = i+1); const me = list.findIndex(r=>r.you);
  const lo = clamp(me - Math.floor((n-1)/2), 1, Math.max(1, list.length - (n-1))), out = [list[0]].concat(list.slice(lo, lo + n - 1)); return out.filter((r,i)=>out.indexOf(r)===i); }
/* what a defeat pays is banked when the player leaves the screen, or at once if he takes a "next step" (then there is no revive) */
function bankDefeat(R){ if(!R.pendingDefeatRewards || R.banked) return; const rw = R.rewards; S.gold += rw.gold; S.orbs += rw.orbs; if(rw.item) S.inv.push(rw.item); R.banked = true; }
/* the battle's gold counts toward quests once, when the result card opens (so its quest line is already up to date), and again at the end for gold won after a revive */
function countRunGold(R){ const c = R.goldCounted || 0; if(R.gold > c){ S.stats.goldEarned += R.gold - c; R.goldCounted = R.gold; } }      // a revive goes on earning: only the new gold is added
function finishRun(opt={}){
  const R = run; if(!R) return;
  if(R.pendingDefeatRewards){ bankDefeat(R); R.pendingDefeatRewards = false; }
  S.lastSpeed = R.speed; countRunGold(R); S.pendingRun = null;
  if(R.mode!=="arena") rollMapLoot(R);
  GameCenter.sync(); if(Cloud.recheck){ Cloud.recheck = false; setTimeout(()=>Cloud.check(), 800); }
  LUCK = false; invGuard(); persist(); closeAllModals(); laneReset(); run = null; Music.duck(false);
  if(opt.then){ opt.then(); return; }
  showScreen("home"); setWorldTheme(homeTheme()); home.dirty = true; renderAll();
  if(R.mode==="arena") openArena(); else if(R.mode==="raid") openRaid(); else if(R.mode==="rush") openRush(); else if(R.mode==="weekly"){ keepTab = "weekly"; openKeep(); } else if(R.mode==="bounty"){ keepTab = "bounty"; openKeep(); } else if(R.mode==="trial"){ keepTab = "trial"; openKeep(); }
  else afterBattle(R);
}
