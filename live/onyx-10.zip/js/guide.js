/* Onyx Vanguard — guide.js
   The first session and the things around it: naming the knight, one lesson per win (coach marks),
   the welcome-back chest and the share card.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   THE KNIGHT'S NAME — asked once, after the first win
===================================================================== */
const NAME_IDEAS = ["Ser Alaric","Dame Ysolt","Ser Corwin","Dame Brenna","Ser Tobias","Dame Elowen","Ser Gareth","Dame Rhosyn","Ser Lucan"];
const cleanName = v => String(v||"").replace(/[<>&"'`\\]/g, "").replace(/\s+/g, " ").trim().slice(0, 14);
let nameAfter = null;
function openNameModal(after){
  nameAfter = after || null;
  const ideas = NAME_IDEAS.slice().sort(()=>Math.random()-.5).slice(0,3);
  openModal(`<div class="modal-title">Name your knight</div><div class="modal-sub">The last of the Onyx Vanguard deserves a name. It shows in battle and in the Arena.</div>
    <div class="name-row"><input type="text" id="nameInp" maxlength="14" placeholder="Type a name" value="${cleanName(S.name)}" autocomplete="off" autocapitalize="words" spellcheck="false" aria-label="Knight's name"></div>
    <div class="name-ideas">${ideas.map(n=>`<button class="chip" data-act="nameIdea" data-v="${n}">${n}</button>`).join("")}</div>
    <div class="mbtns row"><button class="btn ghost" data-act="nameSkip">Keep “${knightName()}”</button><button class="btn gold" data-act="nameSet">That's the name</button></div>`, {noClose:true});
}
function nameDone(){ S.tips.named = 1; persist(); closeTopModal(); stripKey = ""; renderStrip(); const f = nameAfter; nameAfter = null; if(f) f(); }
Object.assign(ACTIONS, {
  nameIdea:(d)=>{ SFX.click(); const el = $("#nameInp"); if(el) el.value = d.v; },
  nameSet:()=>{ const el = $("#nameInp"), v = cleanName(el && el.value); if(!v){ toast("Type a name, or pick one below."); return; } S.name = v; SFX.pick(); nameDone(); toast(`${v} rides for the Vanguard.`, "#d0ab62"); },
  nameSkip:()=>{ SFX.click(); nameDone(); },
  rename:()=>{ SFX.click(); closeAllModals(); openNameModal(); }
});

/* =====================================================================
   ONE LESSON PER WIN — a callout that points at the thing to tap. Each shows once.
   Win 1: equip the drop. Win 2: training (the first rank is free). Win 3: the treasury (pre-filled so the first
   claim feels good). Win 5: card upgrades. The first map treasure gets a hint of its own.
===================================================================== */
const COACH = [
  {id:"equip", tab:"hero", when:()=>S.stats.wins>=1 && SLOTS.some(bestUpgrade), text:"New gear! Open Hero and equip it."},
  {id:"train", tab:"hero", when:()=>S.stats.wins>=2 && !S.tips.trained, text:"Your first training rank is free. Open Hero, then Training.", go(){ heroView = "train"; }},
  {id:"treasury", el:"#treasBtn", when:()=>S.stats.wins>=3, text:"Your Keep's treasury has been filling while you fought. Tap to collect.", pre(){ S.treasury = Math.min(S.treasury || Date.now(), Date.now() - 2*3.6e6); S.tips.c_treasury = 1; persist(); renderStrip(); }},
  {id:"cards", tab:"codex", when:()=>S.stats.wins>=5 && CARDS.some(c=>cardLv(c.id)<CARD_MAX && S.orbs>=orbCost(cardLv(c.id))), text:"You have Orbs. Upgrade a skill card in Skills to make it stronger in every battle."},
  {id:"loot", el:".mloot", when:()=>currentTab==="map" && (S.mapLoot||[]).length>0, text:"Treasure on the road! Tap it to collect."}
];
function coachClear(){ document.querySelectorAll(".coach").forEach(e=>e.remove()); document.querySelectorAll(".coached").forEach(e=>e.classList.remove("coached")); }
function coachNext(){
  if(run || $("#modalRoot").children.length || $(".coach")) return;
  const c = COACH.find(c=>!S.tips["c_"+c.id] && c.when()); if(!c) return;
  if(c.pre) c.pre();
  const target = c.el ? $(c.el) : document.querySelector(`.nav[data-t="${c.tab}"]`); if(!target) return;
  const r = target.getBoundingClientRect(); if(!r.width) return;
  S.tips["c_"+c.id] = 1; persist();
  // the home screen may be zoomed (iPad): positions inside it are in zoomed-out pixels
  const z = uiZoom(), vw = window.innerWidth/z, vh = window.innerHeight/z, cx = (r.left + r.width/2)/z;
  const below = r.top < window.innerHeight*.4, left = cx < vw*.5;
  const el = document.createElement("button"); el.className = `coach ${below?"below":"above"} ${left?"left":"right"}`; el.dataset.act = "coachGo"; el.dataset.id = c.id;
  el.innerHTML = `<span>${c.text}</span>`;
  el.style.cssText = (left ? `left:${Math.max(8, cx - 28)}px;` : `right:${Math.max(8, vw - cx - 28)}px;`) + (below ? `top:${r.bottom/z + 12}px;` : `bottom:${vh - r.top/z + 12}px;`);
  $("#homeScreen").appendChild(el); target.classList.add("coached");
  setTimeout(()=>{ if(el.parentNode) coachClear(); }, 14000);
}
ACTIONS.coachGo = (d)=>{ const c = COACH.find(x=>x.id===d.id); coachClear(); SFX.click(); if(!c) return;
  if(c.go) c.go(); if(c.tab) setTab(c.tab); else if(c.id==="treasury") openTreasury(); };
/* tapping anywhere else dismisses the callout (the tap still does what it would have done) */
document.addEventListener("pointerdown", e=>{ if($(".coach") && !e.target.closest(".coach")) setTimeout(coachClear, 60); }, true);

/* =====================================================================
   WELCOME BACK — away for 3 days or more (see returnReward in modes.js)
===================================================================== */
function openWelcomeBack(back){
  const html = `<div class="mode-head banner" style="background-image:url(${IMG("banner_keep")})">${art("keep",56)}<div><div class="modal-title">Welcome back, ${knightName()}</div><div class="modal-sub">${back.days} days away. The Keep held your share of the spoils.</div></div></div>
    <div class="reward-row">${grantBundle(back.bundle)}</div>
    <div class="mbtns row"><button class="btn gold big" data-act="backDone">To the road</button></div>`;
  SFX.win(); renderCurrencies(); closeAllModals(); openModal(html, {noClose:true});
}
ACTIONS.backDone = ()=>{ SFX.click(); closeAllModals(); renderAll(); setTimeout(()=>{ if(!run && loginReady() && !$("#modalRoot").children.length) openLogin(); }, 300); };

/* =====================================================================
   SHARE CARD — the knight, his build and the deed as one image. No server: the system share sheet does the rest.
   The button only shows where sharing a file is supported.
===================================================================== */
function canShare(){ try{ return !!(navigator.share && navigator.canShare && navigator.canShare({files:[new File([new Blob(["x"])], "x.png", {type:"image/png"})]})); }catch(e){ return false; } }
function loadImg(src){ return new Promise((res, rej)=>{ const im = new Image(); im.onload = ()=>res(im); im.onerror = rej; im.src = src; }); }
async function shareCard(line, theme, tags){
  const W = 1200, H = 630, c = document.createElement("canvas"); c.width = W; c.height = H; const g = c.getContext("2d");
  try{ const bg = await loadImg(IMG("vista_"+theme)); const k = Math.max(W/bg.width, H/bg.height); g.drawImage(bg, (W - bg.width*k)/2, (H - bg.height*k)/2, bg.width*k, bg.height*k); }catch(e){ g.fillStyle = "#0c0812"; g.fillRect(0,0,W,H); }
  const sh = g.createLinearGradient(0,0,W,0); sh.addColorStop(0, "rgba(6,4,10,.2)"); sh.addColorStop(.45, "rgba(6,4,10,.55)"); sh.addColorStop(1, "rgba(6,4,10,.92)"); g.fillStyle = sh; g.fillRect(0,0,W,H);
  const sk = heroSkin(), url = World.portrait(gg=>{ World.drawRig(gg, sk, {ld:1, th:1.05, ph:-1, bth:1.2}, 0); }, 260, 300, 120, 285, 1.9), kn = await loadImg(url); g.drawImage(kn, 70, 60, 520, 600);
  g.textAlign = "left"; g.fillStyle = "#d0ab62"; g.font = `600 30px ${World.FONT}`; g.fillText("ONYX VANGUARD", 640, 150);
  g.fillStyle = "#f6ead2"; g.font = `700 68px ${World.FONT}`; g.fillText(knightName(), 640, 240, 520);
  g.fillStyle = "#e8d6c0"; g.font = `400 36px ${World.FONT}`; let ln = "", y = 310; for(const w of line.split(" ")){ if(g.measureText(ln + w).width > 500){ g.fillText(ln, 640, y); y += 46; ln = ""; } ln += w + " "; } g.fillText(ln, 640, y);
  let x = 640; for(const t of tags.slice(0,3)){ const im = await loadImg(artURL(TAGS[t].icon)); g.drawImage(im, x, y + 40, 96, 96); x += 112; }
  g.fillStyle = "#9a8fb0"; g.font = `400 24px ${World.FONT}`; g.fillText(`Power ${fmt(powerOf(heroStats(null)))}`, 640, 590);
  const blob = await new Promise(r=>c.toBlob(r, "image/png")); c.width = c.height = 0;
  await navigator.share({files:[new File([blob], "onyx-vanguard.png", {type:"image/png"})], title:"Onyx Vanguard", text:`${knightName()} ${line}`});
}
ACTIONS.shareWin = async ()=>{ const R = run; if(!R) return; SFX.click();
  const two = SYN_TAGS.filter(t=>tagCount(t, R)>=2).sort((a,b)=>tagCount(b,R)-tagCount(a,R)), tags = two.length ? two : SYN_TAGS.filter(t=>tagCount(t, R)>0);
  const line = R.mode==="endless" ? `reached wave ${S.endlessBest+1} of the Endless Descent.` : `defeated ${ENEMY[ACTS[R.cfg.a].boss].name}${R.heat?` at Heat ${R.heat}`:""}.`;
  try{ await shareCard(line, R.theme, tags); }catch(e){ /* the player closed the share sheet */ } };
