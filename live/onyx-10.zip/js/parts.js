/* Onyx Vanguard — parts.js
   Drawn body parts (Stage 1 of docs/art/plan.md): hand-drawn SVG plate armour that replaces the painted shapes of an
   "armor" rig. Drawings are in rig units with the joint at (0,0); colours are {placeholders} filled from the figure's
   look. Each filled drawing is rasterised once into a cached canvas (never per frame). Until it is ready, drawRig
   falls back to the painted shapes. */
"use strict";

const PART_K = 10;                       // pixels per rig unit in the cached image
/* box: [x, y, w, h] in units; the joint (or frame origin) is (0,0) */
const PARTS = {
  torso:{ box:[-19,-49,40,61], svg:`
    <defs>
      <linearGradient id="t" x1="-16" x2="18" y1="0" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{shD}"/><stop offset=".3" stop-color="{armD}"/><stop offset=".62" stop-color="{armM}"/><stop offset=".86" stop-color="{armL}"/><stop offset="1" stop-color="{hi}"/></linearGradient>
      <linearGradient id="tv" x1="0" x2="0" y1="-42" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#fff" stop-opacity=".16"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".32"/></linearGradient>
      <linearGradient id="ts" x1="0" x2="0" y1="0" y2="11" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{armM}"/><stop offset="1" stop-color="{shD}"/></linearGradient>
      <pattern id="mail" width="1.6" height="1.4" patternUnits="userSpaceOnUse"><circle cx=".8" cy=".7" r=".55" fill="none" stroke="{armM}" stroke-width=".28"/></pattern>
    </defs>
    <path d="M-11 -7 L11 -7 L12 9 L-12 9 Z" fill="{under}"/><path d="M-11 -7 L11 -7 L12 9 L-12 9 Z" fill="url(#mail)" opacity=".75"/>
    <path d="M-12.5 0 L-4 0 L-5 10.5 L-14 9.5 Z" fill="url(#ts)" stroke="{ink}" stroke-width=".55"/>
    <path d="M-11 0 C-16 -20 -15 -34 -14 -36 L-6 -42 L8 -42 L16 -35 C18 -22 12 -6 11 0 Z" fill="url(#t)"/>
    <path d="M-11 0 C-16 -20 -15 -34 -14 -36 L-6 -42 L8 -42 L16 -35 C18 -22 12 -6 11 0 Z" fill="url(#tv)"/>
    <path d="M3 -41 Q6.5 -25 4 -12" fill="none" stroke="{hi}" stroke-width="1.3" stroke-linecap="round" opacity=".75"/>
    <path d="M1.6 -41 Q4.6 -25 2.4 -12" fill="none" stroke="{shD}" stroke-width=".7" opacity=".7"/>
    <path d="M-13 -30 Q-2 -26 15 -30" fill="none" stroke="{shD}" stroke-width=".6" opacity=".55"/>
    <ellipse cx="9" cy="-29" rx="3.4" ry="6" fill="#fff" opacity=".2"/><ellipse cx="10" cy="-31" rx="1.1" ry="2.6" fill="#fff" opacity=".55"/>
    <path d="M-12.2 -10 Q0 -6.6 12.8 -10 L12.4 -6.8 Q0 -3.6 -12 -6.8 Z" fill="{armM}" stroke="{ink}" stroke-width=".5"/>
    <path d="M-11.6 -10 Q0 -6.6 12.4 -10" fill="none" stroke="{hi}" stroke-width=".45" opacity=".8"/>
    <path d="M-11 -6.4 Q0 -3.2 11.8 -6.4 L11.4 -3.8 Q0 -.8 -10.8 -3.8 Z" fill="{armD}" stroke="{ink}" stroke-width=".5"/>
    <path d="M-11 0 C-16 -20 -15 -34 -14 -36 L-6 -42 L8 -42 L16 -35 C18 -22 12 -6 11 0" fill="none" stroke="{ink}" stroke-width=".9" stroke-linejoin="round"/>
    <g fill="{trimL}" stroke="{ink}" stroke-width=".25"><circle cx="-11" cy="-33" r=".95"/><circle cx="13" cy="-33" r=".95"/><circle cx="-12" cy="-13" r=".95"/><circle cx="13" cy="-13" r=".95"/></g>
    <rect x="-12.4" y="-4.2" width="25" height="4.6" rx=".8" fill="#24170f" stroke="{ink}" stroke-width=".45"/>
    <path d="M-12 -3 L12.4 -3" stroke="#4a3220" stroke-width=".5"/>
    <rect x="-2.8" y="-4.8" width="5.6" height="5.8" rx=".7" fill="{trim}" stroke="{ink}" stroke-width=".5"/><rect x="-1.4" y="-3.4" width="2.8" height="3" fill="none" stroke="{trimD}" stroke-width=".6"/>
    <path d="M4 0.4 L13.6 -.6 L14.6 4.6 L5 5.4 Z" fill="url(#ts)" stroke="{ink}" stroke-width=".55"/>
    <path d="M4.6 5 L14.6 4.2 L15 9.6 L6 10.4 Z" fill="url(#ts)" stroke="{ink}" stroke-width=".55"/>
    <path d="M5 1.2 L13.4 .4 M5.4 5.8 L14.4 5" stroke="{hi}" stroke-width=".4" opacity=".7"/>
    <path d="M-6.4 -46.5 L6.6 -46.5 L7.6 -41 L-7.4 -41 Z" fill="{armM}" stroke="{ink}" stroke-width=".55"/>
    <path d="M-6.8 -44 L7.2 -44" stroke="{shD}" stroke-width=".6"/><path d="M-6 -46 L6.2 -46" stroke="{hi}" stroke-width=".4" opacity=".8"/>` },
  thigh:{ box:[-7,-7,14,34], svg:`
    <defs><linearGradient id="g" x1="-6" x2="6" y1="0" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{shD}"/><stop offset=".35" stop-color="{armD}"/><stop offset=".72" stop-color="{armL}"/><stop offset="1" stop-color="{armM}"/></linearGradient></defs>
    <path d="M-5.7 .5 C-6 -6.2 6.1 -6.2 5.9 .5 L4.6 22.5 Q0 24.4 -4.4 22.5 Z" fill="url(#g)" stroke="{ink}" stroke-width=".55" stroke-linejoin="round"/>
    <path d="M1.8 -1 Q2.6 10 1.6 21.5" fill="none" stroke="{hi}" stroke-width=".9" stroke-linecap="round" opacity=".7"/>
    <path d="M-5 6 Q0 4.6 5.4 6" fill="none" stroke="{ink}" stroke-width=".45" opacity=".7"/>
    <path d="M-4.6 17 Q0 15.8 4.9 17 L4.7 20 Q0 18.9 -4.5 20 Z" fill="{armM}" stroke="{ink}" stroke-width=".45"/>` },
  shin:{ box:[-6.5,-6,13,35], svg:`
    <defs><linearGradient id="g" x1="-5" x2="5" y1="0" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{shD}"/><stop offset=".35" stop-color="{armD}"/><stop offset=".72" stop-color="{armL}"/><stop offset="1" stop-color="{armM}"/></linearGradient>
      <radialGradient id="k" cx="1.5" cy="-1.5" r="6" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{hi}"/><stop offset=".45" stop-color="{armL}"/><stop offset="1" stop-color="{armD}"/></radialGradient></defs>
    <path d="M-4.2 0 Q0 -1.6 4.4 0 L3.5 25 Q0 26.6 -3.4 25 Z" fill="url(#g)" stroke="{ink}" stroke-width=".55" stroke-linejoin="round"/>
    <path d="M1.4 2 Q2 13 1.2 24" fill="none" stroke="{hi}" stroke-width=".8" stroke-linecap="round" opacity=".65"/>
    <path d="M-3.4 22 Q0 21 3.6 22" fill="none" stroke="{ink}" stroke-width=".45" opacity=".7"/>
    <path d="M3.6 -3.4 L6.2 -1 L4.4 2.4 Z" fill="{armM}" stroke="{ink}" stroke-width=".45"/>
    <ellipse cx="0.4" cy="-.6" rx="5.1" ry="4.4" fill="url(#k)" stroke="{ink}" stroke-width=".55"/>
    <path d="M-4.2 -1.4 Q0.4 -3.8 4.8 -1.4" fill="none" stroke="{ink}" stroke-width=".4" opacity=".6"/>
    <circle cx="1.6" cy="-.6" r=".85" fill="{trimL}" stroke="{ink}" stroke-width=".25"/>` },
  foot:{ box:[-6,-7,18,9], svg:`
    <defs><linearGradient id="g" x1="0" x2="0" y1="-6" y2="1" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{armL}"/><stop offset=".6" stop-color="{armD}"/><stop offset="1" stop-color="{shD}"/></linearGradient></defs>
    <path d="M-4.8 -5.4 L3.6 -4.6 Q7 -3.6 10.4 -.6 L10.4 .9 L-5.2 .9 Z" fill="url(#g)" stroke="{ink}" stroke-width=".55" stroke-linejoin="round"/>
    <path d="M1.4 -4.6 Q4.6 -3 6.4 -.4 M4.4 -3.6 Q7.2 -2.2 8.6 -.3" fill="none" stroke="{ink}" stroke-width=".4" opacity=".7"/>
    <path d="M-4.4 -4.8 L3.4 -4.1" stroke="{hi}" stroke-width=".5" opacity=".75"/>
    <rect x="-5.2" y=".1" width="15.6" height=".9" fill="#1a120c"/>` },
  uarm:{ box:[-5,-4,10,20], svg:`
    <defs><linearGradient id="g" x1="-4" x2="4" y1="0" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{shD}"/><stop offset=".4" stop-color="{armD}"/><stop offset=".78" stop-color="{armL}"/><stop offset="1" stop-color="{armM}"/></linearGradient></defs>
    <path d="M-4 -1.5 Q0 -3 4.2 -1.5 L3.5 13.4 Q0 14.6 -3.3 13.4 Z" fill="url(#g)" stroke="{ink}" stroke-width=".5" stroke-linejoin="round"/>
    <path d="M-3.8 4 Q0 3 4 4 M-3.6 8.5 Q0 7.5 3.8 8.5" fill="none" stroke="{ink}" stroke-width=".4" opacity=".65"/>
    <path d="M1.4 -1 L1.2 12.6" stroke="{hi}" stroke-width=".6" opacity=".6" stroke-linecap="round"/>` },
  farm:{ box:[-5,-5,10,20], svg:`
    <defs><linearGradient id="g" x1="-4" x2="4" y1="0" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{shD}"/><stop offset=".4" stop-color="{armD}"/><stop offset=".78" stop-color="{armL}"/><stop offset="1" stop-color="{armM}"/></linearGradient>
      <radialGradient id="k" cx="1" cy="-1" r="4.6" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{hi}"/><stop offset=".5" stop-color="{armL}"/><stop offset="1" stop-color="{armD}"/></radialGradient></defs>
    <path d="M-3.4 0 Q0 -1.2 3.6 0 L3 13.6 Q0 14.6 -2.8 13.6 Z" fill="url(#g)" stroke="{ink}" stroke-width=".5" stroke-linejoin="round"/>
    <path d="M-2.9 11 L3.1 11" stroke="{trim}" stroke-width=".9"/>
    <path d="M1.2 1 L1 10" stroke="{hi}" stroke-width=".55" opacity=".6" stroke-linecap="round"/>
    <ellipse cx="0.2" cy="0" rx="4.2" ry="3.7" fill="url(#k)" stroke="{ink}" stroke-width=".5"/>
    <path d="M-2.6 -1.6 L3 -1.6 L4.4 -.2" fill="none" stroke="{ink}" stroke-width=".35" opacity=".6"/>` },
  hand:{ box:[-5.5,-5.5,11,11], svg:`
    <defs><radialGradient id="k" cx="1" cy="-1.6" r="5" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{hi}"/><stop offset=".5" stop-color="{armL}"/><stop offset="1" stop-color="{armD}"/></radialGradient></defs>
    <path d="M-4 -3.6 Q-1 -4.8 3 -4 Q5 -2.6 4.8 .6 Q4.4 4 1 4.4 Q-3.6 4.6 -4.4 1.2 Z" fill="url(#k)" stroke="{ink}" stroke-width=".5" stroke-linejoin="round"/>
    <path d="M.6 -3.6 Q3.4 -2.4 3.4 .4 M-.8 -2.4 Q1.8 -1.2 1.8 1.6" fill="none" stroke="{ink}" stroke-width=".35" opacity=".65"/>` },
  pauldron:{ box:[-1,-47,23,22], svg:`
    <defs><linearGradient id="p" x1="1" x2="21" y1="-44" y2="-30" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{armD}"/><stop offset=".55" stop-color="{armL}"/><stop offset=".8" stop-color="{hi}"/><stop offset="1" stop-color="{armM}"/></linearGradient></defs>
    <path d="M1 -35 Q3 -45 11 -45 Q19.5 -44.5 20.5 -36 Q20 -32 17 -31 L3 -32.5 Z" fill="url(#p)" stroke="{ink}" stroke-width=".6" stroke-linejoin="round"/>
    <path d="M2.2 -32.6 Q10 -30.6 19.4 -33 L19 -29.6 Q10 -27.4 2.8 -29.6 Z" fill="{armM}" stroke="{ink}" stroke-width=".5"/>
    <path d="M3.2 -29.6 Q10 -27.6 18.4 -29.8 L17.6 -26.8 Q10 -24.8 3.8 -26.8 Z" fill="{armD}" stroke="{ink}" stroke-width=".5"/>
    <path d="M2.6 -32.4 Q10 -30.4 19.2 -32.8" fill="none" stroke="{trim}" stroke-width=".9"/>
    <path d="M6 -42.6 Q11 -44 16.6 -41.6" fill="none" stroke="#fff" stroke-width=".8" opacity=".55" stroke-linecap="round"/>
    <circle cx="4.2" cy="-34.6" r=".8" fill="{trimL}" stroke="{ink}" stroke-width=".25"/><circle cx="17.6" cy="-34.4" r=".8" fill="{trimL}" stroke="{ink}" stroke-width=".25"/>` }
};
/* colours for the drawings from a figure's look; `dim` darkens the far side of the body */
function partPal(sk, dim){
  const d = sk.armD || '#2c2e36', l = sk.armL || '#9aa0ae', tr = sk.trim || '#a88a5a', k = dim ? .38 : 0;
  const dk = c => k ? World.mix(c, '#000000', k) : c;
  return { armD:dk(d), armL:dk(l), armM:dk(World.mix(d, l, .5)), hi:dk(World.mix(l, '#ffffff', .45)), shD:dk(World.mix(d, '#000000', .35)),
    trim:dk(tr), trimL:dk(World.mix(tr, '#ffffff', .25)), trimD:dk(World.mix(tr, '#000000', .4)), under:dk(sk.under || '#1a1418'), ink:World.INK };
}
const partCache = new Map();
/* the ready image for a part in a palette, or null (and start drawing it) */
function partImg(name, pal){
  const key = name + '|' + pal.armD + pal.armL + pal.trim + pal.under; let e = partCache.get(key);
  if (e) return e.ready ? e.cv : null;
  const P = PARTS[name], [x, y, w, h] = P.box;
  e = { ready:false, cv:null }; partCache.set(key, e);
  if (typeof Image === 'undefined' || typeof document === 'undefined') return null;
  const body = P.svg.replace(/\{(\w+)\}/g, (_, v) => pal[v] || '#ff00ff');
  const src = `<svg xmlns="http://www.w3.org/2000/svg" width="${w * PART_K}" height="${h * PART_K}" viewBox="${x} ${y} ${w} ${h}">${body}</svg>`;
  const im = new Image();
  im.onload = () => { const cv = document.createElement('canvas'); cv.width = w * PART_K; cv.height = h * PART_K; cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height); e.cv = cv; e.ready = true; };
  im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(src);
  return null;
}
/* every part a figure needs, ready in both palettes? (a figure is drawn whole one way or the other, never mixed) */
const RIG_PARTS = ['torso', 'thigh', 'shin', 'foot', 'uarm', 'farm', 'hand', 'pauldron'];
function rigPartsReady(sk){
  if (sk.body !== 'armor' || sk.painted) return false;
  const a = partPal(sk, false), b = partPal(sk, true); let ok = true;
  for (const n of RIG_PARTS) { if (!partImg(n, a)) ok = false; if (!partImg(n, b)) ok = false; }
  return ok;
}
/* draw a part placed at a point (no rotation) or along a bone from a to b */
function drawPartAt(g, name, pal, x, y, rot){
  const cv = partImg(name, pal); if (!cv) return; const [bx, by, w, h] = PARTS[name].box;
  g.save(); g.translate(x, y); if (rot) g.rotate(rot); g.drawImage(cv, bx, by, w, h); g.restore();
}
/* along a bone; sx widens the part across the bone and the drawing is stretched to the bone's length, so a limb never
   leaves a gap at the next joint (PART_LEN: the bone length each drawing was made for) */
const PART_LEN = { uarm:13.4, farm:13.6, thigh:24, shin:26 };
function drawPartBone(g, name, pal, a, b, sx){
  const cv = partImg(name, pal); if (!cv) return; const [bx, by, w, h] = PARTS[name].box;
  const len = Math.hypot(b[0] - a[0], b[1] - a[1]), sy = PART_LEN[name] ? len / PART_LEN[name] : 1;
  g.save(); g.translate(a[0], a[1]); g.rotate(Math.atan2(b[1] - a[1], b[0] - a[0]) - Math.PI / 2); g.scale(sx || 1, sy); g.drawImage(cv, bx, by, w, h); g.restore();
}
