/* Onyx Vanguard — map.js
   The painted world map (Map tab). Painted once into one canvas (repainted only when progress or size changes);
   level nodes and landmarks are DOM buttons laid over it in map coordinates.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

const MAP_W = 2840, MAP_H = 500;
/* level nodes per act, in map coordinates (the 5th is the boss) */
const MAP_NODES = [
  [[120,300],[215,232],[300,318],[392,240],[492,188]],
  [[640,246],[730,322],[822,250],[912,326],[1012,226]],
  [[1190,240],[1286,316],[1382,238],[1476,306],[1592,206]],
  [[1772,292],[1866,218],[1962,306],[2058,228],[2166,196]],
  [[2346,286],[2440,212],[2536,300],[2634,222],[2748,198]]
];
const MAP_START = [44,258];
/* landmarks: other modes */
const MAP_MARKS = {
  keep:{x:132, y:150, name:"Vanguard Keep", sub:"Bounties & trials", act:"openKeep", icon:"keep"},
  arena:{x:196, y:420, name:"The Arena", act:"openArena", icon:"arena"},
  raid:{x:430, y:406, name:"Titan's Hollow", sub:"Raid", act:"openRaid", icon:"raid"},
  challenges:{x:790, y:156, name:"Trial Spire", sub:"Challenges", act:"openChallenges", icon:"challenges"},
  endless:{x:1090, y:404, name:"The Endless Descent", act:"openEndless", icon:"endless"}
};
const REGIONS = [
  {x0:0, x1:570, name:"THE KINGSROAD"},
  {x0:570, x1:1130, name:"THE HOLLOW CATHEDRAL"},
  {x0:1130, x1:1700, name:"THE FROSTVEIL"},
  {x0:1700, x1:2270, name:"THE EMBERFORGE"},
  {x0:2270, x1:2840, name:"THE ASTRAL SANCTUM"}
];
const REGION_COL = ["#f2d796", "#f2d796", "#eaf6ff", "#ffc08a", "#dcc8ff"];

/* ---------- small paint helpers ---------- */
const MP = {
  rgba(hex, a){ const n = parseInt(hex.slice(1),16); return `rgba(${n>>16&255},${n>>8&255},${n&255},${a})`; },
  mix(a, b, t){ const A = parseInt(a.slice(1),16), B = parseInt(b.slice(1),16); const c = s=>Math.round(((A>>s)&255)*(1-t) + ((B>>s)&255)*t);
    return "#"+[16,8,0].map(s=>c(s).toString(16).padStart(2,"0")).join(""); },
  blob(g, x, y, r, col, a){ const gr = g.createRadialGradient(x,y,0,x,y,r); gr.addColorStop(0, MP.rgba(col,a)); gr.addColorStop(1, MP.rgba(col,0)); g.fillStyle = gr; g.fillRect(x-r,y-r,r*2,r*2); },
  poly(g, pts){ g.beginPath(); g.moveTo(pts[0][0],pts[0][1]); for(let i=1;i<pts.length;i++) g.lineTo(pts[i][0],pts[i][1]); g.closePath(); },
  spaced(g, txt, x, y, sp){ let w = 0; for(const ch of txt) w += g.measureText(ch).width + sp; w -= sp; let cx = x - w/2; for(const ch of txt){ g.fillText(ch, cx, y); cx += g.measureText(ch).width + sp; } }
};
/* ground colour at a given x (regions blend into each other) */
function groundAt(x){
  const V = "#3a5a2c", G = "#2c2536", F = "#9fb2c6", E = "#3a1e16", A = "#1e1a3e";
  if(x < 520) return V; if(x < 620) return MP.mix(V, G, (x-520)/100);
  if(x < 1090) return G; if(x < 1190) return MP.mix(G, F, (x-1090)/100);
  if(x < 1650) return F; if(x < 1750) return MP.mix(F, E, (x-1650)/100);
  if(x < 2220) return E; if(x < 2320) return MP.mix(E, A, (x-2220)/100); return A;
}
/* smooth road through points (Catmull-Rom), returned as a dense polyline with the index of each source point */
function roadLine(pts){
  const out = [], idx = [];
  for(let i=0;i<pts.length-1;i++){
    const p0 = pts[Math.max(0,i-1)], p1 = pts[i], p2 = pts[i+1], p3 = pts[Math.min(pts.length-1,i+2)];
    idx[i] = out.length;
    for(let t=0;t<1;t+=.05){ const t2 = t*t, t3 = t2*t;
      out.push([.5*((2*p1[0]) + (-p0[0]+p2[0])*t + (2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2 + (-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
                .5*((2*p1[1]) + (-p0[1]+p2[1])*t + (2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2 + (-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)]); }
  }
  idx[pts.length-1] = out.length; out.push(pts[pts.length-1]);
  return {out, idx};
}
function strokeLine(g, pts, from, to){ g.beginPath(); g.moveTo(pts[from][0], pts[from][1]); for(let i=from+1;i<=to;i++) g.lineTo(pts[i][0], pts[i][1]); g.stroke(); }
function nearRoad(road, x, y, r){ for(let i=0;i<road.length;i+=2){ const dx = road[i][0]-x, dy = road[i][1]-y; if(dx*dx+dy*dy < r*r) return true; } return false; }

/* ---------- scenery ---------- */
function mTree(g, x, y, s, dark, light){
  g.fillStyle = "rgba(0,0,0,.28)"; g.beginPath(); g.ellipse(x+2*s, y+1, 8*s, 3*s, 0, 0, 7); g.fill();
  g.fillStyle = "#2a1c12"; g.fillRect(x-1.2*s, y-6*s, 2.4*s, 6*s);
  g.fillStyle = dark; g.beginPath(); g.arc(x-3.5*s, y-9*s, 5.5*s, 0, 7); g.arc(x+3.5*s, y-9*s, 5.5*s, 0, 7); g.arc(x, y-14*s, 6.5*s, 0, 7); g.fill();
  g.fillStyle = light; g.beginPath(); g.arc(x-2*s, y-15*s, 3.4*s, 0, 7); g.arc(x-5*s, y-10.5*s, 2.4*s, 0, 7); g.fill();
}
function mPine(g, x, y, s, dark, snow){
  g.fillStyle = "rgba(0,0,0,.25)"; g.beginPath(); g.ellipse(x+2*s, y+1, 7*s, 2.5*s, 0, 0, 7); g.fill();
  g.fillStyle = "#1e140e"; g.fillRect(x-1*s, y-4*s, 2*s, 4*s);
  for(let k=0;k<3;k++){ const yy = y - 3*s - k*6*s, w = (8 - k*2)*s;
    g.fillStyle = dark; MP.poly(g, [[x-w, yy], [x, yy-10*s], [x+w, yy]]); g.fill();
    if(snow){ g.fillStyle = snow; MP.poly(g, [[x-w*.45, yy-5.5*s], [x, yy-10*s], [x+w*.45, yy-5.5*s], [x, yy-7*s]]); g.fill(); } }
}
function mDeadTree(g, x, y, s){
  g.strokeStyle = "#140c18"; g.lineCap = "round"; g.lineWidth = 2.2*s;
  g.beginPath(); g.moveTo(x, y); g.lineTo(x+1*s, y-18*s); g.stroke(); g.lineWidth = 1.2*s;
  g.beginPath(); g.moveTo(x+.6*s, y-10*s); g.lineTo(x-6*s, y-16*s); g.moveTo(x+.8*s, y-14*s); g.lineTo(x+7*s, y-20*s); g.moveTo(x-3*s, y-13*s); g.lineTo(x-5*s, y-20*s); g.stroke();
}
function mGrave(g, x, y, s){
  g.fillStyle = "rgba(0,0,0,.3)"; g.fillRect(x-3*s, y, 8*s, 2*s);
  g.fillStyle = "#4a4458"; g.beginPath(); g.moveTo(x-3*s, y); g.lineTo(x-3*s, y-7*s); g.arc(x, y-7*s, 3*s, Math.PI, 0); g.lineTo(x+3*s, y); g.fill();
  g.fillStyle = "#6a6480"; g.fillRect(x-3*s, y-8*s, 1.4*s, 8*s);
}
function mMountain(g, x, y, w, h, dark, lit, snow){
  const top = [x + w*.08, y - h];
  g.fillStyle = "rgba(0,0,0,.3)"; g.beginPath(); g.ellipse(x+w*.15, y+2, w*.75, h*.08+3, 0, 0, 7); g.fill();
  g.fillStyle = dark; MP.poly(g, [[x-w*.7, y], top, [x+w*.7, y]]); g.fill();
  g.fillStyle = lit; MP.poly(g, [[x-w*.7, y], top, [x+w*.05, y - h*.35], [x-w*.12, y]]); g.fill();
  if(snow){ g.fillStyle = snow; MP.poly(g, [[top[0]-w*.22, y-h*.66], top, [top[0]+w*.2, y-h*.7], [top[0]+w*.06, y-h*.6], [top[0]-w*.06, y-h*.72]]); g.fill(); }
}

/* ---------- landmarks ---------- */
function mCastle(g, x, y){
  mMountainShadow(g, x, y, 40);
  g.fillStyle = "#6a6272"; g.fillRect(x-24, y-22, 48, 22); g.fillStyle = "#8a8294"; g.fillRect(x-24, y-22, 48, 4);
  for(const tx of [-26, 20]){ g.fillStyle = "#5a5262"; g.fillRect(x+tx, y-38, 10, 38); g.fillStyle = "#8a2a3a"; MP.poly(g, [[x+tx-2, y-38], [x+tx+5, y-52], [x+tx+12, y-38]]); g.fill(); }
  g.fillStyle = "#4a4252"; g.fillRect(x-7, y-46, 14, 46); g.fillStyle = "#a8323c"; MP.poly(g, [[x-9, y-46], [x, y-64], [x+9, y-46]]); g.fill();
  g.fillStyle = "#1a1016"; g.beginPath(); g.moveTo(x-6, y); g.lineTo(x-6, y-10); g.arc(x, y-10, 6, Math.PI, 0); g.lineTo(x+6, y); g.fill();
  g.strokeStyle = "#f2c14e"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x, y-64); g.lineTo(x, y-74); g.stroke(); g.fillStyle = "#f2c14e"; MP.poly(g, [[x, y-74], [x+9, y-71], [x, y-68]]); g.fill();
  MP.blob(g, x+2, y-14, 10, "#ffd27a", .5);
}
function mMountainShadow(g, x, y, r){ g.fillStyle = "rgba(0,0,0,.32)"; g.beginPath(); g.ellipse(x+4, y+2, r, r*.22, 0, 0, 7); g.fill(); }
function mFort(g, x, y){
  mMountainShadow(g, x, y, 36);
  g.fillStyle = "#4a3222";
  for(let i=-28;i<=28;i+=5){ g.beginPath(); g.moveTo(x+i-2.4, y); g.lineTo(x+i-2.4, y-16 - (i%10===0?3:0)); g.lineTo(x+i, y-20 - (i%10===0?3:0)); g.lineTo(x+i+2.4, y-16 - (i%10===0?3:0)); g.lineTo(x+i+2.4, y); g.fill(); }
  g.fillStyle = "#6a4a2e"; for(let i=-28;i<=28;i+=5) g.fillRect(x+i-2.4, y-16, 1.4, 16);
  g.fillStyle = "#7a2230"; MP.poly(g, [[x-14, y-16], [x-4, y-34], [x+6, y-16]]); g.fill(); g.fillStyle = "#a8323c"; MP.poly(g, [[x-4, y-34], [x+6, y-16], [x+1, y-16]]); g.fill();
  MP.blob(g, x+16, y-22, 16, "#ff9a3a", .7); g.fillStyle = "#ffcf5a"; MP.poly(g, [[x+13, y-18], [x+16, y-30], [x+19, y-18]]); g.fill();
  g.fillStyle = "rgba(120,110,110,.35)"; for(let k=0;k<4;k++){ g.beginPath(); g.arc(x+18+k*3, y-36-k*9, 4+k*1.6, 0, 7); g.fill(); }
}
function mCathedral(g, x, y){
  mMountainShadow(g, x, y, 42);
  MP.blob(g, x, y-30, 60, "#8a4ad8", .35);
  g.fillStyle = "#1c1426";
  g.fillRect(x-26, y-34, 52, 34);
  MP.poly(g, [[x-30, y-34], [x, y-58], [x+30, y-34]]); g.fill();
  for(const tx of [-26, 18]){ g.fillRect(x+tx, y-60, 8, 60); MP.poly(g, [[x+tx-1, y-60], [x+tx+4, y-84], [x+tx+9, y-60]]); g.fill(); }
  g.fillRect(x-5, y-74, 10, 40); MP.poly(g, [[x-6, y-74], [x, y-104], [x+6, y-74]]); g.fill();
  g.fillStyle = "#3a2a4e"; g.fillRect(x-26, y-34, 3, 34); g.fillRect(x-5, y-74, 2, 40);
  const rg = g.createRadialGradient(x, y-40, 0, x, y-40, 9); rg.addColorStop(0, "#ffffff"); rg.addColorStop(.3, "#e0b8ff"); rg.addColorStop(1, "#6a2ab8"); g.fillStyle = rg; g.beginPath(); g.arc(x, y-40, 7.5, 0, 7); g.fill();
  g.fillStyle = "#c9a2ff"; for(const wx of [-17, 11]){ g.beginPath(); g.moveTo(wx+x, y-10); g.lineTo(wx+x, y-22); g.arc(wx+x+3, y-22, 3, Math.PI, 0); g.lineTo(wx+x+6, y-10); g.fill(); }
  g.fillStyle = "#0a0610"; g.beginPath(); g.moveTo(x-5, y); g.lineTo(x-5, y-14); g.arc(x, y-14, 5, Math.PI, 0); g.lineTo(x+5, y); g.fill();
}
function mCitadel(g, x, y){
  mMountainShadow(g, x, y, 46);
  MP.blob(g, x, y-40, 70, "#8ff0ff", .35);
  const spire = (sx, h, w)=>{ g.fillStyle = "#6a9ac8"; MP.poly(g, [[sx-w, y], [sx-w*.7, y-h*.8], [sx, y-h], [sx+w*.7, y-h*.8], [sx+w, y]]); g.fill();
    g.fillStyle = "#dff6ff"; MP.poly(g, [[sx-w*.7, y-h*.8], [sx, y-h], [sx+w*.1, y], [sx-w, y]]); g.fill();
    g.fillStyle = "rgba(255,255,255,.9)"; g.fillRect(sx-.6, y-h*.95, 1.2, h*.5); };
  spire(x-24, 44, 9); spire(x+26, 48, 9); spire(x-10, 66, 10); spire(x+10, 60, 10); spire(x, 88, 12);
  g.fillStyle = "#1a2a44"; g.beginPath(); g.moveTo(x-6, y); g.lineTo(x-6, y-12); g.arc(x, y-12, 6, Math.PI, 0); g.lineTo(x+6, y); g.fill();
  MP.blob(g, x, y-86, 14, "#ffffff", .8);
}
function mColosseum(g, x, y){
  mMountainShadow(g, x, y, 32);
  g.fillStyle = "#8a7258"; g.beginPath(); g.ellipse(x, y-12, 30, 13, 0, 0, 7); g.fill();
  g.fillStyle = "#c8a878"; g.beginPath(); g.ellipse(x, y-16, 30, 12, 0, 0, 7); g.fill();
  g.fillStyle = "#6a8a4a"; g.beginPath(); g.ellipse(x, y-16, 18, 6.5, 0, 0, 7); g.fill();
  g.fillStyle = "#c8a878"; g.fillRect(x-30, y-16, 60, 12);
  g.fillStyle = "#5a4430"; for(let i=-24;i<=24;i+=8){ g.beginPath(); g.moveTo(x+i-2.5, y-5); g.lineTo(x+i-2.5, y-10); g.arc(x+i, y-10, 2.5, Math.PI, 0); g.lineTo(x+i+2.5, y-5); g.fill(); }
  g.fillStyle = "#a8323c"; for(const fx of [-26, 26]){ g.fillRect(x+fx, y-34, 1.2, 18); MP.poly(g, [[x+fx+1.2, y-34], [x+fx+9, y-31], [x+fx+1.2, y-28]]); g.fill(); }
}
function mLair(g, x, y){
  mMountain(g, x, y+10, 110, 92, "#2a2430", "#4a4250", null);
  mMountain(g, x-58, y+14, 60, 50, "#241e2a", "#3e3646", null);
  mMountain(g, x+60, y+16, 64, 56, "#221c28", "#3a3242", null);
  g.fillStyle = "#07040a"; g.beginPath(); g.moveTo(x-22, y+10); g.quadraticCurveTo(x-18, y-26, x+2, y-28); g.quadraticCurveTo(x+22, y-24, x+24, y+10); g.fill();
  MP.blob(g, x, y-8, 26, "#ff3a2a", .45);
  for(const ex of [-7, 7]){ MP.blob(g, x+ex, y-10, 6, "#ff4a2a", .9); g.fillStyle = "#ffe07a"; g.beginPath(); g.ellipse(x+ex, y-10, 2.6, 1.3, ex>0?-.2:.2, 0, 7); g.fill(); }
  g.strokeStyle = "#d8cfb8"; g.lineWidth = 2; g.lineCap = "round"; for(const [bx,by,r] of [[-30,8,.4],[26,9,-.6],[-12,11,1.2]]){ g.beginPath(); g.moveTo(x+bx-4*Math.cos(r), y+by-4*Math.sin(r)); g.lineTo(x+bx+4*Math.cos(r), y+by+4*Math.sin(r)); g.stroke(); }
}
function mSpire(g, x, y){
  mMountainShadow(g, x, y, 22);
  g.fillStyle = "#241a30"; MP.poly(g, [[x-12, y], [x-7, y-60], [x, y-86], [x+7, y-60], [x+12, y]]); g.fill();
  g.fillStyle = "#3e2e52"; MP.poly(g, [[x-12, y], [x-7, y-60], [x, y-86], [x-2, y]]); g.fill();
  g.fillStyle = "#ffb04a"; for(const wy of [-20, -40, -58]){ g.fillRect(x-1.5, y+wy, 3, 5); }
  MP.blob(g, x, y-88, 22, "#ffb04a", .7); g.fillStyle = "#fff0c0"; g.beginPath(); g.arc(x, y-88, 3.2, 0, 7); g.fill();
}
function mRift(g, x, y){
  MP.blob(g, x, y-6, 90, "#ff6a1a", .38); MP.blob(g, x+24, y-10, 60, "#b04ad8", .3);
  g.fillStyle = "#120806"; g.beginPath(); g.ellipse(x, y-4, 56, 18, -.05, 0, 7); g.fill();
  const lg = g.createRadialGradient(x, y-4, 2, x, y-4, 50); lg.addColorStop(0, "#fff0a0"); lg.addColorStop(.25, "#ffb03a"); lg.addColorStop(.6, "#c83a10"); lg.addColorStop(1, "rgba(60,10,4,0)");
  g.fillStyle = lg; g.beginPath(); g.ellipse(x, y-4, 46, 13, -.05, 0, 7); g.fill();
  g.strokeStyle = "rgba(255,160,255,.6)"; g.lineWidth = 1.6; for(let k=0;k<3;k++){ g.beginPath(); g.ellipse(x+20, y-6, 10+k*6, 4+k*2, .3, k, k+3.4); g.stroke(); }
  g.fillStyle = "#2a1a14"; for(const [rx,ry,s] of [[-58,0,12],[54,2,14],[-40,10,9],[36,12,10]]){ MP.poly(g, [[x+rx-s, y+ry], [x+rx-s*.2, y+ry-s*1.6], [x+rx+s*.6, y+ry-s*.6], [x+rx+s, y+ry]]); g.fill(); }
}

/* ---------- Acts IV and V scenery ---------- */
function mVolcano(g, x, y, w, h){
  mMountain(g, x, y, w, h, "#2a1410", "#4a281e", null);
  const top = [x + w*.08, y - h];
  MP.blob(g, top[0], top[1], w*.5, "#ff5a1a", .55);
  g.fillStyle = "#ffb04a"; MP.poly(g, [[top[0]-w*.08, top[1]+2], [top[0]+w*.08, top[1]+2], [top[0]+w*.02, top[1]+h*.45], [top[0]-w*.03, top[1]+h*.3]]); g.fill();
  g.fillStyle = "rgba(90,70,70,.35)"; for(let k=0;k<3;k++){ g.beginPath(); g.arc(top[0]+k*4, top[1]-10-k*10, 5+k*2, 0, 7); g.fill(); }
}
function mBasalt(g, x, y, s){
  g.fillStyle = "rgba(0,0,0,.3)"; g.beginPath(); g.ellipse(x+2*s, y+1, 8*s, 2.5*s, 0, 0, 7); g.fill();
  const cols = [[-5,12],[-1.6,18],[1.8,14],[5,9]];
  for(const [dx,h] of cols){ g.fillStyle = "#1c100c"; g.fillRect(x+dx*s-1.7*s, y-h*s, 3.4*s, h*s); g.fillStyle = "#3a2218"; g.fillRect(x+dx*s-1.7*s, y-h*s, 1.2*s, h*s); g.fillStyle = "#ff8a3a"; g.fillRect(x+dx*s-1.7*s, y-h*s, 3.4*s, .8*s); }
}
function mVent(g, x, y, s){
  MP.blob(g, x, y-2, 12*s, "#ff6a1a", .5);
  g.strokeStyle = "#ffc24a"; g.lineWidth = 1.2*s; g.beginPath(); g.moveTo(x-6*s, y); g.lineTo(x-2*s, y-1.5*s); g.lineTo(x+1*s, y+.5*s); g.lineTo(x+6*s, y-1*s); g.stroke();
  g.fillStyle = "rgba(110,90,90,.3)"; g.beginPath(); g.arc(x+1*s, y-8*s, 3.4*s, 0, 7); g.arc(x+3*s, y-15*s, 4.2*s, 0, 7); g.fill();
}
function mCrystal(g, x, y, s, col){
  g.fillStyle = "rgba(0,0,0,.28)"; g.beginPath(); g.ellipse(x, y+1, 6*s, 2*s, 0, 0, 7); g.fill();
  const fy = y - 8*s;
  MP.blob(g, x, fy-6*s, 16*s, col, .35);
  g.fillStyle = MP.mix(col, "#000000", .35); MP.poly(g, [[x, fy-16*s], [x+5*s, fy-6*s], [x, fy+2*s], [x-5*s, fy-6*s]]); g.fill();
  g.fillStyle = MP.mix(col, "#ffffff", .45); MP.poly(g, [[x, fy-16*s], [x-5*s, fy-6*s], [x, fy-5*s]]); g.fill();
}
function mPillar(g, x, y, s){
  g.fillStyle = "rgba(0,0,0,.3)"; g.beginPath(); g.ellipse(x+2*s, y+1, 6*s, 2*s, 0, 0, 7); g.fill();
  const h = (12 + (x*7%9))*s;
  g.fillStyle = "#6a6290"; g.fillRect(x-3*s, y-h, 6*s, h); g.fillStyle = "#a8a0d0"; g.fillRect(x-3*s, y-h, 2*s, h);
  g.fillStyle = "#8a82b8"; MP.poly(g, [[x-4*s, y-h], [x+4*s, y-h], [x+3*s, y-h-2.5*s], [x-1*s, y-h-1*s]]); g.fill();
}
function mForge(g, x, y){
  mMountainShadow(g, x, y, 48);
  MP.blob(g, x, y-30, 80, "#ff5a1a", .4);
  g.fillStyle = "#1e1210"; MP.poly(g, [[x-38, y], [x-30, y-38], [x+30, y-38], [x+38, y]]); g.fill();
  g.fillStyle = "#3a221a"; MP.poly(g, [[x-38, y], [x-30, y-38], [x-20, y-38], [x-26, y]]); g.fill();
  for(const [cx,h] of [[-20,64],[0,82],[20,58]]){ g.fillStyle = "#2a1814"; g.fillRect(x+cx-5, y-h, 10, h-30); g.fillStyle = "#ff8a3a"; g.fillRect(x+cx-5, y-h, 10, 3);
    g.fillStyle = "rgba(100,80,80,.4)"; for(let k=0;k<3;k++){ g.beginPath(); g.arc(x+cx+k*3, y-h-8-k*10, 5+k*2, 0, 7); g.fill(); } }
  g.fillStyle = "#ffb04a"; g.beginPath(); g.moveTo(x-9, y); g.lineTo(x-9, y-14); g.arc(x, y-14, 9, Math.PI, 0); g.lineTo(x+9, y); g.fill();
  MP.blob(g, x, y-10, 18, "#ffd27a", .8);
  g.fillStyle = "#ff8a3a"; for(const wx of [-26, 20]) g.fillRect(x+wx, y-26, 6, 8);
}
function mStarThrone(g, x, y){
  mMountainShadow(g, x, y+6, 40);
  MP.blob(g, x, y-46, 90, "#9a6aff", .4);
  g.strokeStyle = "rgba(220,200,255,.75)"; g.lineWidth = 1.6; g.beginPath(); g.ellipse(x, y-58, 46, 12, -.1, 0, 7); g.stroke();
  g.fillStyle = "#2a2450"; MP.poly(g, [[x-34, y-14], [x+34, y-14], [x+22, y+4], [x-22, y+4]]); g.fill();
  g.fillStyle = "#4a3e80"; g.fillRect(x-30, y-48, 60, 34);
  g.fillStyle = "#e8e0ff"; for(const cx of [-24, -8, 8, 24]) g.fillRect(x+cx-2.5, y-48, 5, 34);
  g.fillStyle = "#6a5aa8"; MP.poly(g, [[x-36, y-48], [x, y-72], [x+36, y-48]]); g.fill();
  g.fillStyle = "#fff4c0"; MP.poly(g, [[x, y-96], [x+5, y-84], [x, y-72], [x-5, y-84]]); g.fill();
  MP.blob(g, x, y-84, 20, "#ffe9a0", .9);
  for(const [sx,sy] of [[-44,-80],[40,-90],[-20,-104],[30,-30],[-50,-30]]){ g.fillStyle = "#ffffff"; g.fillRect(x+sx-.8, y+sy-3, 1.6, 6); g.fillRect(x+sx-3, y+sy-.8, 6, 1.6); }
}

/* ---------- full paint ---------- */
function paintMap(cv, pxH, fogFrom){
  const sc = pxH / MAP_H; cv.width = Math.round(MAP_W*sc); cv.height = Math.round(pxH);
  const g = cv.getContext("2d"); g.setTransform(sc,0,0,sc,0,0);
  const R = seeded(90210);
  // sea
  const sea = g.createLinearGradient(0,0,0,MAP_H); sea.addColorStop(0,"#0a1422"); sea.addColorStop(1,"#060a12"); g.fillStyle = sea; g.fillRect(0,0,MAP_W,MAP_H);
  // land (wavy coast top and bottom)
  const coastT = [], coastB = [];
  for(let x=-20;x<=MAP_W+20;x+=20){ coastT.push([x, 26 + Math.sin(x*.011)*10 + Math.sin(x*.037)*5 + R()*5]); coastB.push([x, MAP_H - 18 - Math.sin(x*.009+1)*9 - Math.sin(x*.041)*5 - R()*4]); }
  g.save(); g.beginPath(); g.moveTo(coastT[0][0], coastT[0][1]); coastT.forEach(p=>g.lineTo(p[0],p[1])); for(let i=coastB.length-1;i>=0;i--) g.lineTo(coastB[i][0], coastB[i][1]); g.closePath();
  g.shadowColor = "rgba(120,180,220,.35)"; g.shadowBlur = 14;
  const land = g.createLinearGradient(0,0,MAP_W,0);
  for(let x=0;x<=MAP_W;x+=85) land.addColorStop(x/MAP_W, groundAt(x));
  g.fillStyle = land; g.fill(); g.shadowBlur = 0; g.clip();
  // ground texture
  for(let i=0;i<860;i++){ const x = R()*MAP_W, y = R()*MAP_H, base = groundAt(x); const r = 14 + R()*46;
    MP.blob(g, x, y, r, R()<.5 ? MP.mix(base,"#000000",.35) : MP.mix(base,"#ffffff",.16), .22 + R()*.18); }
  // gothic marsh pools and violet mist
  for(let i=0;i<14;i++){ const x = 600 + R()*480, y = 80 + R()*380; g.fillStyle = "rgba(20,12,30,.55)"; g.beginPath(); g.ellipse(x, y, 16+R()*22, 5+R()*6, R(), 0, 7); g.fill(); MP.blob(g, x, y, 30, "#8a4ad8", .12); }
  // frost: ice lakes
  for(let i=0;i<6;i++){ const x = 1180 + R()*480, y = 110 + R()*340; g.fillStyle = "rgba(160,220,255,.45)"; g.beginPath(); g.ellipse(x, y, 20+R()*20, 6+R()*5, 0, 0, 7); g.fill(); g.strokeStyle = "rgba(255,255,255,.5)"; g.lineWidth = 1; g.stroke(); }
  // ember: lava pools with a glowing rim; astral: starfield and light pools
  for(let i=0;i<12;i++){ const x = 1760 + R()*480, y = 90 + R()*370; MP.blob(g, x, y, 34, "#ff5a1a", .28); g.fillStyle = "#c83a10"; g.beginPath(); g.ellipse(x, y, 14+R()*14, 4+R()*4, R()*.4, 0, 7); g.fill(); g.fillStyle = "#ffb04a"; g.beginPath(); g.ellipse(x, y, 7+R()*6, 2+R()*2, 0, 0, 7); g.fill(); }
  for(let i=0;i<240;i++){ const x = 2290 + R()*540, y = 40 + R()*430, r = R()*1.4 + .3; g.fillStyle = `rgba(255,255,255,${.25+R()*.6})`; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); }
  for(let i=0;i<9;i++){ const x = 2320 + R()*480, y = 100 + R()*340; MP.blob(g, x, y, 40, R()<.5 ? "#7a5aff" : "#ff7ae8", .16); }
  // river between Act I and II
  g.lineCap = "round";
  const riv = [[548,20],[530,120],[572,210],[548,300],[590,400],[566,500]];
  const rl = roadLine(riv).out;
  g.strokeStyle = "#16324a"; g.lineWidth = 14; strokeLine(g, rl, 0, rl.length-1);
  g.strokeStyle = "#2a5a7a"; g.lineWidth = 9; strokeLine(g, rl, 0, rl.length-1);
  g.strokeStyle = "rgba(160,220,255,.35)"; g.lineWidth = 2; g.setLineDash([10,14]); strokeLine(g, rl, 0, rl.length-1); g.setLineDash([]);
  // lava river between Act III and IV, a rift of stars between Act IV and V
  const lav = roadLine([[1712,20],[1690,130],[1728,220],[1700,310],[1740,410],[1716,500]]).out;
  g.strokeStyle = "rgba(255,90,20,.35)"; g.lineWidth = 26; strokeLine(g, lav, 0, lav.length-1);
  g.strokeStyle = "#7a1c08"; g.lineWidth = 14; strokeLine(g, lav, 0, lav.length-1);
  g.strokeStyle = "#ff7a1a"; g.lineWidth = 8; strokeLine(g, lav, 0, lav.length-1);
  g.strokeStyle = "rgba(255,230,140,.7)"; g.lineWidth = 2; g.setLineDash([12,16]); strokeLine(g, lav, 0, lav.length-1); g.setLineDash([]);
  const rift = roadLine([[2282,20],[2262,140],[2300,240],[2270,340],[2300,500]]).out;
  g.strokeStyle = "rgba(160,120,255,.3)"; g.lineWidth = 22; strokeLine(g, rift, 0, rift.length-1);
  g.strokeStyle = "#0a0618"; g.lineWidth = 12; strokeLine(g, rift, 0, rift.length-1);
  g.strokeStyle = "rgba(230,210,255,.75)"; g.lineWidth = 1.4; g.setLineDash([2,9]); strokeLine(g, rift, 0, rift.length-1); g.setLineDash([]);
  // road
  const pts = [MAP_START, ...MAP_NODES.flat()];
  const road = roadLine(pts); const RL = road.out;
  // scenery (kept off the road and landmarks)
  const marks = Object.values(MAP_MARKS).map(m=>[m.x,m.y]).concat(MAP_NODES.map(a=>a[4])).concat([MAP_START]);
  const labelC = REGIONS.map((r,i)=>r.x0 + 190 + (i===0?40:0));
  const clear = (x,y,r)=> !(y < 130 && labelC.some(c=>Math.abs(c-x) < 150)) && !nearRoad(RL, x, y, r) && !marks.some(([mx,my])=>(mx-x)**2+(my-y)**2 < (r+34)**2) && !nearRoad(rl, x, y, 12) && !nearRoad(lav, x, y, 18) && !nearRoad(rift, x, y, 16);
  const items = [];
  // mountains: north rim of every region, lots in the Frostveil
  for(let x=20;x<MAP_W;x+=34+R()*30){ const y = 70 + R()*40; if(!clear(x,y,20)) continue; const w = 34+R()*30, h = 40+R()*40;
    if(x>2290){ items.push({y, f:()=>mMountain(g, x, y, w, h, "#2a2450", "#5a4e90", "#e8e0ff")}); continue; }
    if(x>1720){ items.push({y, f:()=>R()<.45 ? mVolcano(g, x, y, w, h) : mMountain(g, x, y, w, h, "#24120e", "#42261c", null)}); continue; }
    const frost = x>1150, goth = x>600 && x<1100;
    items.push({y, f:()=>mMountain(g, x, y, w, h, frost?"#5a7090":goth?"#2a2232":"#2e3a26", frost?"#c8dcef":goth?"#4a3e58":"#50603e", frost?"#ffffff":goth?null:"#c8d0c0")}); }
  for(let i=0;i<8;i++){ const x = 1760 + R()*480, y = 150 + R()*300; if(!clear(x,y,30)) continue; items.push({y, f:()=>mVolcano(g, x, y, 34+R()*20, 40+R()*26)}); }
  for(let i=0;i<22;i++){ const x = 1160 + R()*520, y = 140 + R()*330; if(!clear(x,y,24)) continue; items.push({y, f:()=>mMountain(g, x, y, 26+R()*26, 30+R()*36, "#5a7090", "#c8dcef", "#ffffff")}); }
  // forests
  for(let i=0;i<700;i++){ const x = R()*MAP_W, y = 60 + R()*(MAP_H-80); if(!clear(x,y,15)) continue; const s = .8 + R()*.5;
    if(x > 2290){ const q = R(); if(q<.45) items.push({y, f:()=>mCrystal(g, x, y, s, R()<.5?"#9a7aff":"#ff8ae8")}); else if(q<.7) items.push({y, f:()=>mPillar(g, x, y, s)}); continue; }
    if(x > 1730){ const q = R(); if(q<.45) items.push({y, f:()=>mBasalt(g, x, y, s)}); else if(q<.65) items.push({y, f:()=>mVent(g, x, y, s)}); continue; }
    if(x > 1680) continue;
    if(x < 540) items.push({y, f:()=>mTree(g, x, y, s, R()<.5?"#1e3a1a":"#244a1e", "#6a9a3a")});
    else if(x < 1110){ if(R()<.35) items.push({y, f:()=>mGrave(g, x, y, s)}); else if(R()<.6) items.push({y, f:()=>mDeadTree(g, x, y, s)}); }
    else if(R()<.7) items.push({y, f:()=>mPine(g, x, y, s, "#1e3a44", "#eef6ff")}); }
  // road under scenery depth: draw road first
  g.strokeStyle = "rgba(0,0,0,.35)"; g.lineWidth = 11; strokeLine(g, RL, 0, RL.length-1);
  g.strokeStyle = "#6a5034"; g.lineWidth = 7; strokeLine(g, RL, 0, RL.length-1);
  g.strokeStyle = "rgba(240,215,160,.45)"; g.lineWidth = 1.6; g.setLineDash([5,7]); strokeLine(g, RL, 0, RL.length-1); g.setLineDash([]);
  // bridge
  { const bi = RL.reduce((b,p,i)=>Math.abs(p[0]-560)<Math.abs(RL[b][0]-560)?i:b, 0), p = RL[bi]; g.fillStyle = "#8a6a44"; g.fillRect(p[0]-14, p[1]-6, 28, 12); g.fillStyle = "#5a4028"; for(let k=-12;k<=12;k+=4) g.fillRect(p[0]+k, p[1]-6, 1.4, 12); }
  // travelled road glows gold up to the furthest open node
  const reach = Math.min(pts.length-1, 1 + fogFrom.reached);
  if(reach>0){ g.strokeStyle = "rgba(242,215,150,.9)"; g.lineWidth = 3; g.shadowColor = "#f2d796"; g.shadowBlur = 8; g.setLineDash([7,6]); strokeLine(g, RL, 0, road.idx[reach]); g.setLineDash([]); g.shadowBlur = 0; }
  items.sort((a,b)=>a.y-b.y).forEach(it=>it.f());
  // landmarks
  mCastle(g, MAP_START[0], MAP_START[1]);
  mFort(g, MAP_NODES[0][4][0], MAP_NODES[0][4][1] - 18);
  mCathedral(g, MAP_NODES[1][4][0], MAP_NODES[1][4][1] - 18);
  mCitadel(g, MAP_NODES[2][4][0], MAP_NODES[2][4][1] - 18);
  mForge(g, MAP_NODES[3][4][0], MAP_NODES[3][4][1] - 18);
  mStarThrone(g, MAP_NODES[4][4][0], MAP_NODES[4][4][1] - 18);
  { const bi = RL.reduce((b,p,i)=>Math.abs(p[0]-1712)<Math.abs(RL[b][0]-1712)?i:b, 0), p = RL[bi]; g.fillStyle = "#3a2a24"; g.fillRect(p[0]-16, p[1]-6, 32, 12); g.fillStyle = "#1a100c"; for(let k=-14;k<=14;k+=4) g.fillRect(p[0]+k, p[1]-6, 1.4, 12); }
  { const bi = RL.reduce((b,p,i)=>Math.abs(p[0]-2282)<Math.abs(RL[b][0]-2282)?i:b, 0), p = RL[bi]; g.fillStyle = "rgba(220,200,255,.85)"; g.fillRect(p[0]-15, p[1]-4, 30, 8); MP.blob(g, p[0], p[1], 24, "#c8a8ff", .5); }
  mColosseum(g, MAP_MARKS.arena.x, MAP_MARKS.arena.y - 16);
  mLair(g, MAP_MARKS.raid.x, MAP_MARKS.raid.y + 12);
  mSpire(g, MAP_MARKS.challenges.x, MAP_MARKS.challenges.y + 20);
  mRift(g, MAP_MARKS.endless.x, MAP_MARKS.endless.y - 14);
  // region names
  g.font = `600 17px "Source Serif 4", Georgia, serif`; g.textBaseline = "middle";
  REGIONS.forEach((r,i)=>{ const cx = labelC[i];
    const pg = g.createLinearGradient(cx-170, 0, cx+170, 0); pg.addColorStop(0,"rgba(6,4,10,0)"); pg.addColorStop(.2,"rgba(6,4,10,.55)"); pg.addColorStop(.8,"rgba(6,4,10,.55)"); pg.addColorStop(1,"rgba(6,4,10,0)"); g.fillStyle = pg; g.fillRect(cx-170, 34, 340, 28);
    g.fillStyle = "rgba(0,0,0,.55)"; MP.spaced(g, r.name, cx+1, 48+1.5, 4); g.fillStyle = REGION_COL[i]; MP.spaced(g, r.name, cx, 48, 4); });
  // fog over locked acts
  for(let a=0;a<REGIONS.length;a++){ if(a < fogFrom.open) continue; const r = REGIONS[a], x0 = r.x0 + (a===0?0:-30);
    const fg = g.createLinearGradient(x0, 0, x0 + 90, 0); fg.addColorStop(0, "rgba(14,10,20,0)"); fg.addColorStop(1, "rgba(14,10,20,.72)"); g.fillStyle = fg; g.fillRect(x0, 0, 90, MAP_H); g.fillStyle = "rgba(14,10,20,.72)"; g.fillRect(x0+90, 0, MAP_W, MAP_H);
    const Rf = seeded(7+a); for(let k=0;k<90;k++) MP.blob(g, x0 + 30 + Rf()*(MAP_W-x0), Rf()*MAP_H, 40 + Rf()*70, "#b8b0d0", .16);
    break; }
  g.restore();
  // coast line highlight + vignette + frame
  const vg = g.createRadialGradient(MAP_W/2, MAP_H/2, MAP_H*.4, MAP_W/2, MAP_H/2, MAP_W*.62); vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,.55)"); g.fillStyle = vg; g.fillRect(0,0,MAP_W,MAP_H);
  g.strokeStyle = "rgba(208,171,98,.55)"; g.lineWidth = 1.2; g.strokeRect(6, 6, MAP_W-12, MAP_H-12);
  g.strokeStyle = "rgba(208,171,98,.25)"; g.strokeRect(10, 10, MAP_W-20, MAP_H-20);
  return road;
}
