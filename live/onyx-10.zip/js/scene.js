/* Onyx Vanguard — scene.js
   The painted world renderer: parallax themes, dynamic light, particles, and a modular
   character rig (helm / body / cape / weapon / shield slots) shared by the hero and mobs.
   Standalone (no game globals). Exposes window.World; engine.js feeds it game state.
   No ctx.filter anywhere: iOS WebKit ignores it, so blur/bloom/flash are done by hand. */
(function () {
"use strict";
const TAU = Math.PI * 2;
let S = 2; // backing-store scale for offscreen layers (set by World.init / quality)
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const eIO = t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
const eOut = t => 1 - Math.pow(1 - t, 3);
const eIn = t => t * t * t;
function RNG(s) { s = (s >>> 0) || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
const HC = {};
function hex(c) { if (HC[c]) return HC[c]; let h = c.replace('#', ''); if (h.length === 3) h = h.split('').map(x => x + x).join(''); const n = parseInt(h, 16); return HC[c] = [n >> 16 & 255, n >> 8 & 255, n & 255]; }
function rgba(c, a) { const v = hex(c); return 'rgba(' + v[0] + ',' + v[1] + ',' + v[2] + ',' + a + ')'; }
function mix(a, b, t) { const x = hex(a), y = hex(b); return '#' + x.map((v, i) => Math.round(lerp(v, y[i], t)).toString(16).padStart(2, '0')).join(''); }
function mkS(w, h) { const c = document.createElement('canvas'); c.width = Math.ceil(w * S); c.height = Math.ceil(h * S); const g = c.getContext('2d'); g.scale(S, S); return { c, g }; }
function freeCanvas(c) { if (c) { c.width = 0; c.height = 0; } }
/* cheap blur without ctx.filter: shrink then enlarge with smoothing  */
function softBlur(src, k) {
  k = Math.max(1.5, k); const w = Math.max(1, Math.round(src.width / k)), h = Math.max(1, Math.round(src.height / k));
  const a = document.createElement('canvas'); a.width = w; a.height = h; const ag = a.getContext('2d'); ag.imageSmoothingEnabled = true; ag.imageSmoothingQuality = 'high'; ag.drawImage(src, 0, 0, w, h);
  const o = document.createElement('canvas'); o.width = src.width; o.height = src.height; const og = o.getContext('2d'); og.imageSmoothingEnabled = true; og.imageSmoothingQuality = 'high'; og.drawImage(a, 0, 0, src.width, src.height);
  freeCanvas(a); return o;
}
function pnoise(seed, N) { const r = RNG(seed), v = []; for (let i = 0; i < N; i++) v.push(r()); return x => { x = ((x % N) + N) % N; const i = Math.floor(x), f = x - i, t = f * f * (3 - 2 * f); return lerp(v[i], v[(i + 1) % N], t); }; }
function pfbm(n, x, o) { let a = 0, m = .5, f = 1, z = 0; for (let i = 0; i < o; i++) { a += m * n(x * f); z += m; f *= 2; m *= .5; } return a / z; }
const dir = a => [Math.cos(a), Math.sin(a)];

/* ---------- glow textures ---------- */
const GC = {};
function glowTex(col) {
  if (GC[col]) return GC[col];
  const s = mkS(64, 64), g = s.g, gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, rgba(col, 1)); gr.addColorStop(.16, rgba(col, .62)); gr.addColorStop(.42, rgba(col, .2)); gr.addColorStop(1, rgba(col, 0));
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return GC[col] = s.c;
}
function glow(ctx, col, x, y, r, a) { if (a <= 0.003 || r <= 0) return; const pa = ctx.globalAlpha; ctx.globalAlpha = pa * Math.min(1, a); ctx.drawImage(glowTex(col), x - r, y - r, r * 2, r * 2); ctx.globalAlpha = pa; }
const VC = {};
function vstrip(col) { if (VC[col]) return VC[col]; const s = mkS(2, 64), gr = s.g.createLinearGradient(0, 0, 0, 64); gr.addColorStop(0, rgba(col, 0)); gr.addColorStop(.2, rgba(col, 1)); gr.addColorStop(1, rgba(col, 0)); s.g.fillStyle = gr; s.g.fillRect(0, 0, 2, 64); return VC[col] = s.c; }

/* =====================================================================
   SCENERY HELPERS (drawn once into tileable offscreen layers)
===================================================================== */
function ridge(g, TW, H, o) {
  const n = pnoise(o.seed, o.N), pts = [], st = 2;
  for (let x = 0; x <= TW; x += st) {
    let v = pfbm(n, x / TW * o.N, o.oct || 5);
    if (o.sharp) { v = 1 - Math.abs(v - .5) * 2; v = Math.pow(clamp(v, 0, 1), o.sharp); }
    pts.push([x, o.y - v * o.amp]);
  }
  g.beginPath(); g.moveTo(0, H); for (const p of pts) g.lineTo(p[0], p[1]); g.lineTo(TW, H); g.closePath();
  const gr = g.createLinearGradient(0, o.y - o.amp, 0, o.y + (o.fade || 60));
  gr.addColorStop(0, o.top); gr.addColorStop(1, o.bot); g.fillStyle = gr; g.fill();
  const d = o.dir || 1;
  if (o.lit) for (let i = 1; i < pts.length; i++) {
    const dy = (pts[i][1] - pts[i - 1][1]) * d, a = clamp(dy * .55, 0, 1) * (o.litA || .3);
    if (a < .02) continue;
    const y = pts[i][1], lh = o.litH || 46, lg = g.createLinearGradient(0, y, 0, y + lh);
    lg.addColorStop(0, rgba(o.lit, a)); lg.addColorStop(1, rgba(o.lit, 0)); g.fillStyle = lg; g.fillRect(pts[i - 1][0], y, st + .6, lh);
  }
  if (o.snow) {
    const sy = o.y - o.amp * o.snow;
    for (let i = 0; i < pts.length; i++) {
      const y = pts[i][1]; if (y > sy) continue;
      const h = (sy - y) * .55 + 2 + Math.sin(i * 1.7) * 2, lit = i > 0 ? clamp((pts[i][1] - pts[i - 1][1]) * d * .5 + .5, .35, 1) : .7;
      const sg = g.createLinearGradient(0, y, 0, y + h); sg.addColorStop(0, rgba(o.snowCol || '#f4faff', .95 * lit)); sg.addColorStop(1, rgba(o.snowCol || '#f4faff', 0));
      g.fillStyle = sg; g.fillRect(pts[i][0], y, st + .6, h);
    }
  }
  if (o.rim) {
    g.lineWidth = o.rimW || 1;
    for (let i = 1; i < pts.length; i++) {
      const dy = (pts[i][1] - pts[i - 1][1]) * d, a = clamp(.3 + dy * .6, 0, 1) * (o.rimA || .6);
      if (a < .02) continue;
      g.strokeStyle = rgba(o.rim, a); g.beginPath(); g.moveTo(pts[i - 1][0], pts[i - 1][1]); g.lineTo(pts[i][0], pts[i][1]); g.stroke();
    }
  }
  return x => pts[clamp(Math.round(((x % TW) + TW) % TW / st), 0, pts.length - 1)][1];
}
function wrapDraw(TW, x, fn) { fn(x); if (x < 160) fn(x + TW); if (x > TW - 160) fn(x - TW); }
function vgrad(g, y0, y1, a, b) { const gr = g.createLinearGradient(0, y0, 0, y1); gr.addColorStop(0, a); gr.addColorStop(1, b); return gr; }
function hgrad(g, x0, x1, a, b) { const gr = g.createLinearGradient(x0, 0, x1, 0); gr.addColorStop(0, a); gr.addColorStop(1, b); return gr; }

function tower(g, x, by, w, h, o) {
  const roofH = w * (o.roof || 2.2);
  g.fillStyle = o.col;
  g.fillRect(x - w / 2, by - h, w, h + 60);
  g.beginPath(); g.moveTo(x - w / 2 - 2, by - h); g.lineTo(x, by - h - roofH); g.lineTo(x + w / 2 + 2, by - h); g.closePath(); g.fill();
  g.fillRect(x - .6, by - h - roofH - 7, 1.2, 8);
  if (o.cross) { g.fillRect(x - 2.5, by - h - roofH - 5, 5, 1.2); }
  for (let k = 0; k < (o.buttress || 0); k++) { const s = k ? 1 : -1; g.beginPath(); g.moveTo(x + s * w / 2, by - h * .6); g.lineTo(x + s * (w / 2 + w * .5), by); g.lineTo(x + s * w / 2, by); g.fill(); }
  if (o.rim) {
    g.fillStyle = rgba(o.rim, o.rimA || .5); g.fillRect(x + o.ld * (w / 2) - (o.ld > 0 ? 1 : 0), by - h, 1, h);
    g.strokeStyle = rgba(o.rim, o.rimA || .5); g.lineWidth = 1; g.beginPath(); g.moveTo(x, by - h - roofH); g.lineTo(x + o.ld * (w / 2 + 2), by - h); g.stroke();
  }
  if (o.win) {
    const rows = Math.max(1, Math.floor(h / 26));
    for (let r = 0; r < rows; r++) {
      if (o.rnd() < .35) continue;
      const wy = by - h + 10 + r * 26, ww = Math.max(2, w * .22), wh = ww * 2.4;
      g.fillStyle = rgba(o.win, .9); g.beginPath(); g.moveTo(x - ww / 2, wy + wh); g.lineTo(x - ww / 2, wy + ww / 2); g.arc(x, wy + ww / 2, ww / 2, Math.PI, 0); g.lineTo(x + ww / 2, wy + wh); g.fill();
      if (o.lights) o.lights.push({ x, y: wy + wh * .6, col: o.win, r: 9, a: .5 });
    }
  }
}
function pine(g, x, by, h, o) {
  const n = 7, pts = [], w = h * .3;
  pts.push([x, by - h]);
  for (let i = 1; i <= n; i++) { const y = by - h + i * h / n * .92, hw = w * (i / n) * (i % 2 ? 1 : .72); pts.push([x + hw, y]); pts.push([x + hw * .35, y - h / n * .15]); }
  const L = pts.slice(1).map(p => [2 * x - p[0], p[1]]).reverse();
  g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (const p of pts.slice(1)) g.lineTo(p[0], p[1]);
  g.lineTo(x + 2, by + 30); g.lineTo(x - 2, by + 30); for (const p of L) g.lineTo(p[0], p[1]); g.closePath();
  g.fillStyle = o.col; g.fill();
  if (o.snow || o.rim) {
    const side = o.ld > 0 ? pts.slice(1) : L.slice().reverse();
    g.strokeStyle = rgba(o.snow || o.rim, o.snow ? .9 : (o.rimA || .45)); g.lineWidth = o.snow ? 1.6 : 1;
    for (let i = 0; i < side.length - 1; i += 2) { g.beginPath(); g.moveTo(side[i + 1][0], side[i + 1][1]); g.lineTo(side[i][0], side[i][1]); g.stroke(); }
  }
}
function branchTree(g, x, by, len, ang, depth, o) {
  const [dx, dy] = dir(ang), x2 = x + dx * len, y2 = by + dy * len;
  g.strokeStyle = o.col; g.lineWidth = Math.max(.6, depth * o.w); g.lineCap = 'round';
  g.beginPath(); g.moveTo(x, by); g.quadraticCurveTo(x + dx * len * .5 + (o.rnd() - .5) * len * .3, by + dy * len * .5, x2, y2); g.stroke();
  if (depth <= 1) { if (o.leaf) o.leaf(x2, y2); return; }
  const k = o.rnd() < .5 ? 2 : 3;
  for (let i = 0; i < k; i++) branchTree(g, x2, y2, len * (.62 + o.rnd() * .2), ang + (i - (k - 1) / 2) * (.55 + o.rnd() * .3), depth - 1, o);
}
function canopyTree(g, x, by, h, o) {
  const tw = h * .09;
  g.fillStyle = hgrad(g, x - tw * 2, x + tw * 2, o.ld > 0 ? o.trunkD : o.trunkL, o.ld > 0 ? o.trunkL : o.trunkD);
  g.beginPath(); g.moveTo(x - tw * 2.2, by + 20); g.bezierCurveTo(x - tw * .8, by - h * .2, x - tw, by - h * .5, x - tw * .5, by - h * .7);
  g.lineTo(x + tw * .5, by - h * .7); g.bezierCurveTo(x + tw, by - h * .5, x + tw * .8, by - h * .2, x + tw * 2.4, by + 20); g.closePath(); g.fill();
  const blobs = [];
  for (let i = 0; i < o.n; i++) { const a = o.rnd() * TAU, r = o.rnd(); blobs.push([x + Math.cos(a) * h * .34 * r, by - h * .78 + Math.sin(a) * h * .2 * r, h * (.12 + o.rnd() * .1)]); }
  blobs.sort((a, b) => a[1] - b[1]);
  for (const b of blobs) {
    const gr = g.createRadialGradient(b[0] + o.ld * b[2] * .45, b[1] - b[2] * .5, b[2] * .1, b[0], b[1], b[2] * 1.1);
    gr.addColorStop(0, o.leafL); gr.addColorStop(.5, o.leafM); gr.addColorStop(1, o.leafD);
    g.fillStyle = gr; g.beginPath();
    for (let k = 0; k <= 18; k++) { const a = k / 18 * TAU, rr = b[2] * (.86 + o.rnd() * .22); g.lineTo(b[0] + Math.cos(a) * rr, b[1] + Math.sin(a) * rr); }
    g.fill();
    if (o.detail) {
      for (let k = 0; k < o.detail; k++) {
        const a = -Math.PI / 2 + o.ld * .6 + (o.rnd() - .5) * 2.4, rr = b[2] * (.55 + o.rnd() * .42), lx = b[0] + Math.cos(a) * rr, ly = b[1] + Math.sin(a) * rr;
        g.fillStyle = rgba(o.leafL, .35 + o.rnd() * .4); g.beginPath(); g.ellipse(lx, ly, 2.4 + o.rnd() * 2, 1.2 + o.rnd(), a + 1.2, 0, TAU); g.fill();
      }
      for (let k = 0; k < o.detail * .5; k++) { const a = Math.PI / 2 + (o.rnd() - .5) * 2, rr = b[2] * (.5 + o.rnd() * .45); g.fillStyle = rgba('#000000', .18); g.beginPath(); g.ellipse(b[0] + Math.cos(a) * rr, b[1] + Math.sin(a) * rr, 3, 1.5, a, 0, TAU); g.fill(); }
    }
  }
  if (o.vines) { g.strokeStyle = rgba(o.leafD, .9); g.lineWidth = 1; for (let i = 0; i < o.vines; i++) { const vx = x + (o.rnd() - .5) * h * .6, vy = by - h * .7; g.beginPath(); g.moveTo(vx, vy); g.quadraticCurveTo(vx + 3, vy + h * .2, vx - 2, vy + h * (.25 + o.rnd() * .2)); g.stroke(); } }
}
function shard(g, x, by, w, h, lean, o) {
  const tx = x + lean * h, mid = by - h * .55;
  const left = [[x - w / 2, by], [x - w * .55, mid], [tx, by - h], [x, by]];
  const right = [[x, by], [tx, by - h], [x + w * .55, mid], [x + w / 2, by]];
  const f = (pts, col) => { g.fillStyle = col; g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (const p of pts) g.lineTo(p[0], p[1]); g.closePath(); g.fill(); };
  f(left, vgrad(g, by - h, by, o.ld > 0 ? o.dark : o.light, o.base));
  f(right, vgrad(g, by - h, by, o.ld > 0 ? o.light : o.dark, o.base));
  g.strokeStyle = rgba(o.edge, .8); g.lineWidth = .8; g.beginPath(); g.moveTo(x, by); g.lineTo(tx, by - h); g.stroke();
  if (o.lights) o.lights.push({ x: tx, y: by - h * .5, col: o.glow, r: h * .7, a: .35 });
}
function rock(g, x, by, w, h, o) {
  const r = o.rnd, pts = [];
  const n = 9; for (let i = 0; i <= n; i++) { const t = i / n, px = x - w / 2 + t * w, py = by - Math.sin(t * Math.PI) * h * (.75 + r() * .35); pts.push([px, py]); }
  g.beginPath(); g.moveTo(x - w / 2, by + 20); for (const p of pts) g.lineTo(p[0], p[1]); g.lineTo(x + w / 2, by + 20); g.closePath();
  g.fillStyle = hgrad(g, x - w / 2, x + w / 2, o.ld > 0 ? o.dark : o.light, o.ld > 0 ? o.light : o.dark); g.fill();
  if (o.top) { g.strokeStyle = rgba(o.top, .75); g.lineWidth = 1.4; g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.stroke(); }
}
function grassClumps(g, TW, H, o) {
  const r = o.rnd;
  for (let i = 0; i < o.n; i++) {
    const x = r() * TW, base = H + 4, blades = 10 + Math.floor(r() * 14), hh = o.h * (.6 + r() * .6);
    for (let k = 0; k < blades; k++) {
      const a = -Math.PI / 2 + (r() - .5) * 1.5, len = hh * (.5 + r() * .5), bx = x + (r() - .5) * 26;
      const tx = bx + Math.cos(a) * len, ty = base + Math.sin(a) * len;
      g.fillStyle = o.col; g.beginPath(); g.moveTo(bx - 2.2, base); g.quadraticCurveTo(bx + Math.cos(a) * len * .5 - 1, base + Math.sin(a) * len * .55, tx, ty); g.quadraticCurveTo(bx + Math.cos(a) * len * .5 + 1.5, base + Math.sin(a) * len * .5, bx + 2.2, base); g.fill();
      if (o.rim && r() < .5) { g.strokeStyle = rgba(o.rim, .25); g.lineWidth = .7; g.beginPath(); g.moveTo(bx + 1.5, base - 4); g.quadraticCurveTo(bx + Math.cos(a) * len * .5 + 1.5, base + Math.sin(a) * len * .5, tx, ty); g.stroke(); }
    }
  }
}
function cumulus(g, x, y, w, o) {
  const r = o.rnd, n = 9 + Math.floor(r() * 6); let top = y;
  g.beginPath();
  for (let i = 0; i < n; i++) {
    const t = i / (n - 1), cx = x - w / 2 + t * w + (r() - .5) * 14, rr = w * (.08 + Math.sin(t * Math.PI) * .13) * (.7 + r() * .5), cy = y - Math.sin(t * Math.PI) * w * .08 + r() * 5;
    top = Math.min(top, cy - rr); g.moveTo(cx + rr, cy); g.arc(cx, cy, rr, 0, TAU);
  }
  g.rect(x - w / 2, y, w, w * .04);
  const gr = g.createLinearGradient(0, top, 0, y + w * .06); gr.addColorStop(0, rgba(o.top, o.a)); gr.addColorStop(.6, rgba(o.mid, o.a)); gr.addColorStop(1, rgba(o.bot, o.a * .5));
  g.fillStyle = gr; g.fill('nonzero');
}
function island(g, x, y, w, o) {
  const r = o.rnd, pts = [[x - w / 2, y]], n = 9;
  for (let i = 1; i < n; i++) { const t = i / n; pts.push([x - w / 2 + t * w, y + Math.sin(t * Math.PI) * w * (.45 + r() * .5) * (i % 2 ? 1 : .7)]); }
  pts.push([x + w / 2, y]);
  g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath();
  g.fillStyle = hgrad(g, x - w / 2, x + w / 2, o.dark, o.light); g.fill();
  g.fillStyle = vgrad(g, y, y + w * .7, 'rgba(0,0,0,0)', 'rgba(0,0,0,.45)'); g.fill();
  g.fillStyle = o.top; g.beginPath(); g.ellipse(x, y, w / 2, 3.2, 0, 0, TAU); g.fill();
  g.fillStyle = rgba('#ffffff', .35); g.fillRect(x - w * .1, y - 1.5, w * .55, 1);
  if (o.lights) for (let i = 0; i < 3; i++) { const cx = x - w * .3 + r() * w * .6, cy = y + w * (.12 + r() * .25); g.fillStyle = o.crystal; g.beginPath(); g.moveTo(cx - 3, cy); g.lineTo(cx, cy + 10 + r() * 8); g.lineTo(cx + 3, cy); g.fill(); o.lights.push({ x: cx, y: cy + 5, col: o.crystal, r: 12, a: .7 }); }
}
function fogTile(TW, h, col, seed, dens) {
  const s = mkS(TW, h), r = RNG(seed);
  for (let i = 0; i < 70 * (dens || 1); i++) {
    const x = r() * TW, y = h * .5 + (r() - .5) * h * .6, rr = 30 + r() * 80;
    for (const ox of [0, -TW, TW]) { const gr = s.g.createRadialGradient(x + ox, y, 0, x + ox, y, rr); gr.addColorStop(0, rgba(col, .16)); gr.addColorStop(1, rgba(col, 0)); s.g.fillStyle = gr; s.g.fillRect(x + ox - rr, y - rr, rr * 2, rr * 2); }
  }
  return s.c;
}

/* =====================================================================
   CHARACTER RIG — modular slots: body, helm, cape, weapon, shield, acc
===================================================================== */
function mgrad(g, x, w, y, d, l, ld) {
  const gr = g.createLinearGradient(x - w * ld, y, x + w * ld, y);
  gr.addColorStop(0, mix(d, '#000000', .35)); gr.addColorStop(.45, d); gr.addColorStop(.8, l); gr.addColorStop(1, mix(l, '#ffffff', .5)); return gr;
}
function seg(g, a, b, w, st) { g.lineCap = 'round'; g.lineWidth = w; g.strokeStyle = st; g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); }
/* Legs (Review 9): the foot is placed first and the knee found by two-bone IK, so a foot on the ground stays on the ground.
   Stance (half the cycle): the foot sweeps back in a straight line at the body's own speed (strideK in engine.js), so it
   never slides; swing: it lifts in an arc and comes forward. The knee always bends forward. Returns knee, ankle, foot angle. */
const SH_F = [4, -37];
const ARM_W = [1.3, 1.22], PAUL_FOLLOW = .6, CHEST_FRONT = 14;   // drawn arms are widened to match the plate body; the pauldron follows the arm by PAUL_FOLLOW; the far forearm shows in front of x > CHEST_FRONT   // the near shoulder joint (torso frame): over the middle of the chest, not at its front edge, so the arm hangs from the shoulder
const HIP_Y = -48, THIGH = 24, SHIN = 26, LEG_IDLE = [10, -15];
function gaitLeg(hip, ph, wa, ru, idleX) {
  const A = 20.3 + 9.6 * ru, lift = 7 + 6 * ru;               // A: half a stride in rig units (12.95 u/rad walking × π/2)
  let q = ((ph + Math.PI / 2) % TAU + TAU) % TAU / Math.PI, x, y, r;
  if (q < 1) { const u = eIO(q); x = -A + 2 * A * u; y = -lift * Math.sin(Math.PI * q); r = .55 * Math.sin(Math.PI * q) * (1 - q) - .25 * Math.sin(Math.PI * q) * q; }
  else { const u = q - 1; x = A * (1 - 2 * u); y = 0; r = u > .7 ? (u - .7) / .3 * .3 : 0; }
  const fx = hip[0] + idleX * (1 - wa) + x * wa, fy = y * wa;
  const [k, f] = ik2(hip, [fx, fy], THIGH, SHIN);
  return [k, f, r * wa];
}
function ik2(a, t, L1, L2) {
  let dx = t[0] - a[0], dy = t[1] - a[1], d = Math.hypot(dx, dy); const m = L1 + L2 - .01;
  if (d > m) { dx *= m / d; dy *= m / d; d = m; }
  const base = Math.atan2(dy, dx), c = clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1), k0 = base - Math.acos(c);   // the minus sign puts the knee forward (+x) for a leg pointing down
  const k = [a[0] + Math.cos(k0) * L1, a[1] + Math.sin(k0) * L1];
  return [k, [a[0] + dx, a[1] + dy]];
}
function legPts(hip, a1, a2, L1, L2) { const k = [hip[0] + Math.sin(a1) * L1, hip[1] + Math.cos(a1) * L1]; const f = [k[0] + Math.sin(a2) * L2, k[1] + Math.cos(a2) * L2]; return [k, f]; }

function drawWeapon(g, wp, glowAmt, t, ld) {
  if (wp.type === 'bow') { drawBow(g, wp, 0); return; }
  const L = wp.len || { sword: 58, greatsword: 80, axe: 60, mace: 50, spear: 88, scythe: 86, staff: 72 }[wp.type];
  const sd = wp.steelD || '#5c6070', sl = wp.steelL || '#eef2fa', wood = wp.wood || '#4a3322', tr = wp.trim || '#c9a45c', gl = wp.glow || '#ffffff';
  const haft = (a, b, w) => { g.fillStyle = vgrad(g, -w, w, mix(wood, '#ffffff', .25), mix(wood, '#000000', .4)); g.fillRect(a, -w, b - a, w * 2); };
  const emis = (pts, w) => { g.save(); g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(gl, .55 + glowAmt * .45); g.lineWidth = w; g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.stroke(); for (let i = 0; i < pts.length; i++) glow(g, gl, pts[i][0], pts[i][1], 9 + glowAmt * 10, .18 + glowAmt * .35); g.restore(); };
  if (wp.type === 'sword' || wp.type === 'greatsword') {
    const big = wp.type === 'greatsword', bw = big ? 4.2 : 3, gh = big ? 10 : 8, grip = big ? 16 : 10;
    g.fillStyle = tr; g.beginPath(); g.arc(-grip - 1, 0, big ? 3.2 : 2.6, 0, TAU); g.fill();
    g.fillStyle = vgrad(g, -2, 2, '#5a3b26', '#1e120a'); g.fillRect(-grip, -1.8, grip + 2, 3.6);
    g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = .6; for (let i = -grip + 2; i < 0; i += 2.5) { g.beginPath(); g.moveTo(i, -1.8); g.lineTo(i + 1.2, 1.8); g.stroke(); }
    g.fillStyle = vgrad(g, -gh, gh, mix(tr, '#ffffff', .4), mix(tr, '#000000', .45));
    g.beginPath(); g.moveTo(1, -gh); g.lineTo(4.5, -gh - 2); g.lineTo(5, -2); g.lineTo(5, 2); g.lineTo(4.5, gh + 2); g.lineTo(1, gh); g.closePath(); g.fill();
    g.fillStyle = vgrad(g, -bw, bw, sl, mix(sd, '#000000', .3));
    g.beginPath(); g.moveTo(5, -bw); g.lineTo(L - 8, -bw * .75); g.lineTo(L, 0); g.lineTo(L - 8, bw * .75); g.lineTo(5, bw); g.closePath(); g.fill();
    g.strokeStyle = rgba(sd, .8); g.lineWidth = .7; g.beginPath(); g.moveTo(7, 0); g.lineTo(L - 12, 0); g.stroke();
    emis([[6, -bw + .3], [L * .5, -bw * .85], [L - 8, -bw * .7], [L, 0]], 1.1);
    if (wp.rune) { g.save(); g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 4; i++) glow(g, gl, 14 + i * (L - 26) / 3, 0, 4, .7); g.restore(); }
  } else if (wp.type === 'axe') {
    haft(-14, L - 4, 1.9);
    g.fillStyle = tr; g.fillRect(L - 20, -2.6, 3, 5.2);
    g.fillStyle = vgrad(g, -22, 4, sl, mix(sd, '#000000', .3));
    g.beginPath(); g.moveTo(L - 16, -2); g.bezierCurveTo(L - 18, -12, L - 12, -22, L + 2, -24); g.bezierCurveTo(L - 1, -14, L + 2, -4, L + 6, 2); g.bezierCurveTo(L, 6, L - 8, 6, L - 16, 3); g.closePath(); g.fill();
    g.beginPath(); g.moveTo(L - 12, 1); g.lineTo(L - 16, 10); g.lineTo(L - 6, 4); g.closePath(); g.fill();
    emis([[L + 2, -24], [L - 1, -12], [L + 2, -4], [L + 6, 2]], 1.2);
  } else if (wp.type === 'mace') {
    haft(-12, L - 6, 1.8);
    g.fillStyle = tr; g.fillRect(-12, -2.4, 4, 4.8);
    const cx = L - 2;
    for (let i = 0; i < 6; i++) { const a = i / 6 * TAU + .3; g.fillStyle = mix(sd, sl, .5); g.beginPath(); g.moveTo(cx + Math.cos(a) * 5, Math.sin(a) * 5); g.lineTo(cx + Math.cos(a + .25) * 11, Math.sin(a + .25) * 11); g.lineTo(cx + Math.cos(a + .5) * 5, Math.sin(a + .5) * 5); g.fill(); }
    const gr = g.createRadialGradient(cx + 2, -3, 1, cx, 0, 8); gr.addColorStop(0, sl); gr.addColorStop(1, mix(sd, '#000000', .3)); g.fillStyle = gr; g.beginPath(); g.arc(cx, 0, 7, 0, TAU); g.fill();
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, gl, cx, 0, 14 + glowAmt * 10, .35 + glowAmt * .4); g.restore();
  } else if (wp.type === 'spear') {
    haft(-24, L - 18, 1.6);
    g.fillStyle = tr; g.fillRect(L - 21, -2.4, 4, 4.8);
    g.fillStyle = vgrad(g, -4, 4, sl, sd); g.beginPath(); g.moveTo(L - 17, 0); g.quadraticCurveTo(L - 10, -5, L + 6, 0); g.quadraticCurveTo(L - 10, 5, L - 17, 0); g.fill();
    emis([[L - 12, -3], [L + 6, 0]], 1.1);
  } else if (wp.type === 'scythe') {
    haft(-22, L, 1.7);
    g.fillStyle = vgrad(g, -4, 30, sl, mix(sd, '#000000', .4));
    g.beginPath(); g.moveTo(L - 2, -2); g.bezierCurveTo(L + 10, 8, L + 6, 30, L - 20, 44); g.bezierCurveTo(L - 4, 28, L - 2, 12, L - 8, 3); g.closePath(); g.fill();
    emis([[L - 2, -2], [L + 8, 12], [L + 2, 28], [L - 20, 44]], 1.3);
  } else if (wp.type === 'staff') {
    g.strokeStyle = wood; g.lineWidth = 3.2; g.lineCap = 'round'; g.beginPath(); g.moveTo(-22, 0); g.quadraticCurveTo(L * .4, 3, L - 6, -1); g.stroke();
    g.strokeStyle = mix(wood, '#000', .3); g.lineWidth = 1.4; g.beginPath(); g.moveTo(L - 8, -1); g.quadraticCurveTo(L - 2, -9, L + 6, -4); g.moveTo(L - 8, -1); g.quadraticCurveTo(L - 2, 8, L + 6, 4); g.stroke();
    const pulse = .6 + Math.sin(t * 5) * .15 + glowAmt * .6;
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, gl, L + 1, 0, 16 + glowAmt * 18, pulse); glow(g, '#ffffff', L + 1, 0, 5 + glowAmt * 3, .9); g.restore();
  }
}
/* bow held upright in the hand; pull 0..1 draws the string back with an arrow nocked */
function drawBow(g, wp, pull) {
  const wood = wp.wood || '#5a3a22', tr = wp.trim || '#c9a45c', gl = wp.glow || '#ffffff', bx = 6 - pull * 2, sx = -2 - pull * 12;
  g.strokeStyle = mix(wood, '#000', .35); g.lineWidth = 3.4; g.lineCap = 'round';
  g.beginPath(); g.moveTo(-3, -30); g.quadraticCurveTo(bx + 12, -16, bx + 4, 0); g.quadraticCurveTo(bx + 12, 16, -3, 30); g.stroke();
  g.strokeStyle = wood; g.lineWidth = 2; g.beginPath(); g.moveTo(-3, -30); g.quadraticCurveTo(bx + 12, -16, bx + 4, 0); g.quadraticCurveTo(bx + 12, 16, -3, 30); g.stroke();
  g.fillStyle = tr; g.fillRect(bx + 1, -3, 4, 6);
  g.strokeStyle = 'rgba(230,230,220,.8)'; g.lineWidth = .7; g.beginPath(); g.moveTo(-3, -30); g.lineTo(sx, 0); g.lineTo(-3, 30); g.stroke();
  if (pull > .05) { g.strokeStyle = '#8a6a3a'; g.lineWidth = 1.3; g.beginPath(); g.moveTo(sx, 0); g.lineTo(bx + 22, 0); g.stroke(); g.fillStyle = '#dfe6f2'; g.beginPath(); g.moveTo(bx + 27, 0); g.lineTo(bx + 21, -2.4); g.lineTo(bx + 21, 2.4); g.fill();
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, gl, bx + 24, 0, 8, .5 * pull); g.restore(); }
}
const SHIELD_FWD = 5.5, SHIELD_TURN = .8;
function drawShield(g, sh, ld) {
  const tr = sh.trim || '#c9a45c';
  g.save();
  if (sh.type === 'kite') {
    const p = () => { g.beginPath(); g.moveTo(0, -17); g.quadraticCurveTo(12, -16, 12, -6); g.quadraticCurveTo(10, 10, 0, 22); g.quadraticCurveTo(-10, 10, -12, -6); g.quadraticCurveTo(-12, -16, 0, -17); g.closePath(); };
    p(); g.fillStyle = mgrad(g, 0, 12, 0, mix(sh.col, '#000', .3), mix(sh.col, '#ffffff', .25), ld); g.fill();
    g.strokeStyle = tr; g.lineWidth = 1.8; p(); g.stroke();
  } else {
    g.beginPath(); g.arc(0, 0, 14, 0, TAU); g.fillStyle = mgrad(g, 0, 14, 0, mix(sh.col, '#000', .3), mix(sh.col, '#ffffff', .25), ld); g.fill();
    g.strokeStyle = tr; g.lineWidth = 2; g.stroke();
    g.fillStyle = tr; g.beginPath(); g.arc(ld * 1.5, -1.5, 4, 0, TAU); g.fill();
  }
  g.strokeStyle = sh.emblemCol || tr; g.fillStyle = sh.emblemCol || tr; g.lineWidth = 1.6; g.lineCap = 'round';
  const e = sh.emblem;
  if (e === 'cross') { g.beginPath(); g.moveTo(0, -9); g.lineTo(0, 11); g.moveTo(-6, -2); g.lineTo(6, -2); g.stroke(); }
  if (e === 'sun') { for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; g.beginPath(); g.moveTo(Math.cos(a) * 4, Math.sin(a) * 4); g.lineTo(Math.cos(a) * 8, Math.sin(a) * 8); g.stroke(); } }
  if (e === 'star') { g.beginPath(); for (let i = 0; i < 10; i++) { const a = i / 10 * TAU - Math.PI / 2, r = i % 2 ? 3.2 : 8; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.fill(); }
  if (e === 'flake') { for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI; g.beginPath(); g.moveTo(Math.cos(a) * -8, Math.sin(a) * -8); g.lineTo(Math.cos(a) * 8, Math.sin(a) * 8); g.stroke(); } }
  if (e === 'tree') { g.beginPath(); g.moveTo(0, 10); g.lineTo(0, -4); g.moveTo(0, -1); g.lineTo(-6, -8); g.moveTo(0, -1); g.lineTo(6, -8); g.moveTo(0, 3); g.lineTo(-4, -2); g.moveTo(0, 3); g.lineTo(4, -2); g.stroke(); }
  if (e === 'flame') { g.beginPath(); g.moveTo(0, 9); g.bezierCurveTo(-8, 4, -3, -4, 0, -10); g.bezierCurveTo(1, -3, 7, 0, 0, 9); g.fill(); }
  g.restore();
}

/* The off-hand arm (far side). With a shield it rides the walk, braces as the weapon swings, and snaps up on a block;
   without one the fist swings against the weapon arm. Returns the arm angle and the shield's tilt. */
function offHand(hasShield, walk, walkAmt, run, swing, t, block, hurt, phase) {
  const idle = Math.sin(t * 1.7 + (phase || 0)) * .05, sw = Math.sin(walk + Math.PI) * walkAmt * (hasShield ? .07 + .05 * run : .3 + .25 * run);
  const atk = swing > 0 && swing < 1.3 ? Math.sin(Math.min(1, swing / 1.3) * Math.PI) : 0;
  /* shield arm: SHIELD_ARM is the carry angle (hand out in front of the chest); it drops and tucks in as the weapon comes down, and snaps up in front of the face on a block */
  let bth = (hasShield ? SHIELD_ARM : 1.28) + idle * (hasShield ? .6 : 1) + sw + (hasShield ? run * .1 : -run * .2) + atk * (hasShield ? .42 : -.35), tilt = idle * .8 + sw * .6 - atk * .2;
  if (hasShield && block > 0) { const k = Math.min(1, block * 1.6); bth = bth * (1 - k) + SHIELD_BLOCK * k; tilt = tilt * (1 - k) - .1 * k; }
  if (hurt > 0) { bth += hurt * (hasShield ? .1 : .18); tilt -= hurt * .2; }
  return { bth, tilt };
}
const SHIELD_ARM = .56, SHIELD_BLOCK = -.3, SHIELD_ELBOW = .75;   // SHIELD_ELBOW: how far the upper arm hangs below the forearm (a bent elbow keeps the shield close to the body, not out on a straight arm)
/* the far arm of a shield bearer: shoulder, elbow, hand (torso frame). It starts behind the chest and reaches out past it. */
function shieldArm(bth) { const sh = [1, -36], el = [sh[0] + Math.cos(bth + SHIELD_ELBOW) * 13, sh[1] + Math.sin(bth + SHIELD_ELBOW) * 13]; return [sh, el, [el[0] + Math.cos(bth - .35) * 15, el[1] + Math.sin(bth - .35) * 15]]; }
function drawRig(g, sk, P, t) {
  const ld = P.ld, dark = c => mix(c, '#000000', .38);
  const AP = typeof rigPartsReady === 'function' && rigPartsReady(sk), pa = AP && partPal(sk, false), pb = AP && partPal(sk, true);     // drawn parts (parts.js), or the painted shapes
  const bodyD = sk.armD || mix(sk.robe, '#000000', .5), bodyL = sk.armL || sk.robe;
  const bob = P.bob || 0, hipY = HIP_Y + bob, wa = P.walkAmt || 0, w = P.walk || 0, ru = P.run || 0;
  g.save();
  const hipF = [3, hipY], hipB = [-4, hipY];
  const [kF, fF, rF] = gaitLeg(hipF, w, wa, ru, LEG_IDLE[0] + (P.lungeLeg || 0) * 50), [kB, fB, rB] = gaitLeg(hipB, w + Math.PI, wa, ru, LEG_IDLE[1]);
  const capeSw = Math.sin(t * 2.1) * 3 + wa * (Math.sin(w * 2) * 3 + 6) + (P.capeKick || 0);

  const torsoFrame = fn => { g.save(); g.translate(0, hipY); g.rotate((P.lean || 0) * ld / Math.abs(ld)); fn(); g.restore(); };
  // --- cape (behind everything)
  if (sk.cape && !P.noCape) torsoFrame(() => {
    g.beginPath(); g.moveTo(-9, -39);
    g.bezierCurveTo(-24, -26, -30 - capeSw, 6, -40 - capeSw * 1.85, 44 - wa * 6);
    g.lineTo(-33 - capeSw, 48 - wa * 6); g.lineTo(-26 - capeSw * .7, 42); g.lineTo(-18 - capeSw * .4, 48); g.lineTo(-10, 40);
    g.bezierCurveTo(-8, 10, -4, -20, 6, -38); g.closePath();
    const cg = g.createLinearGradient(-34, -30, 0, 40); cg.addColorStop(0, sk.cape); cg.addColorStop(1, sk.capeD || dark(sk.cape)); g.fillStyle = cg; g.fill();
    g.strokeStyle = rgba(mix(sk.cape, '#ffffff', .3), .35); g.lineWidth = 1; g.beginPath(); g.moveTo(-14, -30); g.bezierCurveTo(-22, 0, -28 - capeSw, 20, -32 - capeSw, 40); g.stroke();
    if (sk.capeTrim) { g.strokeStyle = sk.capeTrim; g.lineWidth = 1.3; g.beginPath(); g.moveTo(-40 - capeSw * 1.85, 44 - wa * 6); g.lineTo(-33 - capeSw, 48 - wa * 6); g.lineTo(-26 - capeSw * .7, 42); g.lineTo(-18 - capeSw * .4, 48); g.lineTo(-10, 40); g.stroke(); }
  });
  // --- back arm (behind torso)
  const bth = P.bth != null ? P.bth : (sk.shield ? SHIELD_ARM : 1.1), sArm = sk.shield ? shieldArm(bth) : null;
  const bSh = sArm ? sArm[0] : [-3, -37];
  const bEl = sArm ? sArm[1] : [bSh[0] + Math.cos(bth + .4) * 13, bSh[1] + Math.sin(bth + .4) * 13], bHa = sArm ? sArm[2] : [bEl[0] + Math.cos(bth - .5) * 12, bEl[1] + Math.sin(bth - .5) * 12];
  const limbCol = (x, wd) => sk.body === 'bone' ? mix(sk.armL, '#000000', .45) : mgrad(g, x, wd, 0, dark(bodyD), dark(bodyL), ld);
  /* a shield bearer's far arm is drawn whole behind the chest, so it comes out from behind the body and reaches the shield */
  torsoFrame(() => {
    if (sArm && AP) { drawPartBone(g, 'uarm', pb, bSh, bEl, ARM_W[0]); drawPartBone(g, 'farm', pb, bEl, bHa, ARM_W[1]); }
    else if (sArm) { const bn = sk.body === 'bone', rb = sk.body === 'robe', c1 = bn ? mix(sk.armL, '#000000', .3) : rb ? dark(sk.robe) : null;
      seg(g, bSh, bEl, bn ? 3.4 : rb ? 8 : 7.5, c1 || mgrad(g, bSh[0], 5, 0, mix(bodyD, '#000000', .25), mix(bodyL, '#000000', .25), ld));
      seg(g, bEl, bHa, bn ? 3.4 : rb ? 7 : 6.8, c1 || mgrad(g, bEl[0], 5, 0, mix(bodyD, '#000000', .18), mix(bodyL, '#000000', .18), ld));
      if (!bn && !rb) { g.fillStyle = mgrad(g, bEl[0], 5, 0, dark(bodyD), dark(bodyL), ld); g.beginPath(); g.ellipse(bEl[0], bEl[1], 4.4, 3.8, 0, 0, TAU); g.fill(); }
      else if (bn) { g.fillStyle = c1; g.beginPath(); g.arc(bEl[0], bEl[1], 2.6, 0, TAU); g.fill(); }
    } else if (AP) { drawPartBone(g, 'uarm', pb, bSh, bEl, ARM_W[0]); drawPartBone(g, 'farm', pb, bEl, bHa, ARM_W[1]); drawPartAt(g, 'hand', pb, bHa[0], bHa[1]); }
    else if (sk.body !== 'robe') { seg(g, bSh, bEl, sk.body === 'bone' ? 3 : 7.5, limbCol(bSh[0], 5)); seg(g, bEl, bHa, sk.body === 'bone' ? 2.6 : 6.5, limbCol(bEl[0], 5)); } else { seg(g, bSh, bEl, 8, dark(sk.robe)); seg(g, bEl, bHa, 7, dark(sk.robe)); }
    if (!sArm && !AP) { const bn = sk.body === 'bone', rb = sk.body === 'robe'; g.fillStyle = bn ? mix(sk.armL, '#000', .3) : rb ? mix(sk.skin || '#8a7a6a', '#000', .4) : mgrad(g, bHa[0], 4, 0, dark(bodyD), dark(bodyL), ld); g.beginPath(); g.arc(bHa[0], bHa[1], bn ? 2.4 : 3.9, 0, TAU); g.fill(); } });
  // --- legs
  const drawLeg = (hip, k, f, back, fr) => {
    if (sk.body === 'bone') {
      const bc = back ? mix(sk.armL, '#000', .4) : sk.armL;
      seg(g, hip, k, 3, bc); seg(g, k, f, 2.6, bc); g.fillStyle = bc; g.beginPath(); g.arc(k[0], k[1], 2.4, 0, TAU); g.fill();
      g.beginPath(); g.moveTo(f[0] - 3, f[1] - 2); g.lineTo(f[0] + 7, f[1] - .5); g.lineTo(f[0] + 7, f[1] + .5); g.lineTo(f[0] - 3, f[1] + .5); g.fill(); return;
    }
    if (AP) { const pp = back ? pb : pa; drawPartBone(g, 'thigh', pp, hip, k); drawPartBone(g, 'shin', pp, k, f); drawPartAt(g, 'foot', pp, f[0], f[1], fr); return; }
    const d = back ? dark(bodyD) : bodyD, l = back ? dark(bodyL) : bodyL;
    if (sk.body === 'robe') { seg(g, hip, k, 7, mix(sk.robe, '#000', .55)); seg(g, k, f, 6, mix(sk.robe, '#000', .6)); }
    else {
      seg(g, hip, k, 9.5, mgrad(g, (hip[0] + k[0]) / 2, 6, 0, d, l, ld)); seg(g, k, f, 8, mgrad(g, (k[0] + f[0]) / 2, 5, 0, d, l, ld));
      g.fillStyle = mgrad(g, k[0], 5, 0, d, l, ld); g.beginPath(); g.ellipse(k[0], k[1], 5, 4.2, 0, 0, TAU); g.fill();
      g.fillStyle = back ? dark(sk.trim) : sk.trim; g.beginPath(); g.arc(k[0] + ld, k[1], 1.4, 0, TAU); g.fill();
    }
    g.fillStyle = mgrad(g, f[0], 6, 0, d, l, ld);
    g.beginPath(); g.moveTo(f[0] - 4.5, f[1] - 5); g.lineTo(f[0] + 4, f[1] - 4); g.lineTo(f[0] + 10, f[1] - .5); g.lineTo(f[0] + 10, f[1] + .8); g.lineTo(f[0] - 5, f[1] + .8); g.closePath(); g.fill();
  };
  drawLeg(hipB, kB, fB, true, rB);
  // --- torso
  torsoFrame(() => {
    if (AP) {
      drawPartAt(g, 'torso', pa, 0, 0);
      const sw = Math.sin(t * 2 + 1) * 1.5 + wa * Math.sin(w) * 2;
      if (sk.tabard) { g.beginPath(); g.moveTo(-7, .4); g.lineTo(7, .4); g.lineTo(6.5 + sw, 21); g.lineTo(0 + sw, 25); g.lineTo(-6.5 + sw, 21); g.closePath(); g.fillStyle = vgrad(g, 0, 25, sk.tabard, dark(sk.tabard)); g.fill(); g.strokeStyle = sk.trim; g.lineWidth = 1; g.stroke(); g.strokeStyle = rgba(INK, .8); g.lineWidth = .5; g.stroke(); }
    } else if (sk.body === 'armor') {
      g.fillStyle = sk.under || '#1a1418'; g.fillRect(-10, -6, 20, 12);
      g.beginPath(); g.moveTo(-11, 0); g.bezierCurveTo(-16, -20, -15, -34, -14, -36); g.lineTo(-6, -42); g.lineTo(8, -42); g.lineTo(16, -35); g.bezierCurveTo(18, -22, 12, -6, 11, 0); g.closePath();
      g.fillStyle = mgrad(g, 1, 17, 0, bodyD, bodyL, ld); g.fill();
      g.strokeStyle = rgba('#000000', .35); g.lineWidth = .8; g.beginPath(); g.moveTo(-12, -14); g.quadraticCurveTo(0, -10, 13, -14); g.stroke();
      g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1.1; g.beginPath(); g.moveTo(3 + ld * 2, -40); g.quadraticCurveTo(7 * ld, -22, 4 * ld, -4); g.stroke();
      g.save(); g.globalCompositeOperation = 'lighter'; glow(g, '#ffffff', 8 * ld, -30, 7, .18); g.restore();
      /* Review 6: inked plate lines: the breastplate edge, two lames over the belly, a keel ridge and rivets */
      g.strokeStyle = rgba(INK, .75); g.lineWidth = .9; g.lineJoin = 'round';
      g.beginPath(); g.moveTo(-11, 0); g.bezierCurveTo(-16, -20, -15, -34, -14, -36); g.lineTo(-6, -42); g.lineTo(8, -42); g.lineTo(16, -35); g.bezierCurveTo(18, -22, 12, -6, 11, 0); g.stroke();
      for (const [y, k] of [[-9, .9], [-5, .85]]) { g.beginPath(); g.moveTo(-12 * k, y); g.quadraticCurveTo(0, y + 2.6, 12.5 * k, y); g.stroke(); }
      g.strokeStyle = rgba(INK, .45); g.lineWidth = .7; g.beginPath(); g.moveTo(1 * ld, -40); g.quadraticCurveTo(2.5 * ld, -26, 1 * ld, -15); g.stroke();
      g.fillStyle = mix(sk.trim || '#c9a44a', '#ffffff', .2); for (const [rx, ry] of [[-11, -33], [13, -33], [-12, -12], [13, -12]]) { g.beginPath(); g.arc(rx, ry, .9, 0, TAU); g.fill(); }
      const sw = Math.sin(t * 2 + 1) * 1.5 + wa * Math.sin(w) * 2;
      if (sk.tabard) { g.beginPath(); g.moveTo(-8, -1); g.lineTo(8, -1); g.lineTo(7 + sw, 21); g.lineTo(0 + sw, 25); g.lineTo(-7 + sw, 21); g.closePath(); g.fillStyle = vgrad(g, 0, 25, sk.tabard, dark(sk.tabard)); g.fill(); g.strokeStyle = sk.trim; g.lineWidth = 1; g.stroke(); }
      for (const s of [-1, 1]) { g.fillStyle = mgrad(g, s * 9, 6, 0, bodyD, bodyL, ld); g.beginPath(); g.moveTo(s * 4, 0); g.lineTo(s * 13, -1); g.lineTo(s * 14, 9); g.lineTo(s * 6, 10); g.closePath(); g.fill(); }
      g.fillStyle = '#20150e'; g.fillRect(-12, -4, 24, 4.5); g.fillStyle = sk.trim; g.fillRect(-2.5, -4.5, 5, 5.5);
      g.fillStyle = mgrad(g, 0, 6, 0, bodyD, bodyL, ld); g.fillRect(-6, -45, 12, 5);
    } else if (sk.body === 'robe') {
      const sw = Math.sin(t * 1.7) * 2 + wa * Math.sin(w) * 3;
      g.beginPath(); g.moveTo(-12, -40); g.lineTo(12, -40); g.bezierCurveTo(16, -20, 18 + sw * .3, 20, 21 + sw, 48);
      for (let i = 0; i <= 6; i++) { const x = 21 + sw - i * 7.3 - (i === 6 ? 0 : 0), y = 48 + (i % 2 ? -4 : 1); g.lineTo(x, y); }
      g.bezierCurveTo(-18, 20, -16, -20, -12, -40); g.closePath();
      g.fillStyle = mgrad(g, 0, 20, 0, dark(sk.robe), mix(sk.robe, '#ffffff', .15), ld); g.fill();
      g.strokeStyle = sk.trim; g.lineWidth = 1.4; g.beginPath(); g.moveTo(-21 + sw * .3, 44); g.lineTo(21 + sw, 44); g.stroke();
      g.strokeStyle = rgba('#000000', .4); g.lineWidth = 1; for (const x of [-6, 2, 9]) { g.beginPath(); g.moveTo(x * .6, -30); g.quadraticCurveTo(x, 10, x * 1.3 + sw * .5, 44); g.stroke(); }
      g.fillStyle = sk.trim; g.fillRect(-12, -2, 24, 3); g.fillRect(4 * ld, 1, 2, 12);
    } else if (sk.body === 'bone') {
      const bc = sk.armL;
      g.strokeStyle = bc; g.lineWidth = 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(-2 * ld, -20, 0, -40); g.stroke();
      g.lineWidth = 1.8; for (let i = 0; i < 5; i++) { const y = -34 + i * 5.5, wd = 11 - i * 1.2; g.beginPath(); g.moveTo(-1 * ld, y); g.quadraticCurveTo(wd * ld * .9, y - 2, wd * ld * .6, y + 5); g.moveTo(-1 * ld, y); g.quadraticCurveTo(-wd * ld * .7, y - 1, -wd * ld * .5, y + 4); g.stroke(); }
      g.fillStyle = bc; g.beginPath(); g.ellipse(0, 1, 9, 5, 0, 0, TAU); g.fill(); g.fillStyle = '#0a0808'; g.beginPath(); g.ellipse(2 * ld, 1, 3, 2, 0, 0, TAU); g.fill();
      g.strokeStyle = bc; g.lineWidth = 3; g.beginPath(); g.moveTo(-10, -38); g.lineTo(11, -38); g.stroke();
      if (sk.rags) { g.fillStyle = rgba(sk.rags, .85); g.beginPath(); g.moveTo(-10, -2); g.lineTo(10, -2); g.lineTo(8, 16); g.lineTo(4, 11); g.lineTo(1, 18); g.lineTo(-3, 12); g.lineTo(-8, 17); g.closePath(); g.fill(); }
    }
    if (sk.acc === 'fur') { g.fillStyle = vgrad(g, -48, -34, '#f1efe8', '#8d8a82'); g.beginPath(); for (let i = 0; i <= 10; i++) { const a = Math.PI + i / 10 * Math.PI, r = 15 + (i % 2) * 3; g.lineTo(Math.cos(a) * r, -40 + Math.sin(a) * 5 + (i % 2) * 2); } g.lineTo(15, -36); g.lineTo(-15, -36); g.closePath(); g.fill(); }
  });
  // --- shield (held forward by back arm, in front of torso)
  // --- the shield and the hand that grips it, in front of the torso
  torsoFrame(() => {
    const bn = sk.body === 'bone', rb = sk.body === 'robe';
    /* Review 9: without a shield the far arm stays whole behind the body (a forearm and fist floating over the belly read as a broken arm) */
    if (sk.shield) {
      /* the shield is held out ahead of the body, turned toward the enemy (so it is seen at an angle), and gripped at its back edge:
         the forearm shows between chest and shield, and a gauntlet and strap wrap the rim */
      const tilt = -.06 + (P.shieldTilt || 0), fa = Math.atan2(bHa[1] - bEl[1], bHa[0] - bEl[0]);
      g.save(); g.translate(bHa[0] + SHIELD_FWD, bHa[1] + 1.5); g.rotate(tilt); g.scale(SHIELD_TURN, 1); drawShield(g, sk.shield, ld); g.restore();
      g.save(); g.translate(bHa[0], bHa[1]); g.rotate(fa);
      const gc = bn ? sk.armL : rb ? mix(sk.skin || '#8a7a6a', '#000', .25) : mgrad(g, 0, 4, 0, mix(bodyD, '#000000', .1), bodyL, ld);
      if (AP) { g.restore(); g.save(); g.beginPath(); g.rect(CHEST_FRONT, -80, 80, 160); g.clip(); drawPartBone(g, 'farm', pb, bEl, bHa, ARM_W[1]); g.restore(); g.save(); g.translate(bHa[0], bHa[1]); g.rotate(fa); }      // drawn parts: the forearm itself comes out past the chest to the shield
      else if (!bn) { g.fillStyle = rb ? mix(sk.robe, '#000000', .15) : mgrad(g, -5, 4, 0, bodyD, bodyL, ld); g.beginPath(); g.moveTo(-9, -3.6); g.lineTo(-2.5, -4.4); g.lineTo(-2.5, 4.4); g.lineTo(-9, 3.6); g.closePath(); g.fill(); }      // vambrace cuff
      g.strokeStyle = bn ? mix(sk.shield.trim || '#6a5a44', '#000000', .35) : '#20150e'; g.lineWidth = 2; g.lineCap = 'butt'; g.beginPath(); g.moveTo(-1.6, -5.2); g.lineTo(-1.6, 5.2); g.stroke();      // the strap over the wrist
      g.fillStyle = gc; g.beginPath(); g.ellipse(2, 0, bn ? 3 : 4.4, bn ? 2.8 : 4.1, 0, 0, TAU); g.fill();                    // gauntlet gripping the rim
      g.strokeStyle = rgba('#000000', .4); g.lineWidth = .7; for (const yy of [-1.6, 0, 1.6]) { g.beginPath(); g.moveTo(2.4, yy); g.lineTo(5.6, yy); g.stroke(); }
      if (!bn && !rb && !AP) { g.strokeStyle = rgba(sk.trim, .8); g.lineWidth = 1; g.beginPath(); g.moveTo(-8.6, -3.2); g.lineTo(-8.6, 3.2); g.stroke(); }
      g.restore();
    }
  });
  drawLeg(hipF, kF, fF, false, rF);
  // --- head
  torsoFrame(() => drawHelm(g, sk, t, ld, wa, w));
  // --- front arm + weapon
  torsoFrame(() => {
    const sh = [SH_F[0], SH_F[1]], th = P.th, ph = P.ph;
    const el = [sh[0] + Math.cos(th + .35) * 13, sh[1] + Math.sin(th + .35) * 13], ha = [el[0] + Math.cos(th - .25) * 13, el[1] + Math.sin(th - .25) * 13];
    const rb = sk.body === 'robe', bn = sk.body === 'bone';
    if (AP) { drawPartBone(g, 'uarm', pa, sh, el, ARM_W[0]); drawPartBone(g, 'farm', pa, el, ha, ARM_W[1]); }
    else if (!rb) { seg(g, sh, el, bn ? 3 : 8, bn ? sk.armL : mgrad(g, sh[0], 5, 0, bodyD, bodyL, ld)); seg(g, el, ha, bn ? 2.6 : 7, bn ? sk.armL : mgrad(g, el[0], 5, 0, bodyD, bodyL, ld)); }
    else { seg(g, sh, el, 9, mix(sk.robe, '#ffffff', .08)); seg(g, el, ha, 8, sk.robe); }
    if (sk.weapon && sk.weapon.type === 'bow') { g.save(); g.translate(ha[0], ha[1]); g.rotate(th * .15); drawBow(g, sk.weapon, P.pull || 0); g.restore(); }
    else if (sk.weapon) { g.save(); g.translate(ha[0], ha[1]); g.rotate(ph); drawWeapon(g, sk.weapon, P.wglow || 0, t, ld); g.restore(); }
    if (AP) drawPartAt(g, 'hand', pa, ha[0], ha[1], ph * .3);
    else { g.fillStyle = bn ? sk.armL : rb ? mix(sk.skin || '#8a7a6a', '#000', .2) : mgrad(g, ha[0], 4, 0, bodyD, bodyL, ld); g.beginPath(); g.arc(ha[0], ha[1], bn ? 2.6 : 4.3, 0, TAU); g.fill(); }
    if (AP) { const pr = clamp((th + .35 - Math.PI / 2) * PAUL_FOLLOW, -1.25, .55);   /* the pauldron rides the upper arm (part of the way), pivoting on the shoulder */
      g.save(); g.translate(sh[0], sh[1]); g.rotate(pr); g.translate(-sh[0], -sh[1]); drawPartAt(g, 'pauldron', pa, SH_F[0] - 9, 0); g.restore();
      if (sk.spikes) { g.fillStyle = sk.trim; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(-1 + i * 6, -42 + i); g.lineTo(1 + i * 6, -50 + i * 1.5); g.lineTo(3 + i * 6, -41 + i); g.fill(); } } }
    else if (sk.body === 'armor') {
      g.fillStyle = mgrad(g, 11, 10, 0, bodyD, bodyL, ld);
      g.beginPath(); g.ellipse(5, -37, 10.5, 7.5, -.25, Math.PI * .95, Math.PI * 2.05); g.fill();
      g.beginPath(); g.ellipse(6, -34, 9, 5.5, -.3, Math.PI * .95, Math.PI * 2.05); g.fill();
      g.strokeStyle = sk.trim; g.lineWidth = 1.2; g.beginPath(); g.ellipse(6, -34, 9, 5.5, -.3, Math.PI * 1.05, Math.PI * 1.95); g.stroke();
      if (sk.spikes) { g.fillStyle = sk.trim; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(-1 + i * 6, -42 + i); g.lineTo(1 + i * 6, -50 + i * 1.5); g.lineTo(3 + i * 6, -41 + i); g.fill(); } }
    }
  });
  g.restore();
}
function drawHelm(g, sk, t, ld, wa, w) {
  const d = sk.helmD || sk.armD || mix(sk.robe || '#333333', '#000000', .5), l = sk.helmL || sk.armL || sk.robe || '#888888', gl = sk.glow || '#ffffff', h = sk.helm;
  if (h === 'none') return;
  if (sk.acc === 'halo') { g.save(); g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba(sk.haloCol || gl, .9); g.lineWidth = 1.6; g.beginPath(); g.ellipse(-1, -72 + Math.sin(t * 2) * 1, 11, 3.2, -.1, 0, TAU); g.stroke(); glow(g, sk.haloCol || gl, -1, -72, 22, .35); g.restore(); }
  if (h === 'hood') {
    g.beginPath(); g.moveTo(-13, -38); g.bezierCurveTo(-17, -58, -8, -74, 3, -73); g.bezierCurveTo(14, -70, 17, -55, 14, -40); g.closePath();
    g.fillStyle = mgrad(g, 0, 15, 0, mix(sk.robe, '#000', .5), mix(sk.robe, '#fff', .12), ld); g.fill();
    g.fillStyle = '#050305'; g.beginPath(); g.ellipse(7, -53, 5.5, 8, .1, 0, TAU); g.fill();
    g.save(); g.globalCompositeOperation = 'lighter'; const f = .8 + Math.sin(t * 6) * .15; glow(g, gl, 6, -55, 7, f); glow(g, gl, 10, -54.5, 6, f); g.fillStyle = mix(gl, '#ffffff', .6); g.fillRect(5, -55.5, 2, 1.3); g.fillRect(9.4, -55, 1.8, 1.2); g.restore();
    return;
  }
  if (h === 'skull') {
    const bc = sk.armL;
    g.fillStyle = vgrad(g, -64, -42, mix(bc, '#fff', .2), mix(bc, '#000', .35)); g.beginPath(); g.arc(3, -55, 9.5, 0, TAU); g.fill();
    g.beginPath(); g.moveTo(-2, -48); g.lineTo(12, -48); g.lineTo(11, -41); g.lineTo(0, -42); g.fill();
    g.fillStyle = '#080506'; g.beginPath(); g.ellipse(6.5, -55, 2.8, 3.2, 0, 0, TAU); g.fill(); g.beginPath(); g.ellipse(-0.5, -55.5, 2.4, 3, 0, 0, TAU); g.fill();
    g.fillRect(3, -50, 1.4, 2.2); g.strokeStyle = '#080506'; g.lineWidth = .7; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(1 + i * 2.6, -45); g.lineTo(1 + i * 2.6, -42); g.stroke(); }
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, gl, 6.5, -55, 7, .9); glow(g, gl, -.5, -55.5, 6, .7); g.restore();
    if (sk.skullCrown) { const cc = sk.crownCol || '#d8b25a'; g.fillStyle = vgrad(g, -76, -62, mix(cc, '#fff', .45), mix(cc, '#000', .3)); g.beginPath(); g.moveTo(-7, -62); for (let i = 0; i <= 4; i++) { g.lineTo(-6 + i * 4, -73 - (i % 2 ? 0 : 3)); g.lineTo(-4 + i * 4, -65); } g.lineTo(12, -62); g.quadraticCurveTo(3, -66, -7, -62); g.fill(); g.save(); g.globalCompositeOperation = 'lighter'; glow(g, sk.gem || gl, 2.5, -67, 5, .9); g.restore(); }
    if (sk.brokenHelm) { g.fillStyle = mgrad(g, 2, 10, 0, d, l, ld); g.beginPath(); g.moveTo(-8, -56); g.quadraticCurveTo(-4, -69, 8, -66); g.lineTo(12, -60); g.lineTo(6, -61); g.lineTo(2, -58); g.closePath(); g.fill(); }
    return;
  }
  // great helm family
  g.beginPath(); g.moveTo(-8, -44); g.lineTo(-9.5, -56); g.quadraticCurveTo(-1, -69, 10, -61); g.lineTo(14, -53); g.lineTo(13, -45); g.lineTo(6, -42); g.closePath();
  g.fillStyle = mgrad(g, 2, 12, 0, d, l, ld); g.fill();
  g.strokeStyle = 'rgba(255,255,255,.3)'; g.lineWidth = .9; g.beginPath(); g.moveTo(1, -66); g.quadraticCurveTo(8, -60, 11, -52); g.stroke();
  g.fillStyle = '#060406'; g.beginPath(); g.moveTo(4, -56); g.lineTo(13.5, -55); g.lineTo(13.5, -53); g.lineTo(4, -53.5); g.closePath(); g.fill();
  g.save(); g.globalCompositeOperation = 'lighter'; const f = .75 + Math.sin(t * 3) * .12; glow(g, gl, 10, -54.5, 10, f * .8); g.fillStyle = rgba(mix(gl, '#ffffff', .5), .9); g.fillRect(6, -55.2, 7, .9); g.restore();
  g.fillStyle = 'rgba(0,0,0,.45)'; for (let i = 0; i < 3; i++) g.fillRect(8 + i * 1.8, -49, .9, .9);
  g.strokeStyle = sk.trim; g.lineWidth = 1.2; g.beginPath(); g.moveTo(-9.5, -56); g.quadraticCurveTo(-1, -69, 10, -61); g.stroke();
  /* Review 6: inked helm: a face plate seam under the visor, the cheek plate and the neck guard */
  g.strokeStyle = rgba(INK, .7); g.lineWidth = .8; g.beginPath(); g.moveTo(4, -53.5); g.quadraticCurveTo(3, -48, 6, -42.5); g.moveTo(-8.6, -50); g.quadraticCurveTo(-2, -47, 4, -48); g.moveTo(-8, -44.5); g.lineTo(6, -42.4); g.stroke();
  if (h === 'greathelm' && sk.plume) {
    const s = Math.sin(t * 2.2) * 2.5 + wa * (5 + Math.sin(w * 2) * 2);
    g.beginPath(); g.moveTo(-1, -66); g.bezierCurveTo(-8, -76, -22 - s, -74, -30 - s * 1.3, -58); g.bezierCurveTo(-22 - s, -64, -12, -64, -6, -62); g.closePath();
    g.fillStyle = hgrad(g, -30, 0, mix(sk.plume, '#000', .45), mix(sk.plume, '#fff', .15)); g.fill();
  }
  if (h === 'horned') {
    for (const s of [0, 1]) { const o = s ? 0 : 5; g.fillStyle = vgrad(g, -86, -58, sk.hornCol || '#e8dcc0', mix(sk.hornCol || '#e8dcc0', '#000', .5)); g.beginPath(); g.moveTo(-4 + o, -60); g.bezierCurveTo(-14 + o, -64, -22 + o, -74, -16 + o, -88 + s * 4); g.bezierCurveTo(-16 + o, -76, -9 + o, -68, 2 + o, -64); g.closePath(); if (s) g.fill(); else { g.globalAlpha = .55; g.fill(); g.globalAlpha = 1; } }
  }
  if (h === 'winged') {
    const f = Math.sin(t * 2) * 1.5;
    for (let i = 0; i < 4; i++) { g.fillStyle = vgrad(g, -80, -56, mix(sk.wingCol || '#e9eef7', '#fff', .3), mix(sk.wingCol || '#e9eef7', '#000', .35)); g.beginPath(); g.moveTo(-5, -58); g.quadraticCurveTo(-14 - i * 3, -66 - i * 4 - f, -22 - i * 4, -60 - i * 7 - f); g.quadraticCurveTo(-14 - i * 2, -60 - i * 2, -5, -55); g.closePath(); g.fill(); }
  }
  if (h === 'crown') {
    g.fillStyle = vgrad(g, -72, -60, mix(sk.crownCol || sk.trim, '#fff', .45), mix(sk.crownCol || sk.trim, '#000', .3));
    g.beginPath(); g.moveTo(-8, -60); for (let i = 0; i <= 4; i++) { g.lineTo(-7 + i * 4.2, -70 - (i % 2 ? 0 : 3)); g.lineTo(-5 + i * 4.2, -63); } g.lineTo(11, -60); g.quadraticCurveTo(2, -66, -8, -60); g.fill();
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, sk.gem || gl, 1.5, -65, 5, .9); g.restore();
  }
}

/* ---------- creature mobs ---------- */
function polyJ(r, cx, cy, rad, n, jit, sx, sy) { const p = []; for (let i = 0; i < n; i++) { const a = i / n * TAU; const rr = rad * (1 - jit + r() * jit * 2); p.push([cx + Math.cos(a) * rr * (sx || 1), cy + Math.sin(a) * rr * (sy || 1)]); } return p; }
function fillPoly(g, p) { g.beginPath(); p.forEach((q, i) => i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.closePath(); }
const CREATURES = {
  wraith: {
    h: 176, engage: 175, hp: 4, atkStyle: 'melee',
    draw(g, c, P, t) {
      const m = c.m, hov = 16 + Math.sin(t * 2) * 5, a = P.atk || 0;
      const lunge = a > .35 && a < .75 ? Math.sin((a - .35) / .4 * Math.PI) * 18 : 0;
      g.save(); g.translate(lunge, -hov);
      const tat = k => Math.sin(t * 5 + k * 1.7) * 5;
      g.beginPath(); g.moveTo(0, -150);
      g.bezierCurveTo(20, -146, 26, -118, 28, -96); g.bezierCurveTo(32, -60, 36, -30, 40, 0);
      for (let i = 0; i <= 8; i++) g.lineTo(40 - i * 10, (i % 2 ? -14 : 6) + tat(i));
      g.bezierCurveTo(-46, -40, -36, -90, -24, -120); g.bezierCurveTo(-18, -140, -10, -150, 0, -150); g.closePath();
      g.fillStyle = mgrad(g, 0, 36, 0, m.d, m.l, P.ld); g.fill();
      g.save(); g.clip(); g.globalCompositeOperation = 'lighter'; glow(g, m.eye, 8, -40, 60, .12); g.restore();
      g.strokeStyle = rgba(m.rim, .55); g.lineWidth = 1.2; g.stroke();
      g.fillStyle = '#030104'; g.beginPath(); g.ellipse(9, -122, 11, 15, .15, 0, TAU); g.fill();
      g.save(); g.globalCompositeOperation = 'lighter'; const f = .85 + Math.sin(t * 7) * .15 + a * .4; glow(g, m.eye, 6, -126, 11, f); glow(g, m.eye, 15, -125, 9, f); g.fillStyle = '#ffffff'; g.fillRect(4.5, -126.8, 3, 1.4); g.fillRect(13.6, -125.8, 2.6, 1.3); g.restore();
      const th = a < .35 ? lerp(.6, -1.9, eIO(a / .35)) : a < .55 ? lerp(-1.9, 1.3, eOut((a - .35) / .2)) : lerp(1.3, .6, eIO((a - .55) / .45));
      const ph = a < .35 ? lerp(-1.4, -2.8, eIO(a / .35)) : a < .55 ? lerp(-2.8, .9, eOut((a - .55 + .2) / .2)) : lerp(.9, -1.4, eIO((a - .55) / .45));
      const sh = [14, -104], ha = [sh[0] + Math.cos(th) * 28, sh[1] + Math.sin(th) * 28];
      g.strokeStyle = mgrad(g, 14, 8, 0, m.d, m.l, P.ld); g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.moveTo(sh[0], sh[1]); g.lineTo(ha[0], ha[1]); g.stroke();
      g.save(); g.translate(ha[0], ha[1]); g.rotate(ph); drawWeapon(g, { type: 'scythe', glow: m.eye, steelL: '#d9d2e8', steelD: '#3a3348', wood: '#2a1f22' }, a > .3 && a < .7 ? 1 : .2, t, P.ld); g.restore();
      g.strokeStyle = m.l; g.lineWidth = 1.4; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(ha[0], ha[1]); g.lineTo(ha[0] + 5 + i, ha[1] + 3 + i * 2); g.stroke(); }
      g.restore();
      c.emit = { x: 0, y: -hov, type: 'wisp' };
    }
  },
  golem: {
    h: 140, engage: 185, hp: 4, atkStyle: 'melee',
    build(c) {
      const r = RNG(c.seed || 3), P = {};
      P.legB = polyJ(r, -16, -22, 14, 7, .22, .9, 1.6); P.legF = polyJ(r, 14, -22, 15, 7, .22, .9, 1.6);
      P.pelvis = polyJ(r, 0, -48, 20, 8, .18, 1.2, .6);
      P.torso = polyJ(r, 0, -82, 34, 10, .16, 1, .95);
      P.head = polyJ(r, 12, -122, 12, 7, .2, 1, .85);
      P.shB = polyJ(r, -26, -104, 16, 7, .25); P.shF = polyJ(r, 28, -102, 17, 7, .25);
      P.arm = polyJ(r, 0, 0, 11, 7, .2, 1, 1.6); P.fist = polyJ(r, 0, 0, 14, 7, .25);
      P.cracks = []; for (let i = 0; i < 9; i++) { const cx = (r() - .5) * 44, cy = -60 - r() * 50, pts = [[cx, cy]]; for (let k = 0; k < 3; k++) pts.push([pts[k][0] + (r() - .5) * 14, pts[k][1] + (r() - .2) * 12]); P.cracks.push(pts); }
      c.shape = P;
    },
    draw(g, c, P, t) {
      const m = c.m, S2 = c.shape, a = P.atk || 0, br = Math.sin(t * 1.6) * 1.5;
      const rock = (p, dk) => { fillPoly(g, p); const x0 = p[0][0] - 8, gr = g.createLinearGradient(x0 - 30 * P.ld, 0, x0 + 30 * P.ld, 0), d0 = dk ? mix(m.d, '#000', .35) : m.d, l0 = dk ? mix(m.l, '#000', .35) : m.l; gr.addColorStop(0, mix(d0, '#000', .3)); gr.addColorStop(.55, d0); gr.addColorStop(1, l0); g.fillStyle = gr; g.fill(); g.strokeStyle = rgba(m.rim, .45); g.lineWidth = 1; g.stroke(); };
      const up = a < .45 ? eIO(a / .45) : a < .6 ? 1 - eOut((a - .45) / .15) : 0;
      const th = lerp(1.1, -1.7, up);
      const gw = P.walk || 0, gwa = P.walkAmt || 0, step = ph => [Math.sin(ph) * 16 * gwa, -Math.max(0, Math.cos(ph)) * 6 * gwa];
      { const o = step(gw + Math.PI); g.save(); g.translate(o[0], o[1]); rock(S2.legB, 1); g.restore(); } rock(S2.shB, 1);
      { const o = step(gw); g.save(); g.translate(o[0], br * .3 + o[1]); rock(S2.legF); g.restore(); }
      g.save(); g.translate(0, br); rock(S2.pelvis); rock(S2.torso); rock(S2.head);
      g.save(); g.globalCompositeOperation = 'lighter';
      g.strokeStyle = rgba(m.crack, .9); g.lineWidth = 1.6; g.shadowColor = m.crack; g.shadowBlur = 8;
      for (const cr of S2.cracks) { g.beginPath(); cr.forEach((q, i) => i ? g.lineTo(q[0], q[1]) : g.moveTo(q[0], q[1])); g.stroke(); }
      g.shadowBlur = 0; const pu = .75 + Math.sin(t * 3) * .2 + a * .5;
      glow(g, m.crack, 0, -82, 30, .32 * pu); glow(g, '#ffffff', 0, -82, 5, .35 * pu);
      glow(g, m.eye, 16, -124, 7, 1); glow(g, m.eye, 8, -125, 6, .8);
      g.restore();
      const sh = [28, -100], el = [sh[0] + Math.cos(th) * 30, sh[1] + Math.sin(th) * 30];
      g.save(); g.translate((sh[0] + el[0]) / 2, (sh[1] + el[1]) / 2); g.rotate(th - Math.PI / 2); rock(S2.arm); g.restore();
      g.save(); g.translate(el[0] + Math.cos(th) * 10, el[1] + Math.sin(th) * 10); rock(S2.fist); g.globalCompositeOperation = 'lighter'; glow(g, m.crack, 0, 0, 16, .25 + up * .5); g.restore();
      rock(S2.shF);
      g.restore();
      c.emit = { x: 0, y: -60, type: m.emit };
    }
  },
  treant: {
    h: 176, engage: 185, hp: 4, atkStyle: 'melee',
    build(c) { const r = RNG(c.seed || 9); c.br = []; for (let i = 0; i < 5; i++) c.br.push([r(), r(), r()]); c.rnd = r; },
    draw(g, c, P, t) {
      const m = c.m, a = P.atk || 0, sw = Math.sin(t * 1.3) * 2;
      const up = a < .4 ? eIO(a / .4) : a < .58 ? 1 - eOut((a - .4) / .18) : 0;
      g.beginPath(); g.moveTo(-40, 2); g.bezierCurveTo(-30, -6, -26, -30, -24, -60); g.bezierCurveTo(-22, -100, -12 + sw, -130, 6 + sw, -140);
      g.bezierCurveTo(24 + sw, -136, 30, -110, 26, -70); g.bezierCurveTo(24, -40, 30, -10, 44, 2); g.closePath();
      g.fillStyle = mgrad(g, 0, 34, 0, m.d, m.l, P.ld); g.fill();
      g.strokeStyle = rgba('#000000', .45); g.lineWidth = 1.2;
      for (let i = 0; i < 7; i++) { const x = -18 + i * 6.5; g.beginPath(); g.moveTo(x, -4); g.bezierCurveTo(x - 3, -40, x + 4 + sw * .3, -80, x + sw * .6, -118 + Math.abs(i - 3) * 6); g.stroke(); }
      g.fillStyle = '#0a0703'; g.beginPath(); g.ellipse(12 + sw, -104, 14, 9, -.1, 0, TAU); g.fill();
      g.save(); g.globalCompositeOperation = 'lighter'; glow(g, m.eye, 8 + sw, -106, 9, 1); glow(g, m.eye, 18 + sw, -105, 8, .9); g.restore();
      g.fillStyle = '#050302'; g.beginPath(); g.moveTo(4 + sw, -88); g.quadraticCurveTo(14 + sw, -82, 22 + sw, -89); g.quadraticCurveTo(14 + sw, -84, 4 + sw, -88); g.fill();
      const leafC = (x, y, r) => { for (let q = 0; q < 3; q++) { const cx = x + (q - 1) * r * .7, cy = y - (q === 1 ? r * .4 : 0), rr = r * (q === 1 ? 1.1 : .85); const gr = g.createRadialGradient(cx + P.ld * rr * .4, cy - rr * .4, 1, cx, cy, rr); gr.addColorStop(0, m.leafL); gr.addColorStop(.6, mix(m.leafL, m.leafD, .5)); gr.addColorStop(1, m.leafD); g.fillStyle = gr; g.beginPath(); for (let k = 0; k <= 14; k++) { const a = k / 14 * TAU, q2 = rr * (.85 + ((k * 7 + q * 3) % 5) * .06); g.lineTo(cx + Math.cos(a) * q2, cy + Math.sin(a) * q2); } g.fill(); } };
      c.rnd = RNG(c.seed || 9);
      branchTree(g, 0 + sw, -134, 24, -1.95, 3, { col: m.d, w: 2.2, rnd: c.rnd, leaf: (x, y) => leafC(x, y, 11) });
      branchTree(g, 14 + sw, -132, 22, -1.05, 3, { col: m.d, w: 2, rnd: c.rnd, leaf: (x, y) => leafC(x, y, 10) });
      for (const [x, y] of [[-20, -70], [22, -40], [-8, -124]]) { g.fillStyle = rgba(m.moss, .9); g.beginPath(); g.ellipse(x, y, 7, 3.5, 0, 0, TAU); g.fill(); }
      g.save(); g.globalCompositeOperation = 'lighter'; for (const [x, y] of [[-20, -72], [-15, -74]]) glow(g, m.shroom, x, y, 8, .8); g.restore();
      g.fillStyle = m.shroom; g.beginPath(); g.ellipse(-20, -73, 4, 2, 0, Math.PI, 0); g.fill();
      const th = lerp(.9, -1.6, up) + Math.sin(t * 1.5) * .05, sh = [22, -96];
      const el = [sh[0] + Math.cos(th) * 30, sh[1] + Math.sin(th) * 30], ha = [el[0] + Math.cos(th + .5) * 28, el[1] + Math.sin(th + .5) * 28];
      g.strokeStyle = mgrad(g, 30, 8, 0, m.d, m.l, P.ld); g.lineCap = 'round'; g.lineWidth = 16; g.beginPath(); g.moveTo(sh[0], sh[1]); g.quadraticCurveTo(el[0], el[1], (el[0] + ha[0]) / 2, (el[1] + ha[1]) / 2); g.stroke(); g.lineWidth = 9; g.beginPath(); g.moveTo((el[0] + ha[0]) / 2, (el[1] + ha[1]) / 2); g.lineTo(ha[0], ha[1]); g.stroke(); g.fillStyle = rgba(m.moss, .9); g.beginPath(); g.ellipse(el[0], el[1] - 5, 8, 3.5, th, 0, TAU); g.fill();
      g.lineWidth = 2.4; for (let i = -1; i <= 1; i++) { const aa = th + .5 + i * .4; g.beginPath(); g.moveTo(ha[0], ha[1]); g.lineTo(ha[0] + Math.cos(aa) * 12, ha[1] + Math.sin(aa) * 12); g.stroke(); }
      c.emit = { x: 0, y: -80, type: 'leaf' };
    }
  },
  wolf: {
    h: 74, engage: 120, hp: 3, atkStyle: 'melee',
    draw(g, c, P, t) {
      const m = c.m, a = P.atk || 0, wa = P.walkAmt || 0, w = P.walk || 0;
      const lunge = a > .3 && a < .7 ? Math.sin((a - .3) / .4 * Math.PI) * 16 : 0, crouch = a < .3 ? eIO(a / .3) * 4 : 0;
      const run = Math.sin(w * 1.85) * wa, bob = -Math.abs(Math.sin(w * 1.85)) * 3 * wa + crouch;
      g.save(); g.translate(lunge, bob);
      const fur = (x, wd) => mgrad(g, x, wd, 0, m.d, m.l, P.ld);
      // tail
      const tw = Math.sin(t * 5) * 4 + run * 6;
      g.fillStyle = fur(-40, 14); g.beginPath(); g.moveTo(-30, -44); g.quadraticCurveTo(-48, -54 + tw * .3, -60, -40 + tw); g.quadraticCurveTo(-50, -46, -30, -36); g.fill();
      // legs (far pair darker)
      const leg = (hx, ph, back) => { const k = [hx + Math.sin(ph) * 7 * wa, -22], f = [hx + Math.sin(ph) * 11 * wa - 2, -Math.max(0, Math.cos(ph)) * 5 * wa];
        const col = back ? mix(m.d, '#000', .35) : m.d; seg(g, [hx, -34], k, 6.5, col); seg(g, k, f, 4.6, col); g.fillStyle = col; g.beginPath(); g.ellipse(f[0] + 2, f[1] - 1, 4, 2.2, 0, 0, TAU); g.fill(); };
      leg(-22, w * 1.85 + Math.PI, 1); leg(16, w * 1.85, 1);
      // body
      g.beginPath(); g.moveTo(-34, -42); g.bezierCurveTo(-30, -58, 8, -60, 22, -52); g.bezierCurveTo(30, -48, 30, -34, 20, -28);
      g.bezierCurveTo(8, -24, -14, -28, -28, -30); g.bezierCurveTo(-36, -32, -38, -38, -34, -42); g.closePath(); g.fillStyle = fur(-4, 30); g.fill();
      g.strokeStyle = rgba(m.rim || m.l, .35); g.lineWidth = 1; for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(-26 + i * 8, -54 + Math.abs(i - 3)); g.lineTo(-30 + i * 8, -47 + Math.abs(i - 3)); g.stroke(); }
      // mane
      g.fillStyle = mix(m.l, '#ffffff', .12); g.beginPath(); g.moveTo(10, -58); for (let i = 0; i <= 6; i++) g.lineTo(12 + i * 3.4, -60 + (i % 2 ? 6 : 0) + i * 1.5); g.lineTo(26, -34); g.lineTo(12, -38); g.closePath(); g.fill();
      leg(-18, w * 1.85, 0); leg(20, w * 1.85 + Math.PI, 0);
      // head
      const jaw = a > .25 && a < .6 ? Math.sin((a - .25) / .35 * Math.PI) * .5 : .05;
      g.save(); g.translate(28, -50); g.rotate(-.08 + (a > .3 && a < .7 ? .15 : 0));
      g.fillStyle = fur(8, 12); g.beginPath(); g.moveTo(-6, -8); g.quadraticCurveTo(4, -12, 12, -7); g.lineTo(26, -3); g.lineTo(27, 1); g.lineTo(12, 3); g.quadraticCurveTo(0, 6, -6, 4); g.closePath(); g.fill();
      g.save(); g.translate(12, 3); g.rotate(jaw); g.fillStyle = mix(m.d, '#000', .2); g.beginPath(); g.moveTo(-10, 0); g.lineTo(14, 0); g.lineTo(12, 3.5); g.lineTo(-8, 4); g.closePath(); g.fill();
      g.fillStyle = '#f2ece0'; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(2 + i * 4, 0); g.lineTo(3.5 + i * 4, -2.4); g.lineTo(5 + i * 4, 0); g.fill(); } g.restore();
      g.fillStyle = '#0a0808'; g.beginPath(); g.arc(26.5, -1.5, 1.6, 0, TAU); g.fill();
      g.fillStyle = mix(m.d, '#000', .25); for (const ex of [-2, 3]) { g.beginPath(); g.moveTo(ex - 3, -8); g.lineTo(ex + 1, -19); g.lineTo(ex + 4, -8); g.fill(); }
      g.save(); g.globalCompositeOperation = 'lighter'; glow(g, m.eye, 11, -5, 6, .95); g.fillStyle = mix(m.eye, '#ffffff', .6); g.fillRect(9.5, -5.6, 3, 1.2); g.restore();
      g.restore();
      g.restore();
      c.emit = null;
    }
  },
  sentinel: {
    h: 150, engage: 200, hp: 4, atkStyle: 'cast',
    draw(g, c, P, t) {
      const m = c.m, a = P.atk || 0, bob = Math.sin(t * 1.8) * 6, cy = -100 + bob;
      g.save(); g.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 3; i++) { g.strokeStyle = rgba(m.eye, .25 - i * .06); g.lineWidth = 3 - i * .6; g.beginPath(); g.moveTo(-8 + i * 8, cy + 20); for (let k = 1; k <= 8; k++) g.lineTo(-8 + i * 8 + Math.sin(t * 3 + k + i) * 5, cy + 20 + k * 9); g.stroke(); }
      g.restore();
      const ring = (rx, ry, rot, back) => { g.save(); g.translate(0, cy); g.rotate(rot); g.strokeStyle = back ? rgba(m.ring, .35) : m.ring; g.lineWidth = 2.4; g.beginPath(); g.ellipse(0, 0, rx, ry, 0, back ? Math.PI : 0, back ? TAU : Math.PI); g.stroke(); g.restore(); };
      const r1 = t * .9, r2 = -t * .6 + 1;
      ring(46, 12, .35 + Math.sin(r1) * .15, true); ring(38, 9, -.5 + Math.sin(r2) * .15, true);
      const shards = []; for (let i = 0; i < 6; i++) { const aa = t * 1.2 + i / 6 * TAU; shards.push([Math.cos(aa) * 58, Math.sin(aa) * 14, Math.sin(aa)]); }
      const shd = s => { g.save(); g.translate(s[0], cy + s[1]); g.rotate(t + s[0] * .02); const k = .7 + s[2] * .3; g.fillStyle = vgrad(g, -8, 8, mix(m.l, '#ffffff', .2), m.d); g.beginPath(); g.moveTo(0, -9 * k); g.lineTo(4 * k, 0); g.lineTo(0, 9 * k); g.lineTo(-4 * k, 0); g.closePath(); g.fill(); g.restore(); };
      shards.filter(s => s[2] < 0).forEach(shd);
      const og = g.createRadialGradient(8 * P.ld, cy - 10, 4, 0, cy, 28); og.addColorStop(0, m.l); og.addColorStop(.7, m.d); og.addColorStop(1, '#05030a');
      g.fillStyle = og; g.beginPath(); g.arc(0, cy, 27, 0, TAU); g.fill();
      g.strokeStyle = m.ring; g.lineWidth = 1.5; g.beginPath(); g.arc(0, cy, 27, 0, TAU); g.stroke();
      g.fillStyle = '#060310'; g.beginPath(); g.ellipse(10, cy, 12, 15, 0, 0, TAU); g.fill();
      g.save(); g.globalCompositeOperation = 'lighter'; const ch = a < .55 ? a / .55 : 1 - (a - .55) / .45; glow(g, m.eye, 12, cy, 14 + ch * 26, .9 + ch * .6); glow(g, '#ffffff', 12, cy, 4 + ch * 5, 1); g.restore();
      ring(46, 12, .35 + Math.sin(r1) * .15, false); ring(38, 9, -.5 + Math.sin(r2) * .15, false);
      shards.filter(s => s[2] >= 0).forEach(shd);
      c.emit = { x: 0, y: cy, type: 'spark' };
      c.castPt = [12, cy];
    }
  }
};

/* =====================================================================
   THEMES
===================================================================== */
function stars(g, W, top, n, seed, cols) { const r = RNG(seed); for (let i = 0; i < n; i++) { const x = r() * W, y = r() * top, s = r(); g.fillStyle = rgba(cols[i % cols.length], .35 + s * .6); g.fillRect(x, y, s > .92 ? 1.6 : 1, s > .92 ? 1.6 : 1); if (s > .96) { g.globalCompositeOperation = 'lighter'; glow(g, cols[0], x, y, 5, .5); g.globalCompositeOperation = 'source-over'; } } }
function skyGrad(g, W, H, stops) { const gr = g.createLinearGradient(0, 0, 0, H); stops.forEach(s => gr.addColorStop(s[0], s[1])); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
function moon(g, x, y, r, a, b, halo) {
  g.globalCompositeOperation = 'lighter'; glow(g, halo, x, y, r * 9, .22); glow(g, halo, x, y, r * 3.2, .35); g.globalCompositeOperation = 'source-over';
  const gr = g.createRadialGradient(x - r * .3, y - r * .3, r * .1, x, y, r); gr.addColorStop(0, a); gr.addColorStop(1, b); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
  const rr = RNG(5); g.fillStyle = 'rgba(60,40,90,.12)'; for (let i = 0; i < 7; i++) { g.beginPath(); g.arc(x + (rr() - .5) * r * 1.2, y + (rr() - .5) * r * 1.2, r * (.08 + rr() * .16), 0, TAU); g.fill(); }
}
function cloudBand(g, W, y, col, n, seed, h) { const r = RNG(seed); for (let i = 0; i < n; i++) { const x = r() * W, yy = y + (r() - .5) * (h || 20), rx = 40 + r() * 90, ry = 4 + r() * 7; g.fillStyle = rgba(col, .2 + r() * .35); g.beginPath(); g.ellipse(x, yy, rx, ry, 0, 0, TAU); g.fill(); } }

const THEMES = {};

/* ---------------- 1. OBSIDIAN CATHEDRAL ---------------- */
THEMES.gothic = {
  ldir: 1, seed: 11,
  sky(g, E) {
    skyGrad(g, E.W, E.H, [[0, '#06040c'], [.35, '#130b24'], [.62, '#2c1b45'], [.8, '#5b3f6e'], [1, '#2a1b33']]);
    stars(g, E.W, E.GY * .7, 160, 3, ['#ffffff', '#d9c9ff', '#ffe9c9']);
    moon(g, 640, 82, 30, '#fbf6ff', '#c9b6ea', '#b9a3ff');
    cloudBand(g, E.W, 92, '#1b1030', 14, 8, 30); cloudBand(g, E.W, 150, '#2a1a40', 10, 9, 20);
  },
  shafts: { x: 640, y: 82, col: '#c8b4ff', n: 5, a: .06, spread: 1.1, ang: 2.2 },
  layers(E) {
    const { TW, H, GY } = E; return [
      { speed: .03, draw(g) { ridge(g, TW, H, { seed: 21, N: 5, y: GY - 30, amp: 120, sharp: 1.5, top: '#46356a', bot: '#2e2350', lit: '#c8b4ff', litA: .2, litH: 60, rim: '#d8c8ff', rimA: .3, dir: 1, fade: 120, oct: 4 }); } },
      { speed: .09, draw(g, E2) {
        const yAt = ridge(g, TW, H, { seed: 22, N: 4, y: GY - 12, amp: 34, top: '#221838', bot: '#160f26', rim: '#a58fe0', rimA: .45, dir: 1 });
        const r = RNG(4), col = '#140d20', lights = this.lights = [];
        for (const cx of [260, 1100]) { const by = yAt(cx) + 6;
          tower(g, cx, by, 26, 120, { col, roof: 2.6, rim: '#b9a3ff', ld: 1, win: '#ffb35c', rnd: r, lights, cross: 1, buttress: 1 });
          for (const o of [-46, 46]) tower(g, cx + o, by, 16, 78, { col, roof: 3, rim: '#b9a3ff', ld: 1, win: '#ffb35c', rnd: r, lights });
          for (const o of [-80, 78]) tower(g, cx + o, by, 12, 46, { col, roof: 3.2, rim: '#b9a3ff', ld: 1, rnd: r });
          g.fillStyle = col; g.fillRect(cx - 70, by - 44, 140, 60);
          g.fillStyle = rgba('#ffb35c', .85); g.beginPath(); g.arc(cx, by - 70, 7, 0, TAU); g.fill(); g.strokeStyle = col; g.lineWidth = 1.4; for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; g.beginPath(); g.moveTo(cx, by - 70); g.lineTo(cx + Math.cos(a) * 7, by - 70 + Math.sin(a) * 7); g.stroke(); }
          lights.push({ x: cx, y: by - 70, col: '#ff9d3c', r: 26, a: .7 });
        }
        for (let i = 0; i < 18; i++) { const x = r() * TW; tower(g, x, yAt(x) + 4, 5 + r() * 6, 14 + r() * 40, { col: '#1a1229', roof: 2.8, rim: '#b9a3ff', rimA: .3, ld: 1, rnd: r }); }
      } },
      { speed: .26, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 23, N: 6, y: GY + 4, amp: 22, top: '#130d1f', bot: '#0c0815', rim: '#9a84d4', rimA: .5, dir: 1 });
        const r = RNG(12);
        for (let i = 0; i < 7; i++) { const x = 40 + i * TW / 7 + r() * 60, by = yAt(x) + 3;
          if (i % 2) { branchTree(g, x, by + 4, 26 + r() * 14, -Math.PI / 2 + (r() - .5) * .3, 5, { col: '#0f0a18', w: 1.2, rnd: r }); }
          else { g.fillStyle = '#100b1a'; g.fillRect(x - 18, by - 64, 8, 70); g.fillRect(x + 12, by - 50, 8, 56); g.beginPath(); g.arc(x + 1, by - 58, 17, Math.PI, 0); g.lineWidth = 7; g.strokeStyle = '#100b1a'; g.stroke(); g.fillStyle = rgba('#b9a3ff', .35); g.fillRect(x - 10.8, by - 64, 1, 70); }
          for (let k = 0; k < 3; k++) { const gx = x + 30 + k * 16, gy = yAt(gx) + 4; g.fillStyle = '#120c1c'; g.fillRect(gx - 3, gy - 12, 6, 14); g.fillRect(gx - 6, gy - 9, 12, 3); }
        }
      } },
      { speed: .55, draw(g) {
        const r = RNG(31), lights = this.lights = [];
        for (let i = 0; i < 4; i++) { const x = 90 + i * TW / 4 + r() * 80, by = GY + 2;
          g.fillStyle = vgrad(g, by - 120, by, '#1d1529', '#0d0914'); g.fillRect(x - 11, by - 118, 22, 120); g.fillRect(x - 15, by - 124, 30, 8); g.fillRect(x - 15, by - 8, 30, 10);
          g.fillStyle = rgba('#c9b6ff', .28); g.fillRect(x + 9, by - 118, 2, 118); g.fillStyle = 'rgba(0,0,0,.35)'; for (let k = 1; k < 8; k++) g.fillRect(x - 11, by - 118 + k * 15, 22, 1); g.strokeStyle = '#16241a'; g.lineWidth = 1.3; g.beginPath(); g.moveTo(x - 11, by - 100); g.bezierCurveTo(x - 4, by - 80, x - 14, by - 50, x - 6, by - 20); g.stroke(); g.fillStyle = '#1e3322'; for (let k = 0; k < 7; k++) { g.beginPath(); g.ellipse(x - 9 + Math.sin(k) * 4, by - 95 + k * 11, 2.6, 1.4, k, 0, TAU); g.fill(); }
          g.beginPath(); g.moveTo(x - 15, by - 124); g.lineTo(x - 6, by - 136); g.lineTo(x + 2, by - 127); g.lineTo(x + 15, by - 124); g.fillStyle = '#1d1529'; g.fill();
          const bx = x + 60; g.fillStyle = '#1a1220'; g.fillRect(bx - 2, by - 34, 4, 34); g.beginPath(); g.moveTo(bx - 9, by - 34); g.lineTo(bx + 9, by - 34); g.lineTo(bx + 5, by - 42); g.lineTo(bx - 5, by - 42); g.fill();
          lights.push({ x: bx, y: by - 44, col: '#ff8a2a', r: 40, a: .9, fire: 1 });
        }
      }, stage: 'bg' },
      { speed: 1.35, stage: 'fg', draw(g) { grassClumps(g, TW, H, { rnd: RNG(41), n: 9, h: 46, col: '#06040a', rim: '#b9a3ff' }); } }
    ];
  },
  fog: [{ y: -70, h: 110, col: '#7a5aa0', a: .55, speed: .06 }, { y: -12, h: 70, col: '#4a3368', a: .7, speed: .22 }],
  ground(g, E) {
    const { TW, H, GY } = E; g.fillStyle = vgrad(g, GY - 4, H, '#231a2c', '#07050a'); g.fillRect(0, GY - 2, TW, H);
    const r = RNG(51);
    for (let row = 0; row < 5; row++) { const y = GY + 3 + row * row * 5 + row * 6, hh = 6 + row * 4; let x = -r() * 30; while (x < TW) { const w = 26 + row * 12 + r() * 20; g.fillStyle = mix('#2a2034', '#120d18', r() * .6 + row * .08); g.fillRect(x + 1, y, w - 2, hh); g.fillStyle = rgba('#c9b6ff', .1 + (4 - row) * .02); g.fillRect(x + 1, y, w - 2, 1); x += w; } }
    for (let i = 0; i < 60; i++) { const x = r() * TW, y = GY + 4 + r() * 30; g.fillStyle = rgba('#d8c8ff', .05 + r() * .08); g.fillRect(x, y, 10 + r() * 40, 1); }
    g.fillStyle = '#0a0710'; for (let x = 0; x < TW; x += 3) { const h = 2 + r() * 6; g.fillRect(x, GY - h + 2, 1.4, h); }
  },
  particles: [{ type: 'wisp', rate: 3, col: '#c79bff' }, { type: 'mote', rate: 6, col: '#e9dcff' }, { type: 'ember', rate: 2, col: '#ffa04a' }],
  grade: { col: '#3a1f5a', a: .14, mode: 'soft-light' }, vignette: .7, ambient: '#b9a3ff', reflect: .16,
  hero: [
    { name: 'Oathkeeper Blade', body: 'armor', armD: '#2a2934', armL: '#b3b0c4', trim: '#d0ab62', cape: '#8a1630', capeD: '#2b0510', capeTrim: '#d0ab62', tabard: '#6a1022', helm: 'greathelm', plume: '#a31d3a', glow: '#c9a2ff', weapon: { type: 'sword', glow: '#c9a2ff', trim: '#d0ab62' }, shield: { type: 'kite', col: '#2b2136', trim: '#d0ab62', emblem: 'cross' } },
    { name: 'Duskreaver Greatsword', body: 'armor', armD: '#221f2c', armL: '#9fa0b8', trim: '#b99bff', cape: '#3a1a5c', capeD: '#110622', capeTrim: '#b99bff', tabard: '#2c1446', helm: 'winged', wingCol: '#d9d0f0', glow: '#d59bff', weapon: { type: 'greatsword', glow: '#d59bff', trim: '#b99bff', rune: 1 } },
    { name: 'Nightfall Axe', body: 'armor', armD: '#2c2622', armL: '#c9b99a', trim: '#e2b75a', cape: '#5c0e1c', capeD: '#1e0409', tabard: '#1a1420', helm: 'crown', crownCol: '#e2b75a', gem: '#ff4d6d', glow: '#ff7a8a', spikes: 1, weapon: { type: 'axe', glow: '#ff6a7a', trim: '#e2b75a' }, shield: { type: 'round', col: '#3a2530', trim: '#e2b75a', emblem: 'sun' } }
  ],
  mobs: [
    { kind: 'rig', name: 'Hollow Squire', skin: { body: 'bone', armD: '#6b6456', armL: '#d8cfb8', trim: '#8a7a5a', helm: 'skull', brokenHelm: 1, rags: '#3a2a3a', glow: '#b58cff', weapon: { type: 'sword', glow: '#9a7ad8', steelL: '#b8b2a8', steelD: '#4a4540', trim: '#6a5a44' }, shield: { type: 'round', col: '#3a3030', trim: '#6a5a44' } } },
    { kind: 'creature', type: 'wraith', name: 'Nave Wraith', m: { d: '#120a1c', l: '#4a2f66', rim: '#c9a2ff', eye: '#ff4fd0' } },
    { kind: 'rig', name: 'Grave Warden', elite: 1, skin: { body: 'armor', armD: '#1c1a20', armL: '#6e6a7c', trim: '#7a5ab0', cape: '#2a1a3a', capeD: '#0a0610', helm: 'horned', hornCol: '#d8ccb0', glow: '#9dff9a', weapon: { type: 'greatsword', glow: '#8dff8a', steelL: '#cfd6c8', steelD: '#3a4038' }, spikes: 1 } }
  ]
};

/* ---------------- 2. EMBERFORGE CALDERA ---------------- */
THEMES.ember = {
  ldir: 1, seed: 12,
  sky(g, E) {
    skyGrad(g, E.W, E.H, [[0, '#0a0404'], [.3, '#210806'], [.6, '#5e1a0c'], [.8, '#b8461a'], [1, '#3a1208']]);
    const x = 560, y = 96;
    g.globalCompositeOperation = 'lighter'; glow(g, '#ff6a1a', x, y, 260, .3); glow(g, '#ffb04a', x, y, 90, .5); g.globalCompositeOperation = 'source-over';
    g.fillStyle = '#0c0302'; g.beginPath(); g.arc(x, y, 30, 0, TAU); g.fill();
    g.globalCompositeOperation = 'lighter'; g.strokeStyle = 'rgba(255,200,120,.9)'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, 30.5, 0, TAU); g.stroke(); g.globalCompositeOperation = 'source-over';
    g.fillStyle = vgrad(g, 0, 120, 'rgba(8,2,2,.85)', 'rgba(8,2,2,0)'); g.fillRect(0, 0, E.W, 120); const r = RNG(7); for (let i = 0; i < 16; i++) { const cx = r() * E.W, cy = 50 + r() * 130, rx = 90 + r() * 160, ry = 14 + r() * 24; const gr = g.createRadialGradient(cx, cy + ry * .6, 2, cx, cy, rx); gr.addColorStop(0, rgba('#ff7a2a', .18)); gr.addColorStop(.5, rgba('#2a0d08', .55)); gr.addColorStop(1, rgba('#1a0806', 0)); g.fillStyle = gr; g.beginPath(); g.ellipse(cx, cy, rx, ry, 0, 0, TAU); g.fill(); }
    stars(g, E.W, 60, 30, 9, ['#ffcf9a']);
  },
  layers(E) {
    const { TW, H, GY } = E; return [
      { speed: .03, draw(g) {
        ridge(g, TW, H, { seed: 61, N: 5, y: GY - 34, amp: 90, sharp: 1.3, top: '#2e110a', bot: '#1a0806', lit: '#ff7a2a', litA: .22, rim: '#ff9a4a', rimA: .3, fade: 110 });
        const lights = this.lights = [];
        for (const vx of [420, 1180]) { g.fillStyle = vgrad(g, GY - 190, GY, '#2a0e08', '#150605'); g.beginPath(); g.moveTo(vx - 170, GY + 10); g.lineTo(vx - 26, GY - 180); g.lineTo(vx + 26, GY - 184); g.lineTo(vx + 180, GY + 10); g.fill();
          g.globalCompositeOperation = 'lighter'; for (let k = 0; k < 4; k++) { const lx = vx - 14 + k * 9; g.strokeStyle = rgba('#ff6a1a', .8); g.lineWidth = 2.6; g.shadowColor = '#ff5a1a'; g.shadowBlur = 10; g.beginPath(); g.moveTo(lx, GY - 180); g.bezierCurveTo(lx - 10 - k * 6, GY - 120, lx + 8 - k * 14, GY - 60, lx - 30 + k * 10, GY); g.stroke(); } g.shadowBlur = 0; g.globalCompositeOperation = 'source-over';
          lights.push({ x: vx, y: GY - 184, col: '#ff7a2a', r: 90, a: .8, pulse: 1 }); }
      } },
      { speed: .12, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 62, N: 7, y: GY - 6, amp: 60, sharp: 2.2, top: '#1f0c08', bot: '#100504', rim: '#ff8a3a', rimA: .6, lit: '#ff6a1a', litA: .16 });
        const r = RNG(14), lights = this.lights = [];
        for (const cx of [200, 950]) { const by = yAt(cx) + 8; g.fillStyle = '#140705'; g.fillRect(cx - 34, by - 70, 68, 80); for (const o of [-26, 0, 22]) { g.fillRect(cx + o - 5, by - 110 - (o ? 0 : 20), 10, 60); }
          for (let i = 0; i < 6; i++) { const wx = cx - 26 + (i % 3) * 22, wy = by - 58 + Math.floor(i / 3) * 22; g.fillStyle = rgba('#ffa040', .9); g.fillRect(wx, wy, 6, 9); lights.push({ x: wx + 3, y: wy + 5, col: '#ff8a2a', r: 12, a: .6 }); }
          lights.push({ x: cx, y: by - 130, col: '#ff5a1a', r: 30, a: .5, pulse: 1 }); }
      } },
      { speed: .34, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 63, N: 9, y: GY + 8, amp: 26, sharp: 1.8, top: '#170906', bot: '#0b0403', rim: '#ff7a2a', rimA: .55 });
        const r = RNG(16), lights = this.lights = [];
        for (let i = 0; i < 9; i++) { const x = r() * TW, by = yAt(x) + 6, h = 40 + r() * 60; shard(g, x, by, 14 + r() * 10, h, (r() - .5) * .25, { dark: '#0e0504', light: '#3a1a10', base: '#140705', edge: '#ff7a2a', ld: 1 }); }
        for (let i = 0; i < 5; i++) { const x = r() * TW, y = yAt(x) + 10; g.fillStyle = '#ff6a1a'; g.beginPath(); g.ellipse(x, y, 26, 3.5, 0, 0, TAU); g.fill(); lights.push({ x, y, col: '#ff6a1a', r: 34, a: .7, pulse: 1 }); }
      } },
      { speed: 1.35, stage: 'fg', draw(g) { const r = RNG(47); for (let i = 0; i < 10; i++) { const x = r() * TW; rock(g, x, H + 4, 50 + r() * 60, 20 + r() * 30, { rnd: r, dark: '#050202', light: '#1a0a06', ld: 1, top: '#ff6a1a' }); } } }
    ];
  },
  fog: [{ y: -120, h: 120, col: '#1a0806', a: .8, speed: .05 }, { y: -30, h: 80, col: '#ff5a1a', a: .28, speed: .18 }],
  ground(g, E) {
    const { TW, H, GY } = E; g.fillStyle = vgrad(g, GY - 4, H, '#2a120c', '#070302'); g.fillRect(0, GY - 2, TW, H);
    const r = RNG(52); for (let i = 0; i < 45; i++) { const x = r() * TW, y = GY + 6 + Math.pow(r(), 1.5) * 80; rock(g, x, y, 14 + r() * 34, 2 + r() * 4, { rnd: r, dark: '#0e0504', light: '#2a130c', ld: 1, top: '#8a3a1a' }); }
  },
  groundEmit(g, E) {
    const { TW, GY } = E, r = RNG(53); g.strokeStyle = '#ff6a1a'; g.lineCap = 'round';
    for (let i = 0; i < 26; i++) { let x = r() * TW, y = GY + 6 + r() * 70; g.lineWidth = .8 + r() * 1.6; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 5; k++) { x += 8 + r() * 16; y += (r() - .5) * 8; g.lineTo(x, y); } g.stroke(); }
  },
  particles: [{ type: 'ember', rate: 22, col: '#ff8a2a' }, { type: 'ash', rate: 8, col: '#8a7a74' }],
  grade: { col: '#ff4a10', a: .1, mode: 'soft-light' }, vignette: .75, ambient: '#ff7a2a', heat: 1,
  hero: [
    { name: 'Magmaforged Axe', body: 'armor', armD: '#241a17', armL: '#a58a7a', trim: '#e8a040', cape: '#5a1408', capeD: '#1a0503', tabard: '#3a0d06', helm: 'horned', hornCol: '#e9d9b8', glow: '#ff9a3a', weapon: { type: 'axe', glow: '#ff8a2a', trim: '#e8a040' }, shield: { type: 'round', col: '#2a1612', trim: '#e8a040', emblem: 'flame' } },
    { name: 'Anvilbreaker Mace', body: 'armor', armD: '#2a2524', armL: '#c4b8b0', trim: '#ffb860', cape: '#8a2a0a', capeD: '#2a0802', capeTrim: '#ffb860', tabard: '#6a1e08', helm: 'greathelm', plume: '#ff6a1a', glow: '#ffb040', spikes: 1, weapon: { type: 'mace', glow: '#ffa040', trim: '#ffb860' }, shield: { type: 'kite', col: '#3a1a10', trim: '#ffb860', emblem: 'sun' } },
    { name: 'Caldera Greatsword', body: 'armor', armD: '#1a1412', armL: '#8a6f63', trim: '#ff7a2a', cape: '#2a0a06', capeD: '#0a0302', capeTrim: '#ff7a2a', helm: 'crown', crownCol: '#ffb060', gem: '#ff3a1a', glow: '#ff6a2a', spikes: 1, weapon: { type: 'greatsword', glow: '#ff5a1a', rune: 1, steelL: '#f0d8c8', steelD: '#4a2a20', trim: '#ff9a4a' } }
  ],
  mobs: [
    { kind: 'rig', name: 'Cinder Cultist', skin: { body: 'robe', robe: '#3a0e0a', trim: '#d88030', helm: 'hood', glow: '#ffcf4a', weapon: { type: 'staff', glow: '#ff7a1a', wood: '#2a1810' } }, atkStyle: 'cast' },
    { kind: 'creature', type: 'golem', name: 'Magma Colossus', m: { d: '#1a100c', l: '#5a3a2c', rim: '#ff8a3a', crack: '#ff6a1a', eye: '#ffe08a', emit: 'ember' } },
    { kind: 'rig', name: 'Forge Brute', elite: 1, skin: { body: 'armor', armD: '#1a1616', armL: '#6a5a54', trim: '#c86020', helm: 'horned', hornCol: '#3a2a22', glow: '#ff5a1a', spikes: 1, weapon: { type: 'axe', glow: '#ff5a1a', steelL: '#d0b8a8', steelD: '#3a2a22' } } }
  ]
};

/* ---------------- 3. FROSTVEIL CITADEL ---------------- */
THEMES.frost = {
  ldir: -1, seed: 13,
  sky(g, E) {
    skyGrad(g, E.W, E.H, [[0, '#040a18'], [.35, '#0c1d3a'], [.62, '#1f4270'], [.82, '#6a9cc8'], [1, '#2a4a6a']]);
    stars(g, E.W, E.GY * .7, 190, 6, ['#ffffff', '#cfe8ff']);
    moon(g, 170, 70, 18, '#ffffff', '#cfe4f8', '#bfe0ff');
  },
  aurora: [{ col: '#5affc0', y: 70, amp: 22, len: 70, sp: .25 }, { col: '#6ab8ff', y: 92, amp: 16, len: 50, sp: -.18 }, { col: '#c07aff', y: 58, amp: 12, len: 40, sp: .12 }],
  shafts: { x: 170, y: 70, col: '#d6ecff', n: 4, a: .045, spread: 1, ang: .85 },
  layers(E) {
    const { TW, H, GY } = E; return [
      { speed: .03, draw(g) { ridge(g, TW, H, { seed: 71, N: 4, oct: 3, y: GY - 36, amp: 140, sharp: 1.3, litH: 70, top: '#6f90b8', bot: '#35527a', snow: .45, snowCol: '#f2f9ff', rim: '#ffffff', rimA: .55, dir: -1, fade: 120 }); } },
      { speed: .09, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 72, N: 4, y: GY - 10, amp: 36, top: '#2c4a72', bot: '#1a3050', snow: .1, rim: '#d8f0ff', rimA: .5, dir: -1 });
        const r = RNG(18), lights = this.lights = [];
        for (const cx of [520, 1300]) { const by = yAt(cx) + 6;
          for (const [o, w, h] of [[0, 22, 130], [-40, 14, 90], [38, 15, 96], [-70, 10, 56], [66, 10, 60]]) {
            shard(g, cx + o, by, w * 1.3, h, 0, { dark: '#3a6a9a', light: '#dff4ff', base: '#1f3f66', edge: '#ffffff', ld: -1, glow: '#7fe8ff', lights });
          }
          g.fillStyle = '#1c3658'; g.fillRect(cx - 60, by - 36, 120, 44);
          for (let i = 0; i < 5; i++) { g.fillStyle = rgba('#8ff0ff', .9); g.fillRect(cx - 50 + i * 24, by - 26, 5, 10); lights.push({ x: cx - 47 + i * 24, y: by - 21, col: '#6fe6ff', r: 12, a: .6 }); }
        }
      } },
      { speed: .26, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 73, N: 7, y: GY + 4, amp: 18, top: '#1a2d44', bot: '#0f1c2e', snow: .01, rim: '#e8f6ff', rimA: .6, dir: -1 });
        const r = RNG(19); for (let i = 0; i < 38; i++) { const x = r() * TW; pine(g, x, yAt(x) + 4, 34 + r() * 50, { col: mix('#12233a', '#0a1626', r()), snow: '#eef8ff', ld: -1 }); }
      } },
      { speed: .55, draw(g) {
        const r = RNG(33), lights = this.lights = [];
        for (let i = 0; i < 5; i++) { const x = 60 + i * TW / 5 + r() * 60, by = GY + 4;
          for (let k = 0; k < 4; k++) shard(g, x + (k - 1.5) * 9, by, 9 + r() * 6, 20 + r() * 42, (k - 1.5) * .12, { dark: '#2d6aa0', light: '#e6fbff', base: '#1a4a78', edge: '#ffffff', ld: -1, glow: '#6ff0ff', lights });
          rock(g, x + 60, by + 2, 50, 18, { rnd: r, dark: '#1a2a40', light: '#5a7a9a', ld: -1, top: '#ffffff' });
        }
      } },
      { speed: 1.35, stage: 'fg', draw(g) { const r = RNG(48); for (let i = 0; i < 9; i++) { const x = r() * TW; g.fillStyle = '#dce9f5'; g.beginPath(); g.ellipse(x, H + 6, 60 + r() * 50, 16 + r() * 14, 0, 0, TAU); g.fill(); } } }
    ];
  },
  fog: [{ y: -44, h: 90, col: '#cfe6fa', a: .35, speed: .06 }, { y: 6, h: 60, col: '#eef7ff', a: .45, speed: .22 }],
  ground(g, E) {
    const { TW, H, GY } = E; g.fillStyle = vgrad(g, GY - 4, H, '#dcebf8', '#5f7fa4'); g.fillRect(0, GY - 2, TW, H);
    const r = RNG(54); for (let i = 0; i < 26; i++) { const x = r() * TW, y = GY + 10 + r() * 60; g.fillStyle = rgba('#7aa6d0', .35); g.beginPath(); g.ellipse(x, y, 30 + r() * 60, 2 + r() * 4, 0, 0, TAU); g.fill(); }
    for (let i = 0; i < 14; i++) { const x = r() * TW, y = GY + 20 + r() * 50; g.fillStyle = rgba('#bfe8ff', .5); g.beginPath(); g.ellipse(x, y, 20 + r() * 40, 2, 0, 0, TAU); g.fill(); g.fillStyle = rgba('#ffffff', .7); g.fillRect(x - 10, y - .5, 20, .8); }
    for (let i = 0; i < 160; i++) { g.fillStyle = rgba('#ffffff', .5 + r() * .5); g.fillRect(r() * TW, GY + r() * 80, 1, 1); }
    g.fillStyle = '#f4faff'; for (let x = 0; x < TW; x += 4) { const h = 1 + r() * 3; g.beginPath(); g.ellipse(x, GY, 5, h, 0, Math.PI, 0); g.fill(); }
  },
  particles: [{ type: 'snow', rate: 40, col: '#ffffff' }, { type: 'glint', rate: 6, col: '#bff4ff' }],
  grade: { col: '#3a6aa8', a: .12, mode: 'soft-light' }, vignette: .6, ambient: '#bfe6ff', reflect: .2,
  hero: [
    { name: 'Rimeguard Blade', body: 'armor', armD: '#33455e', armL: '#dfeefb', trim: '#a8d8f5', cape: '#1f3f7a', capeD: '#081630', capeTrim: '#dff4ff', tabard: '#1a3668', helm: 'winged', wingCol: '#f1f6ff', glow: '#7fe8ff', acc: 'fur', weapon: { type: 'sword', glow: '#7fe8ff', trim: '#cfe8ff' }, shield: { type: 'kite', col: '#27466e', trim: '#dff4ff', emblem: 'flake' } },
    { name: 'Glacier Greatsword', body: 'armor', armD: '#2a3446', armL: '#c8d8ea', trim: '#8fd0ff', cape: '#2a5a8a', capeD: '#0a1e36', helm: 'greathelm', plume: '#e8f4ff', glow: '#9ff0ff', acc: 'fur', weapon: { type: 'greatsword', glow: '#8ff0ff', rune: 1, steelL: '#ffffff', steelD: '#5a8ab8', trim: '#8fd0ff' } },
    { name: 'Crown of Winter & Mace', body: 'armor', armD: '#3a4a60', armL: '#f0f6ff', trim: '#e8f0ff', cape: '#4a2a8a', capeD: '#140a30', capeTrim: '#e8f0ff', tabard: '#2a1a5a', helm: 'crown', crownCol: '#e6f4ff', gem: '#7fe8ff', glow: '#c9b8ff', weapon: { type: 'mace', glow: '#9fe8ff', trim: '#e8f0ff', steelL: '#ffffff', steelD: '#6a8ab0' }, shield: { type: 'round', col: '#3a4a70', trim: '#e8f0ff', emblem: 'star' } }
  ],
  mobs: [
    { kind: 'rig', name: 'Rimebound Dead', skin: { body: 'bone', armD: '#5a7088', armL: '#cfe6f5', trim: '#8ab0d0', helm: 'skull', rags: '#2a3a55', glow: '#6ff0ff', weapon: { type: 'spear', glow: '#8ff0ff', steelL: '#e6f8ff', steelD: '#6a9ac0', wood: '#3a3a44' } } },
    { kind: 'creature', type: 'golem', name: 'Glacial Colossus', seed: 7, m: { d: '#2a4a70', l: '#cfeeff', rim: '#ffffff', crack: '#6fe8ff', eye: '#ffffff', emit: 'snowburst' } },
    { kind: 'rig', name: 'Frost Templar', elite: 1, skin: { body: 'armor', armD: '#1c2838', armL: '#7a94b0', trim: '#6fb8e8', cape: '#0e2038', capeD: '#050c18', helm: 'horned', hornCol: '#dff4ff', glow: '#4ff0ff', spikes: 1, weapon: { type: 'mace', glow: '#4ff0ff', steelL: '#e6f8ff', steelD: '#3a5a7a' } } }
  ]
};

/* ---------------- 4. VERDANT HOLLOW ---------------- */
THEMES.verdant = {
  ldir: 1, seed: 14,
  sky(g, E) {
    skyGrad(g, E.W, E.H, [[0, '#15303e'], [.3, '#2f5a62'], [.55, '#8a8a62'], [.75, '#f0b46a'], [1, '#6a5a32']]);
    g.globalCompositeOperation = 'lighter'; glow(g, '#ffd48a', 620, E.GY - 70, 300, .45); glow(g, '#fff0c8', 620, E.GY - 70, 70, .7); g.globalCompositeOperation = 'source-over';
    { const r = RNG(3), cl = mkS(E.W, E.H); for (let i = 0; i < 8; i++) cumulus(cl.g, r() * E.W, 60 + r() * 80, 110 + r() * 120, { rnd: r, top: '#fff2dc', mid: '#f0b894', bot: '#9a7a86', a: .55 }); const bl = softBlur(cl.c, 3); g.save(); g.globalAlpha = .75; g.drawImage(bl, 0, 0, E.W, E.H); g.restore(); freeCanvas(bl); freeCanvas(cl.c); }
  },
  shafts: { x: 620, y: 150, col: '#ffe2a0', n: 9, a: .13, spread: 1.5, ang: 2.35 },
  layers(E) {
    const { TW, H, GY } = E; return [
      { speed: .03, draw(g) { ridge(g, TW, H, { seed: 81, N: 4, y: GY - 40, amp: 70, top: '#7a9a8a', bot: '#5a7e76', lit: '#ffe0a0', litA: .25, dir: 1, fade: 100 }); } },
      { speed: .08, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 82, N: 5, y: GY - 20, amp: 30, top: '#4d746a', bot: '#3a5e56' });
        const r = RNG(21); for (let i = 0; i < 30; i++) { const x = r() * TW; canopyTree(g, x, yAt(x) + 6, 60 + r() * 50, { rnd: r, n: 12, detail: 6, ld: 1, trunkD: '#2e4a44', trunkL: '#4a6a60', leafL: '#8ab090', leafM: '#5a8474', leafD: '#40665c' }); }
      } },
      { speed: .24, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 83, N: 6, y: GY + 4, amp: 16, top: '#1f3a2a', bot: '#12241a' });
        const r = RNG(22), lights = this.lights = [];
        for (let i = 0; i < 5; i++) { const x = 80 + i * TW / 5 + r() * 60; canopyTree(g, x, yAt(x) + 6, 190 + r() * 60, { rnd: r, n: 34, ld: 1, trunkD: '#1a2418', trunkL: '#5a5530', leafL: '#e0d880', leafM: '#3f6a34', leafD: '#142a18', vines: 8, detail: 26 });
          for (let k = 0; k < 4; k++) { const mx = x - 30 + r() * 60, my = yAt(mx) + 4; g.fillStyle = '#9ff0e0'; g.beginPath(); g.ellipse(mx, my - 4, 3.5, 2, 0, Math.PI, 0); g.fill(); g.fillStyle = '#d8f0e0'; g.fillRect(mx - .6, my - 4, 1.2, 4); lights.push({ x: mx, y: my - 5, col: '#6fffd8', r: 12, a: .8 }); } }
      } },
      { speed: .55, draw(g) {
        const r = RNG(34); for (let i = 0; i < 14; i++) { const x = r() * TW, by = GY + 4;
          for (let k = 0; k < 7; k++) { const a = -Math.PI / 2 + (k - 3) * .32; g.strokeStyle = mix('#1a3a1c', '#3a6a2c', r()); g.lineWidth = 2.2; g.beginPath(); g.moveTo(x, by); g.quadraticCurveTo(x + Math.cos(a) * 14, by + Math.sin(a) * 26, x + Math.cos(a) * 30, by + Math.sin(a) * 30 + 10); g.stroke(); }
          if (i % 3 === 0) rock(g, x + 40, by + 2, 34, 16, { rnd: r, dark: '#23301f', light: '#6a7a5a', ld: 1, top: '#9ac85a' });
        }
      } },
      { speed: 1.35, stage: 'fg', draw(g) { const r = RNG(49); grassClumps(g, TW, H, { rnd: RNG(149), n: 6, h: 40, col: '#081208', rim: '#ffe0a0' }); for (let i = 0; i < 12; i++) { const x = r() * TW; for (let k = 0; k < 6; k++) { const a = -Math.PI / 2 + (k - 2.5) * .35; g.strokeStyle = '#0a160c'; g.lineWidth = 5; g.beginPath(); g.moveTo(x, H + 10); g.quadraticCurveTo(x + Math.cos(a) * 20, H + Math.sin(a) * 40, x + Math.cos(a) * 44, H + Math.sin(a) * 36 + 16); g.stroke(); } } } }
    ];
  },
  fog: [{ y: -60, h: 110, col: '#ffe2a8', a: .3, speed: .06 }, { y: -8, h: 70, col: '#a8e0c0', a: .22, speed: .2 }],
  ground(g, E) {
    const { TW, H, GY } = E; g.fillStyle = vgrad(g, GY - 4, H, '#3a5a26', '#0e1a0a'); g.fillRect(0, GY - 2, TW, H);
    const r = RNG(55);
    for (let i = 0; i < 40; i++) { const x = r() * TW, y = GY + 14 + r() * 60; g.fillStyle = rgba('#5a4a2a', .45); g.beginPath(); g.ellipse(x, y, 20 + r() * 40, 3, 0, 0, TAU); g.fill(); }
    for (let i = 0; i < 1400; i++) { const x = r() * TW, y = GY - 2 + Math.pow(r(), 2) * 80, h = 4 + r() * 9 * (1 - (y - GY) / 90); g.strokeStyle = r() < .3 ? '#b8d86a' : mix('#2a4a1a', '#5a8a2a', r()); g.lineWidth = .9; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + 1, y - h * .6, x + (r() - .3) * 4, y - h); g.stroke(); }
    for (let i = 0; i < 60; i++) { const x = r() * TW, y = GY + r() * 60; g.fillStyle = ['#ffd86a', '#ff9aa8', '#e8f0ff'][i % 3]; g.beginPath(); g.arc(x, y, 1.3, 0, TAU); g.fill(); }
  },
  particles: [{ type: 'firefly', rate: 5, col: '#e8ff7a' }, { type: 'pollen', rate: 8, col: '#ffe6a0' }, { type: 'leaf', rate: 3, col: '#d88a3a' }],
  grade: { col: '#ffb060', a: .1, mode: 'soft-light' }, vignette: .6, ambient: '#ffe0a0',
  hero: [
    { name: 'Heartwood Blade', body: 'armor', armD: '#3a3a2a', armL: '#c8c090', trim: '#d8b25a', cape: '#2e5a2a', capeD: '#0c1e0a', capeTrim: '#d8b25a', tabard: '#244a22', helm: 'greathelm', plume: '#5a9a3a', glow: '#b8ff7a', weapon: { type: 'sword', glow: '#b8ff7a', trim: '#d8b25a' }, shield: { type: 'round', col: '#4a3a22', trim: '#d8b25a', emblem: 'tree' } },
    { name: 'Stagcrown Axe', body: 'armor', armD: '#3a2e22', armL: '#b8a07a', trim: '#e0c070', cape: '#6a3a18', capeD: '#1e0e04', tabard: '#4a2a12', helm: 'horned', hornCol: '#e8dcb8', glow: '#ffd86a', weapon: { type: 'axe', glow: '#ffe07a', trim: '#e0c070' } },
    { name: 'Sunwarden Greatsword', body: 'armor', armD: '#2e3a2e', armL: '#e0e0c0', trim: '#ffd86a', cape: '#1e4a4a', capeD: '#081818', capeTrim: '#ffd86a', helm: 'winged', wingCol: '#fff4d8', glow: '#9fffd8', weapon: { type: 'greatsword', glow: '#9fffd8', rune: 1, trim: '#ffd86a' } }
  ],
  mobs: [
    { kind: 'rig', name: 'Thornling Scout', skin: { body: 'robe', robe: '#3a4a22', trim: '#8a6a3a', helm: 'hood', glow: '#c8ff5a', weapon: { type: 'spear', glow: '#c8ff5a', wood: '#3a2a18', steelL: '#d8d0b8', steelD: '#5a5040' } } },
    { kind: 'creature', type: 'treant', name: 'Elder Rotbark', m: { d: '#2a1e12', l: '#6a5436', leafL: '#9ac85a', leafD: '#2a4a1a', moss: '#4a7a2a', shroom: '#7affd8', eye: '#ffb03a' } },
    { kind: 'rig', name: 'Briar Knight', elite: 1, skin: { body: 'armor', armD: '#221a10', armL: '#6a5a3a', trim: '#6a8a2a', cape: '#1e2a10', capeD: '#0a1004', helm: 'horned', hornCol: '#4a3a22', glow: '#ff9a3a', spikes: 1, weapon: { type: 'axe', glow: '#b8ff5a', steelL: '#d8d0b8', steelD: '#4a4030' } } }
  ]
};

/* ---------------- 5. ASTRAL SANCTUM ---------------- */
THEMES.astral = {
  ldir: 1, seed: 15,
  sky(g, E) {
    skyGrad(g, E.W, E.H, [[0, '#03020b'], [.3, '#0f0a2a'], [.6, '#261a58'], [.82, '#5a4a9a'], [1, '#221a44']]);
    const r = RNG(8); g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 26; i++) { const x = r() * E.W, y = r() * E.GY * .8; glow(g, ['#ff4fd8', '#4fd8ff', '#7a5aff', '#ffb86a'][i % 4], x, y, 60 + r() * 120, .08 + r() * .1); }
    g.globalCompositeOperation = 'source-over';
    stars(g, E.W, E.GY * .85, 260, 12, ['#ffffff', '#ffe9b8', '#c8e8ff']);
    const px = 170, py = 104, pr = 62;
    g.globalCompositeOperation = 'lighter'; glow(g, '#8a7aff', px, py, pr * 2.6, .25); g.globalCompositeOperation = 'source-over';
    const pg = g.createRadialGradient(px + 22, py - 24, 6, px, py, pr); pg.addColorStop(0, '#f2d8ff'); pg.addColorStop(.5, '#8a6ad8'); pg.addColorStop(1, '#1a1040'); g.fillStyle = pg; g.beginPath(); g.arc(px, py, pr, 0, TAU); g.fill();
    g.save(); g.beginPath(); g.arc(px, py, pr, 0, TAU); g.clip(); for (let i = 0; i < 6; i++) { g.fillStyle = rgba(i % 2 ? '#c8a8ff' : '#5a3aa8', .18); g.fillRect(px - pr, py - pr + i * 22 + 6, pr * 2, 7); } g.restore();
    g.strokeStyle = rgba('#ffe0a8', .7); g.lineWidth = 3; g.beginPath(); g.ellipse(px, py, pr * 1.75, pr * .32, -.28, 0, TAU); g.stroke();
    g.strokeStyle = rgba('#ffe0a8', .3); g.lineWidth = 6; g.beginPath(); g.ellipse(px, py, pr * 1.55, pr * .27, -.28, 0, TAU); g.stroke();
    g.fillStyle = pg; g.beginPath(); g.arc(px, py, pr, Math.PI * 1.02, Math.PI * 1.98); g.fill();
  },
  shafts: { x: 480, y: -20, col: '#ffe0a0', n: 5, a: .05, spread: 1.2, ang: 1.6 },
  starsTwinkle: 1,
  layers(E) {
    const { TW, H, GY } = E; return [
      { speed: .025, draw(g) {
        const r = RNG(91), lights = this.lights = [];
        for (let i = 0; i < 6; i++) { const x = r() * TW, y = 90 + r() * 90, w = 50 + r() * 60;
          island(g, x, y, w, { rnd: r, dark: '#1c1440', light: '#6a5aa8', top: '#b8a8f0', crystal: '#7ff4ff', lights });
          tower(g, x - w * .15, y - 1, 6, 16 + r() * 16, { col: '#d8d0f0', roof: 2.4, rnd: r });
          g.globalCompositeOperation = 'lighter'; g.drawImage(vstrip('#9ae8ff'), x + w * .3, y, 2, 120); g.globalCompositeOperation = 'source-over';
          lights.push({ x: x + w * .3, y: y + 20, col: '#8ae8ff', r: 14, a: .5 }); }
      } },
      { speed: .07, draw(g) {
        const yAt = ridge(g, TW, H, { seed: 92, N: 6, y: GY - 16, amp: 22, top: '#b8a8f0', bot: '#5a4a9a', fade: 50 });
        const r = RNG(24); for (let i = 0; i < 12; i++) { const x = r() * TW, by = yAt(x) + 4; tower(g, x, by, 8 + r() * 8, 30 + r() * 60, { col: '#e8e0ff', roof: 3, rim: '#ffe0a0', rimA: .8, ld: 1, rnd: r }); }
      } },
      { speed: .24, draw(g) {
        const r = RNG(25), lights = this.lights = [];
        const yAt = ridge(g, TW, H, { seed: 93, N: 5, y: GY + 6, amp: 10, top: '#8a7ac8', bot: '#3a2e6a' });
        for (let i = 0; i < 3; i++) { const cx = 120 + i * TW / 3 + r() * 80, by = yAt(cx) + 4;
          for (let k = 0; k < 5; k++) { const x = cx - 80 + k * 40, hh = k === 1 || k === 3 ? 60 + r() * 20 : 110; g.fillStyle = hgrad(g, x - 7, x + 7, '#9a8ac8', '#f4f0ff'); g.fillRect(x - 7, by - hh, 14, hh); g.fillStyle = '#ffe0a0'; g.fillRect(x - 9, by - hh - 4, 18, 4); g.fillRect(x - 9, by - 4, 18, 4); }
          g.fillStyle = hgrad(g, cx - 90, cx + 90, '#8a7ac8', '#f4f0ff'); g.fillRect(cx - 90, by - 122, 100, 10); g.fillStyle = '#ffe0a0'; g.fillRect(cx - 90, by - 112, 100, 2);
          const fx = cx + 110, fy = by - 80; shard(g, fx, fy + 30, 14, 40, 0, { dark: '#1a8aa8', light: '#d8ffff', base: '#2a5aa8', edge: '#ffffff', ld: 1, glow: '#6ff8ff', lights });
        }
      } },
      { speed: .55, draw(g) {
        const r = RNG(35), lights = this.lights = [];
        for (let i = 0; i < 4; i++) { const x = 60 + i * TW / 4 + r() * 90, by = GY + 4, h = 70 + r() * 30;
          g.fillStyle = hgrad(g, x - 10, x + 10, '#1a1438', '#4a3a7a'); g.beginPath(); g.moveTo(x - 10, by); g.lineTo(x - 8, by - h); g.lineTo(x, by - h - 8); g.lineTo(x + 8, by - h); g.lineTo(x + 10, by); g.fill();
          g.strokeStyle = '#6ff8ff'; g.lineWidth = 1.2; for (let k = 0; k < 4; k++) { const y = by - h + 14 + k * 16; g.beginPath(); g.moveTo(x - 4, y); g.lineTo(x + 4, y + 4); g.lineTo(x - 2, y + 8); g.stroke(); lights.push({ x, y: y + 4, col: '#6ff8ff', r: 10, a: .7 }); }
        }
      } },
      { speed: 1.35, stage: 'fg', draw(g) { const r = RNG(50); for (let i = 0; i < 8; i++) { const x = r() * TW; shard(g, x, H + 10, 20 + r() * 20, 40 + r() * 40, (r() - .5) * .4, { dark: '#0a0820', light: '#3a2a7a', base: '#140e30', edge: '#8a7aff', ld: 1 }); } } }
    ];
  },
  fog: [{ y: -30, h: 80, col: '#d8c8ff', a: .38, speed: .05 }, { y: 10, h: 60, col: '#9a84e8', a: .3, speed: .2 }],
  ground(g, E) {
    const { TW, H, GY } = E; g.fillStyle = vgrad(g, GY - 4, H, '#4a3e7a', '#0c0820'); g.fillRect(0, GY - 2, TW, H);
    const r = RNG(56);
    for (let row = 0; row < 4; row++) { const y = GY + 6 + row * row * 6 + row * 8; g.fillStyle = rgba('#ffe0a0', .55 - row * .1); g.fillRect(0, y, TW, 1); }
    for (let x = 0; x < TW; x += 64) { g.strokeStyle = rgba('#ffe0a0', .35); g.lineWidth = 1; g.beginPath(); g.moveTo(x, GY + 6); g.lineTo(x - 30, H); g.stroke(); }
    g.fillStyle = rgba('#ffffff', .15); g.fillRect(0, GY - 2, TW, 2);
  },
  groundEmit(g, E) {
    const { TW, GY } = E; g.strokeStyle = '#6ff8ff';
    for (let x = 60; x < TW; x += 190) { g.lineWidth = 1.2; g.beginPath(); g.ellipse(x, GY + 26, 34, 7, 0, 0, TAU); g.stroke(); g.beginPath(); g.ellipse(x, GY + 26, 22, 4.5, 0, 0, TAU); g.stroke(); for (let k = 0; k < 8; k++) { const a = k / 8 * TAU; g.beginPath(); g.moveTo(x + Math.cos(a) * 22, GY + 26 + Math.sin(a) * 4.5); g.lineTo(x + Math.cos(a) * 34, GY + 26 + Math.sin(a) * 7); g.stroke(); } }
  },
  particles: [{ type: 'sparkle', rate: 10, col: '#ffe0a0' }, { type: 'mote', rate: 6, col: '#9ae8ff' }],
  grade: { col: '#6a3aff', a: .1, mode: 'soft-light' }, vignette: .65, ambient: '#b8a8ff', reflect: .24,
  hero: [
    { name: 'Starforged Blade', body: 'armor', armD: '#2a2e4e', armL: '#e4e6f6', trim: '#f2cf6b', cape: '#2a1c6c', capeD: '#0a0624', capeTrim: '#f2cf6b', tabard: '#1e1656', helm: 'crown', crownCol: '#f2cf6b', gem: '#6ff3ff', glow: '#6ff3ff', acc: 'halo', haloCol: '#ffe08a', weapon: { type: 'sword', glow: '#6ff3ff', trim: '#f2cf6b' }, shield: { type: 'kite', col: '#23205a', trim: '#f2cf6b', emblem: 'star' } },
    { name: 'Seraph Greatsword', body: 'armor', armD: '#2a2a3e', armL: '#f4f2ff', trim: '#ffe08a', cape: '#e8e0ff', capeD: '#6a5aa8', capeTrim: '#ffe08a', helm: 'winged', wingCol: '#ffffff', glow: '#ffe08a', acc: 'halo', haloCol: '#ffe08a', weapon: { type: 'greatsword', glow: '#ffe08a', rune: 1, steelL: '#ffffff', steelD: '#8a8ab8', trim: '#ffe08a' } },
    { name: 'Eclipse Mace', body: 'armor', armD: '#1c1638', armL: '#9a8ad8', trim: '#6ff3ff', cape: '#4a1a6a', capeD: '#12061e', tabard: '#2a0e44', helm: 'greathelm', plume: '#6ff3ff', glow: '#ff6ff0', spikes: 1, weapon: { type: 'mace', glow: '#ff6ff0', trim: '#6ff3ff', steelL: '#f0e8ff', steelD: '#4a3a8a' }, shield: { type: 'round', col: '#2a1a4a', trim: '#6ff3ff', emblem: 'sun' } }
  ],
  mobs: [
    { kind: 'rig', name: 'Void Acolyte', skin: { body: 'robe', robe: '#1a0c2e', trim: '#b04ad8', helm: 'hood', glow: '#ff4fd8', weapon: { type: 'staff', glow: '#ff4fd8', wood: '#1a1024' } }, atkStyle: 'cast' },
    { kind: 'creature', type: 'sentinel', name: 'Void Sentinel', m: { d: '#1a1030', l: '#6a4aa8', ring: '#f2cf6b', eye: '#ff4fd8' } },
    { kind: 'rig', name: 'Void Templar', elite: 1, skin: { body: 'armor', armD: '#140c22', armL: '#5a4a7a', trim: '#b04ad8', cape: '#2a0c3a', capeD: '#0a0412', helm: 'crown', crownCol: '#b04ad8', gem: '#ff4fd8', glow: '#ff4fd8', spikes: 1, weapon: { type: 'greatsword', glow: '#ff4fd8', steelL: '#e8d8ff', steelD: '#3a2a5a', trim: '#b04ad8' } } }
  ]
};


/* =====================================================================
   POSES
===================================================================== */
const POSE = { I: { th: 1.05, ph: -1.0 }, G: { th: 1.12, ph: -1.12 }, W: { th: -1.95, ph: -2.75 }, E: { th: 1.25, ph: .75 } };   // G: guard, the idle stance beside a shield: sword hand at the hip on the near side, blade up and forward (never down across the legs)
function rigPose(atk, style, guard) {
  const I = guard ? POSE.G : POSE.I;
  if (atk == null) return { th: I.th, ph: I.ph, lunge: 0, swing: -1, wglow: 0, pull: 0 };
  if (style === 'cast') {
    const up = atk < .5 ? eIO(atk / .5) : 1 - eIO((atk - .5) / .5);
    return { th: lerp(I.th, -.9, up), ph: lerp(I.ph, -1.35, up), lunge: 0, swing: -1, wglow: up, pull: 0 };
  }
  if (style === 'shoot') {
    const up = atk < .5 ? eIO(atk / .5) : 1 - eIO((atk - .5) / .5);
    return { th: lerp(I.th, -.12, Math.min(1, up * 1.6)), ph: I.ph, lunge: 0, swing: -1, wglow: 0, pull: atk < .5 ? eIO(atk / .5) : 0 };
  }
  let th, ph, sw = -1, lunge = 0;
  if (atk < .4) { const k = eIO(atk / .4); th = lerp(I.th, POSE.W.th, k); ph = lerp(I.ph, POSE.W.ph, k); lunge = -k * 3; }
  else if (atk < .56) { const k = eOut((atk - .4) / .16); th = lerp(POSE.W.th, POSE.E.th, k); ph = lerp(POSE.W.ph, POSE.E.ph, k); sw = k; lunge = -3 + k * 17; }
  else { const k = eIO((atk - .56) / .44); th = lerp(POSE.E.th, I.th, k); ph = lerp(POSE.E.ph, I.ph, k); lunge = 14 * (1 - k); sw = 1 + k; }
  return { th, ph, lunge, swing: sw, wglow: atk > .3 && atk < .75 ? 1 : 0, pull: 0 };
}
function swingTip(k, hipY, L) {
  const th = lerp(POSE.W.th, POSE.E.th, k), ph = lerp(POSE.W.ph, POSE.E.ph, k);
  const sh = [SH_F[0], hipY + SH_F[1]], el = [sh[0] + Math.cos(th + .35) * 13, sh[1] + Math.sin(th + .35) * 13], ha = [el[0] + Math.cos(th - .25) * 13, el[1] + Math.sin(th - .25) * 13];
  return [[ha[0] + Math.cos(ph) * L, ha[1] + Math.sin(ph) * L], [ha[0] + Math.cos(ph) * L * .45, ha[1] + Math.sin(ph) * L * .45]];
}

/* =====================================================================
   WORLD — one live theme at a time. engine.js calls World.frame(view,…)
   Coordinates: logical px, H≈390, ground at GY, hero drawn at HX.
===================================================================== */
const FONT = '"Source Serif 4", Georgia, serif';
const W_ = { W: 844, H: 390, GY: 300, TW: 1688, HX: 253, CS: 1.22 };
let canvas = null, ctx = null, MS = 2, quality = 'high', fxAmt = 1;
let T = null, themeKey = null, A = null;
const rnd = RNG(4242);
let camX = 0, camV = 0, shake = 0, time = 0;
const parts = [], nums = [], frags = [], coins = [], rings = [], bolts = [], beams = [];
let coinTarget = [700, 24];
let bufN = null, bufB = null, bloom1 = null, bloom2 = null;

function mkBuf(bw, bh, box, boy) { return { A: mkS(bw, bh), R: mkS(bw, bh), BW: bw, BH: bh, BOX: box, BOY: boy }; }
function freeBuf(b) { if (b) { freeCanvas(b.A.c); freeCanvas(b.R.c); } }
function freeAssets() {
  if (!A) return;
  freeCanvas(A.sky.c); for (const L of A.layers) freeCanvas(L.c); freeCanvas(A.ground.c); if (A.gEmit) freeCanvas(A.gEmit.c);
  for (const f of A.fogs) freeCanvas(f.c); freeCanvas(A.vig.c); A = null;
}
function clearCaches() { for (const k in GC) { freeCanvas(GC[k]); delete GC[k]; } for (const k in VC) { freeCanvas(VC[k]); delete VC[k]; } }

function buildTheme(key) {
  const t0 = performance.now();
  freeAssets(); T = THEMES[key]; themeKey = key;
  const { W, H, GY, TW } = W_, E = { W, H, GY, TW };
  const sky = mkS(W, H); T.sky(sky.g, E);
  const layers = T.layers(E).map((L, li) => {
    let s = mkS(TW, H); L.draw.call(L, s.g, E);
    const bl = L.stage === 'fg' ? (L.blur || 2.5) : li === 0 ? 1.1 : li === 1 ? .6 : 0;
    if (bl && quality === 'high') { const b = softBlur(s.c, 1 + bl * 1.6); freeCanvas(s.c); s = { c: b }; }
    return { c: s.c, speed: L.speed, stage: L.stage || 'bg', lights: L.lights || null };
  });
  const ground = mkS(TW, H); T.ground(ground.g, E);
  let gEmit = null; if (T.groundEmit) { gEmit = mkS(TW, H); T.groundEmit(gEmit.g, E); }
  const fogs = (T.fog || []).map((f, i) => ({ c: fogTile(TW, f.h, f.col, 100 + i, 1), y: GY + f.y - f.h / 2, h: f.h, a: f.a, speed: f.speed }));
  const vig = mkS(W, H); { const g = vig.g, gr = g.createRadialGradient(W / 2, H * .48, H * .35, W / 2, H * .5, W * .62); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,' + T.vignette + ')'); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
  const twinkle = []; if (T.starsTwinkle || T.aurora || key === 'gothic') { const r = RNG(77); for (let i = 0; i < 40; i++) twinkle.push([r() * W, r() * GY * .7, r() * TAU, .6 + r() * 1.6]); }
  A = { sky, layers, ground, gEmit, fogs, vig, twinkle, key, W, H, S };
  parts.length = 0; frags.length = 0; coins.length = 0; rings.length = 0; nums.length = 0; bolts.length = 0; beams.length = 0;
  return performance.now() - t0;
}

/* ---------- particles ---------- */
let AMB = false;   // ambient weather: most of it falls behind the fighters, only a few flakes cross in front
function addPart(p) { if (AMB && p.d < 1.2 && rnd() < .8) p.back = 1; if (parts.length < (quality === 'high' ? 420 : 200)) parts.push(p); }
function ambient(dt) {
  const { W, GY, H } = W_; AMB = true;
  for (const P of T.particles) {
    const n = P.rate * fxAmt * dt; let k = Math.floor(n) + (rnd() < n % 1 ? 1 : 0);
    while (k--) {
      const tp = P.type, d = .3 + rnd() * .9;
      if (tp === 'ember') addPart({ tp, x: rnd() * W, y: H + 5, vx: (rnd() - .5) * 14, vy: -(25 + rnd() * 50), life: 3 + rnd() * 3, t: 0, s: .8 + rnd() * 1.8, col: P.col, d, add: 1 });
      else if (tp === 'ash') addPart({ tp, x: rnd() * W, y: -5, vx: -8 - rnd() * 10, vy: 10 + rnd() * 16, life: 8, t: 0, s: .8 + rnd() * 1.2, col: P.col, d });
      else if (tp === 'snow') { const big = rnd() < .08; addPart({ tp, x: rnd() * (W + 100), y: -8, vx: -18 - rnd() * 14, vy: 22 + rnd() * 34 + (big ? 30 : 0), life: 12, t: 0, s: big ? 3 + rnd() * 3 : .7 + rnd() * 1.6, col: P.col, d: big ? 1.6 : d, blur: big }); }
      else if (tp === 'wisp') addPart({ tp, x: rnd() * W, y: GY - rnd() * 40, vx: (rnd() - .5) * 8, vy: -10 - rnd() * 12, life: 4 + rnd() * 3, t: 0, s: 2 + rnd() * 2, col: P.col, d, add: 1, ph: rnd() * TAU });
      else if (tp === 'mote') addPart({ tp, x: rnd() * W, y: rnd() * GY, vx: (rnd() - .5) * 6, vy: -2 - rnd() * 5, life: 5 + rnd() * 4, t: 0, s: .8 + rnd(), col: P.col, d, add: 1 });
      else if (tp === 'firefly') addPart({ tp, x: rnd() * W, y: GY - 10 - rnd() * 130, vx: 0, vy: 0, life: 6 + rnd() * 4, t: 0, s: 1.4 + rnd(), col: P.col, d, add: 1, ph: rnd() * TAU });
      else if (tp === 'pollen') addPart({ tp, x: rnd() * W, y: rnd() * GY, vx: 6 + rnd() * 6, vy: -1 + rnd() * 2, life: 6, t: 0, s: .9 + rnd() * .8, col: P.col, d, add: 1, ph: rnd() * TAU });
      else if (tp === 'leaf') addPart({ tp, x: rnd() * W + 60, y: -8, vx: -14 - rnd() * 10, vy: 18 + rnd() * 14, life: 12, t: 0, s: 2.4 + rnd() * 1.6, col: rnd() < .5 ? P.col : '#9ab83a', d, ph: rnd() * TAU, rot: rnd() * TAU });
      else if (tp === 'sparkle') addPart({ tp, x: rnd() * W, y: GY + 10 - rnd() * 60, vx: (rnd() - .5) * 6, vy: -8 - rnd() * 14, life: 3 + rnd() * 3, t: 0, s: 1 + rnd() * 1.4, col: P.col, d, add: 1, ph: rnd() * TAU });
      else if (tp === 'glint') addPart({ tp, x: rnd() * W, y: GY + rnd() * 70, vx: 0, vy: 0, life: .8 + rnd(), t: 0, s: 1 + rnd() * 1.5, col: P.col, d: 1, add: 1, star: 1 });
    }
  }
  AMB = false;
}
function burst(x, y, col, n, spd, opt) {
  opt = opt || {};
  const cnt = Math.round(n * (quality === 'high' ? 1 : .5));
  for (let i = 0; i < cnt; i++) { const a = (opt.a != null ? opt.a : 0) + (rnd() - .5) * (opt.spread || TAU), v = spd * (.4 + rnd() * .8); addPart({ tp: opt.tp || 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (opt.up || 0), life: opt.life || (.35 + rnd() * .4), t: 0, s: opt.s || (1 + rnd() * 1.6), col, d: 1, add: 1, g: opt.g != null ? opt.g : 260, streak: opt.streak !== 0 }); }
}
function themeBurst(x, y, type, n) {
  if (type === 'wisp') for (let i = 0; i < n; i++) addPart({ tp: 'wisp', x: x + (rnd() - .5) * 50, y: y - rnd() * 110, vx: (rnd() - .5) * 30, vy: -20 - rnd() * 40, life: 1.5 + rnd(), t: 0, s: 2 + rnd() * 3, col: '#d59bff', d: 1, add: 1, ph: rnd() * TAU });
  else if (type === 'ember') burst(x, y - 40, '#ff8a2a', n, 160, { up: 60, life: 1.2, g: 120 });
  else if (type === 'snowburst') burst(x, y - 50, '#dff6ff', n, 150, { up: 40, life: 1.2, g: 160 });
  else if (type === 'leaf') for (let i = 0; i < n; i++) addPart({ tp: 'leaf', x: x + (rnd() - .5) * 40, y: y - rnd() * 120, vx: (rnd() - .5) * 120, vy: -40 - rnd() * 80, life: 2.5, t: 0, s: 2.5 + rnd() * 2, col: rnd() < .5 ? '#9ac85a' : '#d88a3a', d: 1, ph: rnd() * TAU, rot: rnd() * TAU, grav: 1 });
  else burst(x, y - 60, T.ambient, n, 150, { up: 40, life: 1, g: 60 });
}

function updateFX(dt, gdt) {
  const { W, GY } = W_;
  ambient(dt);
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i], d = p.d === 1 ? gdt : dt; p.t += d; if (p.t > p.life) { parts.splice(i, 1); continue; }
    if (p.tp === 'firefly') { p.vx += (rnd() - .5) * 60 * d; p.vy += (rnd() - .5) * 60 * d; p.vx *= .97; p.vy *= .97; }
    if (p.tp === 'wisp' || p.tp === 'pollen') p.vx += Math.sin(p.t * 2 + p.ph) * 12 * d;
    if (p.tp === 'snow' || p.tp === 'leaf') p.vx += Math.sin(p.t * 1.5 + (p.ph || 0)) * 8 * d;
    if (p.g) p.vy += p.g * d; if (p.grav) p.vy += 90 * d;
    p.x += p.vx * d - camV * dt * p.d; p.y += p.vy * d; if (p.rot != null) p.rot += d * 3;
    if (p.x < -80 || p.x > W + 140) parts.splice(i, 1);
  }
  for (let i = frags.length - 1; i >= 0; i--) { const f = frags[i]; f.t += gdt; f.vy += 520 * gdt; f.x += f.vx * gdt - camV * dt; f.y += f.vy * gdt; f.r += f.vr * gdt; if (f.y > GY + 6) { f.y = GY + 6; f.vy *= -.3; f.vx *= .6; f.vr *= .6; } if (f.t > 1.6) frags.splice(i, 1); }
  for (let i = coins.length - 1; i >= 0; i--) { const c = coins[i]; c.t += gdt;
    if (c.t < c.delay) { c.vy += 600 * gdt; c.x += c.vx * gdt - camV * dt; c.y += c.vy * gdt; if (c.y > GY + 2) { c.y = GY + 2; c.vy *= -.45; c.vx *= .7; } c.sx = c.x; c.sy = c.y; }
    else { const k = eIn(clamp((c.t - c.delay) / .55, 0, 1)); c.x = lerp(c.sx, coinTarget[0], k); c.y = lerp(c.sy, coinTarget[1], k) - Math.sin(k * Math.PI) * 50; if (k >= 1) { coins.splice(i, 1); burst(coinTarget[0], coinTarget[1], '#ffd86a', 4, 90, { life: .3, g: 0 }); } } }
  for (let i = rings.length - 1; i >= 0; i--) { const r = rings[i]; r.t += gdt / .45; r.x -= camV * dt; if (r.t >= 1) rings.splice(i, 1); }
  for (let i = nums.length - 1; i >= 0; i--) { const n = nums[i]; n.t += gdt; n.x -= camV * dt; if (n.t > 1.1) nums.splice(i, 1); }
  for (let i = bolts.length - 1; i >= 0; i--) { const b = bolts[i]; b.t += gdt; b.x -= camV * dt; if (b.t > .28) bolts.splice(i, 1); }
  for (let i = beams.length - 1; i >= 0; i--) { const b = beams[i]; b.t += gdt; b.x -= camV * dt; if (b.t > b.dur) beams.splice(i, 1); }
  shake *= Math.exp(-dt * 10);
}

/* ---------- drawing helpers ---------- */
function drawTile(c, speed, y, a) {
  const { W, TW } = W_;
  const off = ((camX * speed) % TW + TW) % TW, sc = c.width / TW;
  const pa = ctx.globalAlpha; ctx.globalAlpha = pa * (a == null ? 1 : a);
  ctx.drawImage(c, off * sc, 0, Math.min(TW - off, W) * sc, c.height, 0, y || 0, Math.min(TW - off, W), c.height / sc);
  if (TW - off < W) ctx.drawImage(c, 0, 0, (W - (TW - off)) * sc, c.height, TW - off, y || 0, W - (TW - off), c.height / sc);
  ctx.globalAlpha = pa;
}
function drawLights(L, speed, t) {
  if (!L) return; const { W, TW } = W_; const off = ((camX * speed) % TW + TW) % TW;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const l of L) { let x = l.x - off; if (x < -60) x += TW; if (x > W + 60) continue;
    let a = l.a * fxAmt; if (l.fire) a *= .75 + Math.sin(t * 13 + l.x) * .12 + Math.sin(t * 7.3 + l.y) * .1; if (l.pulse) a *= .7 + Math.sin(t * 1.8 + l.x * .01) * .3;
    glow(ctx, l.col, x, l.y, l.r, a); if (l.fire) { glow(ctx, '#fff0c0', x, l.y, l.r * .18, .9); glow(ctx, l.col, x, l.y + 30, l.r * 1.2, a * .25); } }
  ctx.restore();
}
function drawShafts(t) {
  const s = T.shafts; if (!s) return; const { H } = W_;
  ctx.save(); ctx.globalCompositeOperation = 'screen';
  for (let i = 0; i < s.n; i++) {
    const a = s.ang + (i - (s.n - 1) / 2) * .16 * s.spread + Math.sin(t * .2 + i) * .02, len = H * 1.4, w = 16 + (i % 3) * 14;
    const x2 = s.x + Math.cos(a) * len, y2 = s.y + Math.sin(a) * len, nx = -Math.sin(a), ny = Math.cos(a);
    const gr = ctx.createLinearGradient(s.x, s.y, x2, y2); const al = s.a * (.6 + Math.sin(t * .5 + i * 1.7) * .4) * fxAmt;
    gr.addColorStop(0, rgba(s.col, al)); gr.addColorStop(.6, rgba(s.col, al * .5)); gr.addColorStop(1, rgba(s.col, 0));
    ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(s.x + nx * 3, s.y + ny * 3); ctx.lineTo(x2 + nx * w, y2 + ny * w); ctx.lineTo(x2 - nx * w, y2 - ny * w); ctx.lineTo(s.x - nx * 3, s.y - ny * 3); ctx.fill();
  }
  ctx.restore();
}
function drawAurora(t) {
  if (!T.aurora) return; const { W } = W_; ctx.save(); ctx.globalCompositeOperation = 'lighter';
  const step = quality === 'high' ? 2 : 4;
  for (const Au of T.aurora) { const st = vstrip(Au.col); for (let x = -10; x < W + 10; x += step) { const y = Au.y + Math.sin(x * .011 + t * Au.sp * 3) * Au.amp + Math.sin(x * .031 - t * .6) * 6; const len = Au.len * (.6 + .4 * Math.sin(x * .02 + t * .4)); ctx.globalAlpha = (.1 + .06 * Math.sin(x * .05 + t)) * fxAmt; ctx.drawImage(st, x, y - len * .2, step + .6, len); } }
  ctx.restore();
}
function drawPart(p) {
  const k = p.t / p.life, fade = Math.min(1, p.t * 3) * (1 - k);
  if (p.add) {
    if (p.tp === 'firefly') { const b = Math.max(0, Math.sin(p.t * 3 + p.ph)); glow(ctx, p.col, p.x, p.y, 7 + b * 4, fade * (.3 + b * .7)); ctx.fillStyle = rgba('#ffffff', fade * b); ctx.fillRect(p.x - .6, p.y - .6, 1.2, 1.2); return; }
    if (p.star) { const b = Math.sin(k * Math.PI); ctx.strokeStyle = rgba(p.col, b); ctx.lineWidth = .8; ctx.beginPath(); ctx.moveTo(p.x - p.s * 3, p.y); ctx.lineTo(p.x + p.s * 3, p.y); ctx.moveTo(p.x, p.y - p.s * 3); ctx.lineTo(p.x, p.y + p.s * 3); ctx.stroke(); glow(ctx, p.col, p.x, p.y, p.s * 3, b * .6); return; }
    if (p.tp === 'spark' && p.streak) { const sp = Math.hypot(p.vx, p.vy) * .03; ctx.strokeStyle = rgba(p.col, fade); ctx.lineWidth = p.s * .8; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * .03, p.y - p.vy * .03); ctx.stroke(); glow(ctx, p.col, p.x, p.y, p.s * 3 + sp, fade * .5); return; }
    const tw = p.tp === 'sparkle' ? .5 + .5 * Math.sin(p.t * 8 + p.ph) : 1;
    glow(ctx, p.col, p.x, p.y, p.s * (p.tp === 'wisp' ? 5 : 3.2), fade * .75 * tw); ctx.fillStyle = rgba(mix(p.col, '#ffffff', .6), fade * tw); ctx.fillRect(p.x - p.s * .4, p.y - p.s * .4, p.s * .8, p.s * .8);
  } else {
    if (p.tp === 'leaf') { ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.scale(1, Math.abs(Math.sin(p.t * 3 + p.ph)) * .7 + .3); ctx.fillStyle = rgba(p.col, fade); ctx.beginPath(); ctx.ellipse(0, 0, p.s, p.s * .45, 0, 0, TAU); ctx.fill(); ctx.restore(); return; }
    if (p.blur) { glow(ctx, p.col, p.x, p.y, p.s * 2.2, fade * .45); return; }
    ctx.fillStyle = rgba(p.col, fade * (p.tp === 'ash' ? .6 : .9)); ctx.beginPath(); ctx.arc(p.x, p.y, p.s, 0, TAU); ctx.fill();
  }
}
function drawParts(back) { ctx.save(); for (const p of parts) { if (!p.back !== !back) continue; if (p.add) { ctx.globalCompositeOperation = 'lighter'; drawPart(p); ctx.globalCompositeOperation = 'source-over'; } else drawPart(p); } ctx.restore(); }
/* Review 6: painted depth: a band of haze over the far layers just above the fighting line, and a fixed film grain over the frame */
function drawHaze() { const { W, GY } = W_, c = (T.fog && T.fog[T.fog.length - 1] || {}).col || T.ambient || '#808080';
  const gr = ctx.createLinearGradient(0, GY - 150, 0, GY); gr.addColorStop(0, rgba(c, 0)); gr.addColorStop(.75, rgba(c, .16)); gr.addColorStop(1, rgba(c, .24)); ctx.fillStyle = gr; ctx.fillRect(0, GY - 150, W, 150); }
let GRAIN = null;
function drawGrain() { if (quality !== 'high') return;
  if (!GRAIN) { GRAIN = document.createElement('canvas'); GRAIN.width = GRAIN.height = 160; const g = GRAIN.getContext('2d'), im = g.createImageData(160, 160), r = RNG(77);
    for (let i = 0; i < im.data.length; i += 4) { const v = 96 + r() * 64 | 0; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; } g.putImageData(im, 0, 0); }
  ctx.save(); ctx.globalCompositeOperation = 'overlay'; ctx.globalAlpha = .07; for (let x = 0; x < W_.W; x += 160) for (let y = 0; y < W_.H; y += 160) ctx.drawImage(GRAIN, x, y); ctx.restore(); }
function drawHeroStage(view, t) { const { W, H, GY } = W_, x = view.hero ? view.hero.x : W * .3, c = T.ambient || '#8a6ad0';
  ctx.save(); ctx.setTransform(MS, 0, 0, MS, 0, 0); ctx.fillStyle = '#0b0710'; ctx.fillRect(0, 0, W, H);
  let gr = ctx.createRadialGradient(x, H * .45, 10, x, H * .45, H * .95); gr.addColorStop(0, rgba(mix(c, '#2a1d38', .6), .95)); gr.addColorStop(.5, '#170f20'); gr.addColorStop(1, '#09060d'); ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H); ctx.restore();
  gr = ctx.createRadialGradient(x, GY + 4, 4, x, GY + 4, 150); gr.addColorStop(0, 'rgba(255,236,200,.16)'); gr.addColorStop(1, 'rgba(255,236,200,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(x, GY + 4, 150, 30, 0, 0, TAU); ctx.fill();
  ctx.strokeStyle = 'rgba(216,178,90,.22)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(x, GY + 4, 92, 15, 0, 0, TAU); ctx.stroke(); }
function drawShadow(x, w, a) { const { GY } = W_; const gr = ctx.createRadialGradient(x, GY + 2, 1, x, GY + 2, w); gr.addColorStop(0, 'rgba(0,0,0,' + a + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(x, GY + 2, w, w * .22, 0, 0, TAU); ctx.fill(); }

/* draw an actor into an offscreen buffer, then composite it with a rim light, reflection and hit-flash */
/* flashMax caps the white hit-flash; flashFn (optional) draws the part of the actor that flashes (the knight's cape is left out, so he never looks like a ghost) */
const INK = '#170e20', COOL = '#4a5a72', INK_PASS = [[-1, 0], [1, 0], [0, -1], [0, 1], [-.7, -.7], [.7, -.7], [-.7, .7], [.7, .7]];
let INK_W = 1.7;
function renderActor(fn, x, y, flash, alpha, rimA, rimCol, big, flashMax, flashFn, cool) {
  const B = big ? bufB : bufN, Ab = B.A, R = B.R, { BW, BH, BOX, BOY } = B;
  Ab.g.setTransform(S, 0, 0, S, 0, 0); Ab.g.clearRect(0, 0, BW, BH); Ab.g.save(); Ab.g.translate(BOX, BOY); Ab.g.scale(W_.CS, W_.CS); fn(Ab.g); Ab.g.restore();
  /* Review 6: an ink outline around every figure (the silhouette dilated in 8 directions, under the figure) */
  const iw = INK_W * (big ? 1.15 : 1);
  if (iw > 0 && alpha > .05) {
    R.g.setTransform(1, 0, 0, 1, 0, 0); R.g.globalCompositeOperation = 'copy'; R.g.drawImage(Ab.c, 0, 0);
    R.g.globalCompositeOperation = 'source-in'; R.g.fillStyle = INK; R.g.fillRect(0, 0, R.c.width, R.c.height); R.g.globalCompositeOperation = 'source-over';
    ctx.save(); ctx.globalAlpha = alpha * .92; for (let i = 0; i < INK_PASS.length; i++) { const o = INK_PASS[i]; ctx.drawImage(R.c, x - BOX + o[0] * iw, y - BOY + o[1] * iw, BW, BH); } ctx.restore();
  }
  /* enemies are tinted greyer and cooler than the knight, so his cape stays the brightest thing in the fight */
  if (cool > 0) { Ab.g.setTransform(1, 0, 0, 1, 0, 0); Ab.g.globalCompositeOperation = 'source-atop'; Ab.g.globalAlpha = cool; Ab.g.fillStyle = COOL; Ab.g.fillRect(0, 0, Ab.c.width, Ab.c.height); Ab.g.globalAlpha = 1; Ab.g.globalCompositeOperation = 'source-over'; }
  if (T.reflect && quality === 'high') { ctx.save(); ctx.globalAlpha = alpha * T.reflect; ctx.translate(0, W_.GY * 2 + 4); ctx.scale(1, -1); ctx.drawImage(Ab.c, x - BOX, y - BOY, BW, BH); ctx.restore(); }
  ctx.save(); ctx.globalAlpha = alpha; ctx.drawImage(Ab.c, x - BOX, y - BOY, BW, BH); ctx.restore();
  const rim = rimA != null ? rimA : .75;
  if (rim > 0 && quality === 'high') {
    R.g.setTransform(1, 0, 0, 1, 0, 0); R.g.globalCompositeOperation = 'copy'; R.g.drawImage(Ab.c, 0, 0);
    R.g.globalCompositeOperation = 'source-in'; R.g.fillStyle = rimCol || T.rim || T.ambient; R.g.fillRect(0, 0, R.c.width, R.c.height);
    R.g.globalCompositeOperation = 'destination-out'; R.g.drawImage(Ab.c, -T.ldir * 1.9 * S, 1.4 * S); R.g.globalCompositeOperation = 'source-over';
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = alpha * rim; ctx.drawImage(R.c, x - BOX, y - BOY, BW, BH); ctx.restore();
  }
  if (flash > .02) {
    if (flashFn) { R.g.setTransform(1, 0, 0, 1, 0, 0); R.g.globalCompositeOperation = 'source-over'; R.g.clearRect(0, 0, R.c.width, R.c.height); R.g.setTransform(S, 0, 0, S, 0, 0); R.g.save(); R.g.translate(BOX, BOY); R.g.scale(W_.CS, W_.CS); flashFn(R.g); R.g.restore(); R.g.setTransform(1, 0, 0, 1, 0, 0); }
    else { R.g.setTransform(1, 0, 0, 1, 0, 0); R.g.globalCompositeOperation = 'copy'; R.g.drawImage(Ab.c, 0, 0); }
    R.g.globalCompositeOperation = 'source-in'; R.g.fillStyle = '#ffffff'; R.g.fillRect(0, 0, R.c.width, R.c.height); R.g.globalCompositeOperation = 'source-over';
    const fm = flashMax || .45; ctx.save(); ctx.globalAlpha = alpha * Math.min(fm, flash * fm * 1.1); ctx.drawImage(R.c, x - BOX, y - BOY, BW, BH); ctx.restore();
  }
}

/* the rig parameters for the knight (shared by the battle and the pose sheet in tools/qa/poses.cjs) */
function heroRigP(h, P, t, bob) {
  const ru = h.runAmt || 0, d = h.dead || 0;
  const oh = offHand(!!h.skin.shield, h.walk, d ? 0 : h.walkAmt, ru, d ? 0 : P.swing, t, d ? 0 : h.shieldUp || 0, h.flash || 0, 0);
  return { ld: T ? T.ldir : 1, bob, walk: h.walk, walkAmt: d ? 0 : h.walkAmt, run: ru, th: P.th + (h.walkAmt * Math.sin(h.walk) * (.12 + .2 * ru)) + ru * (h.skin.shield ? .2 : .35), ph: P.ph + ru * (h.skin.shield ? -.05 : .5), wglow: P.wglow, lean: P.swing > 0 && P.swing < 1 ? .12 : h.walkAmt * (.06 + .16 * ru), lungeLeg: P.lunge * .012, capeKick: P.lunge * .4 + ru * 9, bth: oh.bth, shieldTilt: oh.tilt };
}
function heroBob(h, t) { const ru = h.runAmt || 0; return h.walkAmt > .1 ? (Math.pow(Math.sin(h.walk), 2) * (4.2 + 3 * ru) - ru * 2) * h.walkAmt : Math.sin(t * 2.4) * 1.1; }
function drawHero(h, t) {
  const { GY, CS } = W_;
  const P = h.victory ? { th: POSE.W.th + .3, ph: POSE.W.ph + .4, lunge: 0, swing: -1, wglow: 1 } : rigPose(h.atk, 'swing', !!h.skin.shield);
  const x = h.x + P.lunge + (h.kb || 0), bob = heroBob(h, t);
  const d = h.dead || 0, fall = eIn(clamp(d / .5, 0, 1)) * 1.45, alpha = 1 - clamp((d - .8) / .6, 0, .55);
  drawShadow(x, 34 * CS, .55);
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; glow(ctx, T.ambient, x, GY, 60, .08 * fxAmt); ctx.restore();
  const wp = h.skin.weapon;
  if (P.swing > 0 && !d) {
    const k1 = Math.min(1, P.swing), fade = P.swing > 1 ? 1 - (P.swing - 1) * 2.5 : 1;
    if (fade > 0) { const L = { sword: 58, greatsword: 80, axe: 62, mace: 50 }[wp.type] || 60;
      ctx.save(); ctx.translate(x, GY); ctx.scale(CS, CS); ctx.globalCompositeOperation = 'lighter';
      const outer = [], inner = []; const k0 = Math.max(.15, k1 - .55); for (let i = 0; i <= 14; i++) { const k = k0 + (k1 - k0) * i / 14; const [o, n] = swingTip(k, HIP_Y + bob, L + 4); const w2 = .55 + .35 * (i / 14); outer.push(o); inner.push([lerp(o[0], n[0], w2), lerp(o[1], n[1], w2)]); }
      const gcol = wp.glow || '#ffffff';
      ctx.beginPath(); outer.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); for (let i = inner.length - 1; i >= 0; i--) ctx.lineTo(inner[i][0], inner[i][1]); ctx.closePath();
      const gr = ctx.createLinearGradient(outer[0][0], outer[0][1], outer[outer.length - 1][0], outer[outer.length - 1][1]); gr.addColorStop(0, rgba(gcol, 0)); gr.addColorStop(.7, rgba(gcol, .3 * fade)); gr.addColorStop(1, rgba('#ffffff', .6 * fade)); ctx.fillStyle = gr; ctx.fill();
      ctx.strokeStyle = rgba(mix(gcol, '#ffffff', .6), .55 * fade); ctx.lineWidth = 1; ctx.beginPath(); outer.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.stroke();
      glow(ctx, gcol, outer[outer.length - 1][0], outer[outer.length - 1][1], 30, .6 * fade);
      ctx.restore(); }
  }
  const RP = heroRigP(h, P, t, bob);
  const heroRig = noCape => g => { if (fall) { g.translate(-4, 0); g.rotate(-fall); } RP.noCape = noCape; drawRig(g, h.skin, RP, t); };
  const fl = (h.flash || 0) + (h.equip || 0) * .6;
  /* a hit flashes the knight at half the old strength, and not his cape; equipping new gear keeps the full shimmer */
  renderActor(heroRig(false), x, GY, fl, alpha, .75, null, false, h.equip > 0 ? .45 : .22, h.equip > 0 || fl <= .02 ? null : heroRig(true));
  if (h.equip > 0) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; glow(ctx, wp.glow || T.ambient, x, GY - 60 * CS, 100, h.equip * .6); ctx.restore(); }
  if (h.shieldUp > 0) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.strokeStyle = rgba('#9ad0ff', h.shieldUp); ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x + 26, GY - 60 * CS, 16, 46, 0, -1.2, 1.2); ctx.stroke(); glow(ctx, '#9ad0ff', x + 30, GY - 60 * CS, 40, h.shieldUp * .5); ctx.restore(); }
}

const CORPSE_FADE = [.42, .85];   // when a fallen enemy starts and finishes fading (1 = the moment the engine removes it)
function enemyTop(e) { return (e.vis.C ? e.vis.C.h : 124) * e.scale * W_.CS; }
function drawEnemy(e, t, dt) {
  const { GY, CS, W } = W_, v = e.vis;
  const d = e.dead || 0, x = e.x + (e.kb || 0);
  if (x < -160 || x > W + 160) return;
  let fall = 0, sink = 0, alpha = 1;
  if (d) { fall = eIn(clamp(d / .45, 0, 1)) * (v.C ? .35 : 1.45); sink = v.C ? eIn(clamp(d, 0, 1)) * 30 : 0; alpha = 1 - clamp((d - CORPSE_FADE[0]) / (CORPSE_FADE[1] - CORPSE_FADE[0]), 0, 1); }   // the fallen drop and are gone in well under a second, so they never cover the fight
  if (alpha <= 0) return;
  const sc = e.scale || 1, big = sc > 1.15 || (v.C && v.C.h * sc > 170);
  drawShadow(x, (v.C ? (v.type === 'wolf' ? 36 : 50) : 32) * CS * sc, .5 * alpha);
  const rimCol = e.boss ? '#ffcf6a' : e.elite ? '#ffd27a' : null;
  renderActor(g => { g.scale(-sc, sc); if (fall) { g.translate(-4, 0); g.rotate(-fall); }
    if (v.C) v.C.draw(g, v, { ld: -T.ldir, atk: e.atk, t, walk: e.walk, walkAmt: e.walkAmt }, t);
    else { const P = rigPose(e.atk, v.style, !!v.skin.shield && (!v.style || v.style === 'swing')); const bob = e.walkAmt > .1 ? Math.pow(Math.sin(e.walk), 2) * 4.2 * e.walkAmt : Math.sin(t * 2.1 + e.phase) * 1;
      const eo = offHand(!!v.skin.shield, e.walk, e.walkAmt, 0, P.swing, t, 0, Math.min(1, e.flash || 0), e.phase);
      drawRig(g, v.skin, { ld: -T.ldir, bob, walk: e.walk, walkAmt: e.walkAmt, th: P.th + e.walkAmt * Math.sin(e.walk) * .14, ph: P.ph, wglow: P.wglow + .2, lean: P.swing > 0 && P.swing < 1 ? .1 : 0, lungeLeg: P.lunge * .012, bth: eo.bth, shieldTilt: eo.tilt, pull: P.pull }, t); }
  }, x, GY + sink, d ? 0 : e.flash || 0, alpha, d ? 0 : rimCol ? .95 : .65, rimCol, big, null, null, e.boss ? .08 : d ? .32 : .18);
  if (d && d < .6) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; glow(ctx, T.ambient, x, GY - 60 * CS, 90, (1 - d / .6) * .5); ctx.restore(); }
  // creature ambient emission
  if (v.C && v.emit && !d && dt > 0 && quality === 'high') { v.emitT = (v.emitT || 0) - dt; if (v.emitT <= 0) { v.emitT = .14; const em = v.emit, ex = x, s2 = sc * CS;
    if (em.type === 'wisp') addPart({ tp: 'wisp', x: ex + (rnd() - .5) * 60, y: GY + em.y * s2 - rnd() * 20, vx: (rnd() - .5) * 10, vy: -16 - rnd() * 16, life: 1.6, t: 0, s: 2 + rnd() * 2, col: v.m.rim, d: 1, add: 1, ph: rnd() * TAU });
    else if (em.type === 'ember') addPart({ tp: 'ember', x: ex + (rnd() - .5) * 50, y: GY - 40 - rnd() * 60, vx: (rnd() - .5) * 20, vy: -30 - rnd() * 30, life: 1.5, t: 0, s: 1.2 + rnd(), col: '#ff8a2a', d: 1, add: 1 });
    else if (em.type === 'snowburst') addPart({ tp: 'mote', x: ex + (rnd() - .5) * 60, y: GY - rnd() * 100, vx: (rnd() - .5) * 10, vy: -10, life: 1.5, t: 0, s: 1.2, col: '#dff6ff', d: 1, add: 1 });
    else if (em.type === 'spark') addPart({ tp: 'mote', x: ex + (rnd() - .5) * 70, y: GY - 60 - rnd() * 80, vx: (rnd() - .5) * 14, vy: -8, life: 1.4, t: 0, s: 1.3, col: v.m.eye, d: 1, add: 1 });
    else if (em.type === 'leaf') addPart({ tp: 'leaf', x: ex + (rnd() - .5) * 50, y: GY - 120 * s2 + rnd() * 20, vx: (rnd() - .5) * 20, vy: 10 + rnd() * 10, life: 2, t: 0, s: 2 + rnd(), col: rnd() < .5 ? '#9ac85a' : '#d88a3a', d: 1, ph: rnd() * TAU, rot: rnd() * TAU });
  } }
}
function drawEnemyBars(e) {
  const { GY } = W_; if (e.dead || e.noBar || e.x < -60 || e.x > W_.W + 60) return;      // noBar: staged shots for the menu art
  if (e.tele > 0) {      // a heavy move is coming: a ring closes on the enemy; an ability cast before it shuts interrupts the move
    const k = e.tele, cy = GY - enemyTop(e) * .5, r0 = 26 * (e.scale || 1), r = lerp(r0 * 3.1, r0, eIO(k)), col = e.teleCol || '#ff5a4a';
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    ctx.strokeStyle = rgba(col, .35); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(e.x, cy, r0, 0, TAU); ctx.stroke();
    ctx.strokeStyle = rgba(mix(col, '#ffffff', .25), .55 + .45 * k); ctx.lineWidth = 3 + 2 * k; ctx.beginPath(); ctx.arc(e.x, cy, r, 0, TAU); ctx.stroke();
    glow(ctx, col, e.x, cy, r0 * 2.2, .16 + .3 * k); ctx.restore();
  }
  const top = enemyTop(e) + (e.vis.C && e.vis.type === 'wraith' ? 20 : 0);
  if (!e.boss && e.dead !== true && (e.aggro || e.x < W_.W - 20)) {
    const bw = e.elite ? 64 : 44, bx = Math.round(e.x - bw / 2), by = Math.round(GY - top - 10);
    if (e.elite) { ctx.fillStyle = '#f2c14e'; ctx.fillRect(bx - 2, by - 2, bw + 4, 8); } ctx.fillStyle = 'rgba(0,0,0,.75)'; ctx.fillRect(bx - 1, by - 1, bw + 2, 6); ctx.fillStyle = '#3a1018'; ctx.fillRect(bx, by, bw, 4);
    ctx.fillStyle = e.elite ? '#ffb84a' : '#e0485a'; ctx.fillRect(bx, by, bw * clamp(e.hpFrac, 0, 1), 4);
    if (e.bleed) { ctx.fillStyle = '#ff4a5a'; ctx.beginPath(); ctx.arc(bx - 5, by + 2, 2.4, 0, TAU); ctx.fill(); }
    if (e.burn) { ctx.fillStyle = '#ff9a3a'; ctx.beginPath(); ctx.arc(bx + bw + 5, by + 2, 2.4, 0, TAU); ctx.fill(); }
  }
  if (e.elite && !e.boss) { ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; const ny = GY - top - 16; ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.fillText(e.name, e.x + 1, ny + 1); ctx.fillStyle = '#ffd27a'; ctx.fillText(e.name, e.x, ny); }
}

function drawGrave(x, g2, t) {
  const { GY } = W_; if (x < -60 || x > W_.W + 60) return;
  ctx.save(); ctx.translate(x, GY + 2);
  ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(0, 0, 22, 4, 0, 0, TAU); ctx.fill();
  const gr = ctx.createLinearGradient(-14, 0, 14, 0); gr.addColorStop(0, '#2a2632'); gr.addColorStop(.6, '#6a6478'); gr.addColorStop(1, '#9a94a8');
  ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(-13, 0); ctx.lineTo(-13, -30); ctx.quadraticCurveTo(-13, -44, 0, -44); ctx.quadraticCurveTo(13, -44, 13, -30); ctx.lineTo(13, 0); ctx.closePath(); ctx.fill();
  ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(0, -36); ctx.lineTo(0, -14); ctx.moveTo(-6, -29); ctx.lineTo(6, -29); ctx.stroke();
  if (g2.you) { ctx.globalCompositeOperation = 'lighter'; glow(ctx, '#f2c14e', 0, -26, 30, .35 + Math.sin(t * 3) * .1); ctx.globalCompositeOperation = 'source-over'; }
  ctx.textAlign = 'center'; ctx.font = '700 11px ' + FONT; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.75)';
  ctx.strokeText(g2.name, 0, -52); ctx.fillStyle = g2.you ? '#f2c14e' : '#efe6d8'; ctx.fillText(g2.name, 0, -52);
  ctx.font = '600 10px ' + FONT; ctx.strokeText('Wave ' + g2.wave, 0, -64); ctx.fillStyle = '#c9bde0'; ctx.fillText('Wave ' + g2.wave, 0, -64);
  ctx.restore();
}
const props = [];
/* event stops painted in the world */
function drawProp(p, t) {
  const { GY, CS } = W_, x = p.x; if (x < -120 || x > W_.W + 120) return;
  const g = ctx; g.save(); g.translate(x, GY + 2); g.scale(CS, CS);
  const shadow = w => { const gr = g.createRadialGradient(0, 0, 1, 0, 0, w); gr.addColorStop(0, 'rgba(0,0,0,.5)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.ellipse(0, 0, w, w * .22, 0, 0, TAU); g.fill(); };
  const stone = (x0, x1) => hgrad(g, x0, x1, '#3a3446', '#8a8298');
  const dim = p.done ? .35 : 1;
  if (p.type === 'heal') {
    shadow(40); g.fillStyle = stone(-34, 34); g.beginPath(); g.moveTo(-34, 0); g.lineTo(-30, -18); g.lineTo(30, -18); g.lineTo(34, 0); g.fill();
    g.fillStyle = '#5a5268'; g.fillRect(-30, -22, 60, 5); g.fillStyle = stone(-6, 6); g.fillRect(-5, -52, 10, 32); g.beginPath(); g.ellipse(0, -52, 14, 4, 0, 0, TAU); g.fill();
    g.fillStyle = rgba('#6affc8', .75 * dim); g.beginPath(); g.ellipse(0, -21, 27, 3.5, 0, 0, TAU); g.fill();
    g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 3; i++) { const k = (t * 1.2 + i / 3) % 1; g.fillStyle = rgba('#bfffe8', (1 - k) * .8 * dim); g.fillRect(-1 + Math.sin(i * 2) * 8, -55 + k * 34, 2, 6); }
    glow(g, '#6affc8', 0, -30, 60, .45 * dim); glow(g, '#ffffff', 0, -52, 12, .5 * dim);
  } else if (p.type === 'chest') {
    shadow(34); const o = p.open;
    if (o > 0) { g.save(); g.globalCompositeOperation = 'lighter'; glow(g, '#ffd86a', 0, -30, 70 * o, .7 * o * dim); g.restore(); }
    g.fillStyle = hgrad(g, -26, 26, '#3a1e0c', '#8a5a2a'); g.fillRect(-26, -26, 52, 26);
    g.fillStyle = '#d8b25a'; g.fillRect(-26, -16, 52, 3); g.fillRect(-20, -26, 5, 26); g.fillRect(15, -26, 5, 26); g.fillRect(-4, -20, 8, 8);
    g.save(); g.translate(-26, -26); g.rotate(-o * 1.9); g.fillStyle = vgrad(g, -16, 0, '#a06a34', '#5a3418'); g.beginPath(); g.moveTo(0, 0); g.bezierCurveTo(0, -18, 52, -18, 52, 0); g.closePath(); g.fill(); g.fillStyle = '#d8b25a'; g.fillRect(6, -12, 5, 12); g.fillRect(41, -12, 5, 12); g.restore();
  } else if (p.type === 'shrine') {
    shadow(30); g.fillStyle = stone(-12, 12); g.beginPath(); g.moveTo(-14, 0); g.lineTo(-10, -86); g.lineTo(0, -98); g.lineTo(10, -86); g.lineTo(14, 0); g.fill();
    g.fillStyle = '#4a4458'; g.fillRect(-22, -8, 44, 8);
    const pulse = .7 + Math.sin(t * 2.4) * .3; g.save(); g.globalCompositeOperation = 'lighter'; g.strokeStyle = rgba('#c9a2ff', .9 * dim); g.lineWidth = 1.8;
    g.beginPath(); g.moveTo(0, -78); g.lineTo(0, -40); g.moveTo(-6, -66); g.lineTo(6, -56); g.moveTo(6, -66); g.lineTo(-6, -56); g.stroke(); glow(g, '#c9a2ff', 0, -60, 50, .55 * pulse * dim);
    for (let i = 0; i < 4; i++) { const a = t * 1.3 + i * 1.57; glow(g, '#e8d8ff', Math.cos(a) * 22, -60 + Math.sin(a * 1.3) * 26, 5, .8 * dim); } g.restore();
  } else if (p.type === 'altar') {
    shadow(38); g.fillStyle = hgrad(g, -30, 30, '#1a1014', '#4a3038'); g.fillRect(-30, -30, 60, 30); g.fillStyle = '#2a1a20'; g.fillRect(-34, -36, 68, 7);
    g.fillStyle = '#6a0a14'; g.beginPath(); g.ellipse(0, -37, 12, 3, 0, 0, TAU); g.fill();
    for (const cx of [-26, 26]) { g.fillStyle = '#e8dcc0'; g.fillRect(cx - 2, -50, 4, 14); g.save(); g.globalCompositeOperation = 'lighter'; glow(g, '#ffb04a', cx, -53, 12, (.8 + Math.sin(t * 11 + cx) * .15) * dim); g.restore(); g.fillStyle = '#ffd080'; g.beginPath(); g.ellipse(cx, -53, 1.6, 3.4, 0, 0, TAU); g.fill(); }
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, '#ff2a3a', 0, -38, 44, (.45 + Math.sin(t * 2) * .15) * dim); g.restore();
  } else if (p.type === 'fork') {
    shadow(30); g.fillStyle = hgrad(g, -4, 4, '#2a1c10', '#6a4a2a'); g.fillRect(-3.5, -96, 7, 96);
    g.fillStyle = '#3a2816'; g.beginPath(); g.ellipse(0, -1, 12, 4, 0, 0, TAU); g.fill();
    const board = (y, dirn, col) => { g.save(); g.translate(0, y); g.rotate(dirn * -.07); g.fillStyle = hgrad(g, -34, 34, mix(col, '#000', .35), mix(col, '#fff', .12));
      g.beginPath(); if (dirn > 0) { g.moveTo(-8, -9); g.lineTo(30, -9); g.lineTo(40, 0); g.lineTo(30, 9); g.lineTo(-8, 9); } else { g.moveTo(8, -9); g.lineTo(-30, -9); g.lineTo(-40, 0); g.lineTo(-30, 9); g.lineTo(8, 9); } g.closePath(); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 1; g.stroke(); g.fillStyle = rgba('#f2d796', .85 * dim); g.fillRect(dirn > 0 ? 2 : -24, -2.5, 22, 1.6); g.fillRect(dirn > 0 ? 2 : -18, 1.8, 16, 1.4); g.restore(); };
    board(-80, 1, '#8a5a2a'); board(-58, -1, '#6a4a2a');
    g.save(); g.globalCompositeOperation = 'lighter'; glow(g, '#f2d796', 0, -70, 46, (.28 + Math.sin(t * 2.2) * .08) * dim); g.restore();
  } else if (p.type === 'merchant') {
    shadow(50); g.fillStyle = hgrad(g, -40, 30, '#3a2410', '#7a5028'); g.fillRect(-40, -34, 70, 22);
    for (const wx of [-30, 20]) { g.fillStyle = '#2a1a0c'; g.beginPath(); g.arc(wx, -10, 10, 0, TAU); g.fill(); g.strokeStyle = '#8a6a3a'; g.lineWidth = 1.5; g.stroke(); }
    g.fillStyle = vgrad(g, -70, -34, '#c8b890', '#8a7a58'); g.beginPath(); g.moveTo(-44, -34); g.quadraticCurveTo(-36, -76, -5, -74); g.quadraticCurveTo(26, -76, 34, -34); g.closePath(); g.fill();
    g.fillStyle = '#e8b04a'; g.beginPath(); g.arc(-18, -38, 3, 0, TAU); g.arc(-8, -39, 3, 0, TAU); g.fill(); g.fillStyle = '#c0304a'; g.beginPath(); g.arc(4, -38, 3, 0, TAU); g.fill();
    g.fillStyle = '#2a1a0c'; g.fillRect(36, -64, 2, 60); g.save(); g.globalCompositeOperation = 'lighter'; glow(g, '#ffb04a', 44, -60, 24, (.8 + Math.sin(t * 9) * .1) * dim); g.restore(); g.fillStyle = '#ffd080'; g.fillRect(41, -64, 6, 8);
    g.save(); g.translate(58, 0); g.scale(-.9, .9); drawRig(g, { body: 'robe', robe: '#3a2a4a', trim: '#d8b25a', helm: 'hood', glow: '#ffd080' }, { ld: 1, th: 1.05, ph: -1, bth: 1.1, walkAmt: 0 }, t); g.restore();
  }
  g.restore();
}
function drawFinish(x, t) {
  const { GY } = W_; if (x < -80 || x > W_.W + 80) return;
  ctx.save(); ctx.translate(x, GY + 2);
  ctx.fillStyle = '#2a1e14'; ctx.fillRect(-2, -110, 4, 110); ctx.fillStyle = '#d0ab62'; ctx.beginPath(); ctx.arc(0, -112, 4, 0, TAU); ctx.fill();
  const wv = Math.sin(t * 3) * 3;
  ctx.beginPath(); ctx.moveTo(2, -104); ctx.quadraticCurveTo(22, -104 + wv, 40, -100); ctx.lineTo(40, -70); ctx.lineTo(30, -76 + wv * .5); ctx.lineTo(21, -70); ctx.quadraticCurveTo(12, -74 - wv, 2, -72); ctx.closePath();
  const gr = ctx.createLinearGradient(0, -104, 0, -70); gr.addColorStop(0, '#9a1a30'); gr.addColorStop(1, '#4a0a16'); ctx.fillStyle = gr; ctx.fill();
  ctx.strokeStyle = '#d0ab62'; ctx.lineWidth = 1.2; ctx.stroke();
  ctx.fillStyle = '#d0ab62'; ctx.beginPath(); ctx.moveTo(20, -96); ctx.lineTo(24, -88); ctx.lineTo(20, -80); ctx.lineTo(16, -88); ctx.closePath(); ctx.fill();
  ctx.globalCompositeOperation = 'lighter'; glow(ctx, '#ffd27a', 20, -88, 40, .3 + Math.sin(t * 2) * .08);
  ctx.restore();
}
function drawProj(p, t) {
  const { GY, CS } = W_, x = p.x, y = GY - p.h * CS;
  ctx.save();
  if (p.kind === 'arrow') { ctx.translate(x, y); ctx.strokeStyle = '#8a6a3a'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(22, 0); ctx.stroke(); ctx.fillStyle = '#e6ecf6'; ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(0, -3); ctx.lineTo(0, 3); ctx.fill(); ctx.fillStyle = '#c0303a'; ctx.fillRect(19, -2.5, 4, 5);
    ctx.globalCompositeOperation = 'lighter'; glow(ctx, p.col || '#ffffff', -2, 0, 8, .35); }
  else { const col = p.col || '#ff8a2a', r = p.kind === 'fireball' ? 1.2 : 1; ctx.globalCompositeOperation = 'lighter';
    for (let i = 1; i < 6; i++) glow(ctx, col, x - (p.vx > 0 ? 1 : -1) * i * 7, y, (12 - i * 1.6) * r, .45 - i * .07);
    glow(ctx, col, x, y, 22 * r, .9); glow(ctx, '#ffffff', x, y, 6 * r, 1); }
  ctx.restore();
}
function drawFX(t) {
  const { GY } = W_;
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (const b of beams) { const k = b.t / b.dur, a = Math.sin(k * Math.PI) * (b.a || 1); const w = b.w * (1 - k * .3);
    if (b.line) { const [x0, x1, y] = b.line, off = b.x - (x0 + x1) / 2; ctx.strokeStyle = rgba(b.col, a); ctx.lineWidth = 3 * (1 - k); ctx.beginPath(); ctx.moveTo(x0 + off, y); ctx.lineTo(x1 + off + 20, y); ctx.stroke(); glow(ctx, b.col, x1 + off, y, 30, a * .6); continue; }
    const gr = ctx.createLinearGradient(0, 0, 0, GY); gr.addColorStop(0, rgba(b.col, 0)); gr.addColorStop(.7, rgba(b.col, a * .55)); gr.addColorStop(1, rgba('#ffffff', a * .8));
    ctx.fillStyle = gr; ctx.fillRect(b.x - w / 2, b.top || 0, w, GY - (b.top || 0)); ctx.fillStyle = rgba('#ffffff', a * .7); ctx.fillRect(b.x - w * .12, b.top || 0, w * .24, GY - (b.top || 0)); glow(ctx, b.col, b.x, GY - 6, w * 2, a * .8); }
  for (const b of bolts) { const a = 1 - b.t / .28; ctx.strokeStyle = rgba('#e8fbff', a); ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.beginPath(); for (let i = 0; i < b.pts.length; i++) { const p = b.pts[i]; i ? ctx.lineTo(b.x + p[0], p[1]) : ctx.moveTo(b.x + p[0], p[1]); } ctx.stroke();
    ctx.strokeStyle = rgba(b.col, a * .6); ctx.lineWidth = 6; ctx.stroke(); glow(ctx, b.col, b.x, b.gy, 50, a * .8); }
  for (const r of rings) { const tt = Math.min(1, Math.max(0, r.t)), k = eOut(tt), a = 1 - tt; if(a<=0) continue; ctx.strokeStyle = rgba(r.col, a * .9); ctx.lineWidth = (r.big ? 3 : 2) * (1 - k * .6); ctx.beginPath(); if (r.flat) ctx.ellipse(r.x, r.y, 20 + k * 110, 4 + k * 16, 0, 0, TAU); else ctx.arc(r.x, r.y, 8 + k * (r.big ? 70 : 40), 0, TAU); ctx.stroke(); }
  ctx.restore();
  for (const f of frags) { const a = 1 - clamp((f.t - 1) / .6, 0, 1); ctx.save(); ctx.globalAlpha = a; ctx.translate(f.x, f.y); ctx.rotate(f.r); ctx.fillStyle = f.col; ctx.beginPath(); ctx.moveTo(-f.s, -f.s * .6); ctx.lineTo(f.s * .8, -f.s * .4); ctx.lineTo(f.s * .4, f.s * .7); ctx.lineTo(-f.s * .7, f.s * .5); ctx.closePath(); ctx.fill(); ctx.restore(); }
  for (const c of coins) { const sx = Math.abs(Math.cos(c.t * 9 + c.ph)); ctx.save(); ctx.translate(c.x, c.y); ctx.fillStyle = '#7a5a10'; ctx.beginPath(); ctx.ellipse(0, 0, 4.2 * sx + .6, 4.2, 0, 0, TAU); ctx.fill(); ctx.fillStyle = sx > .5 ? '#ffd86a' : '#e0a830'; ctx.beginPath(); ctx.ellipse(0, -.3, 3.4 * sx + .4, 3.4, 0, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = 'lighter'; glow(ctx, '#ffd86a', 0, 0, 9, .5); ctx.restore(); }
}
const NUM_MAX = 14, DMG_MAX = 6, NUM_LANE = 26, NUM_LANES = 7;
let textTop = 70, textL = 16, textR = 4000, shakeMul = 1;
function fmtDmg(n) { n = Math.round(n); return n >= 10000 ? (n / 1000).toFixed(1) + 'K' : n.toLocaleString('en-US'); }
const NUMCOL = { resist: '#a8a2b8', dmg: '#ffffff', crit: '#ffd24a', hurt: '#ff6a6a', heal: '#6af08a', gold: '#ffd86a', block: '#9ad0ff', burn: '#ff9a3a', bleed: '#ff5a6a', zap: '#9ff0ff', holy: '#ffe07a', fire: '#ffb04a', thorn: '#9ad0ff', blast: '#ffb03a', lvl: '#e0c2ff', info: '#ffe9c0' };
function drawNums() {
  ctx.save(); ctx.textAlign = 'center'; ctx.lineJoin = 'round';
  let lastCrit = null; for (const n of nums) if (n.dm && n.kind === 'crit') lastCrit = n;      // only the newest critical hit carries the word
  for (const n of nums) {
    const k = n.t / 1.1, pop = n.t < .12 ? eOut(n.t / .12) * 1.3 : 1.3 - Math.min(.3, (n.t - .12) * 2), y0 = n.y - eOut(Math.min(1, n.t * 1.4)) * 34,
      /* text carried towards a screen edge by the scrolling world fades out before it reaches it: nothing is cut off or left piled at the edge */
      a = (1 - clamp((k - .6) / .4, 0, 1)) * clamp(Math.min(n.x - (n.half || 20) - textL, textR - n.x - (n.half || 20)) / 26 + 1, 0, 1);
    if (a <= 0) continue;
    const sz = (n.kind === 'crit' ? 30 : n.kind === 'lvl' ? 20 : (n.kind === 'dmg' ? 16 : 14)) * (1 + (n.big || 0) * .55);
    /* the whole text (and the word CRITICAL above it) stays under the HUD and the boss bar, however far it has risen or grown */
    const y = Math.max(y0, textTop + Math.max(sz * .8, n === lastCrit ? 36 : 0) * pop + 3, textTop + 3 + ((n.lane || 0) + 1) * NUM_LANE);
    ctx.save(); ctx.translate(n.x + (n.kind === 'crit' ? Math.sin(n.t * 40) * (1 - Math.min(1, n.t * 5)) * 3 : 0), y); ctx.scale(pop, pop); ctx.globalAlpha = a;
    ctx.font = '700 ' + sz + 'px ' + FONT; ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,4,8,.85)';
    if (n.kind === 'crit') { ctx.globalCompositeOperation = 'lighter'; glow(ctx, '#ff9a2a', 0, -8, 40, .5 * a); ctx.globalCompositeOperation = 'source-over'; if (n === lastCrit) { ctx.font = '700 10px ' + FONT; ctx.strokeText('CRITICAL', 0, -24); ctx.fillStyle = '#ffe9a8'; ctx.fillText('CRITICAL', 0, -24); } ctx.font = '700 ' + sz + 'px ' + FONT; }
    ctx.strokeText(n.txt, 0, 0); ctx.fillStyle = NUMCOL[n.kind] || '#ffffff'; ctx.fillText(n.txt, 0, 0); ctx.restore();
  }
  ctx.restore();
}
function doBloom() {
  const bw = bloom1.width, bh = bloom1.height, b1 = bloom1.getContext('2d'), b2 = bloom2.getContext('2d');
  b1.globalCompositeOperation = 'copy'; b1.imageSmoothingEnabled = true; b1.drawImage(canvas, 0, 0, bw, bh);
  b2.globalCompositeOperation = 'copy'; b2.drawImage(bloom1, 0, 0);
  b1.globalCompositeOperation = 'multiply'; b1.drawImage(bloom2, 0, 0); // square: keep only highlights
  b2.drawImage(bloom1, 0, 0); b1.drawImage(bloom2, 0, 0);            // ^4
  ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = .55 * Math.min(1.3, fxAmt); ctx.imageSmoothingEnabled = true; ctx.drawImage(bloom1, 0, 0, W_.W, W_.H); ctx.restore();
}

/* =====================================================================
   PUBLIC API
===================================================================== */
const World = {
  get W() { return W_.W; }, get H() { return W_.H; }, get GY() { return W_.GY; }, get HX() { return W_.HX; }, get CS() { return W_.CS; },
  get theme() { return themeKey; }, get quality() { return quality; }, FONT,
  init(el, q) { canvas = el; ctx = canvas.getContext('2d'); if (q) quality = q; this.resize(true); },
  setQuality(q) { if (q === quality) return; quality = q; this.resize(true); },
  /* fit the logical stage to the screen: H≈390, width follows the aspect ratio (at least 700 wide) */
  resize(force) {
    const cw = Math.max(320, window.innerWidth), ch = Math.max(200, window.innerHeight), asp = cw / ch;
    let H = 390, W = Math.round(H * asp); if (W < 700) { W = 700; H = Math.round(W / asp); }
    const dpr = window.devicePixelRatio || 1, newS = quality === 'high' ? Math.min(2, Math.max(1, dpr)) : 1.25, newMS = quality === 'high' ? Math.min(2, Math.max(1, dpr)) : 1.25;
    const changed = force || W !== W_.W || H !== W_.H || newS !== S || newMS !== MS;
    if (!changed) return false;
    W_.W = W; W_.H = H; W_.GY = Math.round(H * .77); W_.TW = W * 2; W_.HX = Math.round(W * .3);
    if (newS !== S) { S = newS; clearCaches(); }
    MS = newMS; fxAmt = quality === 'high' ? 1 : .5;
    canvas.width = Math.round(W * MS); canvas.height = Math.round(H * MS);
    freeBuf(bufN); freeBuf(bufB); bufN = mkBuf(340, 300, 170, 272); bufB = mkBuf(470, 440, 235, 410);
    freeCanvas(bloom1); freeCanvas(bloom2); bloom1 = document.createElement('canvas'); bloom1.width = Math.round(W / 6); bloom1.height = Math.round(H / 6); bloom2 = document.createElement('canvas'); bloom2.width = bloom1.width; bloom2.height = bloom1.height;
    if (themeKey) buildTheme(themeKey);
    return true;
  },
  setTheme(key) { if (key === themeKey && A && A.W === W_.W && A.H === W_.H && A.S === S) return 0; return buildTheme(key); },
  release() { freeAssets(); themeKey = null; },
  themeInfo(key) { const Th = THEMES[key || themeKey]; return Th ? { ambient: Th.ambient, ldir: Th.ldir } : null; },
  makeVis(look, seed) {
    if (look.kind === 'creature') { const C = CREATURES[look.type], v = { C, type: look.type, m: look.m, seed: seed || 7, emitT: 0 }; if (C.build) C.build(v); return v; }
    return { skin: look.skin, style: look.style || 'swing' };
  },
  /* ---- effects (all in screen px) ---- */
  setCoinTarget(x, y) { coinTarget = [x, y]; },
  clearFX() { parts.length = 0; nums.length = 0; frags.length = 0; coins.length = 0; rings.length = 0; bolts.length = 0; beams.length = 0; },
  shake(px) { shake = Math.max(shake, px * shakeMul); },
  setCalm(on) { shakeMul = on ? .35 : 1; },
  /* floating text stays below the top HUD and inside the screen: yMin / xMin / xMax in world px (engine.js measures the HUD) */
  setTextBounds(yMin, xMin, xMax) { textTop = yMin; textL = xMin; textR = xMax; },
  num(x, y, txt, kind, big) {
    if (nums.length >= NUM_MAX) { const i = nums.findIndex(n => n.dm && n.kind !== 'crit'); nums.splice(i < 0 ? 0 : i, 1); }
    txt = String(txt); const half = Math.min(170, txt.length * (kind === 'lvl' ? 7.5 : kind === 'crit' ? 9 : 5.5) + 10);
    const n = { x: clamp(x, textL + half, Math.max(textL + half, textR - half)), y: Math.max(y, textTop + 40), txt, kind: kind || 'dmg', t: 0, big: big || 0, half, lane: 0, rows: 1 };
    /* numbers pushed to the same spot (under the HUD or the boss bar, or against a screen edge) take the next free row down instead of piling up */
    n.by = n.y; let used = 0; for (const m of nums) if (m.t < .8 && Math.abs(m.x - n.x) < (m.half + half) && Math.abs(m.by - n.by) < NUM_LANE) used |= m.rows;
    const need = n.kind === 'crit' ? 3 : 1; let k = 0; while (k < NUM_LANES - 1 && (used >> k) & need) k++;      // a critical hit is taller: it takes two rows
    n.rows = need << k; n.lane = k + (need > 1 ? 1 : 0); n.y += n.lane * NUM_LANE;
    nums.push(n); return n; },
  /* damage numbers: at most DMG_MAX alive; quick hits on one target merge into a single growing number (crits stand alone) */
  dmgNum(key, x, y, amt, kind, big) {
    if (kind !== 'crit') { const m = nums.find(n => n.dm && n.key === key && n.kind !== 'crit' && n.t < .5); if (m) { m.val += amt; m.txt = fmtDmg(m.val); m.t = Math.min(m.t, .08); m.big = Math.min(1.1, Math.max(m.big, big || 0) + .07); return m; } }
    let live = 0; for (const n of nums) if (n.dm) live++;
    while (live >= DMG_MAX) { let i = nums.findIndex(n => n.dm && n.kind !== 'crit'); if (i < 0) i = nums.findIndex(n => n.dm); if (i < 0) break; nums.splice(i, 1); live--; }
    const n = this.num(x, y, fmtDmg(amt), kind, big); n.dm = 1; n.key = key; n.val = amt; return n; },
  hit(x, y, col, crit) { burst(x, y, col, crit ? 30 : 14, crit ? 320 : 220, { a: 0, spread: 2.2 }); burst(x, y, '#ffffff', crit ? 8 : 4, 200, { a: 0, spread: 1.6, life: .2 }); rings.push({ x, y, t: 0, col, big: crit }); },
  hurt(x, y) { burst(x, y, '#ff5a5a', 10, 180, { a: Math.PI, spread: 1.8 }); },
  block(x, y) { burst(x, y, '#cfe6ff', 10, 200, { a: 0, spread: 1.4 }); rings.push({ x, y, t: 0, col: '#9ad0ff' }); },
  ring(x, y, col, big, flat) { rings.push({ x, y, t: 0, col, big, flat }); },
  burst(x, y, col, n, spd, opt) { burst(x, y, col, n, spd, opt); },
  spark(x, y, col) { addPart({ tp: 'mote', x, y, vx: (rnd() - .5) * 20, vy: -20 - rnd() * 20, life: .5, t: 0, s: 1.2, col, d: 1, add: 1 }); },
  kill(e) {
    const { GY } = W_, v = e.vis, ex = e.x, ey = GY - 60 * (e.scale || 1);
    const pal = v.C ? [v.m.d, v.m.l, v.m.rim || v.m.eye] : [v.skin.armD || v.skin.robe, v.skin.armL || v.skin.trim, v.skin.trim];
    const n = quality === 'high' ? 14 : 7; for (let i = 0; i < n; i++) frags.push({ x: ex + (rnd() - .5) * 40, y: ey - rnd() * 60, vx: 40 + rnd() * 160, vy: -120 - rnd() * 180, r: rnd() * TAU, vr: (rnd() - .5) * 14, s: 3 + rnd() * 6, col: pal[i % 3], t: 0 });
    if (frags.length > 80) frags.splice(0, frags.length - 80);
    themeBurst(ex, GY, v.C ? (v.m.emit || (v.type === 'wraith' ? 'wisp' : v.type === 'treant' ? 'leaf' : 'spark')) : 'spark', e.boss ? 40 : 18);
    burst(ex, ey, '#ffffff', 12, 260, { life: .3 }); rings.push({ x: ex, y: ey, t: 0, col: T.ambient, big: 1 });
  },
  coins(x, y, n) { for (let i = 0; i < n; i++) coins.push({ x, y, vx: (rnd() - .3) * 160, vy: -160 - rnd() * 140, t: 0, delay: .55 + i * .05, ph: rnd() * TAU }); if (coins.length > 40) coins.splice(0, coins.length - 40); },
  bolt(x, col) { const { GY } = W_, pts = []; let y = -10, xx = (rnd() - .5) * 30; while (y < GY - 20) { pts.push([xx, y]); y += 14 + rnd() * 16; xx += (rnd() - .5) * 18; } pts.push([0, GY - 20]); bolts.push({ x, pts, t: 0, col: col || '#8ff0ff', gy: GY - 20 }); burst(x, GY - 24, col || '#8ff0ff', 10, 160, { up: 40 }); },
  slash(x, y, col) { rings.push({ x, y, t: 0, col, big: 0 }); burst(x, y, col, 10, 200, { a: 0, spread: 1.4 }); },
  thrust(x0, x1, y, col) { beams.push({ x: (x0 + x1) / 2, col, w: 0, t: 0, dur: .25, line: [x0, x1, y] }); burst(x1, y, col, 8, 180, { a: 0, spread: 1 }); },
  whirl(x, y, col) { rings.push({ x, y, t: 0, col, big: 1, flat: 1 }); rings.push({ x: x + 10, y: y - 20, t: -.15, col, big: 1 }); burst(x + 30, y, col, 24, 260); },
  beam(x, col, w, dur, top) { beams.push({ x, col, w: w || 26, t: 0, dur: dur || .5, top: top || 0 }); },
  enemyTop(e) { return enemyTop(e); },
  /* ---- main entry: advance effects and draw one frame ----
     view = { camX, camV, hero, enemies[], projs[], graves[], finishX, t } */
  frame(view, dt, gdt) {
    if (!A || !ctx) return;
    const { W, H, GY } = W_, t = view.t;
    camX = view.camX; camV = view.camV || 0;
    updateFX(dt, gdt);
    ctx.setTransform(MS, 0, 0, MS, 0, 0); ctx.imageSmoothingEnabled = true;
    const sx = (rnd() - .5) * shake, sy = (rnd() - .5) * shake;
    ctx.translate(sx, sy);
    const zm = view.zoom > 1.001 ? view.zoom : 1;        // boss entrance: push in on (zx, zy)
    if (zm > 1) { ctx.translate(view.zx, view.zy); ctx.scale(zm, zm); ctx.translate(-view.zx, -view.zy); }
    if (view.stage) { drawHeroStage(view, t); if (view.hero) drawHero(view.hero, t); if (zm > 1) ctx.setTransform(MS, 0, 0, MS, 0, 0); ctx.drawImage(A.vig.c, 0, 0, W, H); return; }
    ctx.drawImage(A.sky.c, 0, 0, W, H);
    if (A.twinkle.length) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; for (const s of A.twinkle) { const b = .5 + .5 * Math.sin(t * s[3] + s[2]); ctx.fillStyle = rgba('#ffffff', b * .9); ctx.fillRect(s[0], s[1], 1.3, 1.3); if (b > .92) glow(ctx, '#ffffff', s[0] + .6, s[1] + .6, 5, (b - .92) * 8); } ctx.restore(); }
    drawAurora(t);
    let fi = 0; const fogs = A.fogs;
    for (let i = 0; i < A.layers.length; i++) {
      const L = A.layers[i]; if (L.stage === 'fg') continue;
      drawTile(L.c, L.speed, 0); drawLights(L.lights, L.speed, t);
      if (i === 0) drawShafts(t);
      if (fogs[fi] && ((i === 1) || (i === 2 && fi === 1))) { drawTile(fogs[fi].c, fogs[fi].speed, fogs[fi].y, fogs[fi].a * (.85 + Math.sin(t * .4 + fi) * .15)); fi++; }
    }
    while (fi < fogs.length) { drawTile(fogs[fi].c, fogs[fi].speed, fogs[fi].y, fogs[fi].a); fi++; }
    drawHaze();
    drawTile(A.ground.c, 1, 0);
    if (A.gEmit) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; drawTile(A.gEmit.c, 1, 0, (.55 + Math.sin(t * 1.7) * .25) * fxAmt); ctx.restore(); }
    if (T.heat) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createLinearGradient(0, GY - 60, 0, GY + 10); gr.addColorStop(0, 'rgba(255,90,20,0)'); gr.addColorStop(1, rgba('#ff5a1a', .16 * fxAmt)); ctx.fillStyle = gr; ctx.fillRect(0, GY - 60, W, 70); ctx.restore(); }
    drawParts(1);
    if (view.graves) for (const g2 of view.graves) drawGrave(g2.x, g2, t);
    if (view.finishX != null) drawFinish(view.finishX, t);
    if (view.props) for (const p of view.props) drawProp(p, t);
    const es = view.enemies || [];
    for (let i = es.length - 1; i >= 0; i--) drawEnemy(es[i], t, gdt);
    if (view.hero) drawHero(view.hero, t);
    for (const e of es) drawEnemyBars(e);
    if (view.projs) for (const p of view.projs) drawProj(p, t);
    drawFX(t);
    drawParts(0);
    for (const L of A.layers) if (L.stage === 'fg') drawTile(L.c, L.speed, 0, .95);
    drawNums();
    if (T.grade) { ctx.save(); ctx.globalCompositeOperation = T.grade.mode; ctx.fillStyle = rgba(T.grade.col, T.grade.a * 3); ctx.fillRect(-10, -10, W + 20, H + 20); ctx.restore(); }
    if (zm > 1) ctx.setTransform(MS, 0, 0, MS, 0, 0);
    if (quality === 'high') doBloom();
    drawGrain();
    ctx.drawImage(A.vig.c, zm > 1 ? 0 : -sx, zm > 1 ? 0 : -sy, W, H);
  },
  /* ---- painted scene snapshots for menus: renders each theme at w×h into JPEG data URLs, then restores the live world ----
     viewFn(key) may return a view (hero, enemies…) to stage in the shot; otherwise it's the empty landscape. */
  snapshots(keys, w, h, viewFn) {
    const save = { canvas, ctx, W: W_.W, H: W_.H, GY: W_.GY, TW: W_.TW, HX: W_.HX, key: themeKey, MS, b1: bloom1, b2: bloom2 };
    const fx = [parts, nums, frags, coins, rings, bolts, beams].map(a => a.splice(0, a.length));
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    canvas = c; ctx = c.getContext('2d'); MS = 1;
    W_.W = w; W_.H = h; W_.GY = Math.round(h * .77); W_.TW = w * 2; W_.HX = Math.round(w * .3);
    bloom1 = document.createElement('canvas'); bloom1.width = Math.round(w / 6); bloom1.height = Math.round(h / 6); bloom2 = document.createElement('canvas'); bloom2.width = bloom1.width; bloom2.height = bloom1.height;
    const out = {};
    try {
      for (const key of keys) {
        buildTheme(key);
        const v = Object.assign({ camX: 380, camV: 0, hero: null, enemies: [], projs: [], graves: [], finishX: null, t: 6 }, viewFn ? viewFn(key) || {} : {});
        this.frame(v, 0, 0);
        out[key] = c.toDataURL('image/jpeg', .84);
      }
    } finally {
      freeCanvas(c); freeCanvas(bloom1); freeCanvas(bloom2);
      canvas = save.canvas; ctx = save.ctx; MS = save.MS; bloom1 = save.b1; bloom2 = save.b2;
      W_.W = save.W; W_.H = save.H; W_.GY = save.GY; W_.TW = save.TW; W_.HX = save.HX;
      [parts, nums, frags, coins, rings, bolts, beams].forEach((a, i) => { a.length = 0; a.push(...fx[i]); });
      if (save.key) buildTheme(save.key); else { freeAssets(); themeKey = null; }
    }
    return out;
  },
  /* ---- static renders for menus (returns a PNG data URL) ---- */
  portrait(fn, w, h, ox, oy, sc) {
    const k = 2, c = document.createElement('canvas'); c.width = w * k; c.height = h * k; const g = c.getContext('2d');
    g.scale(k, k); g.translate(ox, oy); g.scale(sc, sc); fn(g, time);
    const url = c.toDataURL(); freeCanvas(c); return url;
  },
  drawRig, drawWeapon, drawShield, drawHelm, drawBow, offHand, rigPose, CREATURES, THEMES, glow, vgrad, hgrad, mgrad,
  ringIcon(g, col, gem) { g.lineWidth = 5; g.strokeStyle = mix(col, '#000', .35); g.beginPath(); g.ellipse(0, 6, 14, 9, 0, 0, TAU); g.stroke(); g.lineWidth = 3; g.strokeStyle = col; g.stroke(); g.fillStyle = mix(gem, '#fff', .3); g.beginPath(); g.moveTo(0, -12); g.lineTo(7, -4); g.lineTo(0, 3); g.lineTo(-7, -4); g.closePath(); g.fill(); g.save(); g.globalCompositeOperation = 'lighter'; glow(g, gem, 0, -4, 14, .8); g.restore(); },
  mix, rgba
};
/* QA only: draw the knight at the origin of g in a given state (tools/qa/poses.cjs) */
World.rigDebug = (g, h, t) => { const P = h.victory ? { th: POSE.W.th + .3, ph: POSE.W.ph + .4, lunge: 0, swing: -1, wglow: 1 } : rigPose(h.atk, 'swing', !!h.skin.shield); drawRig(g, h.skin, heroRigP(h, P, t, heroBob(h, t)), t); };
window.World = World; World.mix = mix; World.INK = INK;
})();
