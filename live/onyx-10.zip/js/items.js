/* Onyx Vanguard — items.js
   Item generation, gear stats and hero stat calculation.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* =====================================================================
   RARITY + GEAR LOOKS
   Every item maps to a visual slot of the character rig, so what you equip is what the knight wears.
===================================================================== */
const RARITY = [
  {key:"common",name:"Common",color:"#b4b9c4",mult:1},
  {key:"rare",name:"Rare",color:"#5aa8ff",mult:1.5},
  {key:"epic",name:"Epic",color:"#c08aff",mult:2.2},
  {key:"legendary",name:"Legendary",color:"#ffb347",mult:3.2},
  {key:"mythic",name:"Mythic",color:"#ff4a5a",mult:4.2},
  {key:"ancient",name:"Ancient",color:"#3ff0d0",mult:5.2}
];
/* metal finishes by rarity; set pieces override the glow */
const METAL = [
  {d:"#2c2e36",l:"#9aa0ae",trim:"#a88a5a",glow:"#dfe6f2",steelL:"#e6ebf2",steelD:"#4a4e58"},
  {d:"#1e2a44",l:"#8fb2e8",trim:"#c9d8f0",glow:"#6ab8ff",steelL:"#eef4ff",steelD:"#3a5a88"},
  {d:"#241c36",l:"#b9a3e8",trim:"#d0ab62",glow:"#c9a2ff",steelL:"#f2eaff",steelD:"#4a3a6a"},
  {d:"#17131c",l:"#6a6078",trim:"#f2c14e",glow:"#ffae3c",steelL:"#fff0d8",steelD:"#5a3a1a"},
  {d:"#1c0a0e",l:"#9a3a44",trim:"#ff7a5a",glow:"#ff4a5a",steelL:"#ffe4dc",steelD:"#6a1a1a"},
  {d:"#0c1c1e",l:"#5aa8a4",trim:"#9affea",glow:"#3ff0d0",steelL:"#effffb",steelD:"#1a4a48"}
];
const SET_GLOW = {warden:"#7fe8d8", ember:"#ff7a2a", storm:"#7ee0ff"};
function itemGlow(it){ return it.set ? SET_GLOW[it.set] : METAL[it.r].glow; }
function weaponSpec(it){
  const m = METAL[it.r], nm = it.name;
  let type = "sword", len = 52, rune = 0;
  if(/Longsword/.test(nm)) len = 60; else if(/Bastard Sword/.test(nm)){ type = "greatsword"; len = 72; } else if(/Warblade/.test(nm)){ type = "greatsword"; len = 80; rune = 1; }
  if(nm==="Kingsbane") type = "axe"; else if(nm==="Oathkeeper"){ type = "sword"; len = 64; rune = 1; } else if(nm==="Dawnsplitter"){ type = "greatsword"; len = 82; rune = 1; }
  else if(nm==="Worldrender"){ type = "greatsword"; len = 88; rune = 1; } else if(nm==="Grief of Kings") type = "axe";
  if(it.r===5){ type = "greatsword"; len = 90; rune = 1; }
  if(it.set==="ember" && type==="sword") type = "axe";
  if(it.set==="storm" && type==="sword") type = "mace";
  return {type, len:type==="axe"||type==="mace"?null:len, rune, glow:itemGlow(it), trim:m.trim, steelL:m.steelL, steelD:m.steelD};
}
function shieldSpec(it){
  const m = METAL[it.r], col = [ "#6a5236", "#33609a", "#56388a", "#3a2c40", "#5a1820", "#14504e" ][it.r];      // lighter than the armour so the shield reads as a shield
  const emblem = it.set==="ember" ? "flame" : it.set==="storm" ? "star" : it.set==="warden" ? "cross" : [null,"cross","star","sun","flame","sun"][it.r];
  return {type: it.r===0 || it.r===3 ? "round" : "kite", col, trim:m.trim, emblem};
}
/* The knight's full look, built from gear + cape. Unequipped slots fall back to plain kit. */
let skinPreview = null;     // a skin being tried on from the wardrobe (not owned yet)
function heroSkin(){ const sk = skinFrom(equipped, S.cape), key = skinPreview || S.skin, K = key && SKINS[key];
  if(S.trim==="league" && leagueOf(S.arena.best).min >= LEAGUES[1].min) sk.capeTrim = leagueOf(S.arena.best).color;      // league-coloured cape trim (Silver and up)
  if(K){ Object.assign(sk, K.look); if(K.weaponGlow) sk.weapon = Object.assign({}, sk.weapon, {glow:K.weaponGlow}); }
  return sk; }
/* any knight's look from a gear getter (slot -> item) and a cape key; used for the hero and arena rivals */
function skinFrom(get, capeKey){
  const w = get("weapon"), hm = get("helm"), ar = get("armor"), sh = get("shield"), rg = get("ring");
  const cape = CAPES[capeKey] || CAPES.crimson, am = ar ? METAL[ar.r] : null;
  const sk = { body:"armor", armD: am ? am.d : "#3a3026", armL: am ? am.l : "#8a7a60", trim: am ? am.trim : "#8a6a3a",
    cape:cape.c, capeD:cape.d, capeTrim: ar && ar.r>=1 ? am.trim : null, tabard: ar && ar.r>=1 ? mixHex(cape.c,"#000000",.25) : null,
    glow: rg ? itemGlow(rg) : "#cfd6e6", spikes: ar && ar.r===3 ? 1 : 0 };
  if(ar && ar.set) sk.trim = SET_GLOW[ar.set];
  // two or more pieces of one set: the whole knight glows in the set's colour
  const cnt = {}; for(const p of [w, hm, ar, sh, rg]) if(p && p.set) cnt[p.set] = (cnt[p.set]||0) + 1;
  const full = Object.keys(cnt).find(k=>cnt[k]>=2); if(full){ sk.glow = SET_GLOW[full]; sk.capeTrim = SET_GLOW[full]; }
  if(hm){ const hmm = METAL[hm.r]; sk.helmD = hmm.d; sk.helmL = hmm.l;
    if(hm.name==="Crown of Ash"){ sk.helm = "crown"; sk.crownCol = "#e8b04a"; sk.gem = "#ff5a3c"; }
    else if(hm.name==="Warden's Gaze"){ sk.helm = "winged"; sk.wingCol = "#fff4d8"; }
    else sk.helm = helmType(hm);
    if(hm.r>=1 && sk.helm==="greathelm") sk.plume = cape.c;
    if(sk.helm==="horned") sk.hornCol = "#e8dcc0";
    if(hm.set) sk.glow = SET_GLOW[hm.set];
  } else { sk.helm = "greathelm"; sk.helmD = "#3a3a40"; sk.helmL = "#7a7a84"; }
  sk.weapon = w ? weaponSpec(w) : {type:"sword", len:46, glow:"#b8c0d0", trim:"#6a5a44", steelL:"#c8ccd4", steelD:"#4a4e58"};
  if(sh) sk.shield = shieldSpec(sh);
  if(rg && rg.r>=3) { sk.acc = "halo"; sk.haloCol = itemGlow(rg); }
  if(ar && ar.r>=4) sk.spikes = 1;
  if(hm && hm.r===5){ sk.crownCol = "#9affea"; sk.gem = "#3ff0d0"; }
  return sk;
}
function helmType(it){ if(it.name==="Crown of Ash" || it.r===5) return "crown"; if(it.name==="Warden's Gaze") return "winged"; return ["greathelm","greathelm","winged","horned","horned"][it.r] || "greathelm"; }
function mixHex(a,b,t){ const h=x=>[1,3,5].map(i=>parseInt(x.slice(i,i+2),16)); const A=h(a),B=h(b); return "#"+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,"0")).join(""); }

/* painted item icons (PNG data URLs), cached by look */
const ICON_CACHE = {};
function itemIcon(it){
  if(!it) return "";
  const key = `${it.slot}|${it.r}|${it.set||""}|${it.name}`; if(ICON_CACHE[key]) return ICON_CACHE[key];
  let url;
  if(it.slot==="weapon"){ const sp = weaponSpec(it); url = World.portrait(g=>{ g.rotate(-.78); World.drawWeapon(g, sp, .8, 0, 1); }, 64, 64, 12, 52, .62); }
  else if(it.slot==="shield"){ const sp = shieldSpec(it); url = World.portrait(g=>World.drawShield(g, sp, 1), 64, 64, 32, 30, 1.45); }
  else if(it.slot==="helm"){ const m = METAL[it.r], sk = {helmD:m.d, helmL:m.l, trim:m.trim, glow:itemGlow(it), helm:helmType(it), plume:it.r>=1?"#a31d3a":null, hornCol:"#e8dcc0", crownCol:it.r===5?"#9affea":"#e8b04a", gem:it.r===5?"#3ff0d0":"#ff5a3c", wingCol:"#fff4d8"};
    if(sk.helm==="crown"){ sk.helmD = m.d; } url = World.portrait(g=>World.drawHelm(g, sk, 0, 1, 0, 0), 64, 64, 30, 118, 1.35); }
  else if(it.slot==="armor"){ const m = METAL[it.r], sk = {body:"armor", armD:m.d, armL:m.l, trim:it.set?SET_GLOW[it.set]:m.trim, tabard:it.r>=1?"#6a1022":null, spikes:it.r>=3?1:0, helm:"none"};
    url = World.portrait(g=>{ g.beginPath(); g.rect(-34,-100,70,64); g.clip(); World.drawRig(g, sk, {ld:1, th:1.05, ph:-1, bth:1.1}, 0); }, 64, 64, 31, 101, .98); }
  else { url = World.portrait(g=>World.ringIcon(g, METAL[it.r].trim, itemGlow(it)), 64, 64, 32, 34, 1.3); }
  ICON_CACHE[key] = url; return url;
}
function enemyPortrait(type){
  const key = "e|"+type; if(ICON_CACHE[key]) return ICON_CACHE[key];
  const L = LOOKS[type], v = World.makeVis(L, 7);
  const draw = g=>{ g.scale(-1,1); if(v.C) v.C.draw(g, v, {ld:1, atk:null, t:0, walk:0, walkAmt:0}, 0); else World.drawRig(g, v.skin, {ld:1, th:1.05, ph:-1, bth:1.2}, 0); };
  const h = v.C ? v.C.h : 124, sc = 72 / (h + 26);
  const url = World.portrait(draw, 80, 80, 44, 76, sc);
  ICON_CACHE[key] = url; return url;
}

/* =====================================================================
   ITEMS
===================================================================== */
let LUCK = false;   // Fortune's Favor (map treasure): every item roll takes the better of two
const rarityWeights = il => [Math.max(6,62-il*1.8), 27+Math.min(il,40)*.8, 9+il*.55, 1.6+il*.28, il>=30 ? .4+(il-30)*.06 : 0];
function rollRarity(il, minR=0){
  const w = rarityWeights(il);
  const tot = w.reduce((a,b)=>a+b,0), once = ()=>{ let x = Math.random()*tot; for(let i=0;i<w.length;i++){ if(x<w[i]) return i; x-=w[i]; } return 0; };
  const r = LUCK ? Math.max(once(), once()) : once();
  return Math.min(4, Math.max(r, minR));
}
/* The exact chance of each rarity from a roll (same weights and rules as rollRarity), as fractions that sum to 1.
   Used to show the odds of the Knight's chest before it is bought (App Store guideline 3.1.1). */
function rarityOdds(il, minR=0, luck=LUCK){
  const w = rarityWeights(il), tot = w.reduce((a,b)=>a+b,0); let p = w.map(x=>x/tot);
  if(luck){ let c = 0; p = p.map(x=>{ const lo = c; c += x; return c*c - lo*lo; }); }      // the better of two rolls
  const out = p.map(()=>0); p.forEach((x,r)=>{ out[Math.min(4, Math.max(r, minR))] += x; }); return out;
}
const CHEST_MIN_R = 2, chestIl = () => Math.max(2, maxClearedD()+1);
/* odds as whole-number-friendly text that always adds up to 100% (one decimal; anything possible shows at least 0.1%) */
function chestOdds(){
  const p = rarityOdds(chestIl(), CHEST_MIN_R, false), rows = []; p.forEach((x,r)=>{ if(x>0) rows.push({r, t:Math.max(1, Math.round(x*1000))}); });
  const big = rows.reduce((a,b)=>b.t>a.t?b:a); big.t += 1000 - rows.reduce((a,b)=>a+b.t,0);
  return rows.map(o=>({r:o.r, name:RARITY[o.r].name, pct:(o.t/10).toFixed(1).replace(/\.0$/,"") + "%"}));
}
const NSEC = [0,1,1,2,3,3];
function genItem(il, minR=0, slot=null, forceSet=false){
  slot = slot || pick(SLOTS); let r = rollRarity(il, minR); let set = null;
  if(r<=3 && (forceSet || (r>=2 && Math.random()<.35))){ const c = Object.keys(SETS).filter(k=>SETS[k].slots.includes(slot)); if(c.length){ set = pick(c); r = Math.max(r,1); } }
  const d = SLOT_DEF[slot], stats = d.main(il, RARITY[r].mult);
  const nSec = NSEC[r]; const pool = SECONDARY.filter(s=>!(s.k in stats));
  for(let i=0;i<nSec;i++){ const s = pool.splice(Math.floor(Math.random()*pool.length),1)[0]; stats[s.k] = (stats[s.k]||0) + s.v(r); }
  for(const k in stats) stats[k] = r1(stats[k]);
  const name = itemName(slot, r, set);
  const it = {uid:S.uid++, slot, r, il, upg:0, set, name, stats, sock:Array(SOCKETS[r]).fill(null)};
  if(r>=2) it.perk = pick(PERK_KEYS);          // Epic and better: one build-shaping line
  return it;
}
function itemName(slot, r, set){ const d = SLOT_DEF[slot];
  if(set) return `${SETS[set].name} ${d.bases[Math.min(3,r)]}`; if(r===5) return ANCIENTS[slot].name; if(r===4) return pick(d.mythic); if(r===3) return pick(d.legend);
  return `${["Worn","Fine","Masterwork"][r]} ${d.bases[r]}`; }
/* the premium relic for a slot; only created from an Ancient Sigil */
function genAncient(slot, il){
  const d = SLOT_DEF[slot], stats = d.main(il, RARITY[5].mult), pool = SECONDARY.filter(x=>!(x.k in stats));
  for(let i=0;i<NSEC[5];i++){ const x = pool.splice(Math.floor(Math.random()*pool.length),1)[0]; stats[x.k] = (stats[x.k]||0) + x.v(5); }
  for(const k in stats) stats[k] = r1(stats[k]);
  return {uid:S.uid++, slot, r:5, il, upg:0, set:null, name:ANCIENTS[slot].name, stats, sock:Array(SOCKETS[5]).fill(null), power:ANCIENTS[slot].power};
}
const itemById = uid => S.inv.find(i=>i.uid===uid);
const equipped = slot => S.equip[slot] ? itemById(S.equip[slot]) : null;
const isEquipped = it => S.equip[it.slot]===it.uid;
function itemStats(it){ const m = 1 + .12*(it.upg||0), o={}; for(const k in it.stats) o[k] = it.stats[k]*m; return o; }
function statLine(k,v){ const L = STAT_LABEL[k]; const val = L[0]==="%" ? r1(v) : Math.round(v); return `+${val}${L[0]} ${L[1]}`; }
const forgeCost = it => Math.round(25*Math.pow(it.upg+1,1.35)*(1+it.r*.6)*(it.upg>=10 ? Math.pow(1.35, it.upg-9) : 1));
const salvageValue = it => Math.round(8*(1+it.r*1.8)*(1+it.il*.08)*(1+it.upg*.3));
const salvageDust = it => Math.round(3*(1+it.r*1.6)*(1+it.il*.04));
const transmuteCost = it => Math.round(15*(1+it.r)*(1+it.il*.03));
const hasPower = p => SLOTS.some(s=>{ const it = equipped(s); return it && it.power===p; });
const hasPerk = p => SLOTS.some(s=>{ const it = equipped(s); return it && it.perk===p; });
/* how many pieces of a set are worn right now */
const setWorn = k => SLOTS.reduce((n,s)=>{ const it = equipped(s); return n + (it && it.set===k ? 1 : 0); }, 0);
const FORGE_MAX = 20;   // +1..+10 are the normal ladder; +11..+20 are the endless gold sink (steeper, same +12% a step)
function gearStats(){
  const g = {dmg:0,hp:0,armor:0,block:0,crit:0,aspd:0,dmgPct:0,hpPct:0,armorPct:0,goldPct:0,sets:{}};
  for(const s of SLOTS){ const it = equipped(s); if(!it) continue; const st = itemStats(it);
    for(const k in st) g[k] = (g[k]||0) + st[k]; if(it.set) g.sets[it.set] = (g.sets[it.set]||0)+1;
    for(const rn of it.sock||[]) if(rn && RUNES[rn.t]){ const R = RUNES[rn.t]; g[R.stat] = (g[R.stat]||0) + R.per[rn.lv]; } }
  const n = k => g.sets[k]||0;
  if(n("warden")>=2) g.hpPct += 15; if(n("warden")>=3){ g.armorPct += 25; g.block += 6; }
  if(n("ember")>=2) g.dmgPct += 12; if(n("storm")>=2) g.aspd += 12;
  return g;
}
function giveStarterGear(){
  if(S.starterGiven) return;
  const w = {uid:S.uid++,slot:"weapon",r:0,il:1,upg:0,set:null,name:"Worn Shortsword",stats:{dmg:4}};
  const a = {uid:S.uid++,slot:"armor",r:0,il:1,upg:0,set:null,name:"Worn Gambeson",stats:{armor:4,hp:6}};
  const sh = {uid:S.uid++,slot:"shield",r:0,il:1,upg:0,set:null,name:"Worn Buckler",stats:{armor:2,block:3}};
  S.inv.push(w,a,sh); S.equip.weapon=w.uid; S.equip.armor=a.uid; S.equip.shield=sh.uid; S.starterGiven = true; persist();
}

/* =====================================================================
   HERO STATS
===================================================================== */
/* skills of a type in the build. Review 5: a Core skill counts as one skill of the type it joined when it was picked (R.coreTo),
   so a Core pick is a step toward a synergy instead of a dead end. */
function tagCount(tag, R=run){ if(!R) return 0; let n=0; for(const id in R.cards) if(R.cards[id]>0 && CARD_BY[id] && CARD_BY[id].tag===tag && !CARD_BY[id].evo) n++;
  if(R.coreTo) for(const id in R.coreTo) if(R.coreTo[id]===tag && R.cards[id]>0) n++; return n; }
/* skills of a type, Core skills not counted */
function tagOwn(tag, R=run){ if(!R) return 0; let n=0; for(const id in R.cards) if(R.cards[id]>0 && CARD_BY[id] && CARD_BY[id].tag===tag && !CARD_BY[id].evo) n++; return n; }
/* the type a Core skill picked now would join: the one held most (ties: the one held first); "" while the build has no type yet */
function mainTag(R=run){ if(!R) return ""; let best = "", bn = 0; for(const t of (R.tagSeq||[])){ const n = tagOwn(t, R); if(n > bn){ bn = n; best = t; } } return best; }
const syn = (tag, n, R=run) => tagCount(tag, R) >= n;
/* the alternative synergy III of a tag is active (unlocked at tag mastery I, switched on in the Skills tab) */
const synAlt = t => !!(S.synAlt && S.synAlt[t] && masteryRank(t) >= 1);
const cv = (id, R=run) => { if(!R) return 0; const r = R.cards[id]||0; return r ? CARD_BY[id].v(r, cardMult(id)) : 0; };
function heroStats(R){
  const g = gearStats();
  let maxHp = 100 + S.meta.vit*15 + g.hp, dmg = 10 + S.meta.might*2 + g.dmg, armor = 4 + S.meta.plating*3 + g.armor;
  let crit = 5 + g.crit + (S.meta.precision||0)*.5, critMult = 1.75, aspd = 1 + (g.aspd + (S.meta.swift||0))/100, block = g.block, potions = 2 + S.meta.flasks, potionHeal = 35 + S.meta.alchemy*4;
  let dmgPct = g.dmgPct, hpPct = g.hpPct, goldPct = g.goldPct + (S.meta.fortune||0)*4, armorPct = g.armorPct, synMul = 1, synHpMul = 1;
  if(hasPower("crown")){ potions += 1; potionHeal *= 1.5; }
  if(hasPower("aegis")) block += 10;
  if(R){
    dmgPct += cv("edge",R); aspd *= 1 + cv("tempest",R)/100; if(syn("blade",2,R)) aspd *= 1.1;
    armor += cv("ironskin",R); if(syn("shield",2,R)){ armor += 10; block += 8; }
    block += cv("bulwark",R); crit += cv("keen",R); hpPct += cv("vigor",R); goldPct += cv("greed",R);
    potionHeal *= 1 + cv("flask",R)/100; if(syn("blade",3,R) && !synAlt("blade")) critMult += .5;
    // synergy payoffs: every tag at 2 and at 3 cards pays in damage and health; a build of two tags or fewer is Focused
    let synDmg = 0, synHp = 0; const sn = synState(R);
    for(const t of SYN_TAGS){ const n = sn.n[t]; if(n>=2){ synDmg += SYN_PAY[2].dmg; synHp += SYN_PAY[2].hp; } if(n>=3){ synDmg += SYN_PAY[3].dmg; synHp += SYN_PAY[3].hp; } }
    if(sn.focus) synDmg += FOCUS_DMG;
    synMul = 1 + synDmg/100; synHpMul = 1 + synHp/100;
    const B = R.buffs || {}; if(R.boost && R.boost.might) dmgPct += 20; if(R.resolve){ dmgPct += R.resolve; hpPct += R.resolve; } dmgPct += 20*(B.might||0) + 10*(B.whet||0); aspd *= 1 + .15*(B.swift||0); hpPct += 25*(B.vigor||0); crit += 8*(B.keen||0); armor += 12*(B.ward||0); goldPct += 40*(B.fortune||0);
  }
  armor *= 1 + armorPct/100;
  if(R && R.mods && R.mods.fragile) hpPct -= 40;
  return { maxHp:Math.round(maxHp*(1+hpPct/100)*synHpMul), dmg:dmg*(1+dmgPct/100)*synMul, armor:Math.round(armor), crit:Math.min(crit,80), critMult,
    atkInterval:.95/aspd, block:Math.min(block,60), potions, potionHeal, goldPct, sets:g.sets };
}
/* synergy state of a run: cards per tag, and whether the build is Focused (two tags or fewer, at least two synergy cards) */
function synState(R){ const n = {}; let tags = 0, cards = 0; for(const t of SYN_TAGS){ n[t] = tagCount(t, R); if(n[t]){ tags++; cards += n[t]; } } return {n, tags, focus:tags>=1 && tags<=2 && cards>=2}; }
/* POWER — one formula used everywhere (recommended power, upgrade arrows, Equip best, the Arena):
   the geometric mean of what the knight deals per second and what he can take, so attack speed, crit damage,
   block, armor and potions all count. */
function powerOf(st){
  const dps = st.dmg*(1 + st.crit/100*(st.critMult-1))/st.atkInterval;
  const red = st.armor/(st.armor+60), ehp = st.maxHp*(1 + st.potions*st.potionHeal/100*.5)/(1-red)/(1-Math.min(st.block,60)/100);
  return Math.round(POWER_K*Math.sqrt(dps*ehp));
}
const POWER_K = 1.75;
/* what a level asks for: follows the enemy curve (their health sets the damage you need, their damage the health you need) */
/* Review 3: past Act I the number climbs faster than the raw curve (POWER_LATE). Measured with bot players who pick cards at random:
   a knight at the recommended power wins about three battles in four on every act, so a green number can be trusted. */
function suggestedPower(d){ const s1 = enemyScaling(1), raw = x => { const sc = enemyScaling(x); return POWER_BASE*Math.pow(sc.hp*sc.dmg/(s1.hp*s1.dmg), POWER_EXP); };
  const s = raw(d); return Math.round(d > POWER_LATE_FROM ? s*Math.pow(s/raw(POWER_LATE_FROM), POWER_LATE) : s); }
const POWER_BASE = 92, POWER_EXP = .5, POWER_LATE = .30, POWER_LATE_FROM = 5;
/* what a level asks for on a given Oath Tier (tiers multiply enemy health and damage) */
const recPower = (t, d) => Math.round(suggestedPower(d)*Math.sqrt(Math.pow(2.3, t-1)*Math.pow(1.65, t-1)));
const setN = k => (run && run.st.sets[k]) || 0;

/* =====================================================================
   CRAFTING: runes, sockets, transmute, ascend
===================================================================== */
const runeCount = (t, lv) => (S.runes[t] && S.runes[t][lv]) || 0;
function addRune(t, lv, n=1){ if(!S.runes[t]) S.runes[t] = [0,0,0,0,0]; S.runes[t][lv] = Math.max(0, (S.runes[t][lv]||0) + n); }
function addFrags(t, n){ S.frags[t] = (S.frags[t]||0) + n; }
/* n random fragments; returns {type:count} */
function rollFrags(n){ const out = {}; if(typeof runesOpen==="function" && !runesOpen()){ S.orbs += Math.ceil(n/2); return out; } for(let i=0;i<n;i++){ const t = pick(RUNE_KEYS); out[t] = (out[t]||0) + 1; addFrags(t, 1); } return out; }
const fragTotal = () => RUNE_KEYS.reduce((a,t)=>a+(S.frags[t]||0),0);
function forgeRune(t){ if((S.frags[t]||0) < FRAGS_PER_RUNE) return false; S.frags[t] -= FRAGS_PER_RUNE; addRune(t, 0); S.stats.crafted++; return true; }
function mergeRune(t, lv){ if(lv>=4 || runeCount(t,lv) < RUNES_TO_MERGE) return false; addRune(t, lv, -RUNES_TO_MERGE); addRune(t, lv+1); S.stats.crafted++; return true; }
function socketRune(it, idx, t, lv){ if(!it || !it.sock || idx>=it.sock.length || runeCount(t,lv)<=0) return false;
  if(it.sock[idx]) addRune(it.sock[idx].t, it.sock[idx].lv); addRune(t, lv, -1); it.sock[idx] = {t, lv}; return true; }
function unsocket(it, idx){ const rn = it && it.sock && it.sock[idx]; if(!rn) return false; addRune(rn.t, rn.lv); it.sock[idx] = null; return true; }
const runeLine = rn => { const R = RUNES[rn.t], L = STAT_LABEL[R.stat]; return `+${R.per[rn.lv]}${L[0]} ${L[1]}`; };
/* reroll the bonus (secondary) stats, keeping the main ones */
function transmute(it){
  const main = SLOT_DEF[it.slot].main(it.il, RARITY[it.r].mult), n = Object.keys(it.stats).filter(k=>!(k in main)).length;
  const stats = {}; for(const k in main) stats[k] = r1(main[k]);
  const pool = SECONDARY.filter(x=>!(x.k in stats));
  for(let i=0;i<n && pool.length;i++){ const x = pool.splice(Math.floor(Math.random()*pool.length),1)[0]; stats[x.k] = r1((stats[x.k]||0) + x.v(it.r)); }
  it.stats = stats;
}
/* raise rarity by one (Common → Mythic): new main stats, one more bonus stat where the rarity allows, more sockets */
function ascend(it){
  if(it.r>=4) return false; const nr = it.r + 1;
  const main = SLOT_DEF[it.slot].main(it.il, RARITY[nr].mult), oldMain = SLOT_DEF[it.slot].main(it.il, RARITY[it.r].mult);
  const secKeys = Object.keys(it.stats).filter(k=>!(k in oldMain));
  const stats = {}; for(const k in main) stats[k] = r1(main[k]);
  const pool = SECONDARY.filter(x=>!(x.k in stats) && !secKeys.includes(x.k));
  const keys = secKeys.filter(k=>!(k in stats)); while(keys.length < NSEC[nr] && pool.length) keys.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0].k);
  for(const k of keys){ const x = SECONDARY.find(q=>q.k===k); if(x) stats[k] = r1((stats[k]||0) + x.v(nr)); }
  it.stats = stats; it.r = nr; it.name = itemName(it.slot, nr, it.set); if(nr>=2 && !it.perk) it.perk = pick(PERK_KEYS);
  const sock = Array(SOCKETS[nr]).fill(null); (it.sock||[]).forEach((x,i)=>{ if(i<sock.length) sock[i] = x; else if(x) addRune(x.t, x.lv); }); it.sock = sock;
  return true;
}
