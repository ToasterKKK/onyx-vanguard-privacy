/* Onyx Vanguard — modes.js
   Daily quests, the Journey (milestones), the Arena (duels against computer-controlled rival knights)
   and the solo Raid boss. All offline; nothing here pretends to be another player.
   All game scripts share one global scope (classic <script> tags, loaded in order from index.html). */
"use strict";

/* ---------- unlocks ---------- */
const UNLOCK = {
  arena:{test:()=>!!S.cleared["0-2"], how:"Clear Bandit Camp (Act I) to unlock"},
  raid:{test:()=>!!S.cleared["0-4"], how:"Defeat the Outlaw King to unlock"},
  endless:{test:()=>!!S.cleared["0-4"], how:"Defeat the Outlaw King to unlock"},
  challenges:{test:()=>!!S.cleared["0-4"], how:"Defeat the Outlaw King to unlock"},
  keep:{test:()=>!!S.cleared["0-1"], how:"Clear Wolfwood (Act I) to unlock bounties and trials"},
  heat:{test:()=>!!S.cleared["0-4"], how:"Defeat the Outlaw King to unlock"}
};
const isOpen = k => UNLOCK[k].test();
function homeTheme(){ const nx = nextLevel(); return ACTS[nx ? nx.a : LAST_ACT].theme; }

/* ---------- daily reset (tickets, keys, quests) ---------- */
function dailyReset(){
  const k = todayKey(); let ch = false;
  if(S.arena.date!==k){ S.arena.date = k; S.arena.tickets = Math.max(S.arena.tickets, ARENA_TICKETS); S.arena.adTicket = false; ch = true; }
  if(S.raid.date!==k){ S.raid.date = k; S.raid.keys = Math.max(S.raid.keys, RAID_KEYS); S.raid.day = 0; S.raid.goal = false; ch = true; }
  if(S.command.date!==k){ cmdDay(); ch = true; }
  if(S.quests.date!==k){ newQuests(k); ch = true; }
  if(S.bounty.date!==k && isOpen("keep")){ genBounties(k); ch = true; }
  if(S.trials.date!==k && isOpen("keep")){ genTrials(k); ch = true; }
  if(S.weekly.week!==weekKey() || S.weekly.day!==k){ weeklyState(); ch = true; }
  passSeason();
  if(!S.treasury) { S.treasury = Date.now(); ch = true; }
  if(ch) persist();
}

/* =====================================================================
   QUESTS
===================================================================== */
function newQuests(k){
  const rnd = seeded(hashStr("q"+k));
  const pool = QUESTS.filter(q=>!q.unlock || isOpen(q.unlock));
  for(let i=pool.length-1;i>0;i--){ const j = Math.floor(rnd()*(i+1)); [pool[i],pool[j]] = [pool[j],pool[i]]; }
  // two quests that count, two that ask for a choice (as many as are unlocked); always one "win battles" or "defeat enemies"
  // quest so the day is completable by just playing
  const counts = pool.filter(q=>!q.choice), choices = pool.filter(q=>q.choice).slice(0,2), picks = counts.slice(0, 4 - choices.length);
  if(!picks.some(q=>q.id==="kills"||q.id==="wins")) picks[picks.length-1] = QUESTS[0];
  picks.push(...choices);
  S.quests = {date:k, list:picks.map(q=>({id:q.id, start:S.stats[q.key]||0, claimed:false})), bonus:false};
}
const QUEST_BY = Object.fromEntries(QUESTS.map(q=>[q.id,q]));
function questProg(q){ const Q = QUEST_BY[q.id]; return Q ? clamp((S.stats[Q.key]||0) - q.start, 0, Q.need) : 0; }
const questDone = q => QUEST_BY[q.id] && questProg(q) >= QUEST_BY[q.id].need;
function questReward(){ const d = Math.max(1, maxClearedD()); return {gold:Math.round(90 + d*35), orbs:3 + Math.floor(d/4)}; }
const DAILY_BONUS_GEMS = 30;
function journeyState(j){ const v = j.val(); return {v:Math.min(v, j.need), done:v>=j.need, claimed:!!S.journey[j.id]}; }
function questsClaimable(){
  dailyReset();
  let n = S.quests.list.filter(q=>!q.claimed && questDone(q)).length;
  if(!S.quests.bonus && S.quests.list.length && S.quests.list.every(q=>q.claimed)) n++;
  n += JOURNEY.filter(j=>{ const s = journeyState(j); return s.done && !s.claimed; }).length;
  return n;
}
function claimQuest(id){
  const q = S.quests.list.find(x=>x.id===id); if(!q || q.claimed || !questDone(q)) return;
  const rw = questReward(); q.claimed = true; passXP(PASS_XP_FOR.quest); S.gold += rw.gold; S.orbs += rw.orbs; persist();
  SFX.coin(); toast(`Quest complete: +${fmt(rw.gold)} gold, +${rw.orbs} orbs`, "#d0ab62");
}
function claimDailyBonus(){
  if(S.quests.bonus || !S.quests.list.every(q=>q.claimed)) return;
  S.quests.bonus = true; S.gems += DAILY_BONUS_GEMS; const it = genItem(Math.max(2, maxClearedD()+1), 1); S.inv.push(it); persist();
  SFX.win(); haptic("HEAVY"); toast(`Daily chest: +${DAILY_BONUS_GEMS} gems and ${it.name}`, RARITY[it.r].color);
}
function claimJourney(id){
  const j = JOURNEY.find(x=>x.id===id); if(!j) return; const s = journeyState(j); if(!s.done || s.claimed) return;
  S.journey[id] = true; S.gems += j.gems; persist(); SFX.level(); toast(`${j.name}: +${j.gems} gems`, "#ff6a8a");
}

/* =====================================================================
   ARENA — duels against computer-controlled rival knights
===================================================================== */
/* Review 5: the three rivals stand at 90%, 115% and 145% of the knight's strength and every league adds 10% (it was 86/100/116 and
   3.5%, and the Arena could not be lost). Measured: Bronze about 100/100/90% wins; Crown about 100/65/28% for random picks and
   100/85/50% for skilled picks. */
const ARENA_RIVALS = [.90, 1.15, 1.45], ARENA_LEAGUE_STEP = .10;
function genOpps(){
  const t = S.arena.trophies, il = Math.max(1, maxClearedD()+1), capes = Object.keys(CAPES);
  const firsts = RIVAL_NAMES.slice(), titles = RIVAL_TITLES.slice(), draw = (arr, r) => arr.splice(Math.floor(r()*arr.length), 1)[0];   // drawn without replacement: no two rivals share a name or a title
  const lgK = 1 + LEAGUES.indexOf(leagueOf(t))*ARENA_LEAGUE_STEP;     // rivals grow tougher league by league: climbing takes a better build, not only more days
  S.arena.opps = ARENA_RIVALS.map(f=>+(f*lgK).toFixed(3)).map((f,i)=>{
    const seed = (Math.random()*1e9)>>>0, r = seeded(seed);
    const name = `${draw(firsts, r)} ${draw(titles, r)}`;
    const tag = SYN_TAGS[Math.floor(r()*SYN_TAGS.length)], own = CARDS.filter(c=>c.tag===tag && !CARD_NEEDS[c.id]), rest = CARDS.filter(c=>c.tag===tag && CARD_NEEDS[c.id]), other = CARDS.filter(c=>c.tag!==tag && !CARD_NEEDS[c.id]);
    const first = draw(own, r), second = draw(own.length ? own : rest, r);          // an enabler first, so payoff cards (Hemorrhage) never stand alone
    const cards = [first.id, second.id, draw(other, r).id];
    const gear = {};
    for(const sl of SLOTS){ if(sl==="shield" && r()<.25) continue;
      const it = genItem(il, clamp(Math.floor(r()*1.6 + i*.7 + il/9), 0, 3), sl); gear[sl] = {slot:sl, r:it.r, set:it.set, name:it.name}; }
    return {name, f, seed, gear, tag, cards, cape:capes[Math.floor(r()*capes.length)], trophies:Math.max(0, Math.round(t + (f-1)*260 + (r()-.5)*60)), win:[14,24,48][i], lose:[15,11,8][i]};
  });
  persist();
}
function arenaOpps(){ if(S.arena.opps.length!==3 || S.arena.opps.some(o=>!o.cards)) genOpps(); return S.arena.opps; }
const oppPower = o => Math.round(powerOf(heroStats(null))*o.f);
/* The rival's numbers come from your own build so every duel is a fair, readable fight: easy, even, hard. */
function mkRival(o, x){
  const st = heroStats(null), red = st.armor/(st.armor+60);
  const heroDps = st.dmg*(1 + st.crit/100*(st.critMult-1))/st.atkInterval*1.35;
  const hp = heroDps*21*o.f, atk = 1.05, dmg = st.maxHp*1.6/(1-red)/(21/o.f)*atk;
  const look = {kind:"rig", w:7, skin:skinFrom(sl=>o.gear[sl]||null, o.cape)};
  const T = {name:o.name, hp, dmg, atk, spd:0, xp:0, gold:0, boss:true, scale:1, trait:"Rival knight"};
  const e = mkEnemy("rival", x, 1, {T, look, hp, dmg}); e.blockPct = o.gear.shield ? 10 : 4; e.rival = true; e.move = o.tag; e.mt = 4;
  return e;
}
const KNIGHT_CACHE = {};
function knightPortrait(o){
  if(KNIGHT_CACHE[o.seed]) return KNIGHT_CACHE[o.seed];
  const skin = skinFrom(sl=>o.gear[sl]||null, o.cape);
  const url = World.portrait(g=>{ g.scale(-1,1); World.drawRig(g, skin, {ld:1, th:1.05, ph:-1, bth:1.2}, 0); }, 80, 80, 44, 76, 72/150);
  const keys = Object.keys(KNIGHT_CACHE); if(keys.length>12) delete KNIGHT_CACHE[keys[0]];
  return KNIGHT_CACHE[o.seed] = url;
}
function arenaBoard(){
  const me = S.arena.trophies, base = Math.max(300, S.arena.best);
  const list = RIVAL_NAMES.map((n,i)=>{ const h = hashStr("arena"+n); return {name:`${n} ${RIVAL_TITLES[h%RIVAL_TITLES.length]}`, t:Math.round(base*(.35 + (h%1000)/1000*1.05))}; });
  list.push({name:"You", t:me, you:true});
  return list.sort((a,b)=>b.t-a.t);
}
function openArena(){
  if(!isOpen("arena")){ toast(UNLOCK.arena.how); return; }
  dailyReset();
  const A = S.arena, L = leagueOf(A.trophies), nextL = LEAGUES.find(l=>l.min>A.trophies), myP = powerOf(heroStats(null));
  const opps = arenaOpps().map((o,i)=>{ const p = oppPower(o), M = RIVAL_MOVE[o.tag];
    return `<div class="opp"><img src="${knightPortrait(o)}" alt=""><div class="grow"><div class="lt">${o.name}</div>
      <div class="ld">${art("trophy",14)} ${o.trophies} · Power <b style="color:${p<=myP*.95?'var(--green)':p<=myP*1.05?'var(--gold-l)':'var(--red)'}">${p}</b> · <span class="up-g">+${o.win}</span> / <span class="dn-r">−${o.lose}</span></div>
      <div class="opp-cards">${o.cards.map(id=>`<button class="oc" style="--tc:${TAGS[CARD_BY[id].tag].color}" data-act="oppCard" data-id="${id}" aria-label="${CARD_BY[id].name}">${art(CARD_BY[id].icon,26)}</button>`).join("")}<span style="color:${TAGS[o.tag].color}">${tagIco(o.tag,13)} uses ${M.name}</span></div></div>
      <button class="btn sm gold" data-act="duel" data-i="${i}" ${A.tickets<=0?'disabled':''}>${art("energy",16)} Fight</button></div>`; }).join("");
  const chest = arenaChest(), cr = arenaChestReady();
  const board = arenaBoard(), myRank = board.findIndex(r=>r.you)+1, top = boardAround(board.map(r=>Object.assign({}, r, {v:r.t})), 5);
  const html = `<div class="mode-head banner" style="background-image:url(img/banner_arena.jpg)">${art("arena",64)}<div><div class="modal-title">The Arena</div><div class="modal-sub">Duel rival knights one on one. You start each duel with three skills. Rivals are computer-controlled: each shows the skills he favours and uses one ability, always with a warning.</div></div></div>
    <div class="arena-cols"><div>
      <div class="league" style="--lc:${L.color}">${art("trophy",44)}<div class="grow"><div class="ln">${L.name} league</div><div class="lt2">${A.trophies} trophies${nextL?` · ${nextL.min-A.trophies} to ${nextL.name}`:''}</div>
        <div class="bar thin"><i style="width:${nextL?clamp((A.trophies-L.min)/(nextL.min-L.min),0,1)*100:100}%;background:${L.color}"></i></div></div></div>
      <div class="tickets">${Array.from({length:ARENA_TICKETS},(_,k)=>`<span class="${k<A.tickets?'':'off'}">${art("energy",20)}</span>`).join("")}<span class="grow mute">${A.tickets}/${ARENA_TICKETS} tickets · refill at midnight</span></div>
      ${A.tickets<=0 && !A.adTicket && adsLeft()>0 ? `<button class="btn sm teal wide" data-act="adTicket">${adFree()?'':ico("video",16)} Get 1 more ticket</button>` : ""}
      <div class="wk-chest ${cr?'ready':''}">${art("knightchest",40)}<div class="grow"><b>${L.name} league chest</b><small>${S.stats.duels ? (cr ? "This week's chest is ready." : `Claimed. A new one on Monday.`) : "Fight a duel to earn this week's chest."}</small>${rchips(chest, 18, 'sm')}</div><button class="btn sm ${cr?'gold glow':''}" data-act="arenaChest" ${cr?'':'disabled'}>${cr?'Claim':ico("check",14)}</button></div>
      <div class="h2">Rival knights <small>you are #${myRank}</small>${GameCenter.player?`<button class="linkbtn" data-act="gcBoard" data-lb="arena">${art("trophy",14)} Game Center</button>`:""}</div>
      <div class="stat-lines board"><div class="bh">Rival knights of the realm (computer-controlled)</div>${top.map(r=>`<div class="${r.you?'you':''}"><span>${r.rank}. ${r.you ? knightName() : r.name}</span><span>${art("trophy",14)} ${r.t}</span></div>`).join("")}</div>
      <div class="mute" style="font-size:12px;margin-top:6px">Reach Silver to wear your league's colour as a cape trim (Hero → Style).</div>
    </div><div>
      <div class="h2" style="margin-top:0">Choose an opponent <button class="linkbtn" data-act="reOpps">${ico("dice",14)} New rivals</button></div>
      ${opps}
    </div></div>`;
  closeAllModals(); openModal(html, {wide:true});
}
function startDuel(i){
  const o = S.arena.opps[i]; if(!o || S.arena.tickets<=0) return;
  S.arena.tickets--; persist(); closeAllModals(); startRun({mode:"arena", opp:o});
}

/* =====================================================================
   RAID — one huge boss, HP carries over between attempts
===================================================================== */
function mkRaidBoss(x){
  const rb = raidBoss(), T = ENEMY[rb.type], max = raidMaxHp(S.raid.tier), left = Math.max(1, max - S.raid.dmg);
  const dmg = T.dmg * enemyScaling(Math.max(3, maxClearedD())).dmg * (1 + .12*S.raid.tier);
  const e = mkEnemy(rb.type, x, 1, {hp:left, dmg}); e.maxHp = max; e.hp = left; e.raid = true;
  return e;
}
function openRaid(){
  if(!isOpen("raid")){ toast(UNLOCK.raid.how); return; }
  dailyReset();
  const R_ = S.raid, rb = raidBoss(), max = raidMaxHp(R_.tier), left = max - R_.dmg, goal = raidGoal(), gp = clamp((R_.day||0)/goal, 0, 1);
  const html = `<div class="mode-head banner tall" style="background-image:url(img/foe_${rb.type}.jpg)">${art("raid",54)}<div><div class="modal-title">${rb.name}</div><div class="modal-sub">Tier ${R_.tier+1} raid boss. ${rb.text}</div></div></div>
    <div class="modal-body">
    <div class="raid-top">
      <div class="grow">
      <div class="raid-hp"><div class="bb"><i style="width:${left/max*100}%"></i></div><span>${fmt(left)} / ${fmt(max)} HP</span></div>
      <div class="tickets" style="margin-top:8px">${Array.from({length:RAID_KEYS},(_,k)=>`<span class="${k<R_.keys?'':'off'}">${art("key",22)}</span>`).join("")}<span class="grow mute">${R_.keys}/${RAID_KEYS} keys today</span></div></div></div>
    <div class="raid-goal ${R_.goal?'done':gp>=1?'ready':''}">${art("knightchest",36)}<div class="grow"><b>Today's goal: deal ${fmt(goal)} damage</b><div class="pbar thin ${gp>=1?'pdone':''}"><i style="width:${gp*100}%"></i><span>${fmt(Math.min(R_.day||0, goal))} / ${fmt(goal)}</span></div></div>${R_.goal ? `<span class="done-badge sm">${ico("check",16)}</span>` : gp>=1 ? `<button class="btn sm gold glow" data-act="raidChest">Open chest</button>` : `<span class="mute" style="font-size:12px">Bonus chest</span>`}</div>
    <div class="set-box">Each attempt lasts ${RAID_TIME} seconds and starts with three skills. Every point of damage stays on the boss. Rewards: gold and orbs for the damage you deal; defeating it pays <b>40 gems</b> and an Epic item, then a stronger boss arrives.${R_.best?`<br>Your best hit: <b>${fmt(R_.best)}</b> damage in one attempt.`:''}</div>
    </div>
    <div class="mbtns row"><button class="btn gold big" data-act="raidGo" ${R_.keys<=0?'disabled':''}>${art("key",22)} ${R_.keys>0?'Attack':'No keys left today'}</button></div>`;
  closeAllModals(); openModal(html, {wide:true});
}
function startRaid(){
  if(S.raid.keys<=0) return; S.raid.keys--; persist(); closeAllModals(); startRun({mode:"raid"});
}

/* ---------- end of an arena duel or raid attempt ---------- */
function modeEnd(R, won){
  let html = "";
  if(R.mode==="arena"){
    const o = R.cfg.opp, A = S.arena, before = leagueOf(A.trophies);
    const dt = won ? o.win : -Math.min(o.lose, A.trophies);
    A.trophies += dt; A.best = Math.max(A.best, A.trophies); S.stats.duels++; passXP(PASS_XP_FOR.duel); if(won){ S.stats.duelWins++; S.stats.wins++; }
    const gold = won ? 60 + R.d*14 : 15 + R.d*3; S.gold += gold;
    const after = leagueOf(A.trophies); genOpps(); persist();
    if(won){ SFX.win(); haptic("HEAVY"); } else SFX.lose();
    html = `<div class="modal-title big ${won?'':'red'}">${won?'Victory':'Defeated'}</div><div class="modal-sub">${won?`${o.name} yields.`:`${o.name} stands over you.`}</div>
      <div class="reward-row">${rewardTile(art("trophy",32), (dt>=0?'+':'')+dt, "Trophies")}${rewardTile(CUR.gold, fmt(gold), "Gold")}</div>
      ${after!==before?`<div class="unlock">${ico("star",14)} ${after.min>before.min?'Promoted to':'Dropped to'} the ${after.name} league</div>`:''}
      <div class="mbtns row"><button class="btn gold" data-act="claim">Continue</button></div>`;
  } else if(R.mode==="rush"){
    const n = R.rushN||0, U = S.rush, wk = weekKey(); if(U.week!==wk){ U.week = wk; U.chest = false; }
    const record = n > (U.best||0); U.best = Math.max(U.best||0, n);
    const gold = R.gold + n*(60 + R.d*10), orbs = n*4; S.gold += gold; S.orbs += orbs; passXP(PASS_XP_FOR.raid);
    let extra = ""; if(n>=RUSH_CHEST && !U.chest){ U.chest = true; extra = grantBundle({gems:25, star:1}); }
    persist(); if(n) { SFX.win(); haptic("HEAVY"); } else SFX.lose();
    html = `<div class="modal-title big ${n?'':'red'}">${won ? "The ladder is cleared" : n ? "Rush over" : "You have fallen"}</div><div class="modal-sub">${n} boss${n===1?"":"es"} brought down${record && n ? " · a new record!" : ` · your best: ${U.best}`}</div>
      <div class="reward-row">${rewardTile(art("skull",32), n, "Bosses")}${rewardTile(CUR.gold, fmt(gold), "Gold")}${rewardTile(CUR.orbs, orbs, "Orbs")}${extra}</div>
      ${extra ? `<div class="unlock">${ico("star",14)} Weekend chest: ${RUSH_CHEST} bosses in one run</div>` : ""}
      <div class="mbtns row"><button class="btn gold" data-act="claim">Continue</button></div>`;
  } else if(R.mode==="weekly"){
    const n = R.rungN||0, U = weeklyState(), record = n > U.best; U.best = Math.max(U.best, n); U.runs = (U.runs||0) + 1;
    const gold = R.gold + n*(25 + Math.round(maxClearedD()*4)), orbs = n*2; S.gold += gold; S.orbs += orbs; if(n>=3){ S.stats.trials++; passXP(PASS_XP_FOR.trial); }
    let extra = ""; const hit = [];
    for(const [at, b] of WEEKLY.goals) if(n>=at && !U.got.includes(at)){ U.got.push(at); extra += grantBundle(b); hit.push(at); }
    persist(); if(n){ SFX.win(); haptic("HEAVY"); } else SFX.lose();
    html = `<div class="modal-title big ${n?'':'red'}">${won ? "The ladder is cleared" : n ? "Trial over" : "You have fallen"}</div><div class="modal-sub">${n} rung${n===1?"":"s"} climbed${record && n ? " · your best this week!" : ` · your best this week: ${U.best}`}${R.tire ? " · the knight tired" : ""}</div>
      <div class="reward-row">${rewardTile(art("trial",32), n, n===1?"Rung":"Rungs")}${rewardTile(CUR.gold, fmt(gold), "Gold")}${rewardTile(CUR.orbs, orbs, "Orbs")}${extra}</div>
      ${hit.map(at=>`<div class="unlock">${ico("star",14)} Weekly goal reached: rung ${at}</div>`).join("")}
      <div class="mbtns row"><button class="btn gold" data-act="claim">Continue</button></div>`;
  } else {
    const dealt = Math.round(R.raidDmg), R_ = S.raid, max = raidMaxHp(R_.tier), killed = won && R_.dmg + dealt >= max - 1;
    R_.best = Math.max(R_.best, dealt); R_.day = (R_.day||0) + dealt; S.stats.raids++; passXP(PASS_XP_FOR.raid); if(killed || dealt>1500){ rollFrags(2 + R_.tier); }
    const gold = Math.round(40 + dealt/8), orbs = 2 + Math.floor(dealt/600);
    S.gold += gold; S.orbs += orbs;
    let extra = "", item = null;
    if(killed){ R_.tier++; R_.dmg = 0; S.gems += 40; addShards(3); item = genItem(Math.max(3, maxClearedD()+2), 2); S.inv.push(item); extra = rewardTile(CUR.gems, 40, "Gems") + itemTile(item); }
    else R_.dmg = Math.min(max-1, R_.dmg + dealt);
    persist(); if(killed){ SFX.win(); haptic("HEAVY"); } else SFX.level();
    const left = killed ? 0 : max - R_.dmg;
    html = `<div class="modal-title big">${killed?'Boss defeated':'Attempt over'}</div><div class="modal-sub">You dealt <b style="color:var(--gold-l)">${fmt(dealt)}</b> damage${killed?`. A stronger raid boss has arrived.`:` to ${raidBoss().name}.`}</div>
      ${killed?'':`<div class="raid-hp" style="margin:0 20px"><div class="bb"><i style="width:${left/max*100}%"></i></div><span>${fmt(left)} HP left</span></div>`}
      <div class="reward-row">${rewardTile(CUR.gold, fmt(gold), "Gold")}${rewardTile(CUR.orbs, orbs, "Orbs")}${extra}</div>
      <div class="mbtns row"><button class="btn gold" data-act="claim">Continue</button></div>`;
  }
  R.rewards = {gold:0, orbs:0}; R.pendingDefeatRewards = false;
  setTimeout(()=>{ if(run===R) R.resultModal = openModal(html, {noClose:true, center:true}); }, 1000);
}

/* =====================================================================
   OATH TIERS — the whole map again, harder, forever
===================================================================== */
const isClearedT = (t, a, i) => t===1 ? !!S.cleared[`${a}-${i}`] : !!S.oath.cl[`${t}:${a}-${i}`];
function setClearedT(t, a, i){ if(t===1) S.cleared[`${a}-${i}`] = true; else S.oath.cl[`${t}:${a}-${i}`] = true; }
const actUnlockedT = (t, a) => a===0 || isClearedT(t, a-1, 4);
const levelUnlockedT = (t, a, i) => t<=S.oath.max && actUnlockedT(t, a) && (i===0 || isClearedT(t, a, i-1));
function nextLevelT(t){ for(let a=0;a<ACTS.length;a++) for(let i=0;i<5;i++) if(!isClearedT(t,a,i)) return levelUnlockedT(t,a,i) ? {a,i} : null; return null; }
const threatOf = (t, a, i) => (t-1)*ACTS.length*5 + a*5 + i + 1;

/* =====================================================================
   REWARD BUNDLES (login, pass, treasury, bounties, trials)
===================================================================== */
/* applies a bundle to the save and returns reward tiles */
function grantBundle(b){
  let h = "";
  if(b.gold){ S.gold += b.gold; h += rewardTile(CUR.gold, fmt(b.gold), "Gold"); }
  if(b.orbs){ S.orbs += b.orbs; h += rewardTile(CUR.orbs, b.orbs, "Orbs"); }
  if(b.gems){ S.gems += b.gems; h += rewardTile(CUR.gems, b.gems, "Gems"); }
  if(b.dust){ S.dust += b.dust; h += rewardTile(art("dust",32), b.dust, "Arcane Dust"); }
  if(b.star){ S.star += b.star; h += rewardTile(art("starmetal",32), b.star, "Starmetal"); }
  if(b.frags){ rollFrags(b.frags); h += rewardTile(art("frag",32), b.frags, b.frags===1 ? "Rune fragment" : "Rune fragments"); }
  if(b.sigil){ S.sigils += b.sigil; h += rewardTile(art("sigil",32), b.sigil, "Ancient Sigil"); }
  if(b.cape && CAPES[b.cape]){ if(!S.capes.includes(b.cape)) S.capes.push(b.cape); h += rewardTile(`<span class="cape-sw big" style="background:linear-gradient(${CAPES[b.cape].c},${CAPES[b.cape].d})"></span>`, "Cape", CAPES[b.cape].name); }
  if(b.weapon){ const it = genItem(Math.max(4, maxClearedD()+2), 3, "weapon"); it.name = "Oathkeeper"; S.inv.push(it); h += itemTile(it); }
  if(b.item){ S.inv.push(b.item); h += itemTile(b.item); }
  persist(); return h;
}
const scaleBy = () => 1 + maxClearedD()/12;

/* =====================================================================
   BOUNTIES — named champions with traits
===================================================================== */
function genBounties(k){
  const rnd = seeded(hashStr("b"+k)), f = Math.max(2, maxClearedD()), acts = ACTS.map((_,a)=>a).filter(a=>a===0 || S.cleared[`${a-1}-4`] || S.oath.max>1);
  const used = [[], []], draw = (pool, k) => { let n = Math.floor(rnd()*pool.length); while(used[k].includes(n)) n = (n + 1) % pool.length; used[k].push(n); return pool[n]; };      // no two champions of a day share a name
  const list = [1,2,3].map(stars=>{
    const act = acts[Math.floor(rnd()*acts.length)], pool = ACTS[act].pool.filter(t=>!ENEMY[t].big), type = pool[Math.floor(rnd()*pool.length)];
    const affs = Object.keys(AFFIXES).sort(()=>rnd()-.5).slice(0, stars);
    const d = Math.max(2, f + stars - 2);
    const reward = {gold:Math.round((80 + d*18)*stars), orbs:8*stars, frags:2 + stars*2, dust:25*stars, star:stars-1 + (S.oath.max>1?1:0), gems:stars===3?15:0};
    return {id:"b"+stars, stars, act, type, d, aff:affs, name:`${draw(CHAMP_FIRST, 0)} ${draw(CHAMP_LAST, 1)}`, reward, mythic:stars===3 && S.oath.max>=2, done:false};
  });
  S.bounty = {date:k, list};
}
function mkChampion(b, x, d){
  const e = mkEnemy(b.type, x, d, {elite:true});
  let hp = e.hp*(1.35 + .2*b.stars); if(b.aff.includes("colossal")) hp *= 1.6;
  e.hp = e.maxHp = hp; e.dmg *= 1.15; e.boss = true; e.v.boss = true; e.aff = b.aff; e.name = e.v.name = b.name;
  if(b.aff.includes("frenzied")) e.atk /= 1.3; if(b.aff.includes("shielded")) e.blockPct = 25;
  e.v.scale *= 1.18; e.hw *= 1.18; e.xp *= 2; e.gold *= 3;
  return e;
}
function startBounty(i){ const b = S.bounty.list[i]; if(!b || b.done) return; closeAllModals(); startRun({mode:"bounty", b}); }

/* =====================================================================
   DAILY TRIALS — cleared levels with twisted rules
===================================================================== */
function genTrials(k){
  const rnd = seeded(hashStr("t"+k)); let t = S.oath.max;
  const cands = t2 => { const c = []; for(let a=0;a<ACTS.length;a++) for(let i=0;i<5;i++) if(isClearedT(t2,a,i)) c.push([a,i]); return c; };
  let c = cands(t); if(!c.length && t>1){ t--; c = cands(t); } if(!c.length) c = [[0,0]];
  const ruleKeys = Object.keys(TRIAL_RULES);
  const list = [1,2,3].map(n=>{
    const [a,i] = c[Math.floor(rnd()*c.length)], rules = ruleKeys.slice().sort(()=>rnd()-.5).slice(0,n), mods = {};
    for(const r of rules) mods[r] = r==="oneTag" ? SYN_TAGS[Math.floor(rnd()*SYN_TAGS.length)] : true;
    const d = Math.max(threatOf(t,a,i), maxClearedD() - 2 + n);
    const reward = {frags:2 + 3*n, dust:35*n, orbs:4*n, star:n-1 + (t>1?1:0), gems:n===3?20:0};
    return {id:"t"+n, n, a, i, tier:t, d, rules, mods, reward, done:false};
  });
  S.trials = {date:k, list};
}
function startTrial(i){ const tr = S.trials.list[i]; if(!tr || tr.done) return; closeAllModals();
  startRun({mode:"trial", a:tr.a, i:tr.i, tier:tr.tier, d:tr.d, mods:Object.assign({}, tr.mods), tr, title:`${ACTS[tr.a].levels[tr.i]}`}); }
/* called from victory() for trials and bounties */
function finishSpecial(R, rw){
  const T = R.mode==="trial" ? R.cfg.tr : R.cfg.b, list = R.mode==="trial" ? S.trials.list : S.bounty.list;
  const live = list.find(x=>x.id===T.id); if(live && live.done) return; if(live) live.done = true;
  const b = T.reward; rw.gold += b.gold||0; rw.orbs += b.orbs||0; rw.gems += b.gems||0; rw.dust += b.dust||0; rw.star += b.star||0;
  if(b.frags){ rollFrags(b.frags); rw.frags += b.frags; }
  if(R.mode==="bounty"){ S.stats.bounties++; passXP(PASS_XP_FOR.bounty); if(T.stars===3) addShards(1); if(T.mythic && Math.random()<.25){ const it = genItem(Math.max(30, R.d+4), 4); S.inv.push(it); rw.extra = itemTile(it); rw.unlocks.push(`Mythic drop: ${it.name}`); } }
  else { S.stats.trials++; passXP(PASS_XP_FOR.trial); }
  rw.unlocks.push(R.mode==="trial" ? "Trial complete" : `Bounty claimed: ${T.name}`);
}

/* =====================================================================
   LOGIN CALENDAR + TREASURY (idle income while away)
===================================================================== */
const loginReady = () => S.login.last !== todayKey() && S.seenIntro && !!S.cleared["0-0"];
/* the first week is a welcome week: day 7 is a Legendary blade, not a chest */
const welcomeWeek = () => !S.login.cycle;
function loginReward(day){ if(welcomeWeek() && day%7===6) return {weapon:1, gems:60};
  const L = LOGIN[day%7], k = scaleBy(), b = {};
  for(const key of ["gold","orbs","dust","frags","gems","star"]) if(L[key]) b[key] = (key==="gold"||key==="dust") ? Math.round(L[key]*k) : L[key];
  return b; }
function claimLogin(){
  if(!loginReady()) return "";
  const grace = streakGrace(); if(grace) S.grace = weekKey();
  S.login.streak = (S.login.last===yesterdayKey() || S.login.fixed || grace) ? S.login.streak+1 : 1; S.login.fixed = false; S.login.graced = grace;
  const b = loginReward(S.login.day); if(S.login.streak>0 && S.login.streak%7===0) b.gems = (b.gems||0) + STREAK_BONUS_GEMS;        // every 7th day in a row pays a streak bonus
  S.login.day = (S.login.day+1)%7; if(S.login.day===0) S.login.cycle = (S.login.cycle||0) + 1; S.login.last = todayKey();
  return grantBundle(b);
}
/* the treasury's cap grows with progress: 4h, then 8h after Act I, 12h after Act II; Vanguard's Favor adds 50% income */
const treasuryCap = () => S.cleared["1-4"] || S.oath.max>1 ? 12 : S.cleared["0-4"] ? 8 : 4;
let TREASURY_CAP_H = 12;
function treasuryState(){
  TREASURY_CAP_H = treasuryCap();
  const hrs = Math.min(TREASURY_CAP_H, Math.max(0, (Date.now() - (S.treasury||Date.now()))/3.6e6)), f = Math.max(1, maxClearedD()), k = favorActive() ? 1.5 : 1;
  return {hrs, cap:TREASURY_CAP_H, full:hrs>=TREASURY_CAP_H, gold:Math.floor(hrs*(40 + 12*f)*k), dust:Math.floor(hrs*(3 + f/4)*k), frags:runesOpen() ? Math.floor(hrs/3) : 0};
}
function claimTreasury(){ const T = treasuryState(); if(T.hrs < 1/12) return ""; S.treasury = Date.now(); return grantBundle({gold:T.gold, dust:T.dust, frags:T.frags}); }

/* =====================================================================
   OATH PASS — a 28-day season track with a free and a premium lane
===================================================================== */
function passSeason(){
  if(!S.pass.start){ S.pass.start = Date.now(); }
  const season = Math.floor((Date.now() - S.pass.start)/(PASS_DAYS*864e5));
  if(season !== S.pass.season){ S.pass.season = season; S.pass.xp = 0; S.pass.cf = []; S.pass.cp = []; S.pass.prem = false; }
}
const passLevel = () => Math.min(PASS_LEVELS, Math.floor(S.pass.xp/PASS_XP));
const passDaysLeft = () => Math.max(0, Math.ceil((S.pass.start + (S.pass.season+1)*PASS_DAYS*864e5 - Date.now())/864e5));
function passXP(n){ if(!n) return; passSeason(); S.pass.xp = Math.min(PASS_LEVELS*PASS_XP, S.pass.xp + n); }
/* Endless Descent pays pass points up to ENDLESS.passDay a day */
function passXPEndless(n){ if(!(n>0)) return; const k = todayKey(); if(S.pass.endDay!==k){ S.pass.endDay = k; S.pass.endXp = 0; }
  const give = Math.max(0, Math.min(n, ENDLESS.passDay - (S.pass.endXp||0))); S.pass.endXp = (S.pass.endXp||0) + give; passXP(give); }
function claimPass(lv, prem){
  if(lv>passLevel()) return ""; const arr = prem ? S.pass.cp : S.pass.cf; if(arr.includes(lv) || (prem && !S.pass.prem)) return "";
  arr.push(lv); return grantBundle(passReward(lv, prem));
}
const passClaimable = () => { const L = passLevel(); let n = 0; for(let lv=1; lv<=L; lv++){ if(!S.pass.cf.includes(lv)) n++; if(S.pass.prem && !S.pass.cp.includes(lv)) n++; } return n; };

/* =====================================================================
   ANCIENT RELICS — claimed with Ancient Sigils (premium)
===================================================================== */
const ownsAncient = slot => S.inv.some(it=>it.r===5 && it.slot===slot);
function claimAncient(slot){ if(S.sigils<=0 || !ANCIENTS[slot] || ownsAncient(slot)) return null; S.sigils--; const it = genAncient(slot, Math.max(12, maxClearedD() + 4)); S.inv.push(it); persist(); return it; }

/* =====================================================================
   REVIEW PASS: unlock pacing, sinks, favor, shards, one-time offers
===================================================================== */
/* runes (fragments, forging, sockets) open after Act II so a new player sees four currencies, not nine */
const runesOpen = () => !!S.cleared["1-4"] || S.oath.max>1;
/* Vanguard's Favor: monthly subscription (RevenueCat entitlement "favor"; in browser test mode it lasts 30 days) */
const favorActive = () => !!(S.favor.active || S.favor.until > Date.now());
const adFree = () => S.removeAds || favorActive();
const FAVOR_GEMS = 50;
function claimFavorGems(){ if(!favorActive() || S.favor.gemsDay===todayKey()) return false; S.favor.gemsDay = todayKey(); S.gems += FAVOR_GEMS; persist(); return true; }
/* Ancient Sigils can be earned slowly: 10 shards (raid kills, 3-star bounties, every 25 Endless waves) make one */
const SHARDS_PER_SIGIL = 10;
function addShards(n){ S.shards = (S.shards||0) + n; let made = 0; while(S.shards >= SHARDS_PER_SIGIL){ S.shards -= SHARDS_PER_SIGIL; S.sigils++; made++; } if(made) setTimeout(()=>toast(`${made} Ancient Sigil forged from shards!`, RARITY[5].color), 600); }
/* gem sinks */
const GEM_SINKS = {
  ticket:{name:"Arena ticket", icon:"energy", price:40, max:3, can:()=>isOpen("arena"), give(){ S.arena.tickets++; }},
  key:{name:"Raid key", icon:"key", price:80, max:2, can:()=>isOpen("raid"), give(){ S.raid.keys++; }},
  haul:{name:"Treasury haul", icon:"treasury", price:60, max:3, can:()=>true, give(){ const f = Math.max(1, maxClearedD()), k = favorActive()?1.5:1; S.gold += Math.floor(4*(40+12*f)*k); S.dust += Math.floor(4*(3+f/4)*k); }},
  passxp:{name:"Oath Pass level", icon:"pass", price:150, max:5, can:()=>passLevel()<PASS_LEVELS, give(){ passXP(PASS_XP); }}
};
function buySink(k){ const G = GEM_SINKS[k]; if(!G || !G.can() || S.gems < G.price) return false; if(S.buys.date!==todayKey()) S.buys = {date:todayKey()};
  if((S.buys[k]||0) >= G.max) return false; S.gems -= G.price; S.buys[k] = (S.buys[k]||0) + 1; G.give(); persist(); return true; }
const sinkLeft = k => GEM_SINKS[k].max - (S.buys.date===todayKey() ? (S.buys[k]||0) : 0);
/* knight skins: cosmetic armour sets bought with gems */
function buySkin(k){ const K = SKINS[k]; if(!K || S.skins.includes(k) || S.gems < K.price) return false; S.gems -= K.price; S.skins.push(k); S.skin = k; persist(); return true; }
/* Moment offers: first boss win and first Arena visit each open a real 48-hour window (TIMED, further down) with
   something the shop never sells; the second loss on a level shows the starter pack once. */
let offerAfter = null;
function offerPopup(why, after){
  const T = TIMED[why];
  if(!T || !Monetization.storeReady() || S.offers[why]){ if(after) after(); return; }
  S.offers[why] = {until:Date.now() + OFFER_HOURS*3.6e6, bought:false}; S.offersSeen[why] = 1; persist(); offerAfter = after || null;
  openModal(`<div class="modal-title">${T.head}</div><div class="modal-sub">${T.sub} <b class="timer">${ico("clock",13)} ${offerLeft(why)} left</b></div><div class="offers solo">${offerCard(T.k, why)}</div>
    <div class="mbtns row"><button class="btn ghost" data-act="offerLater">Not now</button><button class="btn gold" data-act="iap" data-k="${T.k}" data-why="${why}" data-offer="1">${Monetization.price(T.k)}</button></div>`, {noClose:true});
}

/* =====================================================================
   LOCAL NOTIFICATIONS — at most one a day, only after the player says yes
   (treasury full today; tomorrow evening: daily reward, new quests, raid keys)
===================================================================== */
function notifPlugin(){ const P = nativePlugins(); return P.LocalNotifications || (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null; }
function askNotifs(){
  if(S.notif || !isNativeApp() || !notifPlugin()) return;
  openModal(`<div class="modal-title">Get a nudge?</div><div class="confirm-text">We can tell you when your treasury is full and when your daily reward is ready. At most one message a day.</div>
    <div class="mbtns row"><button class="btn" data-act="notifNo">No thanks</button><button class="btn gold" data-act="notifYes">Yes, remind me</button></div>`);
}
async function scheduleNotifs(){
  const N = notifPlugin(); if(!N || S.notif!=="yes") return;
  try{
    const pend = await N.getPending(); if(pend && pend.notifications && pend.notifications.length) await N.cancel({notifications: pend.notifications.map(n=>({id:n.id}))});
    const list = [], now = Date.now(), T = treasuryState(), fullAt = (S.treasury||now) + T.cap*3.6e6;
    const tmr = new Date(); tmr.setDate(tmr.getDate()+1); tmr.setHours(18, 45, 0, 0);
    const endToday = new Date(); endToday.setHours(22, 0, 0, 0);
    if(S.cleared["0-0"] && fullAt > now + 15*60e3 && fullAt < endToday.getTime())
      list.push({id:101, title:"Your treasury is overflowing, Vanguard", body:"The Keep's coffers can hold no more. Come and claim your gold.", schedule:{at:new Date(fullAt)}});
    if(S.cleared["0-0"]) list.push({id:102, title:"The road calls, Vanguard", body:`Your day ${((S.login.day||0)%7)+1} reward waits at the Keep, with new bounties posted${isOpen("raid") ? " and fresh keys for the raid" : ""}.`, schedule:{at:tmr}});
    if(list.length) await N.schedule({notifications:list});
  }catch(e){ console.warn("notifications", e); }
}

/* =====================================================================
   MAP TREASURES — after every battle each kind has its own chance to appear somewhere on the
   explored map (at most 3 at once, gone after 8 hours). Tap to claim: instant loot or a timed boost.
   Boosts run on real time and apply to every battle started while they're active.
===================================================================== */
const BOOSTS = {
  xp:{name:"Battle Fervor", short:"+50% XP", icon:"frenzy", text:"+50% experience in battle: more skill cards", col:"#c9a2ff"},
  luck:{name:"Fortune's Favor", short:"Lucky", icon:"rune_fortune", text:"Better item drops: every item rolls twice and keeps the best", col:"#6ee08a"},
  might:{name:"War Banner", short:"+20% dmg", icon:"might", text:"+20% damage in battle", col:"#ff9a6a"}
};
const TREASURES = {
  gold:{name:"Gold cache", icon:"gold", chance:.30},
  orbs:{name:"Orb cluster", icon:"orbs", chance:.20},
  xp:{name:"Battle Fervor", icon:"frenzy", chance:.14, boost:"xp", mins:20},
  luck:{name:"Fortune's Favor", icon:"rune_fortune", chance:.10, boost:"luck", mins:15},
  might:{name:"War Banner", icon:"might", chance:.10, boost:"might", mins:15},
  frags:{name:"Rune cache", icon:"frag", chance:.08, need:()=>runesOpen()},
  gems:{name:"Gem shard", icon:"gems", chance:.05}
};
const LOOT_MAX = 3, LOOT_TTL = 8*3.6e6; let lootFresh = [];
const boostLeft = k => Math.max(0, ((S.boosts||{})[k]||0) - Date.now());
function activeBoosts(){ const o = {}; for(const k in BOOSTS) if(boostLeft(k)>0) o[k] = 1; return o; }
function lootSpot(){
  const T = S.oath.sel||1, pts = [], marks = MAP_NODES.flat().concat(Object.values(MAP_MARKS).map(m=>[m.x,m.y]));
  const wide = Object.values(MAP_MARKS).map(m=>[m.x, m.y]).concat(MAP_NODES.map(a=>a[4]));     // landmark and boss art is big: keep 70 px clear
  const nx = nextLevelT(T); if(nx){ const n = MAP_NODES[nx.a][nx.i]; wide.push([n[0]-44, n[1]-8]); }   // the knight marker stands left of the next node
  const taken = marks.concat(marks.map(q=>[q[0], q[1]+50]), marks.map(q=>[q[0]-40, q[1]+50]), marks.map(q=>[q[0]+40, q[1]+50]), marks.map(q=>[q[0], q[1]-50])).concat((S.mapLoot||[]).map(l=>[l.x,l.y]));   // nodes, their labels, other loot
  MAP_NODES.forEach((act,a)=>{ if(actUnlockedT(T,a)) act.forEach(p=>pts.push(p)); });
  const nodes = MAP_NODES.flat();                                   // a node button is up to 80 map units wide on a small phone
  for(let k=0;k<160 && pts.length;k++){ const p = pts[Math.floor(Math.random()*pts.length)], ang = Math.random()*Math.PI*2, r = 76 + Math.random()*40;
    const x = Math.round(p[0] + Math.cos(ang)*r), y = Math.round(p[1] + Math.sin(ang)*r*.8);
    if(y<70 || y>MAP_H-50 || x<40 || x>MAP_W-40) continue;
    if(taken.every(q=>Math.hypot(q[0]-x, q[1]-y) > 46) && wide.every(q=>Math.hypot(q[0]-x, q[1]-y) > 72) && nodes.every(q=>Math.hypot(q[0]-x, q[1]-y) > 74)) return [x,y]; }
  return null;
}
function rollMapLoot(R, force){
  if(!S.cleared["0-0"] && !force) return [];
  const now = Date.now(); S.mapLoot = (S.mapLoot||[]).filter(l=>l.exp>now); const made = [], we = weekendEvent(), wk = we && we.id==="treasure" ? 2 : 1;
  const keys = force ? [force] : Object.keys(TREASURES).filter(k=>{ const T = TREASURES[k]; return (!T.need || T.need()) && Math.random() < T.chance*(R && R.result==="victory" ? 1 : .6)*wk; });
  if(!S.lootSeen && !force && !keys.length) keys.push("gold");          // the first time, always leave one to find
  for(const k of keys){ if(S.mapLoot.length>=LOOT_MAX || S.mapLoot.some(l=>l.k===k)) continue; const sp = lootSpot(); if(!sp) break;
    const l = {id:now.toString(36)+Math.floor(Math.random()*1e4), k, x:sp[0], y:sp[1], exp:now + LOOT_TTL}; S.mapLoot.push(l); made.push(l); }
  if(made.length) S.lootSeen = true; lootFresh = made.map(l=>l.id);
  return made;
}
function lootAmount(k){ const f = Math.max(1, maxClearedD());
  return k==="gold" ? {gold:Math.round(80 + 30*f + Math.random()*20*f)} : k==="orbs" ? {orbs:Math.round(3 + f/3 + Math.random()*3)} : k==="gems" ? {gems:5 + Math.floor(Math.random()*11)} : k==="frags" ? {frags:3 + Math.floor(Math.random()*3)} : null; }
function claimMapLoot(id){
  const i = (S.mapLoot||[]).findIndex(l=>l.id===id); if(i<0) return null; const l = S.mapLoot[i], T = TREASURES[l.k]; S.mapLoot.splice(i,1);
  if(l.exp < Date.now()) { persist(); return {expired:true}; }
  if(T.boost){ S.boosts[T.boost] = Math.max(Date.now(), S.boosts[T.boost]||0) + T.mins*60e3; persist(); return {boost:T.boost, mins:T.mins, x:l.x, y:l.y}; }
  const b = lootAmount(l.k); const html = grantBundle(b); persist(); return {bundle:b, html, x:l.x, y:l.y};
}

/* =====================================================================
   GAME CENTER + iCLOUD SAVE — through our own plugin (native/onyx-native). Both stay silent in a browser.
   Leaderboard and achievement IDs must match App Store Connect (RELEASE.md §2b).
===================================================================== */
function onyxNative(){ const P = nativePlugins(); return P.OnyxNative || (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.OnyxNative) || null; }
const GC_LB = {endless:"ov_lb_endless", arena:"ov_lb_arena", power:"ov_lb_power", heat:"ov_lb_heat", rush:"ov_lb_rush", weekly:"ov_lb_weekly"};     // ov_lb_weekly is a recurring leaderboard: it resets every Monday (RELEASE.md)
const GC_ACH = [
  {id:"ov_ach_act1", name:"The Outlaw Throne", text:"Defeat the Outlaw King", icon:"battle", pts:10, test:()=>S.cleared["0-4"]},
  {id:"ov_ach_act2", name:"The Bone Crown", text:"Defeat the Bone Lord", icon:"skull", pts:20, test:()=>S.cleared["1-4"]},
  {id:"ov_ach_act3", name:"Throne of Winter", text:"Defeat the Jarl of Winter", icon:"crown", pts:30, test:()=>S.cleared["2-4"]},
  {id:"ov_ach_act4", name:"The Tyrant's Anvil", text:"Defeat the Forge Tyrant", icon:"might", pts:40, test:()=>S.cleared["3-4"]},
  {id:"ov_ach_act5", name:"Beyond the Stars", text:"Defeat the Void Herald", icon:"sigil", pts:60, test:()=>S.cleared["4-4"]},
  {id:"ov_ach_tier2", name:"Oathsworn", text:"Unlock Oath Tier II", icon:"tier", pts:50, test:()=>S.oath.max>=2},
  {id:"ov_ach_tier3", name:"Oathkeeper", text:"Unlock Oath Tier III", icon:"tier", pts:80, test:()=>S.oath.max>=3},
  {id:"ov_ach_endless25", name:"Into the Deep", text:"Reach wave 25 in the Endless Descent", icon:"endless", pts:30, test:()=>S.endlessBest>=25},
  {id:"ov_ach_endless50", name:"No Bottom", text:"Reach wave 50 in the Endless Descent", icon:"endless", pts:60, test:()=>S.endlessBest>=50},
  {id:"ov_ach_kills", name:"Legend of the Vanguard", text:"Defeat 10,000 enemies", icon:"horde", pts:40, test:()=>S.stats.kills>=10000},
  {id:"ov_ach_mythic", name:"Mythic Find", text:"Own a Mythic item", icon:"mythic", pts:30, test:()=>S.inv.some(i=>i.r>=4)},
  {id:"ov_ach_rune", name:"Runesmith", text:"Merge a rune to rank V", icon:"rune_fury", pts:30, test:()=>RUNE_KEYS.some(t=>runeCount(t,4)>0)},
  {id:"ov_ach_arena", name:"Crowned", text:"Reach the Crown league in the Arena", icon:"arena", pts:50, test:()=>S.arena.best>=2500},
  {id:"ov_ach_raid", name:"Titan Slayer", text:"Bring down a raid boss", icon:"raid", pts:30, test:()=>S.raid.tier>=1},
  {id:"ov_ach_challenges", name:"Spire Master", text:"Complete every challenge", icon:"challenges", pts:40, test:()=>CHALLENGES.every(c=>S.challenges[c.id])}
];
const GameCenter = {
  player:null, ready:false, lastSync:0,
  async init(){ const O = onyxNative(); if(!O) return; this.ready = true;
    try{ const r = await O.gcSignIn(); this.player = r && r.authenticated ? r : null; }catch(e){ this.player = null; }
    if(this.player) this.sync(true); },
  sync(force){ const O = onyxNative(); if(!O || !this.player) return; if(!force && Date.now() - this.lastSync < 20e3) return; this.lastSync = Date.now();
    const sub = (lb, v)=>{ if(v>0) O.gcSubmitScore({id:GC_LB[lb], score:Math.floor(v)}).catch(()=>{}); };
    sub("endless", S.endlessBest); sub("arena", S.arena.best || S.arena.trophies); sub("power", powerOf(heroStats(null))); sub("heat", S.heat.max||0); sub("rush", S.rush.best||0); if(S.weekly.week===weekKey()) sub("weekly", S.weekly.best||0);
    for(const a of GC_ACH){ let ok = false; try{ ok = !!a.test(); }catch(e){} if(ok && !S.gcAch[a.id]) O.gcReportAchievement({id:a.id, percent:100}).then(()=>{ S.gcAch[a.id] = 1; persist(); }).catch(()=>{}); } },
  show(view, lb){ const O = onyxNative(); if(!O) return;
    if(!this.player){ O.gcSignIn().then(r=>{ this.player = r && r.authenticated ? r : null; if(this.player){ this.sync(true); O.gcShow({view, id:lb && GC_LB[lb]}).catch(()=>{}); } else toast("Sign in to Game Center in iOS Settings → Game Center to see leaderboards and achievements."); }).catch(()=>{}); return; }
    O.gcShow({view, id:lb && GC_LB[lb]}).catch(()=>{}); }
};
const Cloud = {
  on:false, timer:null, last:0, recheck:false,
  progress(s){ return Object.keys(s.cleared||{}).length*1000 + Object.keys((s.oath && s.oath.cl)||{}).length*1000 + ((s.stats && s.stats.wins)||0); },
  async init(){ const O = onyxNative(); if(!O) return;
    try{ const st = await O.cloudStatus(); this.on = !!(st && st.available); }catch(e){ this.on = false; }
    if(!this.on) return;
    try{ O.addListener("cloudChanged", ()=>this.check()); }catch(e){}
    await this.check(); },
  async check(){ const O = onyxNative(); if(!O || !this.on) return;
    if(run){ this.recheck = true; return; }
    let r; try{ r = await O.cloudGet({key:"save"}); }catch(e){ return; }
    if(!r || !r.value){ this.queue(true); return; }
    let c; try{ c = JSON.parse(r.value); }catch(e){ return; }
    if(!c || !c.d) return;
    if(c.dev===DEVICE_ID || c.t <= (S.savedAt||0) + 2000){ if(c.t < (S.savedAt||0)) this.queue(true); return; }   // ours, or older than what's here
    const mine = this.progress(S);
    if(mine <= 1000 && (c.p||0) > mine){ this.restore(c); return; }   // a fresh install: just bring the progress back
    if(c.t === this.offered) return; this.offered = c.t;
    openModal(`<div class="modal-title">A newer save in iCloud</div><div class="modal-sub">Saved on another device ${new Date(c.t).toLocaleString()}.</div>
      <div class="cloud-cmp"><div><small>iCloud</small><b>${art("might",18,"cur")} ${fmt(c.pw||0)}</b><span>${Math.floor((c.p||0)/1000)} levels cleared</span></div><div><small>This device</small><b>${art("might",18,"cur")} ${fmt(powerOf(heroStats(null)))}</b><span>${Math.floor(mine/1000)} levels cleared</span></div></div>
      <div class="mbtns row"><button class="btn" data-act="cloudKeep">Keep this device's</button><button class="btn gold" data-act="cloudUse">Use the iCloud save</button></div>`, {noClose:true});
    this.pendingSave = c; },
  restore(c){ try{ const o = JSON.parse(c.d); if(!o || typeof o!=="object") return; o.savedAt = c.t; keepOldSave(); localStorage.setItem(SAVE_KEY, JSON.stringify(o)); }catch(e){ return; } this.restoring = true; clearTimeout(this.timer); location.reload(); },
  queue(now){ if(!this.on) return; clearTimeout(this.timer); this.timer = setTimeout(()=>this.push(), now ? 50 : 12000); },
  async push(){ const O = onyxNative(); if(!O || !this.on) return; invGuard(); const d = JSON.stringify(S); if(d.length > 700000){ this.tooBig = true; return; } this.tooBig = false;
    try{ await O.cloudSet({key:"save", value:JSON.stringify({t:S.savedAt || Date.now(), dev:DEVICE_ID, p:this.progress(S), pw:powerOf(heroStats(null)), d})}); this.last = Date.now(); }catch(e){} }
};

/* =====================================================================
   VANGUARD COMMAND (Review 2, rules changed in Review 5)
   Speed x2 and x3, auto-pick and auto-cast are one perk, counted in battles.
   Act I: locked for everyone; beating the Outlaw King unlocks it (cmdOpen).
   After that: CMD_FREE battles a day, a video adds CMD_PER_AD (up to CMD_ADS a day), unlimited with Vanguard's Favor or
   the Commander's Seal. A battle only uses a charge if speed or an auto mode is actually used, and nothing is ever
   switched off mid-battle. x1, tapping abilities, potions and waiting skill picks are free for everyone, always.
   The owner asked for no free allowance at all; the review kept 3 a day so free players taste it daily. Set CMD_FREE to 0 to remove it.
===================================================================== */
const CMD_FREE = 3, CMD_PER_AD = 5, CMD_ADS = 4, ADS_DAY_CAP = 12;
function cmdDay(){ const k = todayKey(); if(S.command.date!==k) S.command = {date:k, used:0, bonus:0, ads:0}; return S.command; }
const cmdOpen = () => !!S.cleared["0-4"];
const cmdUnlimited = () => cmdOpen() && (favorActive() || !!S.removeAds);
const cmdCap = () => CMD_FREE + cmdDay().bonus;
const cmdLeft = () => !cmdOpen() ? 0 : cmdUnlimited() ? 999 : Math.max(0, cmdCap() - cmdDay().used);
/* called the first time a battle uses x2, x3, auto-pick or auto-cast */
function useCommand(R){ if(!R || !R.command) return false; if(R.cmdUsed) return true; R.cmdUsed = true; if(!cmdUnlimited()){ cmdDay().used++; persist(); } if(typeof updateCmdHud==="function") updateCmdHud(); return true; }
/* the ad budget: optional videos stop at ADS_DAY_CAP a day so nobody sits through fifteen (the revive is exempt) */
function adDay(){ const k = todayKey(); if(S.ads.date!==k) S.ads = {date:k, n:0}; return S.ads; }
const adsLeft = () => adFree() ? 99 : Math.max(0, ADS_DAY_CAP - adDay().n);
const cmdAdsLeft = () => Math.min(adsLeft(), CMD_ADS - cmdDay().ads);

/* =====================================================================
   REVIEW 2 — HEAT: a difficulty the player chooses
   Opens with the first boss. Each step: enemy HP and damage x1.2, +10% gold and orbs (up to +200%). Winning at a Heat
   unlocks higher ones, up to Heat 20 (HEAT in data.js). The best Heat is remembered per stage and shown on its map node.
   Review 3: the ceiling jumps after an easy win (HEAT_JUMP), and the prefight screen pre-selects the Heat the last
   result suggests (HEAT_UP), so a strong knight reaches a real fight in a few battles instead of twenty.
   S.heat.max is the highest Heat won (capes and titles); S.heat.cap is the highest Heat unlocked.
===================================================================== */
const heatOpen = () => !!S.cleared["0-4"];
const heatMax = () => heatOpen() ? Math.min(HEAT.max, Math.max((S.heat.max||0) + 1, S.heat.cap||0)) : 0;
/* The ceiling: health left at the win decides how far it opens (HEAT_JUMP: +3 over 80%, +2 over 60%, else +1).
   Review 5: every Heat step is now the same size (x1.2 health and x1.2 damage), so the jump is counted in steps only. */
const HEAT_JUMP = [[.8, 3], [.6, 2]], HEAT_DOWN = 1.5;
const heatHard = h => heatMul(h)*heatMul(h);                                              // enemy health x damage
const heatFor = hard => { let h = 0; while(heatHard(h + 1) <= hard*1.0001 && h < HEAT.max) h++; return (heatHard(h + 1) - hard < hard - heatHard(h)) ? h + 1 : h; };   // the Heat nearest to a hardness
const heatLower = h => Math.max(0, Math.min(h - 1, heatFor(heatHard(h)/HEAT_DOWN)));      // after a loss: about a third easier, at least one step
/* The pre-selected Heat: the highest one this knight's Power can carry on the level ahead. HEAT_EDGE is how far below the
   recommended power he may stand; it is learned per player (S.heat.edge): easy wins lower it, losses raise it, so everyone
   settles where about one battle in four or five is lost. A free newbie whose Power only just matches the level stays at Heat 0. */
const HEAT_EDGE = {start:.95, min:.5, max:1.05, easy:.05, loss:.08, close:.02};
const heatEdge = () => clamp(S.heat.edge || HEAT_EDGE.start, HEAT_EDGE.min, HEAT_EDGE.max);
function heatByPower(t, a, i){ const pw = powerOf(heroStats(null))*(1 + resolveFor(t, a, i)/100), rec = recPower(t, threatOf(1, a, i))*heatEdge(); let h = 0; while(h < HEAT.max && heatPower(rec, h + 1) <= pw) h++; return h; }
const heatKey = (t, a, i) => `${t}:${a}-${i}`;
const heatBest = (t, a, i) => S.heat.best[heatKey(t, a, i)] || 0;
/* a win only raises the Heat ceiling (and earns Heat capes) on levels within HEAT_NEAR threat of the furthest one cleared */
const HEAT_NEAR = 5;
const heatCounts = (t, a, i) => threatOf(t, a, i) >= maxClearedD() - HEAT_NEAR;
const heatTitle = () => { let t = ""; for(const m of HEAT_MILESTONES) if((S.heat.max||0) >= m.at) t = m.title; return t; };
function heatWon(R, rw){
  const h = R.heat||0, k = heatKey(R.cfg.tier||1, R.cfg.a, R.cfg.i), before = S.heat.max||0;
  if(h>0) S.heat.best[k] = Math.max(S.heat.best[k]||0, h);
  const front = heatCounts(R.cfg.tier||1, R.cfg.a, R.cfg.i);          // old ground can be replayed at any unlocked Heat, but only the frontier unlocks more
  const capWas = heatOpen() ? heatMax() : 0;
  if(front){ S.heat.max = Math.max(before, h); const j = HEAT_JUMP.find(r=>R.hpLeft > r[0]); S.heat.cap = Math.min(HEAT.max, Math.max(S.heat.cap||0, h + (j ? j[1] : 1)));
    // what the result says about this player: an easy first-try win lowers the edge, a narrow one raises it a little
    if(!(S.heat.lost > 0)){ if(R.hpLeft > .6) S.heat.edge = Math.max(HEAT_EDGE.min, heatEdge() - HEAT_EDGE.easy); else if(R.hpLeft < .25) S.heat.edge = Math.min(HEAT_EDGE.max, heatEdge() + HEAT_EDGE.close); } }
  S.heat.cur = h; S.heat.easy = R.hpLeft > .5; S.heat.lost = 0;
  const capNow = heatOpen() ? heatMax() : 0;
  if(capWas && capNow > capWas) rw.unlocks.push(capNow - capWas > 1 ? `A clean win: Heat ${capWas+1} to ${capNow} unlocked` : `Heat ${capNow} unlocked`);
  for(const m of HEAT_MILESTONES) if(front && h >= m.at && !S.capes.includes(m.cape)){ S.capes.push(m.cape); rw.unlocks.push(`Heat ${m.at}: the ${CAPES[m.cape].name} cape and the title “${m.title}”`); }
  if(front && h >= HEAT.max && before < HEAT.max) rw.unlocks.push(`Heat ${HEAT.max}: the summit of the ladder`);
}
/* called when a campaign battle is lost (not when the player gives up in the first seconds) */
function heatLost(R){ S.heat.easy = false; S.heat.lost = R.heat||0; if(!R.noResolve && heatCounts(R.cfg.tier||1, R.cfg.a, R.cfg.i)) S.heat.edge = Math.min(HEAT_EDGE.max, heatEdge() + HEAT_EDGE.loss); }
/* the Heat the game would pick for a level right now, whatever the player chose last time */
function heatTarget(t, a, i){ const byPow = Math.min(heatByPower(t, a, i), heatMax()); return S.heat.lost > 0 ? Math.min(heatLower(S.heat.lost), byPow) : byPow; }
/* what the prefight screen pre-selects for a level: the Heat the knight's Power can carry (never above the ceiling),
   and after a loss a step back down. S.heat.own: the player turned the last suggestion down, so his own choice stands. */
function heatSuggest(t, a, i){
  if(!heatOpen()) return {h:0};
  const cur = S.heat.cur||0, top = heatMax(), byPow = Math.min(heatByPower(t, a, i), top);
  if(S.heat.lost > 0){ const h = Math.min(heatLower(S.heat.lost), Math.max(byPow, 0)); return {h, why:"down", from:S.heat.lost}; }
  if(S.heat.own) return {h:Math.min(S.heat.sel!==undefined ? S.heat.sel : cur, top), hint:byPow};
  return {h:byPow, why:byPow > cur ? "up" : byPow < cur ? "ease" : "", from:cur};
}
const heatPower = (sp, h) => Math.round(sp*heatMul(h));

/* =====================================================================
   REVIEW 2 — STARTING OATHS: one unlocked perk chosen before a battle, so the 25th battle differs from the 5th
===================================================================== */
const OATHS = {
  sight:{name:"Oath of Sight", icon:"keen", text:"Your first skill offer shows 4 cards", how:"Defeat the Outlaw King", test:()=>!!S.cleared["0-4"]},
  chance:{name:"Oath of Chance", icon:"greed", text:"+1 free reroll every battle", how:"Defeat the Bone Lord", test:()=>!!S.cleared["1-4"]},
  embers:{name:"Oath of Embers", icon:"ember", tag:"fire", text:"Start with a random Fire card", how:"Defeat the Jarl of Winter", test:()=>!!S.cleared["2-4"]},
  storms:{name:"Oath of Storms", icon:"chain", tag:"storm", text:"Start with a random Storm card", how:"Defeat the Forge Tyrant", test:()=>!!S.cleared["3-4"]},
  blood:{name:"Oath of Blood", icon:"serrated", tag:"bleed", text:"Start with a random Bleed card", how:"Defeat the Void Herald", test:()=>!!S.cleared["4-4"]},
  steel:{name:"Oath of Steel", icon:"edge", tag:"blade", text:"Start with a random Blade card", how:"Win 10 Arena duels", test:()=>S.stats.duelWins>=10},
  wall:{name:"Oath of the Wall", icon:"ironskin", tag:"shield", text:"Start with a random Shield card", how:"Complete 4 challenges in the Trial Spire", test:()=>CHALLENGES.filter(c=>S.challenges[c.id]).length>=4},
  dawn:{name:"Oath of Dawn", icon:"light", tag:"holy", text:"Start with a random Holy card", how:"Bring down a raid boss", test:()=>S.raid.tier>=1}
};
const oathsOpen = () => Object.keys(OATHS).filter(k=>OATHS[k].test());
/* applied at the start of a campaign, challenge or trial battle */
function applyOath(R){
  const k = S.oathSel, O = OATHS[k]; if(!O || !O.test() || !["campaign","challenge","trial","endless","weekly"].includes(R.mode)) return;
  R.oath = k;
  if(k==="chance") R.rerolls++;
  if(O.tag && (!R.oneTag || R.oneTag===O.tag)){ const pool = CARDS.filter(c=>c.tag===O.tag && !CARD_NEEDS[c.id] && !S.bans.includes(c.id)); if(pool.length){ const c = pick(pool); R.cards[c.id] = 1; if(!R.tagSeq.includes(c.tag)) R.tagSeq.push(c.tag); R.st = heroStats(R); R.hero.hp = R.mods.lastBreath ? 1 : R.st.maxHp; if(c.id==="flask" && !R.mods.dry) R.potions++; } }
}

/* =====================================================================
   REVIEW 2 — TAG MASTERY: every win with a tag at synergy III counts; milestones pay gems once
===================================================================== */
const MASTERY_AT = [5, 10, 20], MASTERY_GEMS = [15, 30, 60];
function masteryWon(R, rw){
  for(const t of SYN_TAGS) if(tagCount(t, R) >= 3){ const n = S.mastery[t] = (S.mastery[t]||0) + 1; const k = MASTERY_AT.indexOf(n);
    if(k>=0){ rw.gems += MASTERY_GEMS[k]; rw.unlocks.push(`${TAGS[t].name} mastery ${["I","II","III"][k]}: ${n} wins with ${TAGS[t].name} III`); } }
}
const masteryRank = t => MASTERY_AT.filter(n=>(S.mastery[t]||0) >= n).length;

/* =====================================================================
   REVIEW 2 — WEEKEND EVENTS (Saturday and Sunday, after Act I), rotating weekly
===================================================================== */
const WEEKENDS = [
  {id:"treasure", name:"Treasure weekend", icon:"treasury", text:"Twice as many treasures appear on the map after every battle."},
  {id:"horde", name:"Horde weekend", icon:"horde", text:"Turn on the Horde before a battle: +2 enemies in every pack, double gold and orbs."},
  {id:"rush", name:"Boss rush weekend", icon:"skull", text:"Fight the bosses you have beaten back to back. How many can you bring down?"}
];
function weekendEvent(){
  if(!S.cleared["0-4"]) return null; const d = new Date(), wd = d.getDay(); if(wd!==6 && wd!==0) return null;
  const n = Math.floor((d.getTime() - d.getTimezoneOffset()*6e4)/864e5);       // local day number; Saturday and Sunday share a week index
  return WEEKENDS[((Math.floor((n - 2)/7) % WEEKENDS.length) + WEEKENDS.length) % WEEKENDS.length];
}
const RUSH_CHEST = 3;       // bosses in one run for the weekend chest
/* ---------- THE VANGUARD'S TRIAL (weekly; the ladder itself is built in engine.js) ---------- */
/* this week's record and today's attempts; a new week clears the record and the goals, a new day refills the attempts */
function weeklyState(){ const U = S.weekly, wk = weekKey(), k = todayKey();
  if(U.week!==wk){ U.week = wk; U.best = 0; U.got = []; U.runs = 0; } if(!Array.isArray(U.got)) U.got = [];
  if(U.day!==k){ U.day = k; U.used = 0; } return U; }
const weeklyLeft = () => Math.max(0, WEEKLY.tries - (weeklyState().used||0));
const weeklyOpen = () => !!S.cleared["0-4"];
/* the board shown in the game: knights of the realm, computer-controlled and said to be so. Their rungs are fixed for the week,
   so they are a target that does not move. Real ranks are on Game Center. */
function weeklyGhosts(){ const wk = weekKey(); return RIVAL_NAMES.map((n,i)=>{ const h = hashStr("wk" + wk + n); return {name:`${n} ${RIVAL_TITLES[h % RIVAL_TITLES.length]}`, v:4 + (h % 1000)/1000*34 | 0}; }); }
function startWeekly(){ if(!weeklyOpen() || weeklyLeft()<=0) return; const U = weeklyState(); U.used++; persist(); closeAllModals(); const spec = weeklySpec(); startRun({mode:"weekly", spec, mods:Object.assign({}, spec.mods)}); }
const msToMonday = () => { const d = new Date(), m = new Date(d); m.setHours(24,0,0,0); while(m.getDay()!==1) m.setDate(m.getDate()+1); const s = Math.floor((m - d)/1000), dd = Math.floor(s/86400), hh = Math.floor(s%86400/3600); return dd>0 ? `${dd}d ${hh}h` : `${hh}h ${Math.floor(s%3600/60)}m`; };
function openRush(){
  const we = weekendEvent(), on = !!(we && we.id==="rush"), U = S.rush, got = U.week===weekKey() && U.chest, L = rushLadder();
  const html = `<div class="mode-head banner tall" style="background-image:url(img/foe_${ACTS[L[0].a].boss}.jpg)">${art("skull",54)}<div><div class="modal-title">Boss rush</div><div class="modal-sub">Every boss you have beaten, back to back, each stronger than the last. You start with three skills; a spring waits between fights. No revives.</div></div></div>
    <div class="modal-body">
      <div class="rush-row">${L.slice(0, Math.min(5, new Set(L.map(b=>b.a)).size)).map(b=>`<span class="etile boss"><img src="${enemyPortrait(ACTS[b.a].boss)}" alt=""><div>${ENEMY[ACTS[b.a].boss].name}</div></span>`).join("")}</div>
      <div class="raid-goal ${got?'done':''}">${art("knightchest",36)}<div class="grow"><b>Weekend chest: bring down ${RUSH_CHEST} bosses in one run</b><div class="mute" style="font-size:12px">Your best: ${U.best||0} boss${U.best===1?"":"es"}. Every boss pays gold and orbs.</div></div>${got ? `<span class="done-badge sm">${ico("check",16)}</span>` : rchips({gems:25, star:1}, 20)}</div>
    </div>
    <div class="mbtns row">${GameCenter.player?`<button class="btn ghost" data-act="gcBoard" data-lb="rush">${art("trophy",20)} Leaderboard</button>`:""}<button class="btn gold big" data-act="rushGo" ${on?'':'disabled'}>${art("skull",22)} ${on ? "Start the rush" : "Back next rush weekend"}</button></div>`;
  closeAllModals(); openModal(html, {wide:true});
}
const weekKey = () => { const d = new Date(), n = Math.floor((d.getTime() - d.getTimezoneOffset()*6e4)/864e5); return "w" + Math.floor((n + 3)/7); };   // weeks run Monday to Sunday

/* =====================================================================
   REVIEW 2 — INVENTORY GUARD + AUTO-SALVAGE
   The iCloud key-value store holds 1 MB in total, so the bag is capped; the weakest spare items are salvaged
   past the cap. Auto-salvage (Hero → Inventory) clears spare Common / Rare drops after each battle.
===================================================================== */
const INV_CAP = 300;
const spareItem = it => !isEquipped(it) && !it.upg && it.r<5 && !(it.sock||[]).some(Boolean) && !S.loadouts.some(L=>L && Object.values(L.equip||{}).includes(it.uid));
function salvageMany(list){ let g = 0, du = 0; for(const it of list){ g += salvageValue(it); du += salvageDust(it); } const ids = new Set(list.map(i=>i.uid)); S.inv = S.inv.filter(i=>!ids.has(i.uid)); S.gold += g; S.dust += du; return {n:list.length, gold:g, dust:du}; }
function invGuard(){
  if(S.inv.length <= INV_CAP) return null;
  const spare = S.inv.filter(spareItem).sort((a,b)=>a.r-b.r || a.il-b.il).slice(0, S.inv.length - INV_CAP);
  if(!spare.length) return null; const r = salvageMany(spare); setTimeout(()=>toast(`Your bag was full: ${r.n} old item${r.n>1?"s":""} salvaged for ${fmt(r.gold)} gold.`, "#d0ab62"), 300); return r;
}
/* run after a battle (never during one, so a fresh drop can still be equipped from the victory screen) */
function autoSalvage(keepUid){
  const A = S.autoSalv; if(!A.c && !A.r) return null;
  const list = S.inv.filter(it=>it.uid!==keepUid && spareItem(it) && !it.set && ((A.c && it.r===0) || (A.r && it.r===1)) && !isUpgrade(it));
  return list.length ? salvageMany(list) : null;
}

/* =====================================================================
   REVIEW 2 — RETURN REWARD, STREAKS, RAID GOAL, ARENA WEEKLY CHEST
===================================================================== */
/* a player away for 3 days or more gets a chest scaled to the days away (the treasury only covers 12 hours) */
function returnReward(){
  const now = Date.now(), last = S.seenAt || 0; S.seenAt = now;
  if(!last || !S.cleared["0-0"]) return null; const days = Math.floor((now - last)/864e5); if(days < 3) return null;
  const n = Math.min(7, days), f = Math.max(1, maxClearedD());
  return {days, bundle:{gold:Math.round(n*(120 + 30*f)), orbs:n*3, gems:n*10}};
}
/* a broken login streak can be restored once a week (30 gems or a video) */
const STREAK_FIX_GEMS = 30, STREAK_BONUS_GEMS = 50;
function yesterdayKey(){ const y = new Date(); y.setDate(y.getDate()-1); return y.getFullYear()+"-"+(y.getMonth()+1)+"-"+y.getDate(); }
/* Review 5: one missed day a week is forgiven without asking, so an irregular week does not cost a streak */
const streakGrace = () => S.login.streak >= 1 && daysSince(S.login.last) === 2 && S.grace !== weekKey();
const streakBroken = () => loginReady() && S.login.streak >= 2 && S.login.last !== yesterdayKey() && !S.login.fixed && !streakGrace();
function daysSince(key){ const p = String(key||"").split("-").map(Number); if(p.length!==3 || !p[0]) return 999; const d = new Date(p[0], p[1]-1, p[2]), n = new Date(); n.setHours(0,0,0,0); return Math.round((n - d)/864e5); }
const streakFixable = () => streakBroken() && S.streakFix !== weekKey() && daysSince(S.login.last) <= 4;       // up to three missed days
function fixStreak(){ if(!streakFixable()) return false; S.streakFix = weekKey(); S.login.fixed = true; persist(); return true; }
/* raid: a gentle daily goal so a 40-second attempt has a purpose */
const raidGoal = () => Math.max(400, Math.round(Math.max(S.raid.best||0, raidMaxHp(S.raid.tier)*.06)*1.4/50)*50);
/* arena: one chest a week, richer in higher leagues */
function arenaChest(){ const L = LEAGUES.indexOf(leagueOf(S.arena.trophies)); return {gems:[10,20,35,50,80][L]||10, orbs:[8,12,18,26,36][L]||8, gold:Math.round((200 + 60*Math.max(1, maxClearedD()))*(1 + L*.4))}; }
const arenaChestReady = () => S.arena.week !== weekKey() && S.stats.duels > 0;

/* =====================================================================
   REVIEW 2 — TIMED OFFERS: real 48-hour windows with something the shop never sells
===================================================================== */
const OFFER_HOURS = 48;
const TIMED = {
  boss:{k:"vanguard", head:"You beat the Outlaw King!", cape:"outlaw", bonus:{gems:400}, sub:"His crown is yours to wear, with 400 extra gems. For 48 hours only."},
  arena:{k:"arenapack", head:"Enter the Arena in style", bonus:{gems:200}, sub:"Ten tickets, the Duelist's Mantle and 200 extra gems for the next 48 hours."}
};
function offerLive(why){ const o = S.offers[why]; return !!o && !o.bought && o.until > Date.now(); }
function offerLeft(why){ const ms = Math.max(0, (S.offers[why]||{}).until - Date.now()), h = Math.floor(ms/3.6e6), m = Math.floor(ms%3.6e6/6e4); return h>=1 ? `${h}h ${m}m` : `${m}m`; }
function liveOffers(){ return Object.keys(TIMED).filter(offerLive); }

/* bring an older save up to date (called once at boot, after every script has loaded) */
function migrateSave(){
  if((S.v||1) < SAVE_V) keepOldSave();                         // the save as it was, in case this version has to be rolled back
  if((S.v||1) < 2){
    for(const it of S.inv) if(it.r>=2 && it.r<5 && !it.perk) it.perk = pick(PERK_KEYS);     // Epic and better gear now carries a build-shaping line
    for(const o of (S.daily.offers||[])) if(o.item && o.item.r>=2 && o.item.r<5 && !o.item.perk) o.item.perk = pick(PERK_KEYS);
    if(S.removeAds===undefined) S.removeAds = false;
    S.v = 2; persist();
  }
  if((S.v||1) < 3){
    /* Review 5. Heat was +20% a step with no top; it is now x1.2 a step up to Heat 20. An old Heat keeps its difficulty:
       it becomes the new Heat that is as hard. Capes already earned stay. */
    const conv = h => { h = +h||0; if(h<=0) return 0; return clamp(Math.round(Math.log(1 + .2*h)/Math.log(HEAT.step)), 1, HEAT.max); };
    const H = S.heat; H.max = conv(H.max); H.cap = conv(H.cap); H.cur = conv(H.cur); H.lost = conv(H.lost); if(H.sel!==undefined) H.sel = conv(H.sel);
    for(const k in H.best) H.best[k] = conv(H.best[k]);
    if(S.autoCast){ for(const t of SYN_TAGS) S.autoAb[t] = 1; } delete S.autoCast;      // one Auto switch became one per ability
    if(!cmdOpen()){ S.lastSpeed = 1; S.autoPick = false; }                                // Act I: speed and auto modes are locked
    S.v = 3; persist();
  }
  if(!S.tips.trained && Object.values(S.meta).some(v=>v>0)){ S.tips.trained = 1; }       // the free first training rank is for new knights
}
/* A battle cut short because iOS closed the app: what was looted is kept and the ticket or key comes back.
   The checkpoint is written whenever the app goes to the background and cleared when the battle ends normally. */
function checkpointRun(){ const R = run; if(!R || R.over){ return; } S.pendingRun = {mode:R.mode, gold:Math.round(R.gold||0), cmd:!!R.cmdUsed && !cmdUnlimited(), day:todayKey()}; }
function recoverRun(){
  const P = S.pendingRun; if(!P) return null; S.pendingRun = null;
  const back = []; if(P.gold > 0){ S.gold += P.gold; back.push(`${fmt(P.gold)} gold`); }
  if(P.mode==="arena"){ S.arena.tickets++; back.push("your Arena ticket"); } else if(P.mode==="raid"){ S.raid.keys++; back.push("your raid key"); }
  else if(P.mode==="weekly" && P.day===todayKey() && S.weekly.day===P.day && S.weekly.used>0){ S.weekly.used--; back.push("your trial attempt"); }
  if(P.cmd && P.day===todayKey() && S.command.date===P.day && S.command.used>0){ S.command.used--; back.push("a Command battle"); }
  persist(); return back.length ? `Your last battle was interrupted. Returned: ${back.join(", ")}.` : null;
}
const knightName = () => S.name || "The Vanguard";
